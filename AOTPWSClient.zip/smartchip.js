/**
 * 
 */

//alert("HIII m in SAMRTCHIP");
document.write('<applet width="1" height="1" archive="AuthenticationCapture.jar" code="online.auth.AuthenticationApplet" id="app1" name="app1"> </applet>');





function getBiomFinger(buttonId)

{
	
	alert("Click on finger tip to scan");
	
	var button=buttonId;
		var data;
		var testTag = document.getElementById('app1');
		var val = testTag.captureFinger(buttonId);
		//document.getElementById('finger'+buttonId).value = val;
		
		if(val == "CONNECT_DEVICE_ERROR"){
		alert("Device Not Connected");
		}
		else
		if(val == "LIBRARY_MISSING_ERROR"){
		alert("Setup Not Installed Properly");
		}
		else
		if(val == "CAPTURE_TIMEOUT_ERROR"){
		alert("Device Not Able to Capture Finger Prints. Try Again.");
		}else
		if(val == "DUPLICATE_FINGER_ERROR"){
		alert("Current finger is already captured at some other finger index.");
		}else
		if(val == "INTERNAL_ERROR"){
		alert("Device Internal Error");
		}else{
			
			if(val != null || val.length()!=0 )
				{
			
			document.getElementById('fingerPrint').value = val;
			//document.getElementById('fingerNumber').value = buttonId;
			//alert(document.getElementById('type').value);
			//alert(document.getElementById('fingerPrint').value);
			//alert(temp);
			alert("Finger Print Captured");
			
		
			switch(button)
			{
			case 1: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "RIGHT_THUMB";
					break;
			case 2: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "RIGHT_INDEX";
					break;	
			case 3: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "RIGHT_MIDDLE";
					break;
			case 4: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "RIGHT_RING";
					break;
			case 5: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "RIGHT_LITTLE";
					break;
			case 6: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "LEFT_THUMB";
					break;
			case 7: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "LEFT_INDEX";
					break;
			case 8: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "LEFT_MIDDLE";
					break;
			case 9: $(document).ready(function(){ $("a").attr('onclick', '""'); });
					document.getElementById('fingerPosition').value = "LEFT_RING";
					break;
			case 10:$(document).ready(function(){ $("a").attr('onclick', '""');  });
					document.getElementById('fingerPosition').value = "LEFT_LITTLE";
					break;
			
			
			}
			//alert(document.getElementById('fingerPosition').value);
			
			$( document ).ready(function() { 	
				$(".handdiv ."+button).html("<img src=\"ekyc/image/check.jpg\"></img>");

				});
				
				}
			else
				{
							alert("Finger print not captured");
				}
			
			
		}
}











function getBFDFinger(buttonId)

{
	
	alert("Click on finger tip to scan");
	
		var button=buttonId;
		
		var testTag = document.getElementById('app1');
		var val = testTag.captureFinger(buttonId);
		var finger="";
		//document.getElementById('finger'+buttonId).value = val;
		
		if(val == "CONNECT_DEVICE_ERROR"){
		alert("Device Not Connected");
		}
		else
		if(val == "LIBRARY_MISSING_ERROR"){
		alert("Setup Not Installed Properly");
		}
		else
		if(val == "CAPTURE_TIMEOUT_ERROR"){
		alert("Device Not Able to Capture Finger Prints. Try Again.");
		}else
		if(val == "DUPLICATE_FINGER_ERROR"){
		alert("Current finger is already captured at some other finger index.");
		}else
		if(val == "INTERNAL_ERROR"){
		alert("Device Internal Error");
		}else{
			
			
			
			if(val != null || val.length()!=0 )
				{
				//alert('Response Code '+val[0]);
				//alert('NFIQ: '+val[1]);
				document.getElementById('bfdnfiq').value = document.getElementById('bfdnfiq').value+val.substring(0,1)+"^";
					finger= finger+val.substring(2);
			
				
			//alert("hello");
			document.getElementById('bfdfingerPrint').value = document.getElementById('bfdfingerPrint').value+finger+"^";
			//alert(document.getElementById('bfdnfiq').value);
			
			//document.getElementById('fingerNumber').value = buttonId;
			//alert(document.getElementById('type').value);
			//alert(document.getElementById('fingerPrint').value);
			//alert(temp);
			
			alert("Finger print captured");
			
		
			switch(button)
			{
			case 1: $(document).ready(function(){ $(".1").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"RIGHT_THUMB^";
					break;
			case 2: $(document).ready(function(){ $(".2").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"RIGHT_INDEX^";
					break;	
			case 3: $(document).ready(function(){ $(".3").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value =document.getElementById('bfdfingerPosition').value+ "RIGHT_MIDDLE^";
					break;
			case 4: $(document).ready(function(){ $(".4").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"RIGHT_RING^";
					break;
			case 5: $(document).ready(function(){ $(".5").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value =document.getElementById('bfdfingerPosition').value+ "RIGHT_LITTLE^";
					break;
			case 6: $(document).ready(function(){ $(".6").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"LEFT_THUMB^";
					break;
			case 7: $(document).ready(function(){ $(".7").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"LEFT_INDEX^";
					break;
			case 8: $(document).ready(function(){ $(".8").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"LEFT_MIDDLE^";
					break;
			case 9: $(document).ready(function(){ $(".9").attr('onclick', '""'); });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"LEFT_RING^";
					break;
			case 10:$(document).ready(function(){ $(".10").attr('onclick', '""');  });
					document.getElementById('bfdfingerPosition').value = document.getElementById('bfdfingerPosition').value+"LEFT_LITTLE^";
					break;
			
			
			}
			//alert(document.getElementById('fingerPosition').value);
			//alert(document.getElementById('bfdfingerPrint').value);
			
			$( document ).ready(function() { 	
				$(".handdiv ."+button).html("<img src=\"ekyc/image/check.jpg\"></img>");

				});
				
				}
			else
				{
							alert("Finger print not captured");
				}
			
			
		}
}




