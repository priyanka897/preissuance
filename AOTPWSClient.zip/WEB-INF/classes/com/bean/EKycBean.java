package com.bean;

public class EKycBean {
	private String uid;
	private String encSession;
	private String Session;
	private String encHmac;
	private String pidXML;
	private String certExpiryDate;
	private String fingpos;
	private String name;
	private String year;
	private String gender;
	private String otp;
	private String rc;
	private String mec;
	private String lr;
	private String ts;
	
	
	
	// added parameter for MORPHO by latish - Start
	
	private String fingerprint;
	private String fingerPosition;
	private String bfdnfiq;
	private String bfdfingerprint;
	private String bfdfingerPosition;
	
	

	
	
	public String getBfdfingerprint() {
		return bfdfingerprint;
	}
	public void setBfdfingerprint(String bfdfingerprint) {
		this.bfdfingerprint = bfdfingerprint;
	}
	public String getBfdfingerPosition() {
		return bfdfingerPosition;
	}
	public void setBfdfingerPosition(String bfdfingerPosition) {
		this.bfdfingerPosition = bfdfingerPosition;
	}
	public String getFingerprint() {
		return fingerprint;
	}
	public void setFingerprint(String fingerprint) {
		this.fingerprint = fingerprint;
	}
	public String getFingerposition() {
		return fingerPosition;
	}
	public void setFingerposition(String fingerPosition) {
		this.fingerPosition = fingerPosition;
	}
	public String getBfdNfiq() {
		return bfdnfiq;
	}
	public void setBfdNfiq(String bfdnfiq) {
		this.bfdnfiq = bfdnfiq;
	}
	
	
	// added parameter for MORPHO by latish - End
	
	public String getRc() {
		return rc;
	}
	public void setRc(String rc) {
		this.rc = rc;
	}
	public String getMec() {
		return mec;
	}
	public void setMec(String mec) {
		this.mec = mec;
	}
	public String getLr() {
		return lr;
	}
	public void setLr(String lr) {
		this.lr = lr;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getEncSession() {
		return encSession;
	}
	public void setEncSession(String encSession) {
		this.encSession = encSession;
	}
	public String getSession() {
		return Session;
	}
	public void setSession(String session) {
		Session = session;
	}
	public String getEncHmac() {
		return encHmac;
	}
	public void setEncHmac(String encHmac) {
		this.encHmac = encHmac;
	}
	public String getPidXML() {
		return pidXML;
	}
	public void setPidXML(String pidXML) {
		this.pidXML = pidXML;
	}
	public String getCertExpiryDate() {
		return certExpiryDate;
	}
	public void setCertExpiryDate(String certExpiryDate) {
		this.certExpiryDate = certExpiryDate;
	}
	public String getFingpos() {
		return fingpos;
	}
	public void setFingpos(String fingpos) {
		this.fingpos = fingpos;
	}
	public String getTs() {
		return ts;
	}
	public void setTs(String ts) {
		this.ts = ts;
	}
	
	
}
