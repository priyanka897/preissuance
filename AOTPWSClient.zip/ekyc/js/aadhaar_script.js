/**
 * 
 */

$( document ).ready(function() { 
		
		$("a.10").click(function()
		{
			$(this).css("background");
		}
		);
		
	}); 