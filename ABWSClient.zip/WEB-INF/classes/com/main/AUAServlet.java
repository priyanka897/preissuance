package com.main;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.EKycBean;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebServiceCallLocator;
import com.qualtech.webservice.AadhaarVerification.AadhaarWebServiceSoapBindingStub;
import com.util.EKYCProperties;
import org.apache.commons.codec.binary.Base64; 
import org.json.JSONObject;

/**
 * Servlet implementation class AUAServlet
 */
public class AUAServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AUAServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//String propFilePath="/opt/tomcat/webapps/TIN/WEB-INF/classes/kua.properties";
		//EKYCProperties.load("D:\\EKYC_Final_Wrkspaces\\dev_workspace\\KUAWEB\\kua.properties");
		
		//// Log.kua.info("In get");
		
		String strTxn = request.getParameter("txn");
		String strUid = request.getParameter("uid");
		if(strTxn.contains("/"))
		{
			//// Log.kua.info("Invalid filename"+strTxn);
			response.getWriter().println("<h3 style='text-align:center;'>Invalid file name.</h3>");
		}else if (strTxn!=null && !strTxn.equalsIgnoreCase(""))
			{
				String fileName =  strTxn.replace(":", "_")+".xml";
				fileName = strUid + "_" + fileName; 
				File f = new File(fileName);
				//// Log.kua.info("Filename"+f.getAbsolutePath()+" :"+f.exists());
				if(f.exists())
				{
	            response.setContentType("application/xml");
	            response.setContentLength((int)f.length());
	            response.setHeader("Content-Disposition", "attachment; filename=\""+fileName+"\"");
	            
	            ServletOutputStream sout = response.getOutputStream();

	            DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f)));

	            long i = (int)f.length();

	            for (; i > 0L; i -= 1L) {
	              sout.write(in.read());
	            }
	            in.close();
	            sout.flush();
	            sout.close();
	           // // Log.kua.info(fileName+" File Download Completed");
				}
				else
				{
					//// Log.kua.info(fileName+" File not available");
					response.getWriter().println("<h3 style='text-align:center;'>File not available</h3>");
				}
			}
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	System.out.println("camr in");
	String resCode  ="";
	String resMsg  ="";
	AadhaarVerificationServiceResponse resp=null;
	
		//String propFilePath="/opt/tomcat/webapps/TIN/WEB-INF/classes/com/tin/ekyc/kua/components/kua.properties";
		//EKYCProperties.load("D:\\EKYC_Final_Wrkspaces\\dev_workspace\\KUAWEB\\kua.properties");
		/*// Log.kua.info(EKYCProperties.getProxyIP());
		// Log.kua.info(EKYCProperties.getProxyPortNumber());
		
		// Log.kua.info("PROXY IP :"+System.getProperty("http.proxyHost"));
		// Log.kua.info("PROXY Port :"+System.getProperty("http.proxyPort"));
		
		// Log.kua.info("PROXY IP https :"+System.getProperty("https.proxyHost"));
		// Log.kua.info("PROXY Port https :"+System.getProperty("https.proxyPort"));*/
		EKycBean bean = new EKycBean();
		String isOtpReq = request.getParameter("isOtp");
		
		if(isOtpReq != null)
		{

			if(isOtpReq.equalsIgnoreCase("Y"))
			{
				String uid=request.getParameter("uid");
				if(uid==null)
				{
					response.getWriter().println("Please enter Aadhaar number");
				}
				else if (uid.length()!=12) {
					response.getWriter().println("Invalid Aadhaar number");
				}
				else				
				{				
					//KUA k =new KUA();	
					//String resp=k.sendOTPRequest(uid);
					//response.getWriter().println(resp);
				}
					
			}
			else
			{
				response.getWriter().println("Invalid OTP Generation Request");
			}
		}else
		{
			
			String uid = request.getParameter("uid");
			String policyNo = request.getParameter("policyNo");
			String encSession = request.getParameter("encSession");
			String Session = request.getParameter("Session");
			String encHmac = request.getParameter("encHmac");
			String pidXML = request.getParameter("pidXML");
			String certExpiryDate = request.getParameter("certExpiryDate");
			String fingpos = request.getParameter("fingpos");
			String name = request.getParameter("name");
			String year = request.getParameter("year");
			String gender = request.getParameter("gender");
			String otp = request.getParameter("otp");
			String lr = request.getParameter("lr");
			String mec = request.getParameter("mec");
			String rc = request.getParameter("rc");
		//	System.out.println("rc is---"+rc);
		//	System.out.println("mec is ---"+mec);
		
			// added by latish to set timestamp paramter
			
			String timestamp = request.getParameter("timestamp");
			
			System.out.println(timestamp);
			
			String fingerprint=null;
			String fingerPosition=null;
			String nfiq=null;
			
			
			
		//	System.out.println("HELLO"+request.getParameter("fingerPrint"));
			// added parameter for MORPHO by latish - Start
			if(request.getParameter("fingerPrint")!=null && request.getParameter("fingerPrint").length()!=0)
			{
			fingerprint=(request.getParameter("fingerPrint")).substring(2);
			}
			
			if(request.getParameter("fingerPosition")!=null && request.getParameter("fingerPosition").length()!=0)
			{
			fingerPosition=request.getParameter("fingerPosition");
			}
			
			if(request.getParameter("fingerPrint")!=null && request.getParameter("fingerPrint").length()!=0)
			{
			nfiq=(request.getParameter("fingerPrint")).substring(0,1);
			}
			
			
			
			
			// added parameter for MORPHO by latish - End
	
			/*// Log.kua.info("uid :"+uid);
			// Log.kua.info("encSession :"+encSession);
			// Log.kua.info("Session :"+Session);
			// Log.kua.info("encHmac :"+encHmac);
			//// Log.kua.info("pidXML :"+pidXML);
			// Log.kua.info("certExpiryDate :"+certExpiryDate);
			// Log.kua.info("fingpos :"+fingpos);
			// Log.kua.info("name :"+name);
			// Log.kua.info("year :"+year);
			// Log.kua.info("gender :"+gender);
			// Log.kua.info("otp :"+otp);
			// Log.kua.info("lr :"+lr);
			// Log.kua.info("mec :"+mec);
			// Log.kua.info("rc :"+rc);
			// Log.kua.info("timestamp :"+timestamp);
			// Log.kua.info("bfdfingerPosition");*/
			if(uid==null)
				uid="";
			if(encSession==null)
				encSession="";
			if(Session==null)
				Session="";
			if(encHmac==null)
				encHmac="";
			if(pidXML==null)
				pidXML="";
			if(certExpiryDate==null)
				certExpiryDate="";
			if(fingpos==null)
				fingpos="";
			if(name==null)
				name="";
			if(year==null)
				year="";
			if(gender==null)
				gender="";
			if(otp==null)
				otp="";
			
			// added parameter for MORPHO by latish - Start
			
			
			if(fingerPosition==null)
				fingerPosition="";
			if(fingerprint==null)
					fingerprint="";
			if(nfiq==null)
				nfiq="";
			
			
			// added parameter for MORPHO by latish - End
			
			
			bean.setUid(uid);
			bean.setEncSession(encSession);
			bean.setSession(Session);
			bean.setEncHmac(encHmac);
			bean.setPidXML(pidXML);
			bean.setCertExpiryDate(certExpiryDate);
			bean.setFingpos(fingpos);
			bean.setName(name);
			bean.setYear(year);
			bean.setGender(gender);
			bean.setOtp(otp);
			bean.setRc(rc);
			bean.setMec(mec);
			bean.setLr(lr);
			bean.setTs(timestamp);
		
			
			
			// added parameter for MORPHO by latish - Start
			
			bean.setFingerposition(fingerPosition);
			bean.setFingerprint(fingerprint);
			//bean.setNfiq(nfiq);
			
			for(int i=0;i<1;i++)
			{
				String[] resArr = new String[2];
				
				AadhaarVerificationWebServiceCallLocator docLocator;
				AadhaarWebServiceSoapBindingStub myService;
				try 
				{
					docLocator = new AadhaarVerificationWebServiceCallLocator();
					myService = new AadhaarWebServiceSoapBindingStub();			
					myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://localhost:8080/AadhaarBiometricKUAWebSerice/services/AadhaarVerificationWebService"));
				    //myService = (AadhaarWebServiceSoapBindingStub)docLocator.getAadhaarVerificationWebService(new java.net.URL("http://ekyc.maxlifeinsurance.com/AadhaarBiometricKUAWebSerice/services/AadhaarVerificationWebService"));
					   
				    
				   /* System.out.println("UID "+bean.getUid());
				    System.out.println("fingerPrint "+bean.getFingerprint());
				    System.out.println("fingerPost "+bean.getFingerposition());*/
				  
				    resp=myService.saveAadhaarVerificationInformation(					
							//new AadhaarVerificationServiceRequest("A",bean.getUid(),"QC","dypnU7milCCtWzrnBcXWgA==","00","",
								//	"","","","123456","","M",bean.getFingerprint(),bean.getFingerposition(),bean.getLr(),bean.getMec(),bean.getRc(),null,null,null,null,null));
				    		new AadhaarVerificationServiceRequest(
				    				   "A",
				    		           bean.getUid(),
				    		           "QC",
				    		           "dypnU7milCCtWzrnBcXWgA==",
				    		           "00",
				    		           "",
				    		           null,
				    		           null,
				    		           null,
				    		           policyNo,
				    		           "",
				    		           "M",
				    		           "K",
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           null,
				    		           bean.getFingerprint(),
				    		           bean.getFingerposition(),
				    		           null,
				    		           null,
				    		           null
				    		           ));
					
				    
				    
				    
				    
				    
				    
				    
				    //AadhaarVerificationServiceResponse response=myService.saveAadhaarVerificationInformation(	
					//new AadhaarVerificationServiceRequest("A","423995958384","QC","p@ssw0rd","00","150574","","","","","","N",null,null,null,null,null));
						
					// Ravi  423995958384 ---- 999905987814   02-07-1974
					// Rakesh 999929989823   01-01-1985        
					// Mohit Single 638808139048    999928949401      22-11-1989
					//Amit 849889269350
					//Umesh 475332454990
					System.out.println("reportXML---for response Status >"+resp.getOutputStatus());
					System.out.println("reportXML---for response Message >"+resp.getOutputMessage());
			        
					//System.out.println("getCustomerName >"+resp.getCustomerName());
					//System.out.println("getCustomerDOB >"+resp.getCustomerDOB());
					//System.out.println("getCustomerGender >"+resp.getCustomerGender());
					//System.out.println("getCustomerAddress >"+resp.getCustomerAddress());
					//System.out.println("Phone >"+resp.getOutputParam1());
					//System.out.println("Email >"+resp.getOutputParam2());
					resp.setKycData(Base64.decodeBase64("/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCADIAKADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDst4pwcVBkUZrmGWw9KGquG9aUPQBZ3A0tQBhTg+BTAkAzzSlcCq9xfW9lbtPdTxwxL953YAD8a858TfE0hvJ0KTjHzTtH/IMP5imlcR6aCB1qJ9Qs432PdQq/XaZAD/Ovn++8U61qTbrm/mfthW2r+QwKyfPfoQQPrVcoH0st9BI4CSq5PQIc/wAqm89W4B5r5mWRmBBYY9DyK6HR/Fmq6bIu25d4x1jcllI/Hp+GKfKB7szcE1Fmue0HxVZ62piB8u5xu8s9x3we9b4PvUtATxnLVej6VRiySMVfjGFpAI5xUWakkqE9etAEyVLnA5qCMjNS7+OgpAc9mlBzUeaUNSKJgaAaj3cUbqAJg1BkCqSTwBkk1DvNcD8Q/EjWtuNLt3KmUbpmBwdvZfx7+31ppXEYHjXxW+tXz2ts5FjE2FOPvnu30Pb8/Yca0y7jtBHvUckzOck0wnjPOa1SsBKHb1oLkrjJ4qEMc5A4p4OeRwaoCVJQfwq3FMduQPyrOQ4YnH5VMsjqcgcGkBt6fqg0nUre/jQvJESQu4gElSOfzz+FdZZ/Ee+kGJ7aDdjGU3DH4Z/z+tecSyllGeoNSQ3OG5pWA+jdF1ODUrdZrdwyEZGDnjp/PNdCijZzXhfgPX/7N1qFXJNtO3ltz90no2PrgfT6V7smWgVk5yMj3qGhFeUkDgE/SoC1TysR2A+lQ7CeSaQySKnt0pIk+apWjzSA5Yt70oaoyaTdUlEpajfUe6ml6YCXl7FZWc1zM22KJC7H2ArwPWb6XUdQnupm+aRy3XOM9h7DpXqvjyVl8My4OFMiAj15z/MCvG7hiZOtaQJY0ZYgDOauw2MspAGMVDYxmRicZOa6fT7RjjIqKlXl2N6VJS3M1NCkI+/+lW4fDgxl2Jrq7ayUr0q8tmO4rmdab6nQqMF0OQTw7CB901etvDMZXLYA9K6cQLj7ozU8Vo5OQDUqpLqyvZx7HDX3htcts9MjFctc2r207IR0Nevz2TYyy1w/ibSXh/0lVJX+LAralVd7Myq0la6MWxk8vHoRX0r4WvXv/DGn3ErKZXgUvtOecYP6g18xW3D455r6D+GN5JceFxBLuYW0hjRu+CM4/D1/yelnGdJKMPmkXB4xxTpR83PrQlQA9VpS3FGeKYxIFIZyRam5ppNNL1JVh5aml6YW96jY4oAwvG758LXI7kpjj/aB/pXjUmWkPck8V7rqdoNQ064tGIXzYyoYjOD2NeNW1m/9sJbTKVdJCGU+ozkfpWkHZMTV2aVjbRWdurTcuf4R1rWt9XtInAYFCOxFQzeVBIXcDis+fUVl2gWYYMcAkda52uZ7HWvcW52trqts6Axyo3tmtWC6jljG4jNcD/Z9zbWNvf8AkqLa4GUkRgRnupwTgj0OKtWF7N5oQucE4rOdPlNYS5kd5GYxg54qpceIraxfays2P7oqM28sdmJFcHjJFcfqc12WlKjCxjc3HalTV2OTsjq08VvecQWUrDPVhgfnWgv2fUIDFcRbXYcqRwa47RItWvLa6ntgJBaqGcKc/wB7IHZiMA4yOCOecV0Wiat9q/c3EYV84z2J/H+vNaVItbozi+bZnAaxpp0fW5LZidv34z6qen9R+Fe2/Cpg3haUgEf6Sxx6/KvP9Pw9jXnHxCslW9srjHLxMufZSD/7NXqHw306fTfCwjuHJd5S+zHCZVeP8ffP1PRB3imclRWk0dFKfnwaVegps3+soQ0GZJnBpjnIp/XmoiSc0hnGs1NJoJphNQWLnIqMk0pPFMJoARjxXDazb2z+K1kiUJKiFpf9s4wD9fmH5V27niuIvImh12dpPvNnHuCc/wCFJuxdOKb1IZ7ETfMQagi0yVDtVI3j67XUMM/jW5BKpABxWjFGhXIArHna2OtQuYEyXc0IjllfylGBEhKoPbaOP0pllZeXOrHls9K2r5lijIXGayE1KztbtYZbhGmYjgHp7UczkPlSO4it1nslRhtyPvCsG88PyJN5i5z2Za0v+Eg0uxsUa8ufKDHap6kn6Vc+2JII3ilSa3kGUkXof88UldK5VrmPZ2skcIgklLQ94iPl/KtGG2R512QdP4sYrRhWNwCQDV+LYg4AocmwUTnPEdrE4066lt/N8iUqwyQFVl6/99BK9M01oDpsK27KY0QINpyBgYx/npXBa2PNsZohj5wBn05HNd1pOV0OyyefITr/ALorajJ3sc2IiuW/mE33zTVHFEh+Y0gPFbHISKaaOAc0gyOaTpSGcUTTGNKTTTUFCfjSGjNNJNACN0rmvEUWJoZwOxU+3+c10ZOayNasZbuMGFl3AY2uSAfxFJlRdmc+khHNatrd8cnFYSvgCkmmdYSY859qxlHU7IS0Ni8nin3BnA49a594oJrn/ViVx/FjmqxkZ2+fe3ooGa0bX7Y4BhjSH/e6n9KtRsK7kaVteLABA9qk0QOTvUNzXQ2E2ntEfKkCE8hDgY/AVz8Saqy/uzCpBzgDqfypLlbwYZ7Iq45Lwg4z9KLDd0dfbzDIKtlT0IrRjkyOtcnoty77Y2BznrjB+hrfinCnBPU8etZNWZSldC3v76VIW5STKHHoVOa7+xx/ZtsvYQoP/HRXJ6NpseoXTT3DN5cRwEVsBifXvxweCOveuuACqAoCqBgADAAropRa1OWvNNcpBL940xT2pXPJpi9Sa1Ockye/SjNIOaWkBxBptOYU2oKGmmsacTjrTCaAG1HJT2OKhY5oQHHa1bmzvm4/dy5dD79x/n1FUBOEQ5INdZrNst3YSIfvKNyH0Irz+4nZMg8Y7UnG5rCdkbVuVlcFcHPcVelsp3jykjp9K5W01FoicGujtNX3RLvbk9OamUGnc2jUTVi7p9hdRsCJpcZ5FdApeJMy8rjnPasGPWkV8KcgDkZ4qO71sHcTIvI4xxilytspySR0dpLG07FUxjv0/CrZk+chRuZzhR6k1xljqYDswOc9z1NdfoG+S5+0SgDj5FPUe9HJ71ifae7c7jRIPstmsRO5urN6k9a03bbGaz7GUiPjHNWXkzGQe9dNrHE3d3GSNnimg4qF5eetIJMnrSBFpTmlPSoQ3Sn76QzjWNRs4HWo3lqvJLSsFyZpBUbS9aqSTkZ5qhPqltEDvuEyOoByR+VPlC5qGYDvUTTiudn8QxCSOOJCzSZ2FztU/SsS91K+vYWTJ6MssCDDIfcdSPzqlTE5Gj4j8SzWd5HZWqRkuB5jtztyemPX/GsS8h8zJHWsJ3YPnuK0INWUqFnUg/3hTnB/ZKhJbMqPEVYg5U+tTxeaBtE+Ku4t7nmORST2zSfYTkYzWfP3NOTsRKk65xPUscLFxvdnY9qtwaazkZzW9p+mRxgFlAx3NS6iRSptiaLphDiaVcH+Fa7CGR7Yb41VnUEqrNtBPoTg4/I1lfa7SxQGWaOMdtzAVi6l4whVWjs1Lt03ngD/ABrJc85XSNWowjZncaP4/wBHmJgvGlsLhXEbJOuVDd/mXIAHq2B3rrhOkkSvG6ujjcrKchgehB7182yXMlzM0shJZjk+9dHpj6rYae7RzXlrFKQykb4YweMO0hwm3HuSeOOld3JocN9dD2N5OaRZK8+/4TW6s93nBbtpnH2a3Vdsrpj756AA9RkVvx+KrCJoI74taTTAFUcbhn0BH/1qnlYXOqSQ+tOaU461TtriGdSYZkkx12MDj8qeWqRnnLa8k4P2SJpffPH+fasKfxFqCzMlxZzwxj+NYCc1li1sCrMY7OM99jJz/wCTNPhmswDsbyueMMVH/pUBWqgibiahdrcmN4dSZCvJjuPMUZ9MkEVG8wkljkDrHKBgG3mimVs+qEg1djniBJW8Gc8k3OOP/AuqTGS8vigd5gp6B2lH5Dzh/wDrqrBcaSIy0MwWKPrLEcFSfURylWH/AAE0RxSXm/MUjjbiMFHbA9so+PwYVJL5ljdsjJJHDKAWjbdEh/D9yP0qFraKNxNbvbOMElHeAfq0jk/lQIqXECzShZNytgMxzlh65BJxyD95h9BWfcWcluMs0LZOPkmRz/46TW5iO5AO1vKDc7BvWJ/w2RqD689KkfYGmkG+UIq4aOUEL68/vAPxZRTQHL9KmjuZ4/uTOo9mNbssEM7Dz1EuBx/xNbdcfoahFhY5ANo34avbn/2WiwJtbFKPVr1Ol1J+dOOp3r53XUx/4Gat/YNMADMdo9Ptqsf0jqZLXRo9p8zBH9643fp5NTyrsVzy7mP5hJ55+tWLe2kuFYo0Ix2knRCfoGIzWykulbvKjvIwW4AJJ/lb/wAql/0jT50kEt0kUn8ZaVUP5mIVRJX0/T2aQMYzIV6mMNIv0+SOQH8a0mgitGi86GG3kz5pLwpC4APYvDCSc/3JAfSqa3FvHcym5+zzF2+UyPC5P4tHNx9Wqcyi2hdI5oo3mO+VYJY1HsMRXKocf7i/SkA63vjtKxXMse87iLa52FyT1OyByx56lmPuanRJrSXzBZyLK3IuGs57iQ/8Cl8sD8BWfDFPeXBSOGeZQPm2Ru4/HDSgj6qav3FtFGArWBDAcAWir+n2EUhhKJbqZZZrrVnZOV8u3hjxjvgSVuWniO9gQIkWszYGSzQLIevcBj+mKxltEjh82aw8sMcIHslB/P7EQfzqKbS5bmJmh07Kn+L7BwPxW1T+dFrgZpOtSnE1lrskPp5khLD3ypB/KkMUzu0R8P33yjokaBx7nEOaPJs5GD3vixxcpwdsEsuD7Pnn602S5h8oq/im+mjHHlKkp3D6MQv61QhzadrEEQmWCa3jHI+03ax/1X+lPntZ7+YTz6ppEbgD5Zbk3H6t5n5ZqiraIJwtrYahdf7Ek6r+iqavzWhJBi8F3SAjo7XDZ/LFAEMsSrMEuNa0qMDpLaWxLD8UjH86k2WEbhk8WT7x/EtvKCPoc1LYwaoJjHb+FLZd3T7VbyH9ZGxV6W216CAs3hXSGH+xao5/8camBhXZ0jeXn1LUNSkx8rBPL/Alix/SiK60RpkaawvbTb8ytbXIZs+vzKP0Nai/8JFIPNtNFtdPZOskdssRA/4Gant5PEaZ+y+IrGaVuPKF0jH6YYYpCMoTWkiyPHqiiV266jp6uSPdwJCfyqT7FcOquupeH+gwQsUZ59igP6VqfYvFsknmXek2V2f+m8VuR+mPSobnTtZusb/Cun4/6YRsh/8AHHFAFI2d6q5TxHpaY/553BX/ANBWo1muIptsvirYPWGSdv5KKm/snUc/L4UiUnu3n4/WSryaX4g8kBPDWmqB3aJCen+2xoAzZ7y1AVZvEWqXkRPzKiMP1dx/KmWiWErt9k0S/vlI43T/AK4RP61qww+LrUlV+zWcfXj7Og/8d5qGePV5fmufFVnEc8ot8VI4/uoKBi2sGpKzm08IQhBklbm3ldsf8CYE/hQsGGLXfgmYnPzbDcxrn2yTVUWumTXG668VsJc43/ZZpOf96rZhulQLa+MoxFnABupo/wBAKAIJUtZXPl+FL6IA42pdOf8A0KM0pggjgYyeFL9UHWQ3LAr+Pl4/SnMl7GQZPGa7fVL2dz+WKes0Sgg+N7sHpwtxj86QFBj4WC/OurrLn5gXhYfTOAf0oEXhWSH5f7VR89SkTr/MGtWK91EAC28YwNs6faJJV/8AQlNT3J8R3QijTUNK1lVXgK9vJs+u8Bs0Ac/az20yhLPw39owOTvkdm9+On4Vow2evcXGmaDBYlWyshVfMB9AZTx+AFYcuuavcMHk1GZTjGEkKDH0XAqg58xy8kpdz3PJp3Rfs5bs6i5udedmXU9dismUjcgmG/64iBP54ponhwM+NrzAPGIpz/WuZTYxAWNnP1qwlncv9yxmYYzwjGj5ByrrI1byPS5sNceJLq9Oen2ZyR+LtUUdl4elfKavcWhX+Ka0LZ+mw1n/AGS65/0GTjr+7PFRyKY/9ZblfqCKNQ5Y/wA35mm+n6FkP/b7yY7CycH8yeKkQ+FegfWgcfexER/jWGXjPSP9alCuI9xtzt9cGjUfJH+Zfia/9l+HJFDnxAYyedj2DsR+IOKVdJ8Pdf8AhJFA9rGSsbdG3SM/gabmPP3Gov5B7NdJI2/7J8PFefEgzjPOnSf40n9keHBj/ipAfXGmyf41i7ov7jfnSho/+ebH8aLhyL+ZG39i8Owpk63PN/sRWpUn8zikWXwvEc+Tqs5H8MjIqn8uaxd0eQBHz9atQ2V9OoaDTppAehSFmz+Qo1Dlgt5fmai6r4fBP/FNbh2Jv5Af5YpW1Dw3yRotxyeB9qPH6VWXR9bC8aTefT7OxP8AKkGj6y5wNKugf9qBgPzIpahy0/5vwLP9peH16eHpHH+3fMD+gpRqvh8H/kV//KlL/hSDw1r+0t/Z0hA9AD/WoX0TW1JB0y549IiaNQ5aff8AD/gk41bw+T/yLJUY5xqMh/mKkaXwnIAzRa3Ex5KRtEyD6E4NUf7J1kddJvT/ANuzn+lV547i2O25tGiPpIhU/rRqHLT/AJvwJRYaHBlptWlnK9YoICCfox4pYZ2h+bSNJZwp4uJovOfg8HGNq/l+NNi1G00ty2nWiM+eJrkb3X6DoP50yXXdUum3S3suRx8p2/yqXNGkcNN76GzHf+NJkDKJdo9YY1/pTkj8b8tmbnuHjrCOoXjDDXc5HvIab9omY/NK5x6saXtPI1WDf8x0XleN1bbmUHpjfF/jU6t49jAw79PWFuP1rl/OkIx5j49MmlE8vQSvj/eNHtCvqT/mOhkn8cbwrmXJHGY4sfnip4z47X5kz+AgP6Vzf2262hftM20dt5pqTzKcrK4Psxo9ouwfUX/MdG+p+MoH23VlLdKOSrWYdT7ZQVVfVNUPXwpp/vnTm/xqiNY1NcbdQuxj0mb/ABp6+INWUADUJzj1bJ/Wn7RA8BPo0T/2jqIY/wDFKabk9v7Ob/GpE1PWY8ND4YtYywwGj09h+VVf+Ei1fOft8351G2uao55v7j8JCKPaIn6jPujRTU/GLYENrNCOm1bMAfqtPa38b3gCs0647iVIj+hBrHGq6iBgahdY9POb/GoZJ5Z2zLI8jHuzE0vaeRSwMusjpV0LxeqqRqs43f8AT+wx+tRf2N4kIHna8sZIxiXUG/LvWB2pBml7TyNPqC/mOhXw/ruQya9bFuoxevkfpUn9geKyfk1aRiOm29Y/lzXN844o5Jo9qxfUF0kdAdH8aoVZZ71gT1+3jH6vUss3ju0b5lutwx9yJJT+gOa5vOCCOKsrquoQriO+ukX0WZgP50e08hPAPpIpW9vYxyEXbmRh1CZwPxFasD+Ho0AktJXPXIJ/xoorOUrM6KVCNRXbZOl14dXpp831PP8A7NVtNR8OhQf7NfI7bB/jRRU+0Z0RwVN9X94p1Hw2c/8AEtf2+QD/ANmpTqXhw8/2Y+fTYP8A4qiin7RlfUqXn94f2n4c5/4ljD/gA/8AiqcL/wAMFNp02Y+4AB/9Cooo9oxrA0u7+8kifwhM3zWk0Iz/ABFz/JjTZbbwgfuXEqn0Af8AqKKKPaMHgoLaT+8i+x+FOv2yb8m/+Jp4g8IqP9bIx9Tv/wAKKKfP5E/U4/zP7xC3hJUwLeVm9i/+NPg1Tw3AdqaYzD/bjDfzJoopObK+o0+rf3lp9f8AD5XjRIQe/wC4j5qEeItHVdq6Hb/98IM/pRRUurIv6hQ7P72J/wAJDpGCDoVuc/8ATNP8KkTXtBJG/Q4R67YU/wAKKKPaSH9Qodn97Hzax4alAzpLL67Y1H8mFVi3hORDm1ljbHcuf6miij2jB4Cmtm/vP//Z"));
					//System.out.println("Photo >"+resp.getKycData());
					
					resCode = resp.getOutputStatus();
					resMsg = resp.getOutputMessage();
					
					resArr[0] = resCode;
					resArr[1] = resMsg;
				}
				catch(Exception ex)
				{
					//System.err.println(ex);
					ex.printStackTrace();
					resArr[0] = "E";
					resArr[1] = "Error in calling webservice";
				}
			}
			
			
			
			 //System.out.println("Aadhar number---"+request.getParameter("uid"));
			//System.out.println("fingerPosition---"+fingerPosition);
			//System.out.println("fingerprint---"+fingerprint);
			
			// added parameter for MORPHO by latish - End
		
			if(fingerprint.length()!=0 || pidXML.length()!=0 || encHmac.length() !=0 || certExpiryDate.length()!=0|| encSession.length()!=0)
			{
				//System.out.println("in bio");
				EKYCProperties.setUsesBio(true);
				EKYCProperties.setUsesBioFMR(true);
				EKYCProperties.setUsesOtp(false);
			}
			else
			{
				//System.out.println("in otp");
				EKYCProperties.setUsesBio(false);
				EKYCProperties.setUsesBioFMR(false);
				EKYCProperties.setUsesOtp(true);
			}
		
		
		
        try
        {
		String id = request.getParameter("ID");
		request.setAttribute("message",resMsg);
		request.setAttribute("status",resCode);
		JSONObject addressobj=new JSONObject(resp.getCustomerAddress());

		request.setAttribute("getCustomerName",resp.getCustomerName());
		request.setAttribute("getCustomerDOB",resp.getCustomerDOB());
		request.setAttribute("getCustomerGender",resp.getCustomerGender());
		request.setAttribute("getCustomerAddress",addressobj.getString("CAREOF")+","+addressobj.getString("HOUSE")+","+addressobj.getString("STREET")+","+addressobj.getString("LANDMARK")+","+addressobj.getString("LOCATION")+","+addressobj.getString("PIN")+","+addressobj.getString("POSTOFFICE")+","+addressobj.getString("VILL/CITY")+","+addressobj.getString("SUB-DIST")+","+addressobj.getString("DIST")+","+addressobj.getString("STATE"));
		request.setAttribute("Phone",resp.getOutputParam1());
		request.setAttribute("Email",resp.getOutputParam2());
		request.setAttribute("Photo",resp.getOutputParam3());
		
		request.setAttribute("UID",bean.getUid());
		request.setAttribute("policyNo",policyNo);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("authTest.jsp");  
		   if (dispatcher != null){  
		      dispatcher.forward(request, response);  
		}
        }catch(Exception ex)
        {
        	System.err.println(ex);
			ex.printStackTrace();
			
        }
		//response.getWriter().println("Please check logs to see output");
		}
		   //KycRes kycResp = (KycRes) request.getAttribute("kycResponse");  
		   //System.out.println("sadsad"+kycResp.getUidData().getUid());

		//response.getWriter().println("<b>Response : \n"+resp+"</b>");
		
	}

}
