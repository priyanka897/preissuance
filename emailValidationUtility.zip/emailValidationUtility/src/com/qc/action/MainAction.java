package com.qc.action;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MainAction
{
	static Logger logger = Logger.getLogger(MainAction.class.getName());
	public static void main(String arg[]) 
	{
		try
		{
			PropertyConfigurator.configure("log4j.properties");
			logger.info("emailVerification Notification Schedular Main : Start");
			new emailVerificationScheduler().run(); 
			logger.info("emailVerification Notification Schedular Main : End");
		}
		catch (Throwable t)
		{
			logger.error("Error : HIGH PRIORITY : Analyse Fast : "+t);
		}
	}   

}
