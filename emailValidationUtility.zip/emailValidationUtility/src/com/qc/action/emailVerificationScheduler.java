package com.qc.action;

import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.qc.service.notificationService.EmailVerificationService;
import com.qc.service.utils.UniqueId;

public class emailVerificationScheduler implements Runnable
{

	static Logger logger = Logger.getLogger(emailVerificationScheduler.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("com.rest.service.resources.ApplicationResource");
	SchedulerStatus schedulerStatus = new SchedulerStatus();
	String param[] = null;
	public void run() 
	{
		try
		{
			NDC.push("emailVerificationNotiSch-"+UniqueId.getUniqueId());
			logger.info("emailVerificationNotificationScheduler : Start");

			logger.info("Run Method : Start");
			try 
			{
				logger.info("Inserting Scheduler Status : Start");
				param = new String[4];
				param[0] = "emailVerificationNotiSch";
				param[1] = "emailVerificationNotiSch SCHEDULER IS	INITIATED";
				param[2] = "INITIATED";
				param[3] = "SCHEDULER";
				schedulerStatus.setSchedulardetails(param);
				logger.info("Inserting Scheduler Status : End");
			} 
			catch (Exception e)
			{
				logger.error("Inserting Scheduler Status : Error :-" + e);
			}
			try 
			{
				EmailVerificationService service = new EmailVerificationService();
				logger.info("NotificationService Call : Start");
				service.verifyEmail();
				logger.info("NotificationService Call : End");
			} 
			catch (Exception e)
			{
				logger.error("NotificationService Call : Error :-"+ e);
			}

			try 
			{
				logger.info("Update Scheduler Status : Start");
				param = new String[2];
				param[0] = "emailVerificationNotiSch";
				param[1] = "emailVerificationNotiSch";
				schedulerStatus.updateSchedularStatus(param);
				logger.info("Update Scheduler Status : End");
			}
			catch (Exception e)
			{
				logger.error("Update Scheduler Status : Error :-"+ e);
			}
		}
		catch (Exception e)
		{
			logger.info("We Are in Exception :-"+ e);
		}
		finally
		{
			logger.info("emailVerificationNotificationScheduler : End");
			NDC.pop();
		}
	}
}
