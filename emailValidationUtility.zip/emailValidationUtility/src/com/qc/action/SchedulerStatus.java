package com.qc.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;

import org.apache.log4j.Logger;

import com.qc.service.dbHelper.DBHelper;

public class SchedulerStatus 
{
	static Logger logger = Logger.getLogger(SchedulerStatus.class.getName());
	
	public int getSchedularDetails(String [] param)
	{
		int count=0;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("getSchedularDetails : Start");
		try
		{
			con = DBHelper.getConnection();
			String sql = "SELECT (SELECT COUNT(*) FROM QCIB_SCHEDULAR_TRACK WHERE SCHEDULARID=? AND SCHEDULARSTATE IN ('INITIATED','FINISHED') AND STARTTIME BETWEEN (CURRENT_TIMESTAMP - INTERVAL '90' MINUTE) AND (CURRENT_TIMESTAMP - INTERVAL '0' MINUTE)) AS STATUS FROM DUAL";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}		
			logger.info("Executing query for getSchedularDetails");
			rs = pst.executeQuery();
			if(rs!=null)
			{
				while (rs.next()) 
                {                	
                	count= Integer.parseInt(rs.getString("STATUS"));              		                	
                }    	
			}
		}
		catch (Exception e) 
		{			
			logger.error("SQL exception while closing resource : " + e);
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
            }
            logger.info("getSchedularDetails : End");
        }
		return count;
	}
	
	public void setSchedulardetails(String [] param)
	{
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("setSchedulardetails : Start");
		try
		{
			con = DBHelper.getConnection();
			String sql = "INSERT INTO QCIB_SCHEDULAR_TRACK(SCHEDULARID,SCHEDULARNAME,SCHEDULARSTATE,INITIATEDBY,STARTTIME) VALUES(?,?,?,?,CURRENT_TIMESTAMP)";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}			
			pst.executeUpdate();			
		}
		catch (Exception e) 
		{			
			logger.error("Error in setSchedulardetails :-"+e,new Throwable());
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
            }
            logger.info("setSchedulardetails : End");
        }
	}
	
	public void updateSchedularStatus(String [] param)
	{
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("updateSchedularStatus : Starts");
		try
		{
			con = DBHelper.getConnection();
			String sql = "UPDATE QCIB_SCHEDULAR_TRACK SET ENDTIME=CURRENT_TIMESTAMP,SCHEDULARSTATE='FINISHED' WHERE SCHEDULARID=? AND SCHEDULARSTATE='INITIATED' AND  STARTTIME = (SELECT MAX(STARTTIME) FROM QCIB_SCHEDULAR_TRACK WHERE SCHEDULARID=?)";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}			
			pst.executeUpdate();			
		}
		catch (Exception e) 
		{			
			logger.error("Error in updateSchedularStatus :-"+e,new Throwable());
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
            }
            logger.info("updateSchedularStatus : End");
        }
	}
}
