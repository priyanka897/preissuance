package com.qc.emailverification.bean;

public class DBDataForVerificationHit 
{

	private String corelationId;
	private String uniqueId;
	private String statusFlag;
	private String sid;
	private int difInHours;
	private String validationFlag;
	private String verificationFlag;
	public String getCorelationId() {
		return corelationId;
	}
	public void setCorelationId(String corelationId) {
		this.corelationId = corelationId;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getStatusFlag() {
		return statusFlag;
	}
	public void setStatusFlag(String statusFlag) {
		this.statusFlag = statusFlag;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public int getDifInHours() {
		return difInHours;
	}
	public void setDifInHours(int difInHours) {
		this.difInHours = difInHours;
	}
	public String getValidationFlag() {
		return validationFlag;
	}
	public void setValidationFlag(String validationFlag) {
		this.validationFlag = validationFlag;
	}
	public String getVerificationFlag() {
		return verificationFlag;
	}
	public void setVerificationFlag(String verificationFlag) {
		this.verificationFlag = verificationFlag;
	}
	@Override
	public String toString() {
		return "DBDataForVerificationHit [corelationId=" + corelationId + ", uniqueId=" + uniqueId + ", statusFlag="
				+ statusFlag + ", sid=" + sid + ", difInHours=" + difInHours + ", validationFlag=" + validationFlag
				+ ", verificationFlag=" + verificationFlag + "]";
	}
}
