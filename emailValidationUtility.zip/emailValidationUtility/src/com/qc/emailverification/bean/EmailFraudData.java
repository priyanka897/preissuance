package com.qc.emailverification.bean;

import java.io.Serializable;
import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailFraudData implements Serializable{
	private DataOutput output;
	private String validationStatus;
	private String requestTimestamp;
	private String linkopenTimestamp;
	private String formsubmitTimestamp;
	private String emailsentTimestamp;
	private String emailbouncedTimestamp;
	private boolean riskFlag;
	private String[] riskInfo;
	private EmailInfo emailInfo;
	private CompanyInfo companyInfo;
	private DomainInfo domainInfo;
	private VerifyInfo verifyInfo;
	private FormInfo formInfo;
	private String verificationStatus;
	private String domainName;
	private String responseTime;
	private String overallStatus;
	
	public DataOutput getOutput() {
		return output;
	}

	public void setOutput(DataOutput output) {
		this.output = output;
	}
	public String getValidationStatus() {
		return validationStatus;
	}
	public void setValidationStatus(String validationStatus) {
		this.validationStatus = validationStatus;
	}
	public String getRequestTimestamp() {
		return requestTimestamp;
	}
	public void setRequestTimestamp(String requestTimestamp) {
		this.requestTimestamp = requestTimestamp;
	}
	public String getLinkopenTimestamp() {
		return linkopenTimestamp;
	}
	public void setLinkopenTimestamp(String linkopenTimestamp) {
		this.linkopenTimestamp = linkopenTimestamp;
	}
	public String getFormsubmitTimestamp() {
		return formsubmitTimestamp;
	}
	public void setFormsubmitTimestamp(String formsubmitTimestamp) {
		this.formsubmitTimestamp = formsubmitTimestamp;
	}
	public String getEmailsentTimestamp() {
		return emailsentTimestamp;
	}
	public void setEmailsentTimestamp(String emailsentTimestamp) {
		this.emailsentTimestamp = emailsentTimestamp;
	}
	public String getEmailbouncedTimestamp() {
		return emailbouncedTimestamp;
	}
	public void setEmailbouncedTimestamp(String emailbouncedTimestamp) {
		this.emailbouncedTimestamp = emailbouncedTimestamp;
	}
	public boolean isRiskFlag() {
		return riskFlag;
	}
	public void setRiskFlag(boolean riskFlag) {
		this.riskFlag = riskFlag;
	}
	public String[] getRiskInfo() {
		return riskInfo;
	}
	public void setRiskInfo(String[] riskInfo) {
		this.riskInfo = riskInfo;
	}
	public EmailInfo getEmailInfo() {
		return emailInfo;
	}
	public void setEmailInfo(EmailInfo emailInfo) {
		this.emailInfo = emailInfo;
	}
	public CompanyInfo getCompanyInfo() {
		return companyInfo;
	}
	public void setCompanyInfo(CompanyInfo companyInfo) {
		this.companyInfo = companyInfo;
	}
	
	public VerifyInfo getVerifyInfo() {
		return verifyInfo;
	}
	public void setVerifyInfo(VerifyInfo verifyInfo) {
		this.verifyInfo = verifyInfo;
	}
	public FormInfo getFormInfo() {
		return formInfo;
	}
	public void setFormInfo(FormInfo formInfo) {
		this.formInfo = formInfo;
	}
	public String getVerificationStatus() {
		return verificationStatus;
	}
	public void setVerificationStatus(String verificationStatus) {
		this.verificationStatus = verificationStatus;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getResponseTime() {
		return responseTime;
	}
	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}
	public String getOverallStatus() {
		return overallStatus;
	}
	public void setOverallStatus(String overallStatus) {
		this.overallStatus = overallStatus;
	}

	public DomainInfo getDomainInfo() {
		return domainInfo;
	}

	public void setDomainInfo(DomainInfo domainInfo) {
		this.domainInfo = domainInfo;
	}
	
	@Override
	public String toString() {
		return "EmailFraudData [output=" + output + ", validationStatus=" + validationStatus + ", requestTimestamp="
				+ requestTimestamp + ", linkopenTimestamp=" + linkopenTimestamp + ", formsubmitTimestamp="
				+ formsubmitTimestamp + ", emailsentTimestamp=" + emailsentTimestamp + ", emailbouncedTimestamp="
				+ emailbouncedTimestamp + ", riskFlag=" + riskFlag + ", riskInfo=" + Arrays.toString(riskInfo)
				+ ", emailInfo=" + emailInfo + ", companyInfo=" + companyInfo + ", domainInfo=" + domainInfo
				+ ", verifyInfo=" + verifyInfo + ", formInfo=" + formInfo + ", verificationStatus=" + verificationStatus
				+ ", domainName=" + domainName + ", responseTime=" + responseTime + ", overallStatus=" + overallStatus
				+ "]";
	}

	
}
