package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailInfo implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailStatus;
	private boolean mailboxExists;
	private boolean genericEmail;
	private boolean disposableEmail;
	private boolean gibberishEmail;
	private boolean contactusTypeEmail;
	public String getEmailStatus() {
		return emailStatus;
	}
	public void setEmailStatus(String emailStatus) {
		this.emailStatus = emailStatus;
	}
	public boolean isMailboxExists() {
		return mailboxExists;
	}
	public void setMailboxExists(boolean mailboxExists) {
		this.mailboxExists = mailboxExists;
	}
	public boolean isGenericEmail() {
		return genericEmail;
	}
	public void setGenericEmail(boolean genericEmail) {
		this.genericEmail = genericEmail;
	}
	public boolean isDisposableEmail() {
		return disposableEmail;
	}
	public void setDisposableEmail(boolean disposableEmail) {
		this.disposableEmail = disposableEmail;
	}
	public boolean isGibberishEmail() {
		return gibberishEmail;
	}
	public void setGibberishEmail(boolean gibberishEmail) {
		this.gibberishEmail = gibberishEmail;
	}
	public boolean isContactusTypeEmail() {
		return contactusTypeEmail;
	}
	public void setContactusTypeEmail(boolean contactusTypeEmail) {
		this.contactusTypeEmail = contactusTypeEmail;
	}
	
	@Override
	public String toString() {
		return "EmailInfo [emailStatus=" + emailStatus + ", mailboxExists=" + mailboxExists + ", genericEmail="
				+ genericEmail + ", disposableEmail=" + disposableEmail + ", gibberishEmail=" + gibberishEmail
				+ ", contactusTypeEmail=" + contactusTypeEmail + "]";
	}

}
