package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientReference implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String leadId;
	private String transactionId;
	private String losId;
	
	public String getLeadId() {
		return leadId;
	}
	@Override
	public String toString() {
		return "ClientReference [leadId=" + leadId + ", transactionId=" + transactionId + ", losId=" + losId + "]";
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getLosId() {
		return losId;
	}
	public void setLosId(String losId) {
		this.losId = losId;
	}
	
	

}
