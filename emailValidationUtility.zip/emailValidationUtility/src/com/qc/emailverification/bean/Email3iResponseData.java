package com.qc.emailverification.bean;

import java.io.Serializable;

public class Email3iResponseData implements Serializable
{
	private static final long serialVersionUID = -209861988121298803L;
	private String correlationid;
	private String status;
	private Integer errorcode;
	private String errormessage;
	

	public String getCorrelationid() {
		return correlationid;
	}

	public void setCorrelationid(String correlationid) {
		this.correlationid = correlationid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getErrorcode() {
		return errorcode;
	}

	public void setErrorcode(Integer errorcode) {
		this.errorcode = errorcode;
	}

	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	@Override
	public String toString() {
		return "Email3iResponseData [correlationid=" + correlationid + ", status=" + status + ", errorcode=" + errorcode
				+ ", errormessage=" + errormessage + "]";
	}
}
