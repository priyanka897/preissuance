package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class VerifyInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailBounced;
	private String connectionType;
	private String deviceType;
	private String deviceBrand;
	private String deviceModel;
	private String operatingSystem;
	private String screenSize;
	private String browserName;
	private String deviceOnCharge;
	private String percentageBatteryLeft;
	private String addressLine1;
	private String addressLine2;
	private String city;
	private String state;
	private String pincode;
	private String isp;
	private String subscriberName;
	private String locationAccepted;
	private String addressSource;
	public String getEmailBounced() {
		return emailBounced;
	}
	public void setEmailBounced(String emailBounced) {
		this.emailBounced = emailBounced;
	}
	public String getConnectionType() {
		return connectionType;
	}
	public void setConnectionType(String connectionType) {
		this.connectionType = connectionType;
	}
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getDeviceBrand() {
		return deviceBrand;
	}
	public void setDeviceBrand(String deviceBrand) {
		this.deviceBrand = deviceBrand;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	public String getScreenSize() {
		return screenSize;
	}
	public void setScreenSize(String screenSize) {
		this.screenSize = screenSize;
	}
	public String getBrowserName() {
		return browserName;
	}
	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}
	public String getDeviceOnCharge() {
		return deviceOnCharge;
	}
	public void setDeviceOnCharge(String deviceOnCharge) {
		this.deviceOnCharge = deviceOnCharge;
	}
	public String getPercentageBatteryLeft() {
		return percentageBatteryLeft;
	}
	public void setPercentageBatteryLeft(String percentageBatteryLeft) {
		this.percentageBatteryLeft = percentageBatteryLeft;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getIsp() {
		return isp;
	}
	public void setIsp(String isp) {
		this.isp = isp;
	}
	public String getSubscriberName() {
		return subscriberName;
	}
	public void setSubscriberName(String subscriberName) {
		this.subscriberName = subscriberName;
	}
	public String getLocationAccepted() {
		return locationAccepted;
	}
	public void setLocationAccepted(String locationAccepted) {
		this.locationAccepted = locationAccepted;
	}
	public String getAddressSource() {
		return addressSource;
	}
	public void setAddressSource(String addressSource) {
		this.addressSource = addressSource;
	}
	
	@Override
	public String toString() {
		return "VerifyInfo [emailBounced=" + emailBounced + ", connectionType=" + connectionType + ", deviceType="
				+ deviceType + ", deviceBrand=" + deviceBrand + ", deviceModel=" + deviceModel + ", operatingSystem="
				+ operatingSystem + ", screenSize=" + screenSize + ", browserName=" + browserName + ", deviceOnCharge="
				+ deviceOnCharge + ", percentageBatteryLeft=" + percentageBatteryLeft + ", addressLine1=" + addressLine1
				+ ", addressLine2=" + addressLine2 + ", city=" + city + ", state=" + state + ", pincode=" + pincode
				+ ", isp=" + isp + ", subscriberName=" + subscriberName + ", locationAccepted=" + locationAccepted
				+ ", addressSource=" + addressSource + "]";
	}
	
}
