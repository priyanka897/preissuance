package com.qc.emailverification.bean;

import java.io.Serializable;
import java.util.Arrays;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class EmailVerificationPayload implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String mobileNumber;
	private String city;
	private String uniqueId;
	private String email;
	private String firstName;
	private String middleName;
	private String lastName;
	private ClientReference clientReference;
	private EmailFraudData data;
	private String companyName;
	private String[] errorList;
	private String byteArray;
	
	
	
	@Override
	public String toString() {
		return "EmailVerificationPayload [mobileNumber=" + mobileNumber + ", city=" + city + ", uniqueId=" + uniqueId
				+ ", email=" + email + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName="
				+ lastName + ", clientReference=" + clientReference + ", data=" + data + ", companyName=" + companyName
				+ ", errorList=" + Arrays.toString(errorList) + ", byteArray=" + byteArray + "]";
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public ClientReference getClientReference() {
		return clientReference;
	}
	public void setClientReference(ClientReference clientReference) {
		this.clientReference = clientReference;
	}
	public EmailFraudData getData() {
		return data;
	}
	public void setData(EmailFraudData data) {
		this.data = data;
	}
	public String[] getErrorList() {
		return errorList;
	}
	public void setErrorList(String[] errorList) {
		this.errorList = errorList;
	}
	public String getByteArray() {
		return byteArray;
	}
	public void setByteArray(String byteArray) {
		this.byteArray = byteArray;
	}
	
	 
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

