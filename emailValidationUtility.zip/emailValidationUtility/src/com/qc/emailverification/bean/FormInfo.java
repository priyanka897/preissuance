package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class FormInfo implements Serializable{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String employeeCode;
	 private String dateOfJoining;
	 private String department;
	 private String designation;
	 private String currentPosting;
	 private String addressLine1;
	 private String addressLine2;
	 private String city;
	 private String state;
	 private String pincode;
	 private String mobileNumber;
	public String getEmployeeCode() {
		return employeeCode;
	}
	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}
	public String getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(String dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getCurrentPosting() {
		return currentPosting;
	}
	public void setCurrentPosting(String currentPosting) {
		this.currentPosting = currentPosting;
	}
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	 @Override
		public String toString() {
			return "FormInfo [employeeCode=" + employeeCode + ", dateOfJoining=" + dateOfJoining + ", department="
					+ department + ", designation=" + designation + ", currentPosting=" + currentPosting + ", addressLine1="
					+ addressLine1 + ", addressLine2=" + addressLine2 + ", city=" + city + ", state=" + state + ", pincode="
					+ pincode + ", mobileNumber=" + mobileNumber + "]";
		}
}
