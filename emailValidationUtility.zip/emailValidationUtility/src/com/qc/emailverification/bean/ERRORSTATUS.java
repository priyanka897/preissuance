package com.qc.emailverification.bean;

public enum ERRORSTATUS {
	SUCCESS,FAILURE
}
