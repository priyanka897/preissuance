package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class DomainInfo implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private boolean domainExists;
	private boolean domainExpiryFlag;
	private String domainCreatedDate;
	private Integer domainAge;
	private String domainUpdatedDate;
	private String domainExpiryDate;
	private String registrantName;
	private String registrantOrganization;
	private String registrantEmail;
	private String registrantStreet1;
	private String registrantStreet2;
	private String registrantCity;
	private String registrantState;
	private String registrantPostalcode;
	private String registrantCountry;
	public boolean isDomainExists() {
		return domainExists;
	}
	public void setDomainExists(boolean domainExists) {
		this.domainExists = domainExists;
	}
	public boolean isDomainExpiryFlag() {
		return domainExpiryFlag;
	}
	public void setDomainExpiryFlag(boolean domainExpiryFlag) {
		this.domainExpiryFlag = domainExpiryFlag;
	}
	public String getDomainCreatedDate() {
		return domainCreatedDate;
	}
	public void setDomainCreatedDate(String domainCreatedDate) {
		this.domainCreatedDate = domainCreatedDate;
	}
	public Integer getDomainAge() {
		return domainAge;
	}
	public void setDomainAge(Integer domainAge) {
		this.domainAge = domainAge;
	}
	public String getDomainUpdatedDate() {
		return domainUpdatedDate;
	}
	public void setDomainUpdatedDate(String domainUpdatedDate) {
		this.domainUpdatedDate = domainUpdatedDate;
	}
	public String getDomainExpiryDate() {
		return domainExpiryDate;
	}
	public void setDomainExpiryDate(String domainExpiryDate) {
		this.domainExpiryDate = domainExpiryDate;
	}
	public String getRegistrantName() {
		return registrantName;
	}
	public void setRegistrantName(String registrantName) {
		this.registrantName = registrantName;
	}
	public String getRegistrantOrganization() {
		return registrantOrganization;
	}
	public void setRegistrantOrganization(String registrantOrganization) {
		this.registrantOrganization = registrantOrganization;
	}
	public String getRegistrantEmail() {
		return registrantEmail;
	}
	public void setRegistrantEmail(String registrantEmail) {
		this.registrantEmail = registrantEmail;
	}
	public String getRegistrantStreet1() {
		return registrantStreet1;
	}
	public void setRegistrantStreet1(String registrantStreet1) {
		this.registrantStreet1 = registrantStreet1;
	}
	public String getRegistrantStreet2() {
		return registrantStreet2;
	}
	public void setRegistrantStreet2(String registrantStreet2) {
		this.registrantStreet2 = registrantStreet2;
	}
	public String getRegistrantCity() {
		return registrantCity;
	}
	public void setRegistrantCity(String registrantCity) {
		this.registrantCity = registrantCity;
	}
	public String getRegistrantState() {
		return registrantState;
	}
	public void setRegistrantState(String registrantState) {
		this.registrantState = registrantState;
	}
	public String getRegistrantPostalcode() {
		return registrantPostalcode;
	}
	public void setRegistrantPostalcode(String registrantPostalcode) {
		this.registrantPostalcode = registrantPostalcode;
	}
	public String getRegistrantCountry() {
		return registrantCountry;
	}
	public void setRegistrantCountry(String registrantCountry) {
		this.registrantCountry = registrantCountry;
	}
	
	@Override
	public String toString() {
		return "DomainInfo [domainExists=" + domainExists + ", domainExpiryFlag=" + domainExpiryFlag
				+ ", domainCreatedDate=" + domainCreatedDate + ", domainAge=" + domainAge + ", domainUpdatedDate="
				+ domainUpdatedDate + ", domainExpiryDate=" + domainExpiryDate + ", registrantName=" + registrantName
				+ ", registrantOrganization=" + registrantOrganization + ", registrantEmail=" + registrantEmail
				+ ", registrantStreet1=" + registrantStreet1 + ", registrantStreet2=" + registrantStreet2
				+ ", registrantCity=" + registrantCity + ", registrantState=" + registrantState
				+ ", registrantPostalcode=" + registrantPostalcode + ", registrantCountry=" + registrantCountry + "]";
	}
	

}
