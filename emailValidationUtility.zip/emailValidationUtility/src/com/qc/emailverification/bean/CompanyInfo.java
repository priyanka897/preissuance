package com.qc.emailverification.bean;

import java.io.Serializable;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
@JsonIgnoreProperties(ignoreUnknown = true)
public class CompanyInfo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String rocAddress;
	private String domainCompanyMapping;
	private String companyCin;
	private String companyAlternateDomain;
	private String companyRegistrationDate;
	private String companyAge;
	private String directors;
	public String getRocAddress() {
		return rocAddress;
	}
	public void setRocAddress(String rocAddress) {
		this.rocAddress = rocAddress;
	}
	public String getDomainCompanyMapping() {
		return domainCompanyMapping;
	}
	public void setDomainCompanyMapping(String domainCompanyMapping) {
		this.domainCompanyMapping = domainCompanyMapping;
	}
	public String getCompanyCin() {
		return companyCin;
	}
	public void setCompanyCin(String companyCin) {
		this.companyCin = companyCin;
	}
	public String getCompanyAlternateDomain() {
		return companyAlternateDomain;
	}
	public void setCompanyAlternateDomain(String companyAlternateDomain) {
		this.companyAlternateDomain = companyAlternateDomain;
	}
	public String getCompanyRegistrationDate() {
		return companyRegistrationDate;
	}
	public void setCompanyRegistrationDate(String companyRegistrationDate) {
		this.companyRegistrationDate = companyRegistrationDate;
	}
	public String getCompanyAge() {
		return companyAge;
	}
	public void setCompanyAge(String companyAge) {
		this.companyAge = companyAge;
	}
	public String getDirectors() {
		return directors;
	}
	public void setDirectors(String directors) {
		this.directors = directors;
	}
	
	@Override
	public String toString() {
		return "CompanyInfo [rocAddress=" + rocAddress + ", domainCompanyMapping=" + domainCompanyMapping
				+ ", companyCin=" + companyCin + ", companyAlternateDomain=" + companyAlternateDomain
				+ ", companyRegistrationDate=" + companyRegistrationDate + ", companyAge=" + companyAge + ", directors="
				+ directors + "]";
	}
	
}
