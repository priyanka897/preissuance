package com.qc.service.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

public class MultiFormatDate 
{
	static Logger logger = Logger.getLogger(MultiFormatDate.class.getName());
	public static String getFormattedDate(String dateAsString,String ipFormat,String opFormat) throws ParseException{
		String formattedDate = "";
		SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);//("dd/MM/yyyy hh:mm:ss a");
		Date date = sdf.parse(dateAsString);
		sdf = new SimpleDateFormat(opFormat);//(dd-MMM-yy hh:mm:ss a)
		formattedDate = sdf.format(date);
		return formattedDate;
	}
	public static String getNotificationHolidayDate()
	{
		String formattedDate = "";
		try 
		{
			String opFormat="dd-MMM-yyyy";
			SimpleDateFormat sdf = new SimpleDateFormat(opFormat);
			Date date = new Date();
			formattedDate = sdf.format(date);
		} 
		catch (Exception e) 
		{
			logger.error("Date Format time Exception : Check on Prioority : Service misbehave due to this : "+e);
		}
		return formattedDate.toUpperCase();
	}
	
	public static String getSoaFormattedDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="2010-03-16 00:00:00.0";
			String ipFormat="yyyy-MM-dd HH:mm:ss.S";
			String opFormat="yyyy-MM-dd";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			return formattedDate;
		} 
		catch (ParseException e) 
		{
			logger.info(e);
			return dateAsString;
		}
	}
	
	public static String getSoaInMiliSecDate(String dateAsString)
	{
		try 
		{
			//String dateAsString="2010-03-16";
			String ipFormat="dd-MMM-yy";
			String opFormat="yyyy-MM-dd HH:mm:ss.S";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(ipFormat);
			Date date = sdf.parse(dateAsString);
			sdf = new SimpleDateFormat(opFormat);
			formattedDate = sdf.format(date);
			return formattedDate;
		} 
		catch (ParseException e) 
		{
			logger.info(e);
			return dateAsString;
		}
	}
	
	
	
	public static void main(String... arr)
	{
		try 
		{
			String opFormat="dd-MMM-yyyy";
			String formattedDate = "";
			SimpleDateFormat sdf = new SimpleDateFormat(opFormat);
			Date date = new Date();
			formattedDate = sdf.format(date);
			System.out.println(formattedDate);
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}
