package com.qc.service.utils;

import java.util.UUID;

public class UniqueId 
{
	public static String getUniqueId()
	{
		UUID uniqueId = UUID.randomUUID();
		return ""+uniqueId;
	}

	public static void main(String... arr)
	{
//		System.out.println(UniqueId.getUniqueId());
//		System.out.println(UniqueId.getUniqueId());
//		System.out.println(UniqueId.getUniqueId());
//		System.out.println(UniqueId.getUniqueId());
//		System.out.println(UniqueId.getUniqueId());
//		System.out.println(UniqueId.getUniqueId());
	}
}
