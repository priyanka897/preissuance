package com.qc.service.notificationService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.qc.emailverification.bean.DBDataForVerificationHit;
import com.qc.emailverification.bean.DataOutput;
import com.qc.emailverification.bean.Email3iResponseData;
import com.qc.emailverification.bean.EmailFraudData;
import com.qc.emailverification.bean.EmailVerificationPayload;
import com.qc.emailverification.bean.EmailVerificationResponse;
import com.qc.service.daoImpl.SchedularDaoImpl;
import com.qc.service.utils.UniqueId;
import com.qc.service.utils.XTrustProvider;

public class EmailVerificationService 
{
	static Logger logger = Logger.getLogger(EmailVerificationService.class.getName());
	static SchedularDaoImpl nDao = new SchedularDaoImpl();
	static ResourceBundle res = null;
	public EmailVerificationService() 
	{
		res = ResourceBundle.getBundle("com.rest.service.resources.ApplicationResource");
	}

	public boolean verifyEmail()
	{
		logger.info("sendingPunchPushNotification : Start");
		boolean result = false;
		SchedularDaoImpl daoImpl = new SchedularDaoImpl();
		ObjectMapper om = new ObjectMapper();
		List<DBDataForVerificationHit> ll = daoImpl.getUniqueIdForServiceHit();
		if(ll!=null && !ll.isEmpty())
		{
			for(DBDataForVerificationHit id : ll)
			{
				if(id.getDifInHours()<=96)
				{
					NDC.push(id.getUniqueId());
					try
					{
						if(!id.getStatusFlag().equalsIgnoreCase("Success"))
						{
							boolean dbUpdateFlag = daoImpl.updateEmailAllStatusAsSavingFail(id,"FC");
							logger.info("TimeLimitExceed ****** "+id.getUniqueId()+" Force to Close Crone by setting Update to 3i status as Y for validationflag(FC) Status and validationFlag : DB update status is (Force Close - FC) : "+dbUpdateFlag+" ******" + " For ID : "+id);
							
							String updateMessage = "Domain+ROC+Employee details failed";
							logger.info("validationStatus + Verification is : "+updateMessage + " For ID : "+id);
							String _3iResult = call3iServiceForEmailVerification(null, id.getUniqueId(),updateMessage);
							Email3iResponseData email3iResponseData = om.readValue(_3iResult, Email3iResponseData.class);
							String _3iStatus = email3iResponseData.getStatus();
							logger.info("3iStatus is : "+_3iStatus);
						
						}
					}
					catch(Exception ex)
					{
						logger.error("Something went wrong while tring to stop failure cron while status is failure on save request ");
					}
					
					
					try
					{
						String qcResult = callQCServiceForEmailVerification(id.getUniqueId());
						EmailVerificationResponse emailSaveRes = om.readValue(qcResult, EmailVerificationResponse.class);

						String status = emailSaveRes.getMsgInfo().getCode();
						if(status!=null && status.equals("200"))
						{
							try
							{
								String validationStatus = emailSaveRes.getPayload().getData().getValidationStatus();
								if(validationStatus.equalsIgnoreCase("Failed") 
										|| validationStatus.equalsIgnoreCase("Successful") 
										|| validationStatus.equalsIgnoreCase("Not Confirmed"))
								{
									String updateMessage = "Domain+ROC completed, Employee details pending";
									logger.info("validationStatus is : "+updateMessage + " For ID : "+id);
									String _3iResult = call3iServiceForEmailVerification(emailSaveRes, id.getUniqueId(),updateMessage);
									Email3iResponseData email3iResponseData = om.readValue(_3iResult, Email3iResponseData.class);
									String _3iStatus = email3iResponseData.getStatus();
									if(_3iStatus!=null && _3iStatus.equalsIgnoreCase("Success"))
									{
										boolean dbUpdateFlag = daoImpl.updateEmailValidationStatus(id,"Y");
										logger.info("Final validationStatus update Status in DB is : "+dbUpdateFlag + " For ID : "+id);
									}
									else
									{
										logger.info("3i validationStatus status is : "+_3iStatus+" So Stoping journey" + " For ID : "+id);
									}
								}
								else
								{
									//Do Nothing
									logger.info("QC validationStatus status is : "+status+" So Stoping journey" + " For ID : "+id);
								}
							}
							catch(Exception ex)
							{
								logger.error("We face Exception while calling 3i email verification service : "+ex + " For ID : "+id);
							}
						}
						else
						{
							logger.info("QC Verification status is : "+status+" So Stoping journey" + " For ID : "+id);
						}

					}
					catch(Exception ex)
					{
						logger.error("We face Exception while calling qc save email service : "+ex + " For ID : "+id);
					}
					finally
					{
						NDC.pop();
					}
				}
				else if(id.getDifInHours()>96 && id.getDifInHours() <= 120)
				{
					NDC.push("TimeLimitExceed_"+id.getUniqueId());
					try 
					{
						String qcResult = callQCServiceForEmailVerification(id.getUniqueId());
						EmailVerificationResponse emailSaveRes = om.readValue(qcResult, EmailVerificationResponse.class);
						String status = emailSaveRes.getMsgInfo().getCode();
						if(status!=null && status.equals("200"))
						{
							String updateMessage = "Domain+ROC completed, Employee details pending";
							logger.info("validationStatus is : "+updateMessage + " For ID : "+id);
							String _3iResult = call3iServiceForEmailVerification(emailSaveRes, id.getUniqueId(),updateMessage);
							Email3iResponseData email3iResponseData = om.readValue(_3iResult, Email3iResponseData.class);
							String _3iStatus = email3iResponseData.getStatus();
							if(_3iStatus!=null && _3iStatus.equalsIgnoreCase("Success"))
							{
								boolean dbUpdateFlag = daoImpl.updateEmailValidationStatus(id, "TE");
								logger.info("Final validationStatus update Status in DB is (Time Expire - TE) : "+dbUpdateFlag + " For ID : "+id);
							}
							else
							{
								logger.info("3i validationStatus status is : "+_3iStatus+" So Stoping journey" + " For ID : "+id);
							}
						}
					} 
					catch (Exception e) 
					{
						logger.error("We Face Exception : "+e + " For ID : "+id);
					}
					finally
					{
						NDC.pop();
					}
				}
				else
				{
					try 
					{
						boolean dbUpdateFlag = daoImpl.updateEmailValidationStatus(id,"FC");
						logger.info("TimeLimitExceed ****** "+id.getUniqueId()+" Force to Close Crone by setting Update to 3i status as Y for validationflag(FC) only : DB update status is (Force Close - FC) : "+dbUpdateFlag+" ******" + " For ID : "+id);
					} 
					catch (Exception e)
					{
						// TODO Auto-generated catch block
						logger.error("We Face Exception : "+e + " For ID : "+id);
					}
				}
			}
		}
		return result;
	}

	public String callQCServiceForEmailVerification(String id) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("callQCServiceForEmailVerification Process : Start");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			StringBuilder requestData =new StringBuilder();
			requestData.append(" 	{	 ");
			requestData.append(" 	  \"header\": {	 ");
			requestData.append(" 	    \"msgVersion\": \"1.0\",	 ");
			requestData.append(" 	   \"appId\": \"").append(res.getString("com.qc.pnb.qc.emailVerification.username")).append("\",	 ");
			requestData.append(" 	    \"correlationId\": \"").append(id).append("_EmailValidationCrone").append("\",	 ");
			requestData.append(" 	   \"token\": \"").append(res.getString("com.qc.pnb.qc.emailVerification.password")).append("\"	 ");
			requestData.append(" 	  },	 ");
			requestData.append(" 	  \"payload\": {	 ");
			requestData.append(" 	    \"uniqueId\": \"").append(id).append("\" ");
			requestData.append(" 	  }	 ");
			requestData.append(" 	}	 ");


			String pUrl = res.getString("com.qc.pnb.qc.emailVerification.url");
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+requestData.toString());
			URL url = new URL(pUrl);
			HttpURLConnection conn = null;
			//			String DevMode = env.getString("com.qc.enable.proxy.call");
			//			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			//			{
			//				logger.info("We are running in Development Mode So Proxy Enabled");
			//				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(env.getString("com.qc.proxy.ip"), Integer.parseInt(env.getString("com.qc.proxy.port"))));
			//				conn = (HttpURLConnection) url.openConnection(proxy);
			//			}
			//			else
			//			{
			conn = (HttpURLConnection) url.openConnection();
			//			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setConnectTimeout(Integer.parseInt(res.getString("com.qc.timeout")));
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestData.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			logger.info("API Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				try
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
				catch (Exception e)
				{
					logger.error("We face exception while try to read ErrorStream : "+e);
				}
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling callQCServiceForEmailVerification ::",e);
		}
		logger.info("Response data : "+result.toString());
		logger.info("callQCServiceForEmailVerification Process : End");
		return result.toString();
	}


	public String call3iServiceForEmailVerification(EmailVerificationResponse emailSaveRes, String uniqueId, String updateMessage) 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();
		try 
		{
			logger.info("call3iServiceForEmailVerification Process : Start");
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();

			StringBuilder requestData =new StringBuilder();
			requestData.append(" 	{	 ");
			requestData.append(" 	  \"header\": {	 ");
			requestData.append(" 	    \"username\": \"").append(res.getString("com.qc.pnb.3i.emailVerification.username")).append("\",	 ");
			requestData.append(" 	    \"password\": \"").append(res.getString("com.qc.pnb.3i.emailVerification.password")).append("\",	 ");
			requestData.append(" 	    \"correlationid\": \"").append(uniqueId).append("\"	 ");
			requestData.append(" 	  },	 ");
			requestData.append(" 	  \"payload\": {	 ");
			if(emailSaveRes==null)
			{
				requestData.append(" 	    \"byteArray\": \"\",	 ");
			}
			else
			{
				requestData.append(" 	    \"byteArray\": \"").append(emailSaveRes.getPayload().getData().getOutput().getContent()).append("\",	 ");				
			}
			requestData.append(" 	    \"validationStatus\": \"").append(updateMessage).append("\"	 ");
			requestData.append(" 	  }	 ");
			requestData.append(" 	}	 ");

			//System.out.println(requestData.toString());
			String pUrl = res.getString("com.qc.pnb.3i.emailVerification.url");
			logger.info("URL : "+pUrl);
			logger.info("Payload and Signature : "+requestData.toString());
			URL url = new URL(pUrl);
			HttpURLConnection conn = null;
			//			String DevMode = env.getString("com.qc.enable.proxy.call");
			//			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			//			{
			//				logger.info("We are running in Development Mode So Proxy Enabled");
			//				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(env.getString("com.qc.proxy.ip"), Integer.parseInt(env.getString("com.qc.proxy.port"))));
			//				conn = (HttpURLConnection) url.openConnection(proxy);
			//			}
			//			else
			//			{
			conn = (HttpURLConnection) url.openConnection();
			//			}
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setConnectTimeout(Integer.parseInt(res.getString("com.qc.timeout")));
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestData.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}
			int apiResponseCode = conn.getResponseCode(); 
			logger.info("PerfiosAPI Response Code :: "+apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
			}
			else
			{
				try
				{
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) 
					{
						result.append(output);
					}
					conn.disconnect();
					br.close();
				}
				catch (Exception e)
				{
					logger.error("We face exception while try to read ErrorStream : "+e);
				}
			}
		}
		catch (Exception e) 
		{
			logger.error("ErrorInfo While Calling call3iServiceForEmailVerification ::",e);
		}
		logger.info("Response data : "+result.toString());
		logger.info("call3iServiceForEmailVerification Process : Start");
		return result.toString();
	}
}
