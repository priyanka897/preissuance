package com.qc.service.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.qc.emailverification.bean.DBDataForVerificationHit;
import com.qc.service.dbHelper.DBHelper;


public class SchedularDaoImpl
{

	static Logger logger = Logger.getLogger(SchedularDaoImpl.class.getName());
	
	public List<DBDataForVerificationHit> getUniqueIdForServiceHit()
	{
		logger.info("getUniqueIdForServiceHit : Start");
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<DBDataForVerificationHit> beanList = new ArrayList<DBDataForVerificationHit>();
		try
		{
			//Script applied as per get validation hit details
			con = DBHelper.getConnection();
			//pstmt = con.prepareStatement(" select SID, UNIQUEID,CORELATIONID ,trunc((24 * (sysdate - DT_CREATED))) as DIFF_HOURS , VALIDATIONFLAG , VERIFICATIONFLAG from QCIB_EMAIL_SAVE_RES where to_char(DT_CREATED,'DD-MON-RR') > to_char(sysdate-6,'DD-MON-RR') and STATUSFLAG='N' and VALIDATIONFLAG='N' ");
			pstmt = con.prepareStatement(" select a.SID, a.UNIQUEID,a.CORELATIONID ,trunc((24 * (sysdate - a.DT_CREATED))) as DIFF_HOURS , a.VALIDATIONFLAG , a.VERIFICATIONFLAG , b.STATUS  STATUS from QCIB_EMAIL_SAVE_RES a, QCIB_CREDIT_REQ_RES b where a.DT_CREATED > TRUNC(sysdate)-6  and a.STATUSFLAG='N' and a.VALIDATIONFLAG='N' and a.corelationid = b.corelationid ");
			
			rs = pstmt.executeQuery();
			while (rs.next()) 
			{
				DBDataForVerificationHit dataForVerificationHit = new DBDataForVerificationHit();
				String id = rs.getString("UNIQUEID");
				if(!isNullThanBlank(id).equals(""))
				{
					dataForVerificationHit.setUniqueId(id);
					dataForVerificationHit.setCorelationId(rs.getString("CORELATIONID"));
					dataForVerificationHit.setSid(rs.getString("SID"));
					dataForVerificationHit.setDifInHours(isNullThanZero(rs.getString("DIFF_HOURS")));
					dataForVerificationHit.setValidationFlag(rs.getString("VALIDATIONFLAG"));
					dataForVerificationHit.setVerificationFlag(rs.getString("VERIFICATIONFLAG"));
					dataForVerificationHit.setStatusFlag(rs.getString("STATUS"));
					beanList.add(dataForVerificationHit);
				}
			}

		}
		catch (Exception e) 
		{
			logger.error("getUniqueIdForServiceHit : Error : " + e);
		}
		catch(Throwable t)
		{
			System.out.println(t);
		}
		finally
		{
				if (rs != null)
				{
					try{rs.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
				}
				if (pstmt != null) 
				{
					try{pstmt.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
				}
				if (con != null)
				{
					try{con.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
				}
			
			logger.info("getUniqueIdForServiceHit : End");
		}
		return beanList;
	}
	
	private static String isNullThanBlank(String str) {

		String temp = str;
		temp = (temp == null) ? "" : temp.trim();
		return temp;
	}
	
	private static int isNullThanZero(String str)
	{
		try
		{
			return Integer.parseInt(str);
		}
		catch(Exception ex)
		{
			return 0;
		}
	}
	
	
	public boolean updateEmailValidationStatus(DBDataForVerificationHit bean, String status)
	{
		boolean flag = false;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("updateEmailValidationStatus : Start");
		int i = 0;
		try
		{
			con = DBHelper.getConnection();
			String sql = "update QCIB_EMAIL_SAVE_RES set validationFlag = '"+status+"' where UNIQUEID = ? and CORELATIONID = ? and SID = ? ";
			logger.info("updateEmailVerificationStatus query executing.....: Start" + sql);
			pst = con.prepareStatement(sql);
			pst.setString(1,bean.getUniqueId());
			pst.setString(2,bean.getCorelationId());
			pst.setString(3,bean.getSid());
			logger.info("updateEmailValidationStatus query successfully : End" );
			i=pst.executeUpdate();	
			if(i>0)
			{
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		catch (Exception e) 
		{			
			logger.error("Error in updateEmailValidationStatus :-"+e);
			flag=false;
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
                flag=false;
            }
            logger.info("updateEmailValidationStatus : End");
        }
		return flag;
	}
	
	public boolean updateEmailAllStatusAsSavingFail(DBDataForVerificationHit bean, String status)
	{
		boolean flag = false;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("updateEmailAllStatusAsSavingFail : Start");
		int i = 0;
		try
		{
			con = DBHelper.getConnection();
			String sql = "update QCIB_EMAIL_SAVE_RES set statusflag = '"+status+"' , validationFlag = '"+status+"', verificationflag = '"+status+"' where UNIQUEID = ? and CORELATIONID = ? and SID = ? ";
			logger.info("updateEmailAllStatusAsSavingFail query executing.....: Start" + sql);
			pst = con.prepareStatement(sql);
			pst.setString(1,bean.getUniqueId());
			pst.setString(2,bean.getCorelationId());
			pst.setString(3,bean.getSid());
			logger.info("updateEmailAllStatusAsSavingFail query successfully : End" );
			i=pst.executeUpdate();	
			if(i>0)
			{
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		catch (Exception e) 
		{			
			logger.error("Error in updateEmailAllStatusAsSavingFail :-"+e);
			flag=false;
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
                flag=false;
            }
            logger.info("updateEmailAllStatusAsSavingFail : End");
        }
		return flag;
	}
	public boolean updateEmailVerificationStatus(DBDataForVerificationHit bean, String status, String finalCallStatus)
	{
		boolean flag = false;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("updateEmailVerificationStatus : Start");
		int i = 0;
		try
		{
			con = DBHelper.getConnection();
			String sql = "update QCIB_EMAIL_SAVE_RES set verificationFlag = '"+status+"' , statusFlag = '"+finalCallStatus+"' where UNIQUEID = ? and CORELATIONID = ? and SID = ? ";
			logger.info("updateEmailVerificationStatus query executing.....: Start" + sql);
			pst = con.prepareStatement(sql);
			pst.setString(1,bean.getUniqueId());
			pst.setString(2,bean.getCorelationId());
			pst.setString(3,bean.getSid());
			logger.info("updateEmailVerificationStatus query successfully : End" );
			i=pst.executeUpdate();	
			if(i>0)
			{
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		catch (Exception e) 
		{			
			logger.error("Error in updateEmailVerificationStatus :-"+e);
			flag=false;
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                logger.error("SQL exception while closing resource : " + e);
                flag=false;
            }
            logger.info("updateEmailVerificationStatus : End");
        }
		return flag;
	}
	
	
//	static private String SELECT_EAPP_SSOID_LOGIN_HST = "SELECT DISTINCT SSO_ID FROM EAPP_SSOID_LOGIN_HST WHERE LASTLOGIN BETWEEN TRUNC(SYSDATE-30) AND SYSDATE";
//	static private String SELECT_EAPP_SSOID_X_DEVICEID ="SELECT DISTINCT SSO_ID , DEVICE_TYPE, DEVICE_ID FROM EAPP_SSOID_X_DEVICEID WHERE device_id is not null and DTCREATED BETWEEN TRUNC(SYSDATE-30) AND SYSDATE";
//	static private String FETCH_PUNCH_DATA = " Select emplid \"empId\", TO_CHAR ( PUNCH_DTTM, 'HH:MI:SS AM' ) \"punchTime\" from SYADM.ps_tl_rptd_time where emplid=? and punch_type in (1,2) AND TRUNC(LASTUPDDTTM) = TRUNC(SYSDATE)  ";
//	SimpleDateFormat sdf_yyyyMMdd = new SimpleDateFormat("yyyy-MM-dd");
//	SimpleDateFormat sdf_ddMMM = new SimpleDateFormat("dd/MM/yyyy");
//
//
//	public ArrayList<String> getEmpId() throws SQLException 
//	{
//		logger.info("getEmpId : Start");
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		ArrayList<String> datalist = null;
//		try
//		{
//			con = DBHelper.getConnection();
//			pstmt = con.prepareStatement(SELECT_EAPP_SSOID_LOGIN_HST);
//			datalist = new ArrayList<String>();
//			rs = pstmt.executeQuery();
//			while (rs.next()) 
//			{
//				datalist.add(isNullThanBlank(rs.getString("SSO_ID")));
//			}
//
//		}
//		catch (Exception e) 
//		{
//			logger.error("getEmpId : Error : " + e);
//		}
//		finally
//		{
//			if (rs != null)
//			{
//				try{rs.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (pstmt != null) 
//			{
//				try{pstmt.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (con != null)
//			{
//				try{con.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			logger.info("getEmpId : End");
//		}
//
//		return datalist;
//	}
//
//
//	public List<NotificationBean> getEmpIdFromEAPP_SSOID_X_DEVICEID()
//	{
//		logger.info("getEmpIdFromEAPP_SSOID_X_DEVICEID : Start");
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		List<NotificationBean> beanList = null;
//		try
//		{
//			con = DBHelper.getConnection();
//			pstmt = con.prepareStatement(SELECT_EAPP_SSOID_X_DEVICEID);
//			beanList = new ArrayList<NotificationBean>();
//			rs = pstmt.executeQuery();
//			while (rs.next()) 
//			{
//				NotificationBean notificationBean = new NotificationBean();
//				notificationBean.setEmpId(isNullThanBlank(rs.getString("SSO_ID")));
//				notificationBean.setDeviceType(isNullThanBlank(rs.getString("DEVICE_TYPE")));
//				notificationBean.setDeviceId(isNullThanBlank(rs.getString("DEVICE_ID")));
//				beanList.add(notificationBean);
//			}
//
//		}
//		catch (Exception e) 
//		{
//			logger.error("getEmpIdFromEAPP_SSOID_X_DEVICEID : Error : " + e);
//		}
//		finally
//		{
//				if (rs != null)
//				{
//					try{rs.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//				}
//				if (pstmt != null) 
//				{
//					try{pstmt.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//				}
//				if (con != null)
//				{
//					try{con.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//				}
//			
//			logger.info("getEmpIdFromEAPP_SSOID_X_DEVICEID : End");
//		}
//		return beanList;
//	}
//
//	public ArrayList<NotificationBean> getDataforAudit(
//			String emp,
//			int isException
//			)
//	{
//		logger.info("NotificationDAO --> getDatatoPush Starts...");
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		ArrayList<NotificationBean> datalist = null;
//		NotificationBean nbean = null;
//		try 
//		{
//			con = DBHelperEapp.getConnection();
//			pstmt = con.prepareStatement(FETCH_PUNCH_DATA);
//			pstmt.setString(1, emp);
//			datalist = new ArrayList<NotificationBean>();
//			rs = pstmt.executeQuery();
//			while (rs.next()) 
//			{
//				nbean = new NotificationBean();
//				nbean.setEmpId(rs.getString("empId"));
//				nbean.setStartDate(rs.getString("punchTime"));
//				nbean.setServiceName("GetPunchRequest");
//				datalist.add(nbean);
//			}
//		}
//		catch (Exception e)
//		{
//			logger.error("getDatatoPush --> Error Occurred::" + e);
//		} 
//		finally
//		{
//			if (rs != null)
//			{
//				try{rs.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (pstmt != null) 
//			{
//				try{pstmt.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (con != null)
//			{
//				try{con.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//		}
//		logger.info("NotificationDAO --> getDatatoPush Stop.");
//		return datalist;
//
//	}
//	public Map<String,String> getHolidayMap(List<NotificationBean> datalist)
//	{
//		logger.info("getHolidayMap Start");
//		Connection con = null;
//		PreparedStatement pstmt = null;
//		ResultSet rs = null;
//		Map<String,String> map = new HashMap<String,String>();
//		try 
//		{
//			con = DBHelperDisha.getConnection();
//			List<String> paramList = NotificationDAO.getSsoIdInParameters(datalist);
//			for(String param : paramList)
//			{
//				StringBuilder sb = new StringBuilder();
//				sb.append(" SELECT A.EMPLID EMPID ,a.supervisor_id supervisor_id ,a.dur dur,  A.STATUS STATUS");
//				sb.append(" FROM SYADM.PS_Z_MLIC_WORKDAYS A WHERE A.EMPLID in (");
//				sb.append(param);
//				sb.append(") AND A.DUR ='");
//				sb.append(MultiFormatDate.getNotificationHolidayDate());
//				sb.append("' ORDER BY A.DUR DESC");
//				pstmt = con.prepareStatement(sb.toString());
//				rs = pstmt.executeQuery();
//				while (rs.next()) 
//				{
//					map.put(rs.getString("EMPID").toUpperCase(), rs.getString("STATUS").toUpperCase());
//				}
//				if (rs != null)
//				{
//					try{rs.close(); rs=null;}catch (Exception e){logger.error("Closing time Error : " + e);}
//				}
//				if (pstmt != null) 
//				{
//					try{pstmt.close();pstmt=null;}catch (Exception e){logger.error("Closing time Error : " + e);}
//				}
//			}
//		}
//		catch (Exception e)
//		{
//			logger.error("getHolidayMap --> Error Occurred::" + e);
//		} 
//		finally
//		{
//			if (rs != null)
//			{
//				try{rs.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (pstmt != null) 
//			{
//				try{pstmt.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//			if (con != null)
//			{
//				try{con.close();}catch (Exception e){logger.error("Closing time Error : " + e);}
//			}
//		}
//		logger.info("getHolidayMap Stop.");
//		return map;
//
//	}
//	
//	private static List<String> getSsoIdInParameters(List<NotificationBean> datalist)
//	{
//		List<String> paramList=new ArrayList<String>();
//		if(datalist!=null && datalist.size()>0)
//		{
//			int count=0;
//			StringBuilder inParam=new StringBuilder();
//			inParam.append(" ");
//			boolean lastReached=false;
//			for(NotificationBean bean : datalist)
//			{
//				count++;
//				if(count%500 == 0)
//				{
//					if(bean.getEmpId()!=null && !bean.getEmpId().equals(""))
//					{
//						inParam.append("'").append(bean.getEmpId()).append("',");
//					}
//					inParam.setLength(inParam.length()-1);
//					paramList.add(inParam.toString().trim());
//					if(datalist.size()==count)
//					{
//						lastReached=true;
//					}
//					inParam = new StringBuilder();
//					inParam.append(" ");
//				}
//				else
//				{
//					if(bean.getEmpId()!=null && !bean.getEmpId().equals(""))
//					{
//						inParam.append("'").append(bean.getEmpId()).append("',");
//					}
//				}
//				if(datalist.size()==count && !lastReached)
//				{
//					inParam.setLength(inParam.length()-1);
//					paramList.add(inParam.toString().trim());
//				}
//				logger.info("In Param : "+paramList);
//			}
//		}
//		return paramList;
//	}
//	
//	public boolean insertNotificationDetails(NotificationBean bean,String notificationType)
//	{
//		boolean flag = true;
//		ResultSet rs = null;
//		Connection con = null;
//		PreparedStatement pst = null;
//		logger.info("insertNotificationDetails : Start");
//		int i = 0;
//		try
//		{
//			con = DBHelper.getConnection();
//			String sql = "INSERT INTO EAPP_NOTIFICATION_DETAILS(SSO_ID,DEVICE_ID,DEVICE_TYPE,MESSAGE,SEND_DATE,NOTIFICATION_TYPE) VALUES(?,?,?,?,sysdate,?)";
//			logger.info("insertNotificationDetails query executing.....: Start" + sql);
//			pst = con.prepareStatement(sql);
//			pst.setString(1,bean.getEmpId());
//			pst.setString(2,bean.getDeviceId());
//			pst.setString(3,bean.getDeviceType());
//			pst.setString(4,bean.getMsg());
//			pst.setString(5,notificationType);
//			logger.info("insertNotificationDetails query successfully : End" );
//			i=pst.executeUpdate();	
//			if(i>0){
//				logger.info("Notification Record Insert Successfully for ssoId " +bean.getEmpId() );
//			}
//			else{
//				logger.info("Notification Record Could Not Insert for ssoId " +bean.getEmpId());
//				flag=false;
//			}
//		}
//		catch (Exception e) 
//		{			
//			logger.error("Error in setSchedulardetails :-"+e,new Throwable());
//			flag=false;
//		}	
//		finally 
//        {
//            try 
//            {
//                if (rs != null) 
//                {
//                    rs.close();
//                }
//                if (pst != null) 
//                {
//                	pst.close();
//                }
//                if (con != null) 
//                {
//                    con.close();
//                }
//            }
//            catch (Exception e) 
//            {
//                logger.error("SQL exception while closing resource : " + e);
//                flag=false;
//            }
//            logger.info("insertNotificationDetails : End");
//        }
//		return flag;
//	}
}
