package com.qc.service.dbHelper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

public class DBHelper
{
	private static Logger logger = Logger.getLogger(DBHelper.class.getName());

	
	private static DBHelper instance=null;
	static ResourceBundle rs= ResourceBundle.getBundle("com.rest.service.resources.ApplicationResource");
	
	static final String JDBC_DRIVER    = rs.getString("com.dbhelper.driverClassName");  
	static final String DB_URL 	= rs.getString("com.dbhelper.url");
	static final String USER 	= rs.getString("com.dbhelper.username");
	static final String PASS 	= rs.getString("com.dbhelper.password");
  
	public static void init() 
	{
		
		try
		{
			logger.debug("Executing Init method...");
			Class.forName(JDBC_DRIVER);
		}
		catch(Exception e)
		{
			logger.error("Error while loading JDBC Drier:"+e);
		}		
	}
	public static Connection getConnection() throws SQLException
	{
		Connection con = null;		
		try
		{
			logger.debug("Start getSourceConnection()...");
			
			String localPASS=getPassword(PASS);
			init();
			con = DriverManager.getConnection(DB_URL,USER,localPASS);
			con.getMetaData();
			if(con!=null)
			{
				con.setAutoCommit(true);
			}
		}
		catch(Exception e)
		{
			logger.error("Error while getting connection from data source "+e);
			throw new SQLException("Connection failed...");
		}
		logger.debug("End getSourceConnection()...");
		return con;
	}
	
	
	
	public static DBHelper getInstance()
	{
		if(instance == null){
			
			logger.debug("Start getInstance()...");
			instance = new DBHelper();
			logger.debug("Initializing Instance.");
			
			instance.init();
		}
		logger.debug("End getInstance()...");
		return instance;
	}
	private static String getPassword(String encPassword)
	{
        String password=null;
        
        try
        {
          // StringEncrypter encrypter=new StringEncrypter();	
          // password=encrypter.getPassword(encPassword);
        	password = encPassword;
        }
        catch(Exception e)
        {
        	logger.debug("Error getPassword: "+e);
        }
        return password;
    }
	
}