package com.qc.entity;

public class PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS {
	private String planCode;
    private String navFromDate;
    private String navToDate;
    private String planName;
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getNavFromDate() {
		return navFromDate;
	}
	public void setNavFromDate(String navFromDate) {
		this.navFromDate = navFromDate;
	}
	public String getNavToDate() {
		return navToDate;
	}
	public void setNavToDate(String navToDate) {
		this.navToDate = navToDate;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	@Override
	public String toString() {
		return "PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS [planCode=" + planCode + ", navFromDate=" + navFromDate
				+ ", navToDate=" + navToDate + ", planName=" + planName + "]";
	}
	
}