package com.qc.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="QC_EKUDOS_LOG")

public class EkudosEntity 
{
	private long ekudos_id;
	private Date created_time;                
	private Date updated_time;
	private String tracker_id;
	private String eventName;
	private String appName;
	private String appType;
	private String corelation_id;
	private String eventOccured;
	private String createDate;
	private String userName;
	private String title;
	private String category;
	private String updated;
	private String eKudosEarned;
	private String remark;
	
	@Id
	public long getEkudos_id() {
		return ekudos_id;
	}
	public void setEkudos_id(long ekudos_id) {
		this.ekudos_id = ekudos_id;
	}
	@Column(name="CORELATION_ID")
	public String getCorelation_id() {
		return corelation_id;
	}
	public void setCorelation_id(String corelation_id) {
		this.corelation_id = corelation_id;
	}
	@Column(name="CREATED_TIME")
	public Date getCreated_time() {
		return created_time;
	}
	public void setCreated_time(Date created_time) {
		this.created_time = created_time;
	}
	@Column(name="UPDATED_TIME")
	public Date getUpdated_time() {
		return updated_time;
	}
	public void setUpdated_time(Date updated_time) {
		this.updated_time = updated_time;
	}
	@Column(name="TRACKER_ID")
	public String getTracker_id() {
		return tracker_id;
	}
	public void setTracker_id(String tracker_id) {
		this.tracker_id = tracker_id;
	}
	@Column(name="EVENT_OCCURED")
	public String getEventOccured() {
		return eventOccured;
	}
	public void setEventOccured(String eventOccured) {
		this.eventOccured = eventOccured;
	}
	@Column(name="CREATE_DATE")
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	@Column(name="USER_NAME")
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Column(name="TITLE")
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Column(name="CATEGORY")
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Column(name="UPDATED")
	public String getUpdated() {
		return updated;
	}
	public void setUpdated(String updated) {
		this.updated = updated;
	}
	@Column(name="EKUDOS_EARNED")
	public String geteKudosEarned() {
		return eKudosEarned;
	}
	public void seteKudosEarned(String eKudosEarned) {
		this.eKudosEarned = eKudosEarned;
	}
	@Column(name="REMARKS")
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Column(name="EVENT_NAME")
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	@Column(name="APP_NAME")
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	@Column(name="APP_TYPE")
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
}
