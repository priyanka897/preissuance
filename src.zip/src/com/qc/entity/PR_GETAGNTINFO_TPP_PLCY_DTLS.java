package com.qc.entity;

import java.io.Serializable;

public class PR_GETAGNTINFO_TPP_PLCY_DTLS implements Serializable
{
	private static final long serialVersionUID = 5643253141761378930L;
	
	private String  policyid;

	public String getPolicyid() {
		return policyid;
	}

	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}

	@Override
	public String toString() {
		return "PR_GETAGNTINFO_TPP_PLCY_DTLS [policyid=" + policyid + "]";
	}
 }
