package com.qc.entity;

import java.io.Serializable;

public class PR_GETSTATE_DTLS implements Serializable {

	private static final long serialVersionUID = 5643253141761378930L;
	
	private String country;
	private String state;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "PR_GETMAXCITIES_DTLS [country=" + country + ", state=" + state + "]";
	}

	
	
}
