package com.qc.entity;

import java.io.Serializable;

public class PR_COUNTOFNOTIFICATION_DTLS implements Serializable {

	private static final long serialVersionUID = 5643253141761378930L;
	
	private String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "PR_COUNTOFPOLICY_DTLS [userId=" + userId + "]";
	}
}
