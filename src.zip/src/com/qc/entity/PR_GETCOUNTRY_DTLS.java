package com.qc.entity;

import java.io.Serializable;

public class PR_GETCOUNTRY_DTLS implements Serializable {

	private static final long serialVersionUID = 5643253141761378930L;
	
	private String country;
	//private String state;
	@Override
	public String toString() {
		return "PR_GETCOUNTRY_DTLS [country=" + country + "]";
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
}
