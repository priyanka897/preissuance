package com.qc.entity;

import java.io.Serializable;

public class PR_CAMPAIGN_TPP_IMAGE_DTLS implements Serializable
{
	private static final long serialVersionUID = 5643253141761378930L;
	private String  imageId;
	public String getImageId() {
		return imageId;
	}
	public void setImageId(String imageId) {
		this.imageId = imageId;
	}
	@Override
	public String toString() {
		return "PR_CAMPAIGN_TPP_IMAGE_DTLS [imageId=" + imageId + "]";
	}
 }
