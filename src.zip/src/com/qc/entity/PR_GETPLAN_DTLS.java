package com.qc.entity;

import java.io.Serializable;

public class PR_GETPLAN_DTLS implements Serializable {

	private static final long serialVersionUID = 5643253141761378930L;
	
	private String plancategory;
	private String planname;
	public String getPlancategory() {
		return plancategory;
	}
	public void setPlancategory(String plancategory) {
		this.plancategory = plancategory;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	@Override
	public String toString() {
		return "PR_GETPLAN_DTLS [plancategory=" + plancategory + ", planname=" + planname + "]";
	}
}
