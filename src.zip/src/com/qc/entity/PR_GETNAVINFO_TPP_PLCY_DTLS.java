package com.qc.entity;

import java.io.Serializable;

public class PR_GETNAVINFO_TPP_PLCY_DTLS implements Serializable
{
	private static final long serialVersionUID = 5643253141761378930L;
	private String policyid;
	private String smsstatus;
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	public String getSmsstatus() {
		return smsstatus;
	}
	public void setSmsstatus(String smsstatus) {
		this.smsstatus = smsstatus;
	}
	@Override
	public String toString() {
		return "PR_GETNAVINFO_TPP_PLCY_DTLS [policyid=" + policyid + ", smsstatus=" + smsstatus + "]";
	}	
}
