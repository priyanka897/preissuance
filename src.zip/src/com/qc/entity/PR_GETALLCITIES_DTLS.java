package com.qc.entity;

import java.io.Serializable;

public class PR_GETALLCITIES_DTLS implements Serializable {

	private static final long serialVersionUID = 5643253141761378930L;
	
	private String city;
	private String state;

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "PR_GETMAXCITIES_DTLS [city=" + city + ", state=" + state + "]";
	}

	
	
}
