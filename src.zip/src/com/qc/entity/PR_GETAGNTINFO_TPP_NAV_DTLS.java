package com.qc.entity;

import java.io.Serializable;

public class PR_GETAGNTINFO_TPP_NAV_DTLS implements Serializable
{
	private static final long serialVersionUID = 5643253141761378930L; 
	private String planName;
	private String fromDate;
	private String toDate;
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Override
	public String toString() {
		return "PR_GETAGNTINFO_TPP_NAV_DTLS [planName=" + planName + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ "]";
	}
	
}
