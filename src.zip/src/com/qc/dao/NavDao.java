package com.qc.dao;

import java.util.List;
import java.util.Map;

import com.qc.entity.PR_GETAGNTINFO_TPP_PLCY_DTLS;
import com.qc.entity.PR_GETNAVINFO_TPP_PLCY_DTLS;


public interface NavDao 
{
	public String getNavService(PR_GETAGNTINFO_TPP_PLCY_DTLS req);
	public int getUpdateNavDetails(PR_GETNAVINFO_TPP_PLCY_DTLS req);
	public boolean checkValidPoilcyNumber(String policynum);
	public String getUpdateAlertNav(String policyNumber, String transactionType);
	public List<Object> getNavDetailDao(String policyNumber);
	public List<Map> illustrationDao(String policyNumber);
}
