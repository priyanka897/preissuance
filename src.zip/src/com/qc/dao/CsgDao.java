package com.qc.dao;

import java.util.List;

import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.createNotification.ApiRequestCreateNotification;
import com.qc.api.request.csg.listOfNotificationV2.ApiRequestListOfNotificationV2;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.csg.updateNotification.ApiRequestUpdateNotification;
import com.qc.api.request.csg.updateNotificationReadStatus.ApiRequestUpdateNotificationReadStatus;

public interface CsgDao {

	public List<Object[]> getNotificationSearch(ApiRequestNotificationSearch apirequestnotificationsearch);
	public String createNotification(ApiRequestCreateNotification apirequestcreatenotification);
	public List<Object[]> notificationDetails(ApiRequestNotificationDetails apirequestnotificationdetails);
	public List<Object[]> listOfNotificationsV2(ApiRequestListOfNotificationV2 apirequestlistofnotificationv2);
	public String updateNotificationReadStatus(ApiRequestUpdateNotificationReadStatus apirequestupdatenotificationreadstatus);
	public String updateNotification(ApiRequestUpdateNotification apirequestupdatenotification);
	
	
}
