package com.qc.dao;

import java.util.List;


import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;

public interface FundNavDao 
{
	public List<Object[]> getFundDetails();
	public List<Object[]> getPlanDetails();
	public List<Object[]>getNavDetails(PR_GETAGNTINFO_TPP_NAV_DTLS req); 
	public List<Object[]> getCurrentNavDetails(PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req);
	
}
