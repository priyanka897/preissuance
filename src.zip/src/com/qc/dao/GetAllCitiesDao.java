package com.qc.dao;

import java.util.List;

import com.qc.entity.PR_GETALLCITIES_DTLS;

public interface GetAllCitiesDao 
{
	public List<Object[]> getAllCitiesService(PR_GETALLCITIES_DTLS req);
	
	
}
