package com.qc.dao;

import java.util.List;

import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.request.getneopincodecity.ApiRequestNeoPincodeCity;

public interface NeoDao {
	public List<Object[]> callNeftdetails(ApiRequestNeftDetails apiRequest);
	
	public List<Object[]> callPincodeDetails(ApiRequestNeoPincodeCity apiRequest);
}
