package com.qc.dao;

import java.util.List;


import com.qc.entity.PR_GETMAXCITIES_DTLS;

public interface GetMaxCitiesDao 
{
	public List<Object[]> getMaxCitiesService(PR_GETMAXCITIES_DTLS req);
	
	
}
