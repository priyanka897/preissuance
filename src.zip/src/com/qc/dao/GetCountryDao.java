package com.qc.dao;

import java.util.List;

import com.qc.entity.PR_GETCOUNTRY_DTLS;

public interface GetCountryDao 
{
	public List<Object[]> getCountryService(PR_GETCOUNTRY_DTLS req);
	
	
}
