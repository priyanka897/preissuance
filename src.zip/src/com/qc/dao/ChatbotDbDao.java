package com.qc.dao;

import java.util.List;

import com.qc.api.request.eCube.ChatbotPayloadRequest;

public interface ChatbotDbDao {
	
	public List<Object[]> getSsoValidationProcList(String segment,String ssoid);

	public List<Object[]> getGrowthProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getAchievementProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getPenetrationProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getWipList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getLpcPerformanceProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getRecProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getCaseSizeProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getModeMixProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	//public List<Object[]> getGpaProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	//public List<Object[]> getActivationProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getAppliedProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getPaidProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
	public List<Object[]> getMiscProcList(String segment,String channel, ChatbotPayloadRequest payload);
	//public List<Object[]> getProtectionProcList(String segment,String channel, ChatbotPayloadRequest payload);
	
}
