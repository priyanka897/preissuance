package com.qc.dao;

import java.util.List;

import com.qc.entity.PR_COUNTOFNOTIFICATION_DTLS;




public interface MPowerDao {

	public List<Object[]> countOfNotificationService(PR_COUNTOFNOTIFICATION_DTLS req);
	
}
