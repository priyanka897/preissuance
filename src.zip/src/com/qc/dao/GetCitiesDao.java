package com.qc.dao;

import java.util.List;

import com.qc.entity.PR_GETCITIES_DTLS;

public interface GetCitiesDao 
{
	public List<Object[]> getCitiesService(PR_GETCITIES_DTLS req);
	
	
}
