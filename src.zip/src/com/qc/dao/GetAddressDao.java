package com.qc.dao;

import java.util.List;

import com.qc.entity.PR_GETADDRESS_DTLS;

public interface GetAddressDao {

	public List<Object[]> getAddressService(PR_GETADDRESS_DTLS req);
}
