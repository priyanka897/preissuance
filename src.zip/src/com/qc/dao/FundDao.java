package com.qc.dao;

import java.util.List;

import com.qc.api.response.current.nav.ResCurrentNav;
import com.qc.api.response.fund.ResFundName;
import com.qc.api.response.nav.ResNav;
import com.qc.api.response.plan.ResPlanName;
import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;

public interface FundDao 
{
	public List<ResFundName> getFundDetails();
	public List<ResPlanName> getPlanDetails();
	public List<ResNav> getNavDetails(PR_GETAGNTINFO_TPP_NAV_DTLS req);
	public List<ResCurrentNav> getCurrentNavDetails(PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req);
	
}
