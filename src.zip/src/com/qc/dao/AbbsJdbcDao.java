package com.qc.dao;

import java.util.List;

import com.qc.api.request.abbreviation.AbbreviationRequest;
import com.qc.api.request.abbreviation.Abbs;
import com.qc.api.response.abbreviation.AbbAllTransactions;
import com.qc.api.response.abbreviation.AbbGetTransactions;



public interface AbbsJdbcDao {

	String addAbbreviationDao(AbbreviationRequest abbsRequest);
	List<AbbGetTransactions> getAbbreviationDao(String abbsRequest);
	List<AbbAllTransactions> allAbbreviationDao();
	
	//*******DAO Added for Web App***********
	List<Abbs> searchAbbreviationDao(String abbsRequest);
	String deleteAbbreviationDao(String abbsRequest);
}
