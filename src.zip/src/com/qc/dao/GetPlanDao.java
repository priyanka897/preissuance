package com.qc.dao;

import java.util.List;


import com.qc.entity.PR_GETMAXCITIES_DTLS;
import com.qc.entity.PR_GETPLAN_DTLS;

public interface GetPlanDao 
{
	public List<Object[]> getPlanService(PR_GETPLAN_DTLS req);
	
	
}
