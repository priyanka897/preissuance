package com.qc.model;

public class Events 
{
	private String type;
	private int eKuods;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int geteKuods() {
		return eKuods;
	}
	public void seteKuods(int eKuods) {
		this.eKuods = eKuods;
	}
	
		

}
