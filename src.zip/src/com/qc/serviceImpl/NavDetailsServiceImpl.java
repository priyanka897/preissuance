package com.qc.serviceImpl;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.current.nav.ApiRequestCurrentNav;
import com.qc.api.request.fund.ApiRequestFundName;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.request.plan.ApiRequestPlanName;
import com.qc.api.response.StringConstants;
import com.qc.api.response.current.nav.ApiResponseCurrentNav;
import com.qc.api.response.current.nav.ApiResponseCurrentNavDetails;
import com.qc.api.response.current.nav.PayloadResCurrentNav;
import com.qc.api.response.current.nav.PayloadResCurrentNavDetails;
import com.qc.api.response.current.nav.ResCurrentNav;
import com.qc.api.response.current.nav.ResCurrentNavDetails;
import com.qc.api.response.current.nav.ResponseCurrentNav;
import com.qc.api.response.current.nav.ResponseCurrentNavDetails;
import com.qc.api.response.fund.ApiResponseFundName;
import com.qc.api.response.fund.PayloadResFundName;
import com.qc.api.response.fund.ResFundName;
import com.qc.api.response.fund.ResponseFundName;
import com.qc.api.response.nav.ApiResponseNav;
import com.qc.api.response.nav.ApiResponseNavDetails;
import com.qc.api.response.nav.PayloadResNav;
import com.qc.api.response.nav.PayloadResNavDetails;
import com.qc.api.response.nav.ResNav;
import com.qc.api.response.nav.ResNavDetails;
import com.qc.api.response.nav.ResponseNav;
import com.qc.api.response.nav.ResponseNavDetails;
import com.qc.api.response.plan.ApiResponsePlanName;
import com.qc.api.response.plan.PayloadResPlanName;
import com.qc.api.response.plan.ResPlanName;
import com.qc.api.response.plan.ResponsePlanName;
import com.qc.dao.FundDao;
import com.qc.dao.FundNavDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;
import com.qc.service.NavFundService;
import com.qc.service.ObjectToPojoService;

@Service
public class NavDetailsServiceImpl implements NavFundService
{
	private static Logger logger = LogManager.getLogger(NavDetailsServiceImpl.class);

	@Autowired
	FundDao fundDao;
	
	@Autowired
	FundNavDao fundNavDao;
	
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	public ApiResponseFundName getFundDetails(ApiRequestFundName apiRequest) 
	{
		logger.info("navdetails :: NavDetailsServiceImpl :: getFundDetails : Start");
		ApiResponseFundName response = new ApiResponseFundName();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseFundName responseFundName = new ResponseFundName();
		List<ResFundName> gnvaDetails = null;
		PayloadResFundName payloadResFundName=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");

			List navData = fundNavDao.getFundDetails();

			
			if(navData!=null)
			{
				if(!navData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(navData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResFundName>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResFundName agentDetail  = dozerBeanMapper.map(mapObj, ResFundName.class);
								gnvaDetails.add(agentDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResFundName=new PayloadResFundName();
						payloadResFundName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseFundName.setPayload(payloadResFundName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C601);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C601DESC);
						logger.info(StringConstants.C601DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseFundName.setMsginfo(msginfo);
		responseFundName.setPayload(payloadResFundName);
		response.setResponse(responseFundName);
		logger.info("navdetails :: NavDetailsServiceImpl :: getFundDetails :End");
		return response;
	}

	@Override
	public ApiResponseNavDetails getNavDetails(ApiRequestNav apiRequest) {

		logger.info("navdetails :: NavDetailsServiceImpl :: getNavDetails : Start");
		ApiResponseNavDetails response = new ApiResponseNavDetails();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseNavDetails responseFundName = new ResponseNavDetails();
		List<ResNavDetails> gnvaDetails = null;
		PR_GETAGNTINFO_TPP_NAV_DTLS req = null;
		PayloadResNavDetails payloadResFundName=null;
		try 
		{
			req = new PR_GETAGNTINFO_TPP_NAV_DTLS();
			req.setPlanName(apiRequest.getRequest().getRequestData().getPlanName());
			
			logger.debug("Select data Call from service to Dao : Start");

			List navData = fundNavDao.getNavDetails(req);

			
			if(navData!=null)
			{
				if(!navData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(navData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResNavDetails>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResNavDetails navDetail  = dozerBeanMapper.map(mapObj, ResNavDetails.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResFundName=new PayloadResNavDetails();
						payloadResFundName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseFundName.setPayload(payloadResFundName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C601);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C601DESC);
						logger.info(StringConstants.C601DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			}
			
			else 
			{

				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseFundName.setMsginfo(msginfo);
		responseFundName.setPayload(payloadResFundName);
		response.setResponse(responseFundName);
		logger.info("navdetails :: NavDetailsServiceImpl :: getNavDetails : End");
		return response;
	
	}

	@Override
	public ApiResponsePlanName getPlanDetails(ApiRequestPlanName apiRequest) {


		logger.info("navdetails :: NavDetailsServiceImpl :: getPlanDetails : Start");
		ApiResponsePlanName response = new ApiResponsePlanName();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponsePlanName responsePlanName = new ResponsePlanName();
		List<ResPlanName> gnvaDetails = null;
		PayloadResPlanName payloadResPlanName=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");
			List PlanData = fundNavDao.getPlanDetails();

			
			if(PlanData!=null)
			{
				if(!PlanData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(PlanData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResPlanName>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResPlanName navDetail  = dozerBeanMapper.map(mapObj, ResPlanName.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResPlanName=new PayloadResPlanName();
						payloadResPlanName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responsePlanName.setPayload(payloadResPlanName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C601);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C601DESC);
						logger.info(StringConstants.C601DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responsePlanName.setMsginfo(msginfo);
		responsePlanName.setPayload(payloadResPlanName);
		response.setResponse(responsePlanName);
		logger.info("navdetails :: NavDetailsServiceImpl :: getPlanDetails : End");
		return response;
	
	
}

	@Override
	public ApiResponseCurrentNavDetails getCurrentNavDetails(ApiRequestCurrentNav apiRequest) {


		logger.info("navdetails :: NavDetailsServiceImpl :: getCurrentNavDetails : Start");
		ApiResponseCurrentNavDetails response = new ApiResponseCurrentNavDetails();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseCurrentNavDetails responseCurrentNav = new ResponseCurrentNavDetails();
		List<ResCurrentNavDetails> gnvaDetails = null;
		PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req = null;
		PayloadResCurrentNavDetails payloadResCurrentNav=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");
			req = new PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS();
			
			
			req.setPlanCode(apiRequest.getRequest().getRequestData().getPlanCode());
			req.setNavFromDate(apiRequest.getRequest().getRequestData().getNavFromDate());
			req.setNavToDate(apiRequest.getRequest().getRequestData().getNavToDate());
			req.setPlanName(apiRequest.getRequest().getRequestData().getPlanName());
			
			List PlanData = fundNavDao.getCurrentNavDetails(req);

			
			if(PlanData!=null)
			{
				if(!PlanData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(PlanData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResCurrentNavDetails>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResCurrentNavDetails navDetail  = dozerBeanMapper.map(mapObj, ResCurrentNavDetails.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResCurrentNav=new PayloadResCurrentNavDetails();
						payloadResCurrentNav.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseCurrentNav.setPayload(payloadResCurrentNav);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C601);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C601DESC);
						logger.info(StringConstants.C601DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCurrentNav.setMsginfo(msginfo);
		responseCurrentNav.setPayload(payloadResCurrentNav);
		response.setResponse(responseCurrentNav);
		logger.info("navdetails :: NavDetailsServiceImpl :: getCurrentNavDetails : End");
		return response;
	
	
}

}