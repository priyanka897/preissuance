package com.qc.serviceImpl;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.dozer.DozerBeanMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.getneopincodecity.ApiRequestNeoPincodeCity;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getneopincodecity.ApiResponseNeoPincodeCity;
import com.qc.api.response.getneopincodecity.Location;
import com.qc.api.response.getneopincodecity.PayloadNeoPincodeCity;
import com.qc.api.response.getneopincodecity.PlanDetails;
import com.qc.api.response.getneopincodecity.ResponseNeoPincodeCity;
import com.qc.dao.NeoDao;
import com.qc.service.ObjectToPojoService;
import com.qc.service.PincodeCityService;
import com.qc.utils.XTrustProviderSSL;

@Service
public class PincodeCityServiceImpl implements PincodeCityService {

private static Logger logger = LogManager.getLogger(PincodeCityServiceImpl.class);
	
	@Autowired ObjectToPojoService objectToPojoService;
	@Autowired DozerBeanMapper dozerBeanMapper;
	@Autowired NeoDao neoDao;

	private static ResourceBundle res = ResourceBundle.getBundle("application");
	@Override
	public ApiResponseNeoPincodeCity getPincodeDetails(ApiRequestNeoPincodeCity apiRequest) {
	
		logger.info("PincodeCityServiceImpl service : Start");
		MsgInfo msgInfo = new MsgInfo();
		ResponseNeoPincodeCity response = new ResponseNeoPincodeCity();
		PayloadNeoPincodeCity payload = new PayloadNeoPincodeCity();
		ApiResponseNeoPincodeCity apiResponse =new ApiResponseNeoPincodeCity();
//		PlanDetails planDetails;
		List<Location> listLocation= new ArrayList<Location>();
		List<PlanDetails> listplanDetails= new ArrayList<PlanDetails>();
		Map<String,Map<?, ?>> planDetail = new HashMap<String,Map<?, ?>>();
		Map<String,Map<?, ?>> locationDetail = new HashMap<String,Map<?, ?>>();
		String isNegativeArea ="";
		String flag="";
		try 
		{
			
			logger.info("Proc Call from service to DB : Start");
			
			List<Object[]> pincodeRelatedData= neoDao.callPincodeDetails(apiRequest);
			if(pincodeRelatedData!=null)
		{
				if(!pincodeRelatedData.isEmpty())
				{
				logger.info("Proc Call from service to DB : End");
					
					List<Map<String , String>> result = objectToPojoService.getCustomClass(pincodeRelatedData);
					logger.info("data from database ::" +result.toString());
					if(result != null && result.size() > 0)
					{
						for(Map<?, ?> mapObj : result )
						{
							try
							{
								if(planDetail.containsKey(mapObj.get("key1").toString())){
									logger.info("planDetals contain same key from database");
								}else{
									planDetail.put(mapObj.get("key1").toString(), mapObj);
								}
								if(locationDetail.containsKey(mapObj.get("key4").toString())){
									logger.info("location city contain same key from database");
								}else{
									locationDetail.put(mapObj.get("key4").toString(), mapObj);
								}
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
						for(Map.Entry<String,Map<?, ?>> entry : locationDetail.entrySet() )
						{
							Location locatioDetails =new Location();;
							Map<?, ?> data=entry.getValue();
							 flag = maillingFinance(data);
							locatioDetails.setCity(data.get("key4").toString());
							locatioDetails.setStateCode(data.get("key5").toString());
							locatioDetails.setStateName(data.get("key6").toString());
							listLocation.add(locatioDetails);
						}
						for(Map.Entry<String,Map<?, ?>> entry : planDetail.entrySet() )
						{
							PlanDetails planDetails =new PlanDetails();;
							Map<?, ?> data=entry.getValue();
							planDetails.setPlanName(data.get("key1").toString());
							planDetails.setMedicalCentresAvailability(flag);
							planDetails.setIsPinCodeValid(data.get("key2").toString());
							 listplanDetails.add(planDetails);
						}
						 isNegativeArea = result.get(0).get("key3").toString();
					}
					logger.info("Going to get pincode Data From DB : End");
			
					if(payload!=null && listplanDetails!=null &&  listplanDetails.size()>0 && listLocation!=null && listLocation.size()>0 && !isNegativeArea.equalsIgnoreCase("") && !flag.equalsIgnoreCase("failed"))
					{
						payload.setLocation(listLocation);
						payload.setPlanDetails(listplanDetails);
						payload.setIsNegativeArea(isNegativeArea);
						response.setPayload(payload);
						msgInfo.setMsgCode(StringConstants.C200);
						msgInfo.setMsg(StringConstants.SUCCESS);
						msgInfo.setMsgDescription(StringConstants.C200DESC);
						logger.info(StringConstants.C200DESC);
					}
					else if(flag!=null && flag.equalsIgnoreCase("failed"))
					{
						msgInfo.setMsgCode(StringConstants.C601);
						msgInfo.setMsg(StringConstants.FAILURE);
						msgInfo.setMsgDescription(StringConstants.C604DESC);
						logger.info(StringConstants.C604DESC);
					}
						else
						{
						msgInfo.setMsgCode(StringConstants.C601);
						msgInfo.setMsg(StringConstants.FAILURE);
						msgInfo.setMsgDescription(StringConstants.C603DESC);
						logger.info(StringConstants.C603DESC);
					}
				}
				else 
				{
					msgInfo.setMsgCode(StringConstants.C700);
					msgInfo.setMsg(StringConstants.FAILURE);
					msgInfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
		}
		else 
		{
					msgInfo.setMsgCode(StringConstants.C700);
					msgInfo.setMsg(StringConstants.FAILURE);
					msgInfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
		}
		}
		catch (Exception e)
		{
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		response.setMsgInfo(msgInfo);
		apiResponse.setResponse(response);
		logger.info("PincodeCityServiceImpl service : End");
		return apiResponse;
		
	}
	
	
	public String maillingFinance(Map<?, ?> request) {
		String serviceurl=res.getString("getneopincity.url");
		String output = new String();
		StringBuilder result = new StringBuilder();
		String DevMode = "N";
		HttpURLConnection conn = null;
		String responseCode = "";
		String flag = "No" ;
		JSONObject object = null;
		StringBuilder requestdata = new StringBuilder();
		logger.info("mail to connect with  URL starts...");

		try {
			
			requestdata.append("	{ ");
			requestdata.append("    \"request\": {  ");
			requestdata.append("        \"header\": {  ");
			requestdata.append("            \"soaCorrelationId\": \"12345\",  ");
			requestdata.append("			            \"soaAppId\": \"NEO\"  ");
			requestdata.append("			        }, ");
			requestdata.append("			        \"payload\": {   ");
			requestdata.append("			            \"state\": \""+request.get("key5")+"\",   ");
			requestdata.append("			            \"commPincode\": \""+request.get("key0")+"\",  ");
			requestdata.append("			            \"city\": \""+request.get("key4")+"\" ");
			requestdata.append("			        }");
			requestdata.append("			    }");
			requestdata.append("			} ");
			
			
			//			XTrustProvider trustProvider = new XTrustProvider();
			//			trustProvider.install();
			XTrustProviderSSL.trustHttps();
			URL url = new URL(serviceurl);
			logger.info("getneopincity to connect with  URL ..." + serviceurl);

			// String DevMode =
			// env.getProperty("spring.enable.proxy.development");
			if (DevMode != null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y")) {
				Proxy proxy = new Proxy(Proxy.Type.HTTP,
						new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
			} else {
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			// conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");
			logger.info("Going to connect to  URL ..." + url + "  with request param   " + requestdata);

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {
				writer.close();
			} catch (Exception e1) {
			}

			int apiResponseCode = conn.getResponseCode();
			responseCode = String.valueOf(apiResponseCode);
			// System.out.println(apiResponseCode);
			if (apiResponseCode == 200) {
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}

				object = new JSONObject(result.toString());
				
				if(object.getJSONObject("response").getJSONObject("msginfo").has("msginfo"))
				{
				String status=(object.getJSONObject("response").getJSONObject("msginfo").getJSONObject("msginfo").get("msg")).toString();
				if(status != null && !status.equalsIgnoreCase("") && status.equalsIgnoreCase("Success"))
				{
					try{
					JSONArray payload=	(object.getJSONObject("response").getJSONObject("msginfo").getJSONArray("payload"));
					if(payload!=null && payload.length()>0)
					{
					logger.info("data found  successfully  ");
					flag ="Yes";
					}else{
						flag ="No";
					}
					}catch(Exception e){
						logger.info("Error in execution  :: responce mismatch from api::" + e);
					}
				}else{
					flag ="No";
					logger.info("data not found from soa service for");
				}
				}else{
					String status=(object.getJSONObject("response").getJSONObject("msginfo").get("msg")).toString();
					String statusCode=(object.getJSONObject("response").getJSONObject("msginfo").get("msgCode")).toString();
					logger.info("Api give failure responce " +status +" and given code is ::" +statusCode);
					flag ="No";
				}
				conn.disconnect();
				br.close();
			}
			else{
				try{
					flag="failed";
					BufferedReader br = new BufferedReader(new InputStreamReader((conn.getErrorStream())));
					while ((output = br.readLine()) != null) {
						result.append(output);
					}
					logger.info("failed message ::  " +result.toString());
					conn.disconnect();
					br.close();
				}catch(Exception e){
					logger.error("failed jason parsing have some error::" +e);
				}
			}
		} catch (Exception ex) {
			logger.error("Error in execution  :: method  maillingFinance::" + ex);
			// System.out.println(ex);
		}
		logger.info("getneopincity is successfilly finished with response  " + result.toString());

		return flag;
	}
}
