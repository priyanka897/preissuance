package com.qc.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.request.abbreviation.AbbreviationRequest;
import com.qc.api.request.abbreviation.Abbs;
import com.qc.api.request.abbreviation.ApiRequest;
import com.qc.api.response.abbreviation.AbbAllTransactions;
import com.qc.api.response.abbreviation.AbbGetTransactions;
import com.qc.api.response.abbreviation.ApiResponse;
import com.qc.api.response.abbreviation.ErrorInfo;
import com.qc.api.response.abbreviation.HeaderResponse;
import com.qc.api.response.abbreviation.Payload;
import com.qc.dao.AbbsJdbcDao;
import com.qc.service.AbbsJdbcService;

@Service
public class AbbsJdbcServiceImpl implements AbbsJdbcService 
{
	private static Logger logger = LogManager.getLogger(AbbsJdbcServiceImpl.class);

	@Autowired
	AbbsJdbcDao eappDao;

	HeaderResponse header;
	ApiResponse response;
	Payload payload;
	ErrorInfo errorInfo;
	String statusCode="400";
	String message="";
	String status="FAILURE";
	String correlationId="";
	private static final String DATA_NOT_FOUND = "Data not found from Database!";
	private static final String DATA_FOUND = "Data fetched successfully!";
	
	@SuppressWarnings("null")
	@Override
	public ApiResponse addAbbService(ApiRequest apiRequest) {
		logger.info("Inside AbbsHibernetServiceImpl---> addAbbService: STARTS");
		 header=new HeaderResponse();
		 payload=new Payload();
		 errorInfo=new ErrorInfo();
		AbbreviationRequest abbsReq=apiRequest.getPayload().getTransactions();
		
		try
		{
				correlationId=apiRequest.getHeader().getSoaCorrelationId();
				header.setSoaAppId(apiRequest.getHeader().getSoaAppId());
				header.setSoaCorrelationId(correlationId);
				header.setSoaMsgVersion(apiRequest.getHeader().getSoaMsgVersion());
				if(!"".equals(apiRequest.getPayload().getTransactions().getShortform())
						&& !"".equals(apiRequest.getPayload().getTransactions().getFullform())
						&& !"".equals(apiRequest.getPayload().getTransactions().getDepartment())
						&& !"".equals(correlationId))
				{
					message=eappDao.addAbbreviationDao(abbsReq);
					if("SUCCESS".equalsIgnoreCase(message)){
						statusCode="200";
						status="SUCCESS";
						message="Data Created successfully!";
						logger.info("Data Created successfully!");
					}else{
						status="FAILURE";
						statusCode="400";
						message="Data not Created in Database!";
						logger.info("Data not Created in Database!");
					}
				}else{
					status="FAILURE";
					statusCode="400";
					message="ShortForm and Correlation Id can't be blank!";	
					logger.info("ShortForm and Correlation Id can't be blank!");
				}
			
		}catch(Exception e){
			status="FAILURE";
			statusCode="500";
			message="Invalid Request JSON!";
			logger.info("Invalid Request JSON!"+e);
		}
		payload.setTransactions(message);
		errorInfo.setCode(statusCode);
		errorInfo.setStatus(status);
		errorInfo.setMessage(message);
		response = new ApiResponse(header,errorInfo,payload);
		logger.info("Inside AbbreviationServiceImpl---> addAbbService: ENDS");
		return response;
	}

	@SuppressWarnings("null")
	@Override
	public ApiResponse getAbbService(ApiRequest apiRequest) 
	{
		logger.info("Inside AbbsHibernetServiceImpl---> getAbbService: STARTS");
		 header=new HeaderResponse();
		 payload=new Payload();
		List<AbbGetTransactions> transactions=new ArrayList<>();
		 errorInfo=new ErrorInfo();
		try
		{
				correlationId=apiRequest.getHeader().getSoaCorrelationId();
				header.setSoaAppId(apiRequest.getHeader().getSoaAppId());
				header.setSoaCorrelationId(correlationId);
				header.setSoaMsgVersion(apiRequest.getHeader().getSoaMsgVersion());
				String shortForm=apiRequest.getPayload().getTransactions().getShortform();
				if(!"".equals(shortForm) && !"".equals(correlationId)){
					transactions=eappDao.getAbbreviationDao(shortForm);
					if(transactions!=null && !transactions.isEmpty()){
						statusCode="200";
						status="SUCCESS";
						message=DATA_FOUND;
						logger.info(DATA_FOUND);
					}else{
						status="FAILURE";
						statusCode="400";
						message=DATA_NOT_FOUND;
						logger.info(DATA_NOT_FOUND);
					}
				}else{
					status="FAILURE";
					statusCode="400";
					message="ShortForm and CorrelationId  can't be blank!";	
					logger.info("ShortForm and CorrelationId  can't be blank!");
				}
			
		}catch(Exception e){
			status="FAILURE";
			statusCode="500";
			message="Invalid Request JSON!";
			logger.info("Invalid Request JSON!"+e);
		}
		payload.setTransactions(transactions);
		errorInfo.setCode(statusCode);
		errorInfo.setStatus(status);
		errorInfo.setMessage(message);
		response = new ApiResponse(header,errorInfo,payload);
		logger.info("Inside AbbreviationServiseImpl---> getAbbService: ENDS");
		return response;
	}


	@Override
	public ApiResponse allAbbService(ApiRequest apiRequest) 
	{
		logger.info("Inside AbbreviationServiceImpl---> allAbbService: STARTS");
		 header=new HeaderResponse();
		 payload=new Payload();
		 response=null;
		List<AbbAllTransactions> transactions=new ArrayList<AbbAllTransactions>();
	     errorInfo=new ErrorInfo();
		try
		{
				correlationId=apiRequest.getHeader().getSoaCorrelationId();
				header.setSoaAppId(apiRequest.getHeader().getSoaAppId());
				header.setSoaCorrelationId(correlationId);
				header.setSoaMsgVersion(apiRequest.getHeader().getSoaMsgVersion());
				if(!"".equals(correlationId)){
					transactions=eappDao.allAbbreviationDao();
					if(transactions!=null){
						statusCode="200";
						status="SUCCESS";
						message=DATA_FOUND;
					}else{
						status="FAILURE";
						statusCode="400";
						message=DATA_NOT_FOUND;
						logger.info(DATA_NOT_FOUND);
					}
				}else{
					status="FAILURE";
					statusCode="400";
					message="correlationId can't be blank!";
					logger.info("correlationId can't be blank!");
				}
		}catch(Exception e){
			status="FAILURE";
			statusCode="500";
			message="Invalid Request JSON!";
			logger.info("Invalid Request JSON! "+e);
		}
		payload.setTransactions(transactions);
		errorInfo.setCode(statusCode);
		errorInfo.setStatus(status);
		errorInfo.setMessage(message);
		response = new ApiResponse(header,errorInfo,payload);
		logger.info("Inside AbbreviatioServiceImple :allAbbService:: ENDS");
		return response;
	}

	@Override
	public List<Abbs> serachService(String short_form) 
	{
		logger.info("Inside AbbsHibernetServiceImpl---> serachService: STARTS");
		List<Abbs> searchList=new ArrayList<>();
		try
		{
			if(!"".equals(short_form))
			{
				searchList=eappDao.searchAbbreviationDao(short_form);
				if(searchList!=null && !searchList.isEmpty())
				{
					logger.info("Data fetched successfully!");
				}
				else
				{
					logger.info("Data not found from Database!");
				}
			}
			else
			{
				logger.info("ShortForm can't be blank!");
			}
		}
		catch(Exception e){
			logger.info("Invalid Request JSON!"+e);
		}
		logger.info("Inside AbbreviationServiseImpl---> serachService: ENDS");
		return searchList;

	}

	@Override
	public String deletesService(String sn) {
		logger.info("Inside AbbsHibernetServiceImpl---> deletesService: STARTS");
	    message="Failure";
		try
		{
			if(!"".equals(sn))
			{
				message=eappDao.deleteAbbreviationDao(sn);
				if("SUCCESS".equalsIgnoreCase(message))
				{
					logger.info("Data fetched successfully!");
				}
				else
				{
					logger.info("Data not found from Database!");
				}
			}
			else
			{
				logger.info("SN can't be blank!");
			}
		}
		catch(Exception e){
			logger.info("Exception Occured in :deletesService"+e);
		}
		logger.info("Inside AbbreviationServiseImpl---> deletesService: ENDS");
		return message;
	}


}
