package com.qc.serviceImpl;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;

import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.request.navservices.ApiUpdateRequestNav;
import com.qc.api.request.updateNavAlert.ApiUpdateRequestSetNav;
import com.qc.api.request.updateNavAlert.PayloadSetReqNav;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getNav.ApiResponseGetNavDetails;
import com.qc.api.response.getNav.PayloadResGetNav;
import com.qc.api.response.getNav.UpdateResponseSetNav;
import com.qc.api.response.illustration.ApiResponseIllustration;
import com.qc.api.response.illustration.PayloadResIllustration;
import com.qc.api.response.illustration.UpdateResponseIllustration;
import com.qc.api.response.navservices.ApiResponseNav;
import com.qc.api.response.navservices.ApiUpdateResponseNav;
import com.qc.api.response.navservices.PayloadResNav;
import com.qc.api.response.navservices.PayloadUpdateResNav;
import com.qc.api.response.navservices.ResNav;
import com.qc.api.response.navservices.ResponseNav;
import com.qc.api.response.navservices.UpdateResponseNav;
import com.qc.api.response.updateNavAlert.ApiUpdateResponseSetNav;
import com.qc.api.response.updateNavAlert.UpdateResponseUpdateNav;
import com.qc.dao.NavDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_PLCY_DTLS;
import com.qc.entity.PR_GETNAVINFO_TPP_PLCY_DTLS;
import com.qc.service.NavService;

@Service
public class NavServiceImpl implements NavService
{
	private static Logger logger = LogManager.getLogger(NavServiceImpl.class);

	@Autowired
	NavDao navDao;

	@Override
	public com.qc.api.response.navservices.ApiResponseNav getNavDetails(ApiRequestNav apiRequest) 
	{
		logger.info("getNavDetails service : Start");
		ApiResponseNav response = new ApiResponseNav();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadResNav resPayload = null;
		ResponseNav responseNav = new ResponseNav();
		ResNav resNavNew = new ResNav();
		PR_GETAGNTINFO_TPP_PLCY_DTLS req = null;
		try 
		{
			req = new PR_GETAGNTINFO_TPP_PLCY_DTLS();
			req.setPolicyid(apiRequest.getRequest().getRequestData().getPolicyid());
			logger.debug("Select query Call from service to DB : Start");

			String navData = navDao.getNavService(req);
			if (navData != null) 
			{
				if (!navData.isEmpty())
				{
					if ("Y".equalsIgnoreCase(navData))
					{
						resNavNew.setSmsStatus("N");
					} 
					else 
					{
						resNavNew.setSmsStatus("Y");
					}
					resPayload = new PayloadResNav();
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					logger.info(StringConstants.C200DESC);
				}
				else 
				{
					msginfo.setMsgCode(StringConstants.C601);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			} 
			else 
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}

		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		responseNav.setMsginfo(msginfo);
		responseNav.setResponseData(resNavNew);
		response.setResponse(responseNav);
		logger.info("get Nav service : End");
		return response;
	}

	@Override
	public ApiUpdateResponseNav getUpdateNavDetails(ApiUpdateRequestNav apiRequest) 
	{
		logger.info("get Nav Details service : Start");
		ApiUpdateResponseNav response = new ApiUpdateResponseNav();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadUpdateResNav resPayload = null;
		PR_GETNAVINFO_TPP_PLCY_DTLS req = null;
		UpdateResponseNav responseNav = new UpdateResponseNav();
		try
		{
			req = new PR_GETNAVINFO_TPP_PLCY_DTLS();
			req.setPolicyid(apiRequest.getRequest().getRequestData().getPolicyid());
			req.setSmsstatus(apiRequest.getRequest().getRequestData().getSmsstatus());
			logger.debug("select query from service to DB : Start");

			if(("Y").equalsIgnoreCase(req.getSmsstatus()))
			{
				req.setSmsstatus("N");
			}
			else
			{
				req.setSmsstatus("Y");
			}
			int navData = navDao.getUpdateNavDetails(req);

			if (navData > 0) 
			{
				resPayload = new PayloadUpdateResNav();
				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(StringConstants.C200DESC);
				logger.info(StringConstants.C200DESC);
			} 
			else
			{
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C601DESC);
				logger.info(StringConstants.C601DESC);
			}
		} 
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		responseNav.setMsginfo(msginfo);
		response.setResponse(responseNav);
		logger.info("get Nav service : End");
		return response;
	}
	
	@Override
	public ApiUpdateResponseSetNav getUpdateNavAlert(ApiUpdateRequestSetNav apiRequest) {
		logger.info("get Nav Details service : Start");
		ApiUpdateResponseSetNav response = new ApiUpdateResponseSetNav();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadSetReqNav req = null;
		String status = null;
		UpdateResponseUpdateNav responseNav = new UpdateResponseUpdateNav();

		try {
			req = new PayloadSetReqNav();
			req.setPolicyNo(apiRequest.getRequest().getPayload().getPolicyNo());
			req.setTransactionType(apiRequest.getRequest().getPayload().getTransactionType());
			logger.debug("select query from service to DB : Start");

			String policyNumber = apiRequest.getRequest().getPayload().getPolicyNo();
			String transactionType = apiRequest.getRequest().getPayload().getTransactionType();

			status = navDao.getUpdateAlertNav(policyNumber, transactionType);

			if (status.equalsIgnoreCase("Updated successfully") || status.equalsIgnoreCase("Inserted successfully")) {
				msginfo.setMsgCode(StringConstants.C200);
				msginfo.setMsg(StringConstants.SUCCESS);
				msginfo.setMsgDescription(status);
				logger.info(StringConstants.C200DESC);
				msginfo.setMsgDescription(status);
			} else if (status.equalsIgnoreCase("Already activated/deactivated")) {
				msginfo.setMsgCode(StringConstants.C702);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C702DESC);
				logger.info(StringConstants.C702DESC);
			} else if (status.equalsIgnoreCase("Invalid transaction type")) {
				msginfo.setMsgCode(StringConstants.C601);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C601DESC2);
				logger.info(StringConstants.C601DESC2);
			}
		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C700);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C700DESC);
			logger.info(StringConstants.C700DESC);
		}

		responseNav.setMsgInfo(msginfo);
		response.setResponse(responseNav);
		logger.info("get Nav service : End");
		return response;
	}
	@Override
	public ApiResponseIllustration getIllustration(String policyNumber) {
		logger.info("getNavDetails service : Start");
		ApiResponseIllustration response = new ApiResponseIllustration();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadResIllustration resPayload = null;
		UpdateResponseIllustration responseNav = new UpdateResponseIllustration();
		try {
			logger.debug("Select query Call from service to DB : Start");

			List<Map> navData = navDao.illustrationDao(policyNumber);

			if (navData != null) {
				if (!navData.isEmpty()) {
					resPayload = new PayloadResIllustration();

					resPayload.setFundValueUpper(navData.get(0));
					resPayload.setFundValueLower(navData.get(1));
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					logger.info(StringConstants.C200DESC);
				} else {
					msginfo.setMsgCode(StringConstants.C700);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			} else {
				msginfo.setMsgCode(StringConstants.C700);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}

		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		responseNav.setMsgInfo(msginfo);
		responseNav.setPayload(resPayload);
		response.setResponse(responseNav);
		logger.info("get Nav service : End");
		return response;
	}
	public ApiResponseGetNavDetails getNavPolicyDetails(String policyNumber) {
		logger.info("getNavDetails service : Start");
		String convertedDate = "";
		ApiResponseGetNavDetails response = new ApiResponseGetNavDetails();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadResGetNav resPayload = null;
		UpdateResponseSetNav responseNav = new UpdateResponseSetNav();
		ResNav resNavNew = new ResNav();
		try {
			logger.debug("Select query Call from service to DB : Start");

			List<Object> navData = navDao.getNavDetailDao(policyNumber);

			if (navData != null) {
				if (!navData.isEmpty()) {
					String date = "";
					try {
						date = navData.get(1).toString().substring(1, navData.get(1).toString().length() - 1);
						DateFormat userDateFormat = new SimpleDateFormat("dd-mm-yyyy");
						DateFormat dateFormatNeeded = new SimpleDateFormat("yyyy-mm-dd");
						Date date1 = userDateFormat.parse(date);
						convertedDate = dateFormatNeeded.format(date1);

					} catch (Exception e) {
						logger.error("Unable to parse date" + e);
					}

					resPayload = new PayloadResGetNav();
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					logger.info(StringConstants.C200DESC);
					resPayload.setNavRegistrationStatus(navData.get(0).toString());
					resPayload.setNavRegistrationValidity(convertedDate);
				} else {
					msginfo.setMsgCode(StringConstants.C700);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			} else {
				msginfo.setMsgCode(StringConstants.C700);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
			}

		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		responseNav.setMsgInfo(msginfo);
		responseNav.setPayload(resPayload);
		response.setResponse(responseNav);
		logger.info("get Nav service : End");
		return response;
	}
	@Override
	public boolean checkValidPolicyNumber(String policyNum)
	{
		return navDao.checkValidPoilcyNumber(policyNum);
	}
}
