package com.qc.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.request.getplanname.ApiRequestGetPlan;
import com.qc.api.request.getstates.ApiRequestGetStates;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getaddress.ResGetAddress;
import com.qc.api.response.getcountry.ResGetCountry;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;
import com.qc.api.response.getmaxcities.PayloadResGetMaxCities;
import com.qc.api.response.getmaxcities.ResGetMaxCities;
import com.qc.api.response.getmaxcities.ResponseGetMaxCities;
import com.qc.api.response.getplanname.ApiResponseGetPlan;
import com.qc.api.response.getplanname.PayloadResGetPlan;
import com.qc.api.response.getplanname.ResGetPlan;
import com.qc.api.response.getplanname.ResponseGetPlan;
import com.qc.api.response.getstates.ApiResponseGetStates;
import com.qc.api.response.getstates.PayloadResGetStates;
import com.qc.api.response.getstates.ResGetStates;
import com.qc.api.response.getstates.ResponseGetStates;
import com.qc.dao.GetMaxCitiesDao;
import com.qc.dao.GetStateDao;
import com.qc.entity.PR_GETMAXCITIES_DTLS;
import com.qc.entity.PR_GETPLAN_DTLS;
import com.qc.entity.PR_GETSTATE_DTLS;
import com.qc.service.GetPlanService;
import com.qc.service.GetStateService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetStateServiceImpl implements GetStateService{

	private static Logger logger = LogManager.getLogger(GetStateServiceImpl.class);
	@Autowired
	GetStateDao getStateDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	@Transactional
	public ApiResponseGetStates getStateDetails(ApiRequestGetStates apiRequest) {
		logger.info("getStateDetails service : Start");
		ApiResponseGetStates response = new ApiResponseGetStates();
		@SuppressWarnings("unused")
		PayloadResGetStates resPayload = null;
		ResponseGetStates responsePlan = new ResponseGetStates();
		PR_GETSTATE_DTLS req = null;
		
		/*ResGetMaxCities claimedDetail=null;*/
		PayloadResGetStates plandetail= new PayloadResGetStates();
		try 
		{
			req = new PR_GETSTATE_DTLS();
			req.setCountry(apiRequest.getRequest().getRequestData().getCountry());
			logger.debug("Going to call getStateService  from service to DB : Start");

			List stateData =getStateDao.getStateService(req);
			if(stateData!=null)
			{
				if(!stateData.isEmpty())
				{
					logger.info("call object to pojo service : Start");
					List<Map<String , String>> result = objectToPojoService.getCustomClass(stateData);
					List<ResGetStates> stateList = new ArrayList<>();
					if(result != null && !result.isEmpty())
					{
						logger.info("call dozerBeanMapper : Start");
						for(Map<?, ?> mapObj : result)
						{
							ResGetStates state = dozerBeanMapper.map(mapObj, ResGetStates.class);
							stateList.add(state);
						}
					}
					plandetail.setState(stateList);
					plandetail.setSoaMessage(StringConstants.SUCCESS);
					plandetail.setSoaStatusCode(StringConstants.C200);
					plandetail.setSoaDescription(StringConstants.C200DESC);
					
						logger.info(StringConstants.C200DESC);
					}
					else
					{
						plandetail.setSoaStatusCode(StringConstants.C200);
						plandetail.setSoaMessage(StringConstants.SUCCESS);
						plandetail.setSoaDescription(StringConstants.C700DESC);
						logger.info(StringConstants.C700DESC);
					}
				}
				else
				{
					plandetail.setSoaStatusCode(StringConstants.C601);
					plandetail.setSoaMessage(StringConstants.FAILURE);
					plandetail.setSoaDescription(StringConstants.C600DESC);
					logger.info(StringConstants.C600DESC);
				}
		}
		catch(Exception e)
		{
			plandetail.setSoaStatusCode(StringConstants.C500);
			plandetail.setSoaMessage(StringConstants.FAILURE);
			plandetail.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responsePlan.setResponseData(plandetail);
		response.setResponse(responsePlan);
		logger.info("getStateDetails service : End");
		return response;
	}

}
