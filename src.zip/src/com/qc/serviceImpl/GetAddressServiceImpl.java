package com.qc.serviceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.getaddress.ApiRequestGetAddress;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getaddress.ApiResponseGetAddress;
import com.qc.api.response.getaddress.PayloadResGetAddress;
import com.qc.api.response.getaddress.ResGetAddress;
import com.qc.api.response.getaddress.ResponseGetAddress;
import com.qc.dao.GetAddressDao;
import com.qc.entity.PR_GETADDRESS_DTLS;
import com.qc.service.GetAddressService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetAddressServiceImpl implements GetAddressService{

	private static Logger logger = LogManager.getLogger(GetAddressServiceImpl.class);
	
	@Autowired
	GetAddressDao addressDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;
	
	@Override
	@Transactional
	public ApiResponseGetAddress getAddressDetails(ApiRequestGetAddress apiRequest) {
		logger.info("getAddressDetails service : Start");
		ApiResponseGetAddress response = new ApiResponseGetAddress();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		PayloadResGetAddress resPayload = null;
		ResponseGetAddress responseAddress = new ResponseGetAddress();
		
		PR_GETADDRESS_DTLS req = null;
		PayloadResGetAddress claimedDetail=new PayloadResGetAddress();
		try 
		{
			req = new PR_GETADDRESS_DTLS();
			req.setState(apiRequest.getRequest().getRequestData().getState());
			req.setCity(apiRequest.getRequest().getRequestData().getCity());
			req.setPinCode(apiRequest.getRequest().getRequestData().getPinCode());
			logger.debug("Going to call getAddressService  from service to DB : Start");

			List addressData =addressDao.getAddressService(req);
			if(addressData!=null)
			{
				if(!addressData.isEmpty())
				{
					logger.info("call object to pojo service : Start");
					List<Map<String , String>> result = objectToPojoService.getCustomClass(addressData);
					List<ResGetAddress> addresslist = new ArrayList<>();
					if(result != null && !result.isEmpty())
					{
						logger.info("call dozerBeanMapper : Start");
						for(Map<?, ?> mapObj : result)
						{
							ResGetAddress resaddress = dozerBeanMapper.map(mapObj, ResGetAddress.class);
							addresslist.add(resaddress);
						}
					}
						claimedDetail.setAddressDetails(addresslist);
						claimedDetail.setSoaMessage(StringConstants.SUCCESS);
						claimedDetail.setSoaStatusCode(StringConstants.C200);
						claimedDetail.setSoaDescription(StringConstants.C200DESC);
						logger.info(StringConstants.C200DESC);
					}
					else
					{
						claimedDetail.setSoaStatusCode(StringConstants.C200);
						claimedDetail.setSoaMessage(StringConstants.SUCCESS);
						claimedDetail.setSoaDescription(StringConstants.C700DESC);
						logger.info(StringConstants.C700DESC);
					}
				}
				else
				{
					claimedDetail.setSoaStatusCode(StringConstants.C601);
					claimedDetail.setSoaMessage(StringConstants.FAILURE);
					claimedDetail.setSoaDescription(StringConstants.C600DESC);
					logger.info(StringConstants.C600DESC);
				}
		}
		catch(Exception e)
		{
			claimedDetail.setSoaStatusCode(StringConstants.C500);
			claimedDetail.setSoaMessage(StringConstants.FAILURE);
			claimedDetail.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseAddress.setResponseData(claimedDetail);
		response.setResponse(responseAddress);
		logger.info("getAddressDetails service : End");
		return response;
	}

}
