package com.qc.serviceImpl;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.request.getplanname.ApiRequestGetPlan;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;
import com.qc.api.response.getmaxcities.PayloadResGetMaxCities;
import com.qc.api.response.getmaxcities.ResGetMaxCities;
import com.qc.api.response.getmaxcities.ResponseGetMaxCities;
import com.qc.api.response.getplanname.ApiResponseGetPlan;
import com.qc.api.response.getplanname.PayloadResGetPlan;
import com.qc.api.response.getplanname.ResGetPlan;
import com.qc.api.response.getplanname.ResponseGetPlan;
import com.qc.dao.GetMaxCitiesDao;
import com.qc.dao.GetPlanDao;
import com.qc.entity.PR_GETMAXCITIES_DTLS;
import com.qc.entity.PR_GETPLAN_DTLS;
import com.qc.service.GetPlanService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetPlanServiceImpl implements GetPlanService{

	private static Logger logger = LogManager.getLogger(GetPlanServiceImpl.class);
	@Autowired
	GetPlanDao getPlanDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;
	
	
	@Override
	@Transactional
	public ApiResponseGetPlan getPlanDetails(ApiRequestGetPlan apiRequest) {

			logger.info("getPlanDetails service : Start");
			ApiResponseGetPlan response = new ApiResponseGetPlan();
			@SuppressWarnings("unused")
			PayloadResGetPlan resPayload = null;
			ResponseGetPlan responsePlan = new ResponseGetPlan();
			PR_GETPLAN_DTLS req = null;
			
			/*ResGetMaxCities claimedDetail=null;*/
			PayloadResGetPlan plandetail= new PayloadResGetPlan();
			try 
			{
				req = new PR_GETPLAN_DTLS();
				req.setPlancategory(apiRequest.getRequest().getRequestData().getPlancategory());
				logger.debug("Going to call getPlanService  from service to DB : Start");

				List planData =getPlanDao.getPlanService(req);
				if(planData!=null)
				{
					if(!planData.isEmpty())
					{
 						logger.info("call object to pojo service : Start");
						List<Map<String , String>> result = objectToPojoService.getCustomClass(planData);
						List<ResGetPlan> planList = new ArrayList<>();
						if(result != null && !result.isEmpty())
						{
							logger.info("call dozerBeanMapper : Start");
							for(Map<?, ?> mapObj : result)
							{
								ResGetPlan plan = dozerBeanMapper.map(mapObj, ResGetPlan.class);
								planList.add(plan);
							}
						}
						plandetail.setPlans(planList);
						plandetail.setSoaMessage(StringConstants.SUCCESS);
						plandetail.setSoaStatusCode(StringConstants.C200);
						plandetail.setSoaDescription(StringConstants.C200DESC);
						
							logger.info(StringConstants.C200DESC);
						}
						else
						{
							plandetail.setSoaStatusCode(StringConstants.C200);
							plandetail.setSoaMessage(StringConstants.SUCCESS);
							plandetail.setSoaDescription(StringConstants.C700DESC);
							logger.info(StringConstants.C700DESC);
						}
					}
					else
					{
						plandetail.setSoaStatusCode(StringConstants.C601);
						plandetail.setSoaMessage(StringConstants.FAILURE);
						plandetail.setSoaDescription(StringConstants.C600DESC);
						logger.info(StringConstants.C600DESC);
					}
			}
			catch(Exception e)
			{
				plandetail.setSoaStatusCode(StringConstants.C500);
				plandetail.setSoaMessage(StringConstants.FAILURE);
				plandetail.setSoaMessage(StringConstants.C500DESC);
				logger.error(StringConstants.C500DESC + " : "+e);
			}
			responsePlan.setResponseData(plandetail);
			response.setResponse(responsePlan);
			logger.info("getPlanDetails service : End");
			return response;
	}

}
