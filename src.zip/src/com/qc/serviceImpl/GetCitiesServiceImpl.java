package com.qc.serviceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getcities.ApiRequestGetCities;
import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getcities.ApiResponseGetCities;
import com.qc.api.response.getcities.PayloadResGetCities;
import com.qc.api.response.getcities.ResGetCities;
import com.qc.api.response.getcities.ResponseGetCities;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;
import com.qc.api.response.getmaxcities.PayloadResGetMaxCities;
import com.qc.api.response.getmaxcities.ResGetMaxCities;
import com.qc.api.response.getmaxcities.ResponseGetMaxCities;
import com.qc.dao.GetCitiesDao;
import com.qc.dao.GetMaxCitiesDao;
import com.qc.entity.PR_GETCITIES_DTLS;
import com.qc.entity.PR_GETMAXCITIES_DTLS;
import com.qc.service.GetCitiesService;
import com.qc.service.GetMaxCitiesService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetCitiesServiceImpl implements GetCitiesService
{

	private static Logger logger = LogManager.getLogger(GetCitiesServiceImpl.class);

	@Autowired
	GetCitiesDao getCitiesDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	@Transactional
	public ApiResponseGetCities getCitiesDetails(ApiRequestGetCities apiRequest) {
		logger.info("getCitiesDetails service : Start");
		ApiResponseGetCities response = new ApiResponseGetCities();
		@SuppressWarnings("unused")
		PayloadResGetCities resPayload = null;
		ResponseGetCities responseCities = new ResponseGetCities();
		PR_GETCITIES_DTLS req = null;
		
		/*ResGetMaxCities claimedDetail=null;*/
		PayloadResGetCities citydetail= new PayloadResGetCities();
		try 
		{
			req = new PR_GETCITIES_DTLS();
			req.setState(apiRequest.getRequest().getRequestData().getState());
			logger.debug("Going to call getCitiesService  from service to DB : Start");

			List citiesData =getCitiesDao.getCitiesService(req);
			if(citiesData!=null)
			{
				if(!citiesData.isEmpty())
				{
					List<ResGetCities> hashMap = new ArrayList<>();
					for(Object oo : citiesData)
					{
						ResGetCities cities =new ResGetCities();
						cities.setCity(oo.toString()); 
						hashMap.add(cities);
					}
					citydetail.setCities(hashMap);
					citydetail.setSoaMessage(StringConstants.SUCCESS);
					citydetail.setSoaStatusCode(StringConstants.C200);
					citydetail.setSoaDescription(StringConstants.C200DESC);
					
						logger.info(StringConstants.C200DESC);
					}
					else
					{
						citydetail.setSoaStatusCode(StringConstants.C200);
						citydetail.setSoaMessage(StringConstants.SUCCESS);
						citydetail.setSoaDescription(StringConstants.C700DESC);
						logger.info(StringConstants.C700DESC);
					}
				}
				else
				{
					citydetail.setSoaStatusCode(StringConstants.C601);
					citydetail.setSoaMessage(StringConstants.FAILURE);
					citydetail.setSoaDescription(StringConstants.C600DESC);
					logger.info(StringConstants.C600DESC);
				}
		}
		catch(Exception e)
		{
			citydetail.setSoaStatusCode(StringConstants.C500);
			citydetail.setSoaMessage(StringConstants.FAILURE);
			citydetail.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCities.setResponseData(citydetail);
		response.setResponse(responseCities);
		logger.info("getCitiesDetails service : End");
		return response;
	}


}
