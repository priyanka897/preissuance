package com.qc.serviceImpl;

import java.util.List;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getneftdetails.ApiResponseNeftDetails;
import com.qc.api.response.getneftdetails.PayloadResNeftDetails;
import com.qc.api.response.getneftdetails.ResponseNeftDetails;
import com.qc.dao.NeoDao;
//import com.qc.dao.NeoDao;
import com.qc.service.NeftService;
import com.qc.service.ObjectToPojoService;

@Service
public class NeftServiceImpl implements NeftService{

	private static Logger logger = LogManager.getLogger(NeftServiceImpl.class);
	
	@Autowired ObjectToPojoService objectToPojoService;
	@Autowired DozerBeanMapper dozerBeanMapper;
	@Autowired NeoDao neoDao;
	
	
	@Override
	public ApiResponseNeftDetails getNeftdetails(ApiRequestNeftDetails apiRequest) {
	
		logger.info("NeftServiceImpl service : Start");
		MsgInfo msginfo = new MsgInfo();
		ResponseNeftDetails response = new ResponseNeftDetails();
		PayloadResNeftDetails payload = new PayloadResNeftDetails();
		ApiResponseNeftDetails apiResponse =new ApiResponseNeftDetails();
		try 
		{
			
			logger.debug("Proc Call from service to DB : Start");
			
			List<Object[]> neftRelatedData= neoDao.callNeftdetails(apiRequest);
			
			if(neftRelatedData!=null)
		{
				if(!neftRelatedData.isEmpty())
				{
				logger.debug("Proc Call from service to DB : End");
					
					List<Map<String , String>> result = objectToPojoService.getCustomClass(neftRelatedData);
					if(result != null && result.size() > 0)
					{
						for(Map<?, ?> mapObj : result )
						{
							try
							{
								payload  = dozerBeanMapper.map(mapObj, PayloadResNeftDetails.class);
								break;
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Going to get neft Data From DB : End");
			
					if(payload!=null )
					{
						response.setPayload(payload);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						logger.info(StringConstants.C200DESC);
					}
					else 
					{
						msginfo.setMsgCode(StringConstants.C701);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C701DESC);
						logger.info(StringConstants.C701DESC);
					}
				}
				else 
				{
					msginfo.setMsgCode(StringConstants.C700);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
		}
		else 
		{
				msginfo.setMsgCode(StringConstants.C700);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C700DESC);
				logger.info(StringConstants.C700DESC);
		}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		
		response.setMsgInfo(msginfo);
		
		apiResponse.setResponse(response);
		logger.info("NeftServiceImpl service : End");
		return apiResponse;
	}

}
