package com.qc.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.countofnotification.ApiRequestCountOfNotification;
import com.qc.api.response.StringConstants;
import com.qc.api.response.countofnotification.ApiResponseCountOfNotification;
import com.qc.api.response.countofnotification.PayloadResCountOfNotification;
import com.qc.api.response.countofnotification.ResCountOfNotification;
import com.qc.api.response.countofnotification.ResponseCountOfNotification;
import com.qc.dao.MPowerDao;
import com.qc.entity.PR_COUNTOFNOTIFICATION_DTLS;
import com.qc.service.MPowerService;
import com.qc.service.ObjectToPojoService;

@Service
public class MPowerServiceImpl implements MPowerService{

	private static Logger logger = LogManager.getLogger(MPowerServiceImpl.class);

	@Autowired
	MPowerDao mPowerDao;
	
	@Autowired
	ObjectToPojoService objectToPojoService;
	
	@Autowired
	DozerBeanMapper dozerBeanMapper;


//@Transactional
	@Override
	public ApiResponseCountOfNotification countOfNotification(ApiRequestCountOfNotification apiRequest) {

		logger.info("countOfNotification service : Start");
		ApiResponseCountOfNotification response = new ApiResponseCountOfNotification();
		ResponseCountOfNotification responseCountOfNotification = new ResponseCountOfNotification();
		PR_COUNTOFNOTIFICATION_DTLS req = null;
		MsgInfo msginfo = new MsgInfo();
		PayloadResCountOfNotification payloadCountOfNotification= new PayloadResCountOfNotification();
		List<ResCountOfNotification> countOfNotificationDetails = null;
		try 
		{
			req = new PR_COUNTOFNOTIFICATION_DTLS();
			req.setUserId(apiRequest.getRequest().getUserId());
			logger.debug("Going to call countOfNotification  from service to DB : Start");

			List countOfNotificationData = mPowerDao.countOfNotificationService(req);
			if(countOfNotificationData!=null)
			{
				if(!countOfNotificationData.isEmpty())
				{
					if(countOfNotificationData.contains("transaction timeout expired"))
						
				    {
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C203DESC);
				    }
				 else{

					List<Map<String , String>> result = objectToPojoService.getCustomClass(countOfNotificationData);
					if(result != null && !result.isEmpty())
					{
						countOfNotificationDetails = new ArrayList<ResCountOfNotification>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResCountOfNotification notificationCountDetail  = dozerBeanMapper.map(mapObj, ResCountOfNotification.class);
								countOfNotificationDetails.add(notificationCountDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(countOfNotificationDetails!=null && !countOfNotificationDetails.isEmpty())
					{
						payloadCountOfNotification.setCountOfNotification(countOfNotificationDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseCountOfNotification.setResponseData(payloadCountOfNotification);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C601);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C601DESC);
						logger.info(StringConstants.C601DESC);
					}
				}}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C700DESC);
					logger.info(StringConstants.C700DESC);
				}
			}
			else 
			{
				msginfo.setMsgCode(StringConstants.C701);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C701DESC);
				logger.info(StringConstants.C701DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCountOfNotification.setMsgInfo(msginfo);
		response.setResponse(responseCountOfNotification);
		logger.info("countOfNotification  service : End");
		return response;
	}


}
