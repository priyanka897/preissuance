package com.qc.serviceImpl;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getcountry.ApiRequestGetCountry;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getcountry.ApiResponseGetCountry;
import com.qc.api.response.getcountry.PayloadResGetCountry;
import com.qc.api.response.getcountry.ResGetCountry;
import com.qc.api.response.getcountry.ResponseGetCountry;
import com.qc.dao.GetCountryDao;
import com.qc.entity.PR_GETCOUNTRY_DTLS;
import com.qc.service.GetCountryService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetCountryServiceImpl implements GetCountryService
{

	private static Logger logger = LogManager.getLogger(GetCountryServiceImpl.class);

	@Autowired
	GetCountryDao getCountryDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	@Transactional
	public ApiResponseGetCountry getCountryDetails(ApiRequestGetCountry apiRequest) {
		logger.info("getCountryDetails service : Start");
		ApiResponseGetCountry response = new ApiResponseGetCountry();
		@SuppressWarnings("unused")
		PayloadResGetCountry resPayload = null;
		ResponseGetCountry responseCountry = new ResponseGetCountry();
		PR_GETCOUNTRY_DTLS req = null;
		
		/*ResGetMaxCities claimedDetail=null;*/
		PayloadResGetCountry citydetail= new PayloadResGetCountry();
		try 
		{
			req = new PR_GETCOUNTRY_DTLS();
			//req.setState(apiRequest.getRequest().getRequestData().getState());
			logger.info("Going to call getCountryService  from service to DB : Start");

			List countryData =getCountryDao.getCountryService(req);
			if(countryData!=null)
			{
				if(!countryData.isEmpty())
				{
					logger.info("call object to pojo service : Start");
					List<Map<String , String>> result = objectToPojoService.getCustomClass(countryData);
					List<ResGetCountry> countryList = new ArrayList<>();
					if(result != null && !result.isEmpty())
					{
						logger.info("call dozerBeanMapper : Start");
						for(Map<?, ?> mapObj : result)
						{
							ResGetCountry country = dozerBeanMapper.map(mapObj, ResGetCountry.class);
							countryList.add(country);
						}
					}
					citydetail.setCountry(countryList);
					citydetail.setSoaMessage(StringConstants.SUCCESS);
					citydetail.setSoaStatusCode(StringConstants.C200);
					citydetail.setSoaDescription(StringConstants.C200DESC);
					
						logger.info(StringConstants.C200DESC);
					}
					else
					{
						citydetail.setSoaStatusCode(StringConstants.C200);
						citydetail.setSoaMessage(StringConstants.SUCCESS);
						citydetail.setSoaDescription(StringConstants.C700DESC);
						logger.info(StringConstants.C700DESC);
					}
				}
				else
				{
					citydetail.setSoaStatusCode(StringConstants.C601);
					citydetail.setSoaMessage(StringConstants.FAILURE);
					citydetail.setSoaDescription(StringConstants.C600DESC);
					logger.info(StringConstants.C600DESC);
				}
		}
		catch(Exception e)
		{
			citydetail.setSoaStatusCode(StringConstants.C500);
			citydetail.setSoaMessage(StringConstants.FAILURE);
			citydetail.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCountry.setResponseData(citydetail);
		response.setResponse(responseCountry);
		logger.info("getCountryDetails service : End");
		return response;
	}


}
