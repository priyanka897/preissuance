
package com.qc.serviceImpl;

import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.request.eCube.ChatbotPayloadRequest;
import com.qc.api.response.eCube.ChatbotApiResponse;
import com.qc.api.response.eCube.ChatbotPayloadResponse;
import com.qc.common.dto.AchievementProcDTO;
import com.qc.common.dto.AppliedProcDTO;
import com.qc.common.dto.CaseSizeProcDTO;
import com.qc.common.dto.ERRORSTATUS;
import com.qc.common.dto.ErrorInfo;
import com.qc.common.dto.GrowthProcDTO;
import com.qc.common.dto.LpcPerformanceProcDTO;
import com.qc.common.dto.MiscProcDTO;
import com.qc.common.dto.ModeMixProcDTO;
import com.qc.common.dto.PaidProcDTO;
import com.qc.common.dto.PenetrationProcDTO;
import com.qc.common.dto.RecProcDTO;
import com.qc.common.dto.STATUSCODE;
import com.qc.common.dto.SsoValidationProcDto;
import com.qc.common.dto.WipProcDTO;
import com.qc.dao.ChatbotDbDao;
import com.qc.service.ChatbotApiService;
import com.qc.service.ObjectToPojoService;


@Service
public class ChatbotApiServiceImpl implements ChatbotApiService{

	private static Logger logger = LogManager.getLogger(ChatbotApiServiceImpl.class);
	@Autowired
	ChatbotDbDao chatbotDbDao;
	@Autowired
	DozerBeanMapper dozerBeanMapper;
	@Autowired
	ObjectToPojoService objectToPojoService;

	@Override
	public ChatbotApiResponse getProceduresData(ChatbotPayloadRequest payload) 
	{
		ChatbotApiResponse response = null;
		ChatbotPayloadResponse chatbotPayloadResponse = new ChatbotPayloadResponse();
		ErrorInfo errorInfo = new ErrorInfo();
		try
		{
			if (payload.getSegment() !=null && !"".equalsIgnoreCase(payload.getSegment())) 
			{
				String[] strArray =  payload.getSegment().split(",");
				if(strArray != null && strArray.length > 0)
				{
					for(int i=0;i<strArray.length;i++)
					{
						if("MISC".equalsIgnoreCase(strArray[i]))
						{
							processMiscProcData(strArray[i], payload.getChannel(), chatbotPayloadResponse, payload);
						}
						if("WIP".equalsIgnoreCase(strArray[i]))
						{
							processWipProcData(strArray[i], payload.getChannel(), chatbotPayloadResponse, payload);
						}
						if("APPLIED".equalsIgnoreCase(strArray[i]))
						{
							processAppliedProcData(strArray[i], payload.getChannel(), chatbotPayloadResponse, payload);
						}
						if("PAID".equalsIgnoreCase(strArray[i]))
						{
							processPaidProcData(strArray[i], payload.getChannel(), chatbotPayloadResponse, payload);
						}
					}
				}
				else
				{
					processSsoValidationProcData("", payload.getSsoid(),chatbotPayloadResponse);
					processGrowthProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processAchievementProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processPenetrationProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processWipProcData("", payload.getChannel(), chatbotPayloadResponse, payload);	
					processLpcPerformanceProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processRecProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processCaseSizeProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processModeMixProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processAppliedProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processPaidProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
					processMiscProcData("", payload.getChannel(), chatbotPayloadResponse, payload);
				}
				errorInfo.setCode(STATUSCODE.OK.getValue());
				errorInfo.setStatus(ERRORSTATUS.SUCCESS);
				errorInfo.setMessage("Data fetched successfully!");
				errorInfo.setDescription("Valid information found!");
				response = new ChatbotApiResponse(null, errorInfo, chatbotPayloadResponse);
			} 
			else 
			{
				logger.info("Invalid request!!");
				errorInfo.setCode(STATUSCODE.INVALID_REQUEST.getValue());
				errorInfo.setStatus(ERRORSTATUS.FAILURE);
				errorInfo.setMessage("Invalid request!");
				errorInfo.setDescription("Please verify request json! Invalid Segment ");
				response = new ChatbotApiResponse(null, errorInfo, null);
			}
		}catch(Exception e)
		{
			logger.error("Something went wrong while processing request!!"+e);
			errorInfo.setCode(STATUSCODE.OK.getValue());
			errorInfo.setStatus(ERRORSTATUS.FAILURE);
			errorInfo.setMessage("Invalid request!");
			errorInfo.setDescription("Invalid request!");
			response = new ChatbotApiResponse(null, errorInfo, null);
		}
		return response;
	}

	public void processSsoValidationProcData(String segment,String ssoid, ChatbotPayloadResponse chatbotPayloadResponse)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getSsoValidationProcList(segment, ssoid));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty() && result.size()>1)
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setSsovalidation(dozerBeanMapper.map(mapObj, SsoValidationProcDto.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}

			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processSsoValidationProcData:: "+e);
		}
	}
	public void processGrowthProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getGrowthProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setGrowth(dozerBeanMapper.map(mapObj, GrowthProcDTO.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processSsoValidationProcData:: "+e);
		}
	}


	public void processAchievementProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse, ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getAchievementProcList(segment, channel, payload));
			logger.info("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setAchievement(dozerBeanMapper.map(mapObj, AchievementProcDTO.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processAchievementProcData:: "+e);
		}
	}

	public void processPenetrationProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse, ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getPenetrationProcList(segment, channel, payload));
			logger.info("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setPenetration(dozerBeanMapper.map(mapObj, PenetrationProcDTO.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processPenetrationProcData:: "+e);
		}
	}


	public void processWipProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getWipList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setWIP(dozerBeanMapper.map(mapObj, WipProcDTO.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processWipProcData:: "+e);
		}
	}
	public void processLpcPerformanceProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getLpcPerformanceProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setLPCPerformance(dozerBeanMapper.map(mapObj, LpcPerformanceProcDTO.class));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processLpcPerformanceProcData:: "+e);
		}
	}

	public void processRecProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getRecProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setREC((dozerBeanMapper.map(mapObj, RecProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processRecProcData:: "+e);
		}
	}
	public void processCaseSizeProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getCaseSizeProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setCASESize((dozerBeanMapper.map(mapObj, CaseSizeProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processCaseSizeProcData:: "+e);
		}
	}
	public void processModeMixProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getModeMixProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setMODEMix((dozerBeanMapper.map(mapObj, ModeMixProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processModeMixProcData:: "+e);
		}
	}
	public void processAppliedProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getAppliedProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setApplied((dozerBeanMapper.map(mapObj, AppliedProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processAppliedProcData:: "+e);
		}
	}
	public void processPaidProcData(String segment,String channel, ChatbotPayloadResponse chatbotPayloadResponse , ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getPaidProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setPaid((dozerBeanMapper.map(mapObj, PaidProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processPaidProcData:: "+e);
		}
	}
	public void processMiscProcData(String segment, String channel, ChatbotPayloadResponse chatbotPayloadResponse, ChatbotPayloadRequest payload)
	{
		try
		{
			List<Map<String , String>> result = objectToPojoService.getCustomClass(chatbotDbDao.getMiscProcList(segment, channel, payload));
			logger.debug("Size of proc list : "+result.size());
			if(!result.isEmpty())
			{
				for(Map<?, ?> mapObj : result)
				{
					try
					{
						chatbotPayloadResponse.setMisc((dozerBeanMapper.map(mapObj, MiscProcDTO.class)));
					}
					catch(Exception e)
					{
						logger.error("exception while parsing through dozer mapping :: "+e);
					}
				}
			}
		}
		catch(Exception e)
		{
			logger.error("Exception Occoured In Method :: processPaidProcData:: "+e);
		}
	}
}


