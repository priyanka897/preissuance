package com.qc.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.createNotification.ApiRequestCreateNotification;
import com.qc.api.request.csg.listOfNotificationV2.ApiRequestListOfNotificationV2;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.csg.updateNotification.ApiRequestUpdateNotification;
import com.qc.api.request.csg.updateNotificationReadStatus.ApiRequestUpdateNotificationReadStatus;
import com.qc.api.request.csg.updateNotificationReadStatus.PayloadUpdateNotificationReadStatus;
import com.qc.api.response.StringConstants;
import com.qc.api.response.csg.NotificationDetail.Agents;
import com.qc.api.response.csg.NotificationDetail.ApiResponseNotificationDetails;
import com.qc.api.response.csg.NotificationDetail.NotificationDetailsPayload;
import com.qc.api.response.csg.NotificationDetail.ResponseNotificationDetails;
import com.qc.api.response.csg.createNotification.ApiResponseCreateNotification;
import com.qc.api.response.csg.createNotification.PayloadCreateNotification;
import com.qc.api.response.csg.createNotification.ResponseCreateNotification;
import com.qc.api.response.csg.listOfNotificationV2.ApiResponselistOfNotificationV2;
import com.qc.api.response.csg.listOfNotificationV2.Notifications;
import com.qc.api.response.csg.listOfNotificationV2.PayloadListOfNotificationV2;
import com.qc.api.response.csg.listOfNotificationV2.ResponselistOfNotificationV2;
import com.qc.api.response.csg.notificationsearch.ApiResponseNotificationSearch;
import com.qc.api.response.csg.notificationsearch.Notification;
import com.qc.api.response.csg.notificationsearch.PayloadResNotificationSearch;
import com.qc.api.response.csg.notificationsearch.ResponseNotificationSearch;
import com.qc.api.response.csg.updateNotification.ApiResponseUpdateNotification;
import com.qc.api.response.csg.updateNotification.ResponseUpdateNotification;
import com.qc.api.response.csg.updateNotification.UpdateNotificationPayload;
import com.qc.api.response.csg.updateNotificationReadStatus.ApiResponseUpdateNotificationReadStatus;
import com.qc.api.response.csg.updateNotificationReadStatus.ResponseUpdateNotificationReadStatus;
import com.qc.dao.CsgDao;
import com.qc.service.CsgServices;
import com.qc.service.ObjectToPojoService;

@Service
public class CsgServiceImpl implements CsgServices {

	@Autowired
	ObjectToPojoService objecttopojoservice;

	@Autowired
	DozerBeanMapper dozerbeanmapper;

	@Autowired

	CsgDao csgdao;

	private static Logger logger = LogManager.getLogger(CsgServiceImpl.class);

	@Override
	public ApiResponseNotificationSearch getNotificationSearch(ApiRequestNotificationSearch apiRequest) {
		logger.info("getNotificationSearch service : Start");
		ApiResponseNotificationSearch apiresponse = new ApiResponseNotificationSearch();
		MsgInfo msginfo = new MsgInfo();
		ResponseNotificationSearch response = new ResponseNotificationSearch();
		List<Notification> notification = null;
		PayloadResNotificationSearch payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			List daoData = csgdao.getNotificationSearch(apiRequest);

			if (daoData != null) {
				if (!daoData.isEmpty()) {
					List<Map<String, String>> result = objecttopojoservice.getCustomClass(daoData);
					if (result != null && !result.isEmpty()) {
						notification = new ArrayList<Notification>();
						for (Map<?, ?> mapObj : result) {
							try {
								Notification notificationRes = dozerbeanmapper.map(mapObj, Notification.class);
								notification.add(notificationRes);
							} catch (Exception e) {
								logger.error("exception while parsing through dozer mapping :: " + e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if (notification != null && !notification.isEmpty()) {
						payload = new PayloadResNotificationSearch();
						payload.setNotification(notification);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						response.setPayload(payload);
						;
						logger.info(StringConstants.C200DESC);
					} else {
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}

				else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("notificationsearch service : End");
		return apiresponse;
	}

	@Override
	public ApiResponseCreateNotification createNotificationSearch(ApiRequestCreateNotification apiRequest) {

		logger.info("createNotificationSearch service : Start");
		ApiResponseCreateNotification apiresponse = new ApiResponseCreateNotification();
		MsgInfo msginfo = new MsgInfo();
		ResponseCreateNotification response = new ResponseCreateNotification();
		List<Notification> notification = null;
		PayloadCreateNotification payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			String id = csgdao.createNotification(apiRequest);

			if (id != null) {
				if (!id.equals("")) {
					payload = new PayloadCreateNotification();
					payload.setId(id);
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					response.setPayload(payload);
					logger.info(StringConstants.C200DESC);
				} else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}

		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("createNotificationSearch service : End");
		return apiresponse;

	}

	@Override
	public ApiResponseNotificationDetails notificationDetails(ApiRequestNotificationDetails apiRequest) {
		logger.info("notificationDetails service : Start");
		ApiResponseNotificationDetails apiresponse = new ApiResponseNotificationDetails();
		MsgInfo msginfo = new MsgInfo();
		ResponseNotificationDetails response = new ResponseNotificationDetails();
		List<Agents> agent = null;
		NotificationDetailsPayload payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			List daoData = csgdao.notificationDetails(apiRequest);

			if (daoData != null) {
				if (!daoData.isEmpty()) {
					List<Map<String, String>> result = objecttopojoservice.getCustomClass(daoData);
					if (result != null && !result.isEmpty()) {
						for (Map<?, ?> mapObj : result) {
							try {
								Agents agentRes = dozerbeanmapper.map(mapObj, Agents.class);
								agent.add(agentRes);
								payload = dozerbeanmapper.map(mapObj, NotificationDetailsPayload.class);
								payload.setAgents(agent);
							} catch (Exception e) {
								logger.error("exception while parsing through dozer mapping :: " + e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if (payload != null) {
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						logger.info(StringConstants.C200DESC);
					} else {
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}

				else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("notificationDetails service : End");
		return apiresponse;
	}

	@Override
	public ApiResponselistOfNotificationV2 listOfNotificationsV2(ApiRequestListOfNotificationV2 apiRequest) {
		logger.info("getNotificationSearch service : Start");
		ApiResponselistOfNotificationV2 apiresponse = new ApiResponselistOfNotificationV2();
		MsgInfo msginfo = new MsgInfo();
		ResponselistOfNotificationV2 response = new ResponselistOfNotificationV2();
		List<Notifications> notifications = null;
		PayloadListOfNotificationV2 payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			List daoData = csgdao.listOfNotificationsV2(apiRequest);

			if (daoData != null) {
				if (!daoData.isEmpty()) {
					List<Map<String, String>> result = objecttopojoservice.getCustomClass(daoData);
					if (result != null && !result.isEmpty()) {
						notifications = new ArrayList<Notifications>();
						for (Map<?, ?> mapObj : result) {
							try {
								payload = dozerbeanmapper.map(mapObj, PayloadListOfNotificationV2.class);
								Notifications notificationsRes = dozerbeanmapper.map(mapObj, Notifications.class);
								notifications.add(notificationsRes);

							} catch (Exception e) {
								logger.error("exception while parsing through dozer mapping :: " + e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if (payload != null) {
						payload = new PayloadListOfNotificationV2();
						payload.setNotifications(notifications);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						response.setPayload(payload);
						logger.info(StringConstants.C200DESC);
					} else {
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}

				else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("Fund Name service : End");
		return apiresponse;
	}

	@Override
	public ApiResponseUpdateNotificationReadStatus updateNotificationReadStatus(ApiRequestUpdateNotificationReadStatus apiRequest) {
		logger.info("getNotificationSearch service : Start");
		ApiResponseUpdateNotificationReadStatus apiresponse = new ApiResponseUpdateNotificationReadStatus();
		MsgInfo msginfo = new MsgInfo();
		ResponseUpdateNotificationReadStatus response = new ResponseUpdateNotificationReadStatus();
		PayloadUpdateNotificationReadStatus payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			String id = csgdao.updateNotificationReadStatus(apiRequest);

			if (id != null) {
				if (!id.isEmpty()) {
					payload = new PayloadUpdateNotificationReadStatus();
					payload.setId(id);
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					response.setPayload(payload);
					logger.info(StringConstants.C200DESC);
				} else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}

		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("Fund Name service : End");
		return apiresponse;
	}

	@Override
	public ApiResponseUpdateNotification updateNotification(ApiRequestUpdateNotification apiRequest) {
		logger.info("getNotificationSearch service : Start");
		ApiResponseUpdateNotification apiresponse = new ApiResponseUpdateNotification();
		MsgInfo msginfo = new MsgInfo();
		ResponseUpdateNotification response = new ResponseUpdateNotification();
		UpdateNotificationPayload payload = null;
		try {
			logger.debug("Select data Call from service to Dao : Start");
			String id = csgdao.updateNotification(apiRequest);

			if (id != null) {
				if (!id.isEmpty()) {
					payload = new UpdateNotificationPayload();
					payload.setId(id);
					msginfo.setMsgCode(StringConstants.C200);
					msginfo.setMsg(StringConstants.SUCCESS);
					msginfo.setMsgDescription(StringConstants.C200DESC);
					response.setPayload(payload);
					logger.info(StringConstants.C200DESC);
				} else {
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}

			else {
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}

		} catch (Exception e) {
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
		}
		response.setMsgInfo(msginfo);
		response.setPayload(payload);
		apiresponse.setResponse(response);
		logger.info("Fund Name service : End");
		return apiresponse;
	}

}
