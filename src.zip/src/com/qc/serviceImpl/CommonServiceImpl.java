package com.qc.serviceImpl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.service.CommonService;
import com.qc.utils.XTrustProvider;
@Service
public class CommonServiceImpl implements CommonService
{

	private static Logger logger = LogManager.getLogger(CommonServiceImpl.class);
	@Autowired Environment env;

	@Override
	public String getOtpResponse() 
	{
		String output = new String();
		StringBuilder result = new StringBuilder();	
		HttpURLConnection conn = null;
		try 
		{
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String pUrl = env.getProperty("spring.java.url.v1.otp");
			URL url = new URL(pUrl);
			String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) url.openConnection(proxy);
				logger.info("Running in development Mode");
			}
			else
			{
				conn = (HttpURLConnection) url.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata=new StringBuilder();

			logger.debug("Going to call JAVA otp service : Start : "+pUrl);

			requestdata.append(" { ");
			requestdata.append("   \"NO_OF_CHARS\":\"");
			requestdata.append(env.getProperty("spring.java.req.NO_OF_CHARS"));
			requestdata.append("\",	");
			requestdata.append("   \"TYPE\":\"");
			requestdata.append(env.getProperty("spring.java.req.TYPE"));
			requestdata.append("\"	");
			requestdata.append(" } ");


			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {logger.debug(e1);}

			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("Going to call JAVA otp service : Response Code : "+apiResponseCode+" : "+result.toString());
			}
			else
			{
				logger.info("Going to call JAVA otp service : Response Code : "+apiResponseCode);
			}
		}
		catch(Exception ex)
		{
			logger.error("We are in exception when generating OTP from service"+ex);
			return null;
		}
		return result.toString();
	}

	@Override
	public Map<String,String> getMapFromStringJson(String jsonReq)
	{
		ObjectMapper mapperObj = new ObjectMapper();
		Map<String,String> resultMap = new HashMap<String,String>();
		try
		{
			resultMap = mapperObj.readValue(jsonReq,new TypeReference<HashMap<String,String>>(){});
			logger.debug("Output Map: "+resultMap);
		}
		catch (IOException e)
		{
			logger.error("We are in Exception while converting json to map : "+e);
			return null;
		}
		return resultMap;
	}

}
