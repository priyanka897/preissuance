package com.qc.serviceImpl;

import java.util.ArrayList;

import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderError;
import org.drools.builder.KnowledgeBuilderErrors;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatefulKnowledgeSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.qc.api.dto.ApiErrorInfo;
import com.qc.api.dto.ApiResponseHeader;
import com.qc.api.dto.ERRORSTATUS;
import com.qc.api.dto.EquidosTrackerDTO;
import com.qc.api.request.eKudos.EKudosApiReqTransaction;
import com.qc.api.request.eKudos.eKudosApiRequest;
import com.qc.api.response.eKudos.eKudosApiResPayload;
import com.qc.api.response.eKudos.eKudosApiResTransaction;
import com.qc.api.response.eKudos.eKudosApiResponse;
import com.qc.db.service.EkudosDbservice;
import com.qc.entity.EkudosEntity;
import com.qc.model.Events;
import com.qc.service.eKudosService;

@Service
@PropertySource({ "classpath:application.properties" })
public class eKudosServiceImpl implements eKudosService
{
	private static Logger logger = LogManager.getLogger(eKudosServiceImpl.class);
	@Autowired
	Environment env;
	@Autowired
	EkudosDbservice ekudosDbService;
	@Override
	public eKudosApiResponse eKudosServicepoints(final eKudosApiRequest ekudosApiRequest)
	{
		logger.info("Came Inside :- eKudosServicepoints ");
		logger.info("Request : -" + ekudosApiRequest);
		eKudosApiResponse EKudosApiResponse = new eKudosApiResponse();
		ApiResponseHeader header = new ApiResponseHeader();
		ApiErrorInfo errorInfo = new ApiErrorInfo();
		eKudosApiResPayload responsePayload = new eKudosApiResPayload();
		Events event=null;
		
		if(ekudosApiRequest.getPayload().getTransactions()!=null)
		{
			for(int i=0; i<ekudosApiRequest.getPayload().getTransactions().size();i++)
			{
				try
				{
					EKudosApiReqTransaction eKudosApiReqTransaction=ekudosApiRequest.getPayload().getTransactions().get(i);
					final EquidosTrackerDTO equidosTrackerHolderDTO = new EquidosTrackerDTO();
					String eventOccured= eKudosApiReqTransaction.getEventOccured();
					String createdDate = eKudosApiReqTransaction.getCreatedDate();
					String eventName = eKudosApiReqTransaction.getEventName();
					String userName = eKudosApiReqTransaction.getUserName().toUpperCase();
					String title = eKudosApiReqTransaction.getTitle();
					String category = eKudosApiReqTransaction.getCategory();
					String updated = eKudosApiReqTransaction.getUpdated();
					String appName=eKudosApiReqTransaction.getAppName();
					String appType=eKudosApiReqTransaction.getAppType();

					KnowledgeBase kbase = readKnowledgeBase();
					StatefulKnowledgeSession ksession = kbase.newStatefulKnowledgeSession();
		            event = new Events();
					event.setType(eventOccured);
					ksession.insert(event);
					ksession.fireAllRules();
					logger.info("Rules Fired:End");
					
					equidosTrackerHolderDTO.setSoaCorrelationId(ekudosApiRequest.getHeader().getSoaCorrelationId());
					equidosTrackerHolderDTO.seteKudosEarned(event.geteKuods()+"");
					equidosTrackerHolderDTO.setEventOccured(event.getType());
					equidosTrackerHolderDTO.setCreatedDate(createdDate);
					equidosTrackerHolderDTO.setEventName(eventName);
					equidosTrackerHolderDTO.setUserName(userName);
					equidosTrackerHolderDTO.setTitle(title);
					equidosTrackerHolderDTO.setCategory(category);
					equidosTrackerHolderDTO.setUpdated(updated);
					equidosTrackerHolderDTO.setAppName(appName);
					equidosTrackerHolderDTO.setAppType(appType);
					Thread t1=new Thread(new Runnable() 
					{
						public void run() 
						{
							logger.info("Run Method Start");
							runningBackgroundProcessinsertEkudosValues(ekudosApiRequest, equidosTrackerHolderDTO);
						}
					});
					t1.start();
					t1.join();
					logger.info("For "+ event.getType()+" Event"+ "eKUOS to be earned"+" is :"+event.geteKuods());
					
					}
				
				catch(Exception ex)
				{
		          logger.error(ex);
				}
				
			}
		}
		if(event.getType()!=null && event.geteKuods()!=0){
			EKudosApiResponse.setHeader(header);
			errorInfo.setCode("200");
			errorInfo.setMessage("SUCCESS");
			errorInfo.setDescription("Data Inserted successfully");
			errorInfo.setStatus(ERRORSTATUS.SUCCESS);
			EKudosApiResponse.setApiErrorInfo(errorInfo);
			EKudosApiResponse.setPayload(responsePayload);
			logger.info("CameOutSide Method :- geteKudospoints");
			
		}
		return EKudosApiResponse;
	}
	
	public eKudosApiResponse geteKudospoints(eKudosApiRequest ekudosApiRequest)
	{
		logger.info("CameInside Method :- geteKudospoints");
		eKudosApiResponse EKudosApiResponse = new eKudosApiResponse();
		eKudosApiResTransaction transaction = new eKudosApiResTransaction();
		List<eKudosApiResTransaction> arrayResponseBean = new ArrayList<eKudosApiResTransaction>();
		eKudosApiResPayload responsePayload = new eKudosApiResPayload();
		ApiErrorInfo errorInfo = new ApiErrorInfo();
		ApiResponseHeader header = new ApiResponseHeader();
		
		EKudosApiReqTransaction eKudosApiReqTransaction2=ekudosApiRequest.getPayload().getTransactions().get(0);
		String ssoId = eKudosApiReqTransaction2.getUserName().toUpperCase();
		logger.info("SSO ID get from Ecude :- " + ssoId);
		EKudosApiResponse.setHeader(header);
		if(ssoId!=null && ssoId!="")
		{
			String point = ekudosDbService.getEkudosValue(ssoId);
			int ekudosearned = Integer.parseInt(point);
			transaction.seteKudos(ekudosearned);
			transaction.setEmpId(ssoId);
			arrayResponseBean.add(transaction);
			responsePayload.setTransactions(arrayResponseBean);
			errorInfo.setCode("200");
			errorInfo.setMessage("Detail's matched");
			errorInfo.setDescription("Data Fetched Successfully");
			errorInfo.setStatus(ERRORSTATUS.SUCCESS);
			EKudosApiResponse.setApiErrorInfo(errorInfo);
			EKudosApiResponse.setPayload(responsePayload);
			logger.info("CameOutSide Method :- geteKudospoints");
			return EKudosApiResponse;
			
		}
		else
		{
			logger.error("statcode & statmsg:-");
			errorInfo.setCode("400");
			errorInfo.setMessage("SSOID NOT FOUND FROM ECUBE");
			errorInfo.setDescription("UNABLE TO PROCESS THE DATA");
			errorInfo.setStatus(ERRORSTATUS.FAILURE);
			EKudosApiResponse.setApiErrorInfo(errorInfo);
			return EKudosApiResponse;
		}
	}
	
	private static KnowledgeBase readKnowledgeBase() throws Exception
	{
		logger.info("CameInside Method :- readKnowledgeBase");
		KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
		try{
		kbuilder.add(ResourceFactory.newClassPathResource("MaxRule.drl"), ResourceType.DRL);
		logger.info("MaxRule.Drl loded successfully");
		}catch(Exception ex)
		{
			logger.info("Error found to load :- MaxRule.Drl");
		}
		KnowledgeBuilderErrors errors = kbuilder.getErrors();
		if(errors.size()>0)
		{
			for(KnowledgeBuilderError error : errors)
			{
				logger.error(error);;
			}
			logger.info("Could not Parse Knowledge");
			throw new IllegalArgumentException("Could not Parse Knowledge");
		}
		KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();
		kbase.addKnowledgePackages(kbuilder.getKnowledgePackages());
		logger.info("Process Complete :- Method :- readKnowledgeBase");
		return kbase;
	}
	
	private void runningBackgroundProcessinsertEkudosValues(eKudosApiRequest apiRequest, EquidosTrackerDTO equidosTrackerHolderDTO)
	{
		try
		{
			logger.info("CameInside: runningBackgroundProcessinsertEkudosValues");
			ThreadContext.push(apiRequest.getHeader().getSoaCorrelationId());
			logger.info("runningBackgroundProcessinsertAadhaarValues : START");
			EkudosEntity entity=new EkudosEntity();
			entity.setEkudos_id(ekudosDbService.getEkudosSequenceValue());
			entity.seteKudosEarned(equidosTrackerHolderDTO.geteKudosEarned());
			entity.setTracker_id(""+System.currentTimeMillis());
			entity.setCorelation_id(equidosTrackerHolderDTO.getSoaCorrelationId());
			entity.setEventOccured(equidosTrackerHolderDTO.getEventOccured());
			entity.setCreateDate(equidosTrackerHolderDTO.getCreatedDate());
			entity.setUserName(equidosTrackerHolderDTO.getUserName());
			entity.setTitle(equidosTrackerHolderDTO.getTitle());
			entity.setCategory(equidosTrackerHolderDTO.getCategory());
			entity.setUpdated(equidosTrackerHolderDTO.getUpdated());
			entity.setEventName(equidosTrackerHolderDTO.getEventName());
			entity.setAppName(equidosTrackerHolderDTO.getAppName());
			entity.setAppType(equidosTrackerHolderDTO.getAppType());
			entity.setUpdated_time(new Date());
			entity.setCreated_time(new Date());
			entity.setRemark("service");
			ekudosDbService.save(entity);
			logger.info("GoingOutSide: runningBackgroundProcessinsertEkudosValues");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			ThreadContext.pop();
		}
	}

}
