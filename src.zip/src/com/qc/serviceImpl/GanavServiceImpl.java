package com.qc.serviceImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.api.common.MsgInfo;
import com.qc.api.request.current.nav.ApiRequestCurrentNav;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.response.StringConstants;
import com.qc.api.response.current.nav.ApiResponseCurrentNav;
import com.qc.api.response.current.nav.PayloadResCurrentNav;
import com.qc.api.response.current.nav.ResCurrentNav;
import com.qc.api.response.current.nav.ResponseCurrentNav;
import com.qc.api.response.fund.ApiResponseGAFundName;
import com.qc.api.response.fund.PayloadResGAFundName;
import com.qc.api.response.fund.ResGAFundDetails;
import com.qc.api.response.fund.ResponseGAFundName;
import com.qc.api.response.nav.ApiResponseNav;
import com.qc.api.response.nav.PayloadResNav;
import com.qc.api.response.nav.ResNav;
import com.qc.api.response.nav.ResponseNav;
import com.qc.api.response.plan.ApiResponsePlanName;
import com.qc.api.response.plan.PayloadResPlanName;
import com.qc.api.response.plan.ResPlanName;
import com.qc.api.response.plan.ResponsePlanName;
import com.qc.dao.FundDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;
import com.qc.service.GanavFundService;
import com.qc.service.ObjectToPojoService;

@Service
public class GanavServiceImpl implements GanavFundService
{
	private static Logger logger = LogManager.getLogger(GanavServiceImpl.class);

	@Autowired
	FundDao fundDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	public ApiResponseGAFundName getFundDetails() 
	{
		logger.info("fund Name service : Start");
		ApiResponseGAFundName response = new ApiResponseGAFundName();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseGAFundName responseFundName = new ResponseGAFundName();
		List<ResGAFundDetails> gnvaDetails = null;
		PayloadResGAFundName payloadResFundName=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");

			List navData = fundDao.getFundDetails();

			
			if(navData!=null)
			{
				if(!navData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(navData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResGAFundDetails>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResGAFundDetails agentDetail  = dozerBeanMapper.map(mapObj, ResGAFundDetails.class);
								gnvaDetails.add(agentDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResFundName=new PayloadResGAFundName();
						payloadResFundName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseFundName.setPayload(payloadResFundName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseFundName.setMsginfo(msginfo);
		responseFundName.setPayload(payloadResFundName);
		response.setResponse(responseFundName);
		logger.info("Fund Name service : End");
		return response;
	}

	@Override
	public ApiResponseNav getNavDetails(ApiRequestNav apiRequest) {

		logger.info("getNavDetails service : Start");
		ApiResponseNav response = new ApiResponseNav();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseNav responseFundName = new ResponseNav();
		List<ResNav> gnvaDetails = null;
		PR_GETAGNTINFO_TPP_NAV_DTLS req = null;
		PayloadResNav payloadResFundName=null;
		try 
		{
			req = new PR_GETAGNTINFO_TPP_NAV_DTLS();
			req.setPlanName(apiRequest.getRequest().getRequestData().getPlanName());
			req.setFromDate(apiRequest.getRequest().getRequestData().getFromDate());
			req.setToDate(apiRequest.getRequest().getRequestData().getToDate());
			logger.debug("Select data Call from service to Dao : Start");

			List navData = fundDao.getNavDetails(req);

			
			if(navData!=null)
			{
				if(!navData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(navData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResNav>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResNav navDetail  = dozerBeanMapper.map(mapObj, ResNav.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResFundName=new PayloadResNav();
						payloadResFundName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseFundName.setPayload(payloadResFundName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseFundName.setMsginfo(msginfo);
		responseFundName.setPayload(payloadResFundName);
		response.setResponse(responseFundName);
		logger.info("get Nav service : End");
		return response;
	
	}

	@Override
	public ApiResponsePlanName getPlanDetails() {


		logger.info("getPlanDetails service : Start");
		ApiResponsePlanName response = new ApiResponsePlanName();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponsePlanName responsePlanName = new ResponsePlanName();
		List<ResPlanName> gnvaDetails = null;
		PayloadResPlanName payloadResPlanName=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");
			List PlanData = fundDao.getPlanDetails();

			
			if(PlanData!=null)
			{
				if(!PlanData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(PlanData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResPlanName>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResPlanName navDetail  = dozerBeanMapper.map(mapObj, ResPlanName.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResPlanName=new PayloadResPlanName();
						payloadResPlanName.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responsePlanName.setPayload(payloadResPlanName);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responsePlanName.setMsginfo(msginfo);
		responsePlanName.setPayload(payloadResPlanName);
		response.setResponse(responsePlanName);
		logger.info("get Plan service : End");
		return response;
	
	
}

	@Override
	public ApiResponseCurrentNav getCurrentNavDetails(ApiRequestCurrentNav apiRequest) {


		logger.info("get CurrentNavDetails service : Start");
		ApiResponseCurrentNav response = new ApiResponseCurrentNav();
		MsgInfo msginfo = new MsgInfo();
		@SuppressWarnings("unused")
		ResponseCurrentNav responseCurrentNav = new ResponseCurrentNav();
		List<ResCurrentNav> gnvaDetails = null;
		PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req = null;
		PayloadResCurrentNav payloadResCurrentNav=null;
		try 
		{
			logger.debug("Select data Call from service to Dao : Start");
			req = new PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS();
			req.setPlanName(apiRequest.getRequest().getRequestData().getPlanName());
			
			List PlanData = fundDao.getCurrentNavDetails(req);

			
			if(PlanData!=null)
			{
				if(!PlanData.isEmpty())
				{
					List<Map<String , String>> result = objectToPojoService.getCustomClass(PlanData);
					if(result != null && !result.isEmpty())
					{
						gnvaDetails = new ArrayList<ResCurrentNav>();
						for(Map<?, ?> mapObj : result)
						{
							try
							{
								ResCurrentNav navDetail  = dozerBeanMapper.map(mapObj, ResCurrentNav.class);
								gnvaDetails.add(navDetail);
							}
							catch(Exception e)
							{
								logger.error("exception while parsing through dozer mapping :: "+e);
							}
						}
					}
					logger.debug("Select data Call from service to Dao : End");
					if(gnvaDetails!=null 
							&& !gnvaDetails.isEmpty()
							)
					{
						payloadResCurrentNav=new PayloadResCurrentNav();
						payloadResCurrentNav.setData(gnvaDetails);
						msginfo.setMsgCode(StringConstants.C200);
						msginfo.setMsg(StringConstants.SUCCESS);
						msginfo.setMsgDescription(StringConstants.C200DESC);
						responseCurrentNav.setPayload(payloadResCurrentNav);;
						logger.info(StringConstants.C200DESC);
					}
					else
					{   
						msginfo.setMsgCode(StringConstants.C500);
						msginfo.setMsg(StringConstants.FAILURE);
						msginfo.setMsgDescription(StringConstants.C500DESC);
						logger.info(StringConstants.C500DESC);
					}
				}
				else
				{
					//Data Not Found for Agent ID from Db and Process successfully executed so Success Response
					msginfo.setMsgCode(StringConstants.C500);
					msginfo.setMsg(StringConstants.FAILURE);
					msginfo.setMsgDescription(StringConstants.C500DESC);
					logger.info(StringConstants.C500DESC);
				}
			}
			
			else 
			{
				msginfo.setMsgCode(StringConstants.C500);
				msginfo.setMsg(StringConstants.FAILURE);
				msginfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
			}
		}
		catch (Exception e)
		{
			msginfo.setMsgCode(StringConstants.C500);
			msginfo.setMsg(StringConstants.FAILURE);
			msginfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCurrentNav.setMsginfo(msginfo);
		responseCurrentNav.setPayload(payloadResCurrentNav);
		response.setResponse(responseCurrentNav);
		logger.info("get CurrentNav service : End");
		return response;
	
	
}

}