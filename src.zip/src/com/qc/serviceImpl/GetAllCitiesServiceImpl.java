package com.qc.serviceImpl;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getallcities.ApiRequestGetAllCities;
import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getallcities.ApiResponseGetAllCities;
import com.qc.api.response.getallcities.PayloadResGetAllCities;
import com.qc.api.response.getallcities.ResGetAllCities;
import com.qc.api.response.getallcities.ResponseGetAllCities;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;
import com.qc.api.response.getmaxcities.PayloadResGetMaxCities;
import com.qc.api.response.getmaxcities.ResGetMaxCities;
import com.qc.api.response.getmaxcities.ResponseGetMaxCities;
import com.qc.dao.GetAllCitiesDao;
import com.qc.dao.GetMaxCitiesDao;
import com.qc.entity.PR_GETALLCITIES_DTLS;
import com.qc.entity.PR_GETMAXCITIES_DTLS;
import com.qc.service.GetAllCitiesService;
import com.qc.service.GetMaxCitiesService;
import com.qc.service.ObjectToPojoService;

@Service
public class GetAllCitiesServiceImpl implements GetAllCitiesService
{

	private static Logger logger = LogManager.getLogger(GetAllCitiesServiceImpl.class);

	@Autowired
	GetAllCitiesDao getAllCitiesDao;
	@Autowired
	ObjectToPojoService objectToPojoService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;

	@Override
	@Transactional
	public ApiResponseGetAllCities getAllCitiesDetails(ApiRequestGetAllCities apiRequest) {
		logger.info("getAllCitiesDetails service : Start");
		ApiResponseGetAllCities response = new ApiResponseGetAllCities();
		@SuppressWarnings("unused")
		PayloadResGetAllCities resPayload = null;
		ResponseGetAllCities responseCities = new ResponseGetAllCities();
		PR_GETALLCITIES_DTLS req = null;
		
		/*ResGetMaxCities claimedDetail=null;*/
		PayloadResGetAllCities citydetail= new PayloadResGetAllCities();
		try 
		{
			req = new PR_GETALLCITIES_DTLS();
			//req.setState(apiRequest.getRequest().getRequestData().getState());
			logger.debug("Going to call getAllCitiesService  from service to DB : Start");

			List citiesData =getAllCitiesDao.getAllCitiesService(req);
			if(citiesData!=null)
			{
				if(!citiesData.isEmpty())
				{
					List<ResGetAllCities> hashMap = new ArrayList<>();
					for(Object oo : citiesData)
					{
						ResGetAllCities cities =new ResGetAllCities();
						cities.setCity(oo.toString()); 
						hashMap.add(cities);
					}
					citydetail.setCities(hashMap);
					citydetail.setSoaMessage(StringConstants.SUCCESS);
					citydetail.setSoaStatusCode(StringConstants.C200);
					citydetail.setSoaDescription(StringConstants.C200DESC);
					
						logger.info(StringConstants.C200DESC);
					}
					else
					{
						citydetail.setSoaStatusCode(StringConstants.C200);
						citydetail.setSoaMessage(StringConstants.SUCCESS);
						citydetail.setSoaDescription(StringConstants.C700DESC);
						logger.info(StringConstants.C700DESC);
					}
				}
				else
				{
					citydetail.setSoaStatusCode(StringConstants.C601);
					citydetail.setSoaMessage(StringConstants.FAILURE);
					citydetail.setSoaDescription(StringConstants.C600DESC);
					logger.info(StringConstants.C600DESC);
				}
		}
		catch(Exception e)
		{
			citydetail.setSoaStatusCode(StringConstants.C500);
			citydetail.setSoaMessage(StringConstants.FAILURE);
			citydetail.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : "+e);
		}
		responseCities.setResponseData(citydetail);
		response.setResponse(responseCities);
		logger.info("getAllCitiesDetails service : End");
		return response;
	}


}
