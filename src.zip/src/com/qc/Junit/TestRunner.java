package com.qc.Junit;

import org.drools.command.assertion.AssertEquals;
import org.junit.Test;

import com.qc.api.common.HeaderNew;
import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.NotificationDetail.RequestNotificationDetails;
import com.qc.api.request.csg.NotificationDetail.RequestPayload;
import com.qc.api.response.csg.NotificationDetail.ApiResponseNotificationDetails;
import com.qc.controller.CsgController;

import junit.framework.Assert;

public class TestRunner {

	ApiRequestNotificationDetails apiReq = new ApiRequestNotificationDetails();
	ApiResponseNotificationDetails apiRes = new ApiResponseNotificationDetails();
	RequestNotificationDetails req = new RequestNotificationDetails();
	HeaderNew header = new HeaderNew();
	CsgController csg = new CsgController();
	RequestPayload payload = new RequestPayload();

	@Test
	public void testNotificationDetails() {
		payload.setAppId("");
		payload.setId("");
		header.setSoaAppId("CSG");
		header.setSoaCorrelationId("1234");
		req.setHeader(header);
		req.setPayload(payload);
		apiReq.setRequest(req);

		apiRes = csg.notificationDetails(apiReq);

		Assert.assertEquals("600", apiRes.getResponse().getMsgInfo().getMsgCode());

	}
	
	@Test
	public void testNotificationDetailsV2() {
		payload.setAppId("CSG");
		payload.setId("12334");
		header.setSoaAppId("CSG");
		header.setSoaCorrelationId("1234");
		req.setHeader(header);
		req.setPayload(payload);
		apiReq.setRequest(req);

		apiRes = csg.notificationDetails(apiReq);

		Assert.assertEquals("500", apiRes.getResponse().getMsgInfo().getMsgCode());

	}


}
