package com.qc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBHelperEappAnalytic 
{

	private static final Logger logger = LogManager.getLogger(DBHelperEappAnalytic.class);
	static ResourceBundle rs= ResourceBundle.getBundle("dbConfig");
	/*static String url="jdbc:oracle:thin:@172.23.51.161:1875:ELMT1";
	static String uname="eappanalyticuat";
	static String upass="eapp#123";
	static String driverClassName="oracle.jdbc.driver.OracleDriver";
*/
	
	/*static String url="jdbc:oracle:thin:@172.23.51.251:1875:ELMPRD";
	static String uname="eappanalyticprod";
	static String upass="eappprod#123";
	static String driverClassName="oracle.jdbc.driver.OracleDriver";*/
	
	static final String driverClassName = rs.getString("jdbc.driverClassName");  
	static final String url 	 = rs.getString("jdbc.url.eapp.analytic");
	static final String uname 	 = rs.getString("jdbc.username.eapp.analytic");
	static final String upass 	 = rs.getString("jdbc.password.eapp.analytic");
	
	
	 
	static
	{
		try
		{
			Class.forName(driverClassName);
		}
		catch(Exception ex)
		{
			logger.error(ex);
		}
	}

	public Connection getSourceConnection() throws SQLException
	{
		logger.debug("Inside getSourceConnection... Method");
		Connection con = null;		
		try
		{
			con = DriverManager.getConnection(url, uname, upass);
		}
		catch(Exception e)
		{ 
			logger.error("Error while getting connection from data source "+e);
		}
		logger.debug("Exiting getSourceConnection... Method");
		return con;
	}

	public static DBHelperEappAnalytic getInstance()
	{
		logger.debug("Inside getInstance... Method");
		DBHelperEappAnalytic helper = new DBHelperEappAnalytic();
		logger.debug("Exiting getInstance... Method");
		return helper;
	}
}




