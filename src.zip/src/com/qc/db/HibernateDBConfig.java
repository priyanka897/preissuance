package com.qc.db;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

/**
 * @author Akhi007
 *
 */
@Configuration
@ImportResource({ "classpath*:DataSource.xml", "classpath*:Hibernate.xml" })
@ComponentScan("com.qc")
@PropertySource({ "classpath:dbConfig.properties" })
public class HibernateDBConfig {

	/**
	 * 
	 */
	public HibernateDBConfig() {
		super();
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer properties() {
		final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
		return pspc;
	}
}
