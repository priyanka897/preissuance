package com.qc.db.dao;

import com.qc.common.db.util.GenericDAO;
import com.qc.entity.EkudosEntity;

public interface EkudosDbDao extends GenericDAO<EkudosEntity> {

	Long getEkudosSequenceValue();
	
	String getEkudosValue(String ssoId); 
	
	EkudosEntity getEqubosIdBySSOID(String ssoId);

}

