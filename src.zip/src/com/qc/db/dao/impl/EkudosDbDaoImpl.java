package com.qc.db.dao.impl;

import java.math.BigDecimal;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.qc.common.db.util.AbstractHibernateDAOImpl;
import com.qc.db.dao.EkudosDbDao;
import com.qc.entity.EkudosEntity;


@Repository
public class EkudosDbDaoImpl extends AbstractHibernateDAOImpl<EkudosEntity> implements EkudosDbDao {

	private static final Logger logger = LogManager.getLogger(EkudosDbDaoImpl.class);
	ResourceBundle res= ResourceBundle.getBundle("application");
	
	@Autowired
	Environment env;
	
	@Override
	protected Class<EkudosEntity> getTemplateClass() {
		return EkudosEntity.class;
	}
	
	
	@Override
	public Long getEkudosSequenceValue() {
		try 
		{
			Query query = getSession().createSQLQuery("select qc_ekudos_sequence.NEXTVAL from DUAL");
			query.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			return ((BigDecimal) query.uniqueResult()).longValue();
		}
		catch (Exception e) 
		{
			logger.error("Exception while generating Sequence number for Aadhar BIO : "+e);
		}
		return null;
	}
	
	public String getEkudosValue(String ssoId ) {
		try 
		{
			Criteria criteria = getSession().createCriteria(EkudosEntity.class)
					           .add(Restrictions.eq("userName", ssoId.trim()))
					           .setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
		    List<EkudosEntity> ekudosEntitylist=criteria.list();
			//EkudosEntity ekudosEntity = (EkudosEntity)criteria.uniqueResult();
			 int requiredvalue=0;
		    if(ekudosEntitylist != null){
			for(int i=0;i<ekudosEntitylist.size();i++)
			{
			  EkudosEntity entity=ekudosEntitylist.get(i);
			  try
			  {
			  requiredvalue=requiredvalue+Integer.parseInt(entity.geteKudosEarned());
			  }
			  catch(Exception ec)
			  {
				  logger.error("The ekudos earned not valid getEkudosValue()"+ec);
			  }
			  
			}
			
			return 	requiredvalue+"";
			
		    }else{
				return null;
			}
		}
		catch (Exception e) 
		{
			logger.error("Exception while generating Sequence number for Aadhar BIO : "+e);
		}
		return null;
	}
	
	

	@Override
	public EkudosEntity getEqubosIdBySSOID(String ssoId) {
		Criteria criteria = getSession().createCriteria(EkudosEntity.class)
				.add(Restrictions.eq("userName", ssoId.trim()));
		criteria.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
		EkudosEntity ekudosEntity = (EkudosEntity)criteria.uniqueResult();
		if(ekudosEntity != null){
			return ekudosEntity; 
		}
		return null;
	}

}
