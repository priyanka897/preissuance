package com.qc.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DBHelper 
{

	static Logger logger= LogManager.getLogger(DBHelper.class.getName());
	private static DBHelper instance=null;
	static ResourceBundle rs= ResourceBundle.getBundle("dbConfig");

	/**************** 1'ST DATABASE ***************/
	final String JDBC_DRIVER = rs.getString("jdbc.driverClassName");  
	static final String DB_URL 	= rs.getString("com.dbhelper.url");
	static final String USER 	= rs.getString("com.dbhelper.username");
	static final String PASS 	= rs.getString("com.dbhelper.password");

	public void init()
	{
		try
		{
			logger.debug("Executing Init method...");
			Class.forName(JDBC_DRIVER);
		}
		catch(Exception e)
		{
			logger.error("Error while loading JDBC Drier:"+e);
		}		
	}
	public Connection getSourceConnection() throws SQLException
	{
		Connection con = null;		
		try
		{
			logger.debug("Start getSourceConnection()...");
			String localPASS=getPassword(PASS);
			con = DriverManager.getConnection(DB_URL,USER,localPASS);
			con.getMetaData();
			if(con!=null)
			{
				con.setAutoCommit(true);
			}
		}
		catch(Exception e)
		{
			logger.error("Error while getting connection from data source "+e);
			throw new SQLException("Connection failed...");
		}
		logger.debug("End getSourceConnection()...");
		return con;
	}

	public static DBHelper getInstance()
	{
		if(instance == null)
		{
			logger.debug("Start getInstance()...");
			instance = new DBHelper();
			logger.debug("Initializing Instance.");

			instance.init();
		}
		logger.debug("End getInstance()...");
		return instance;
	}
	private String getPassword(String encPassword)
	{
		String password=null;

		try
		{
			StringEncrypter encrypter=new StringEncrypter();	
			password=encrypter.getPassword(encPassword);
		}
		catch(Exception e)
		{
			logger.debug("Error getPassword: "+e);
		}
		return password;
	}
}
