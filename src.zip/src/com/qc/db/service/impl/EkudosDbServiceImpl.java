package com.qc.db.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qc.common.db.util.AbstractGenericServiceImpl;
import com.qc.db.dao.EkudosDbDao;
import com.qc.db.service.EkudosDbservice;
import com.qc.entity.EkudosEntity;

@Service
@Transactional
public class EkudosDbServiceImpl extends AbstractGenericServiceImpl<EkudosDbDao, EkudosEntity> implements EkudosDbservice{

	@Autowired
	EkudosDbDao aadharOTPDbDao;

	@Override
	protected EkudosDbDao getDAO() {
		return aadharOTPDbDao;
	}

	@Override
	protected void setDAO(EkudosDbDao dao) {
		this.aadharOTPDbDao = dao;
	}

	@Override
	public Long getEkudosSequenceValue() {
		return getDAO().getEkudosSequenceValue();
	}

	@Override
	public EkudosEntity getEqubosIdBySSOID(String ssoId) {
		return  getDAO().getEqubosIdBySSOID(ssoId);
	}
	
	@Override
	public String getEkudosValue(String ssoId)
	{
		return getDAO().getEkudosValue(ssoId);
	}
	
	

}
