package com.qc.db.service;

import com.qc.common.db.util.GenericService;


import com.qc.db.dao.EkudosDbDao;
import com.qc.entity.EkudosEntity;

public interface EkudosDbservice extends GenericService<EkudosDbDao, EkudosEntity>{

	Long getEkudosSequenceValue();
	String getEkudosValue(String ssoId); 
	EkudosEntity getEqubosIdBySSOID(String ssoId);
}
