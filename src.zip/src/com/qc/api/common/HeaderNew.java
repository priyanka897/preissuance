package com.qc.api.common;

public class HeaderNew {
	private static final long serialVersionUID = 2504004817515934483L;
	private String soaAppId = "";
	private String soaCorrelationId = "";
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public HeaderNew() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HeaderNew(String soaAppId, String soaCorrelationId) {
		super();
		this.soaAppId = soaAppId;
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	@Override
	public String toString() {
		return "Header1 [soaAppId=" + soaAppId + ", soaCorrelationId=" + soaCorrelationId + "]";
	}

}
