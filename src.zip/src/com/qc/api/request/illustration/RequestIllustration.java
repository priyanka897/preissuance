package com.qc.api.request.illustration;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;

public class RequestIllustration implements Serializable {
	
	private static final long serialVersionUID = 4063792359550302082L;
	private HeaderNew header;
	private PayloadSetReqIllustration payload;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public PayloadSetReqIllustration getPayload() {
		return payload;
	}
	public void setPayload(PayloadSetReqIllustration payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestIllustration [header=" + header + ", payload=" + payload + "]";
	}
	public RequestIllustration(HeaderNew header, PayloadSetReqIllustration payload) {
		super();
		this.header = header;
		this.payload = payload;
	}
	public RequestIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
