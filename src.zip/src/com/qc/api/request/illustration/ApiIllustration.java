package com.qc.api.request.illustration;

import java.io.Serializable;


public class ApiIllustration implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private RequestIllustration request;
	public RequestIllustration getRequest() {
		return request;
	}
	public void setRequest(RequestIllustration request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiIllustration [request=" + request + "]";
	}
	public ApiIllustration(RequestIllustration request) {
		super();
		this.request = request;
	}
	public ApiIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}
}
