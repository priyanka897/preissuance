package com.qc.api.request.illustration;

import java.io.Serializable;

public class PayloadSetReqIllustration implements Serializable{
	
	
	private static final long serialVersionUID = 8748777980811121938L;
	
	

	private String policyNo;

	public String getPolicyNo() {
		return policyNo;
	}

	public PayloadSetReqIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Override
	public String toString() {
		return "PayloadSetReqNav [policyNo=" + policyNo + "]";
	}

	public PayloadSetReqIllustration(String policyNo) {
		super();
		this.policyNo = policyNo;
	}

	
	
	

}
