package com.qc.api.request.getstates;

import java.io.Serializable;

public class PayloadReqGetStates implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String  country;
	
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "PayloadReqGetStates [country=" + country + "]";
	}
	
}
