package com.qc.api.request.getstates;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetStates implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqGetStates requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetStates getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetStates requestData) {
		this.requestData = requestData;
	}
}
