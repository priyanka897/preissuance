package com.qc.api.request.getstates;

import java.io.Serializable;

public class ApiRequestGetStates implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetStates request;
	public ApiRequestGetStates() {
		super();
	}
	public ApiRequestGetStates(RequestGetStates request) {
		super();
		this.request = request;
	}
	public RequestGetStates getRequest() {
		return request;
	}
	public void setRequest(RequestGetStates request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetStates [request=" + request + "]";
	}
}
