package com.qc.api.request.plan;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.request.fund.PayloadReqFundName;

public class RequestPlanName implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "RequestPlanName [header=" + header + "]";
	}
}