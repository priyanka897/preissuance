package com.qc.api.request.plan;

import java.io.Serializable;

public class PayloadReqPlanName implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	

}