package com.qc.api.request.eKudos;

import java.io.Serializable;
import java.util.List;

public class BioApiReqPayload implements Serializable 
{
	private static final long serialVersionUID = 3007147797603226464L;
	
	List<BioApiReqTransaction> transaction;
	
	public List<BioApiReqTransaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<BioApiReqTransaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "RequestPayload [transaction=" + transaction + "]";
	}
	
}
