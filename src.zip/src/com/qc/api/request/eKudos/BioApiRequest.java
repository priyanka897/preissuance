package com.qc.api.request.eKudos;

import java.io.Serializable;

import com.qc.api.dto.ApiRequestHeader;

public class BioApiRequest implements Serializable
{
	private static final long serialVersionUID = 7204742726795390733L;
	
	ApiRequestHeader header;
	BioApiReqPayload payload;
	
	public ApiRequestHeader getHeader() {
		return header;
	}

	public void setHeader(ApiRequestHeader header) {
		this.header = header;
	}

	public BioApiReqPayload getPayload() {
		return payload;
	}

	public void setPayload(BioApiReqPayload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "ApiRequest [header=" + header + ", payload=" + payload + "]";
	}
}
