package com.qc.api.request.eKudos;

import java.io.Serializable;
import java.util.List;

public class eKudosApiReqPayload implements Serializable 
{
	private static final long serialVersionUID = 3007147797603226464L;
	
	List<EKudosApiReqTransaction> transactions;

	public List<EKudosApiReqTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<EKudosApiReqTransaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "eKudosApiReqPayload [transactions=" + transactions + "]";
	}

	
	
}
