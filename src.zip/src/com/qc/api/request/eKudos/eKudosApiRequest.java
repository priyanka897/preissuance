package com.qc.api.request.eKudos;

import java.io.Serializable;

import com.qc.api.dto.ApiRequestHeader;

public class eKudosApiRequest implements Serializable
{
	private static final long serialVersionUID = 7204742726795390733L;
	
	ApiRequestHeader header;
	eKudosApiReqPayload payload;
	
	public ApiRequestHeader getHeader() {
		return header;
	}
	public void setHeader(ApiRequestHeader header) {
		this.header = header;
	}
	public eKudosApiReqPayload getPayload() {
		return payload;
	}
	public void setPayload(eKudosApiReqPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "EkudosApiRequest [header=" + header + ", payload=" + payload + "]";
	}
	
	

}
