package com.qc.api.request.eKudos;

public class OtpApiReqTransaction 
{
	String aadhaarNumber;
	String requestType;
	String policyno;
	String otp;
	String type;
	
	public String getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	public String getPolicyno() {
		return policyno;
	}
	public void setPolicyno(String policyno) {
		this.policyno = policyno;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "OtpApiReqTransaction [aadhaarNumber=" + aadhaarNumber + ", requestType=" + requestType + ", policyno="
				+ policyno + ", otp=" + otp + ", type=" + type + "]";
	}
	
}
