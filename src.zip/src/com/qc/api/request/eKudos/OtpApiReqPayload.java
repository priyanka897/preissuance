package com.qc.api.request.eKudos;

import java.io.Serializable;
import java.util.List;

public class OtpApiReqPayload implements Serializable 
{
	private static final long serialVersionUID = 3007147797603226464L;
	
	List<OtpApiReqTransaction> transaction;
	
	public List<OtpApiReqTransaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<OtpApiReqTransaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "OtpApiReqPayload [transaction=" + transaction + "]";
	}
	
	
}
