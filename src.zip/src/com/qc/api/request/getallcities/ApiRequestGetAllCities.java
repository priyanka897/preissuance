package com.qc.api.request.getallcities;

import java.io.Serializable;

public class ApiRequestGetAllCities implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetAllCities request;
	public ApiRequestGetAllCities() {
		super();
	}
	public ApiRequestGetAllCities(RequestGetAllCities request) {
		super();
		this.request = request;
	}
	public RequestGetAllCities getRequest() {
		return request;
	}
	public void setRequest(RequestGetAllCities request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetAllCities [request=" + request + "]";
	}
}
