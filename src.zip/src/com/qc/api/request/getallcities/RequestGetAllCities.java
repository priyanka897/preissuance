package com.qc.api.request.getallcities;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetAllCities implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqGetAllCities requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetAllCities getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetAllCities requestData) {
		this.requestData = requestData;
	}
}
