package com.qc.api.request.getcountry;

import java.io.Serializable;

public class ApiRequestGetCountry implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetCountry request;
	public ApiRequestGetCountry() {
		super();
	}
	public ApiRequestGetCountry(RequestGetCountry request) {
		super();
		this.request = request;
	}
	public RequestGetCountry getRequest() {
		return request;
	}
	public void setRequest(RequestGetCountry request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetCountry [request=" + request + "]";
	}
}
