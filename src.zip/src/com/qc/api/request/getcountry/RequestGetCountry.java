package com.qc.api.request.getcountry;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetCountry implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqGetCountry requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetCountry getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetCountry requestData) {
		this.requestData = requestData;
	}
}
