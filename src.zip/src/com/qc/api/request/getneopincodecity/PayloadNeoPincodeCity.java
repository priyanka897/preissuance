package com.qc.api.request.getneopincodecity;

import java.util.List;

public class PayloadNeoPincodeCity {
	
	private List<String> productCode;
	
	private String pincode;


	public List<String> getProductCode() {
		return productCode;
	}

	public void setProductCode(List<String> productCode) {
		this.productCode = productCode;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

		
	
}
