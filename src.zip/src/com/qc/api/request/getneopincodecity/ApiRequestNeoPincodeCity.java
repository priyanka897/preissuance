package com.qc.api.request.getneopincodecity;

public class ApiRequestNeoPincodeCity {

	private RequestNeoPincodeCity request;

	public RequestNeoPincodeCity getRequest() {
		return request;
	}

	public void setRequest(RequestNeoPincodeCity request) {
		this.request = request;
	}
	
	
	
}
