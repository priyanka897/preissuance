package com.qc.api.request.getneopincodecity;

import com.qc.api.common.HeaderNew;

public class RequestNeoPincodeCity {
	
	private HeaderNew header;
	
	private PayloadNeoPincodeCity payload;

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public PayloadNeoPincodeCity getPayload() {
		return payload;
	}

	public void setPayload(PayloadNeoPincodeCity payload) {
		this.payload = payload;
	}


		

}
