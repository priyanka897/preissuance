package com.qc.api.request.eCube;

import java.io.Serializable;

public class ChatbotPayloadRequest implements Serializable
{
	private static final long serialVersionUID = -9093418057925904507L;
	private String segment;
	private String ssoid;
	private String channel;
	private String designationDesc;
	private String subChannel;
	private String zone;
	private String region;
	private String circle;
	private String cluster;
	private String go;
	private String cmo;
	private String amo;
	private String planType;
	public String getSegment() {
		return segment;
	}
	public void setSegment(String segment) {
		this.segment = segment;
	}
	public String getSsoid() {
		return ssoid;
	}
	public void setSsoid(String ssoid) {
		this.ssoid = ssoid;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getDesignationDesc() {
		return designationDesc;
	}
	public void setDesignationDesc(String designationDesc) {
		this.designationDesc = designationDesc;
	}
	public String getSubChannel() {
		return subChannel;
	}
	public void setSubChannel(String subChannel) {
		this.subChannel = subChannel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getCluster() {
		return cluster;
	}
	public void setCluster(String cluster) {
		this.cluster = cluster;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	@Override
	public String toString() {
		return "ChatbotPayloadRequest [segment=" + segment + ", ssoid=" + ssoid + ", channel=" + channel
				+ ", designationDesc=" + designationDesc + ", subChannel=" + subChannel + ", zone=" + zone + ", region="
				+ region + ", circle=" + circle + ", cluster=" + cluster + ", go=" + go + ", cmo=" + cmo + ", amo="
				+ amo + ", planType=" + planType + "]";
	}
}
