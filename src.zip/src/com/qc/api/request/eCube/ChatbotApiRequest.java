package com.qc.api.request.eCube;

import java.io.Serializable;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.qc.common.dto.UserInfo;


public class ChatbotApiRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5785952532670461473L;
	private UserInfo header;
	private ChatbotPayloadRequest payload;

	public UserInfo getHeader() {
		return header;
	}

	public void setHeader(UserInfo header) {
		this.header = header;
	}

	public ChatbotPayloadRequest getPayload() {
		return payload;
	}

	public void setPayload(ChatbotPayloadRequest payload) {
		this.payload = payload;
	}

	public ChatbotApiRequest(UserInfo header, ChatbotPayloadRequest payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public ChatbotApiRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
