package com.qc.api.request.getplanname;

import java.io.Serializable;

public class PayloadReqGetPlan implements Serializable 
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String plancategory;
	
	public String getPlancategory() {
		return plancategory;
	}

	public void setPlancategory(String plancategory) {
		this.plancategory = plancategory;
	}

	@Override
	public String toString() {
		return "PayloadReqGetPlan [plancategory=" + plancategory + "]";
	}
}
