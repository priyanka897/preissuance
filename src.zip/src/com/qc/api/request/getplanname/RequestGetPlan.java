package com.qc.api.request.getplanname;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetPlan implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private Header header;
	private PayloadReqGetPlan requestData;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetPlan getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetPlan requestData) {
		this.requestData = requestData;
	}
	@Override
	public String toString() {
		return "RequestGetPlan [header=" + header + ", requestData=" + requestData + "]";
	}
	
}
