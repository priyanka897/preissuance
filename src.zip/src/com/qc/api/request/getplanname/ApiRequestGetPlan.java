package com.qc.api.request.getplanname;

import java.io.Serializable;

public class ApiRequestGetPlan implements Serializable{

	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetPlan request;
	public ApiRequestGetPlan() {
		super();
	}
	public ApiRequestGetPlan(RequestGetPlan request) {
		super();
		this.request = request;
	}
	public RequestGetPlan getRequest() {
		return request;
	}
	public void setRequest(RequestGetPlan request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetPlan [request=" + request + "]";
	}
	
	
}
