package com.qc.api.request.csg.listOfNotificationV2;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class RequestListOfNotificationV2 implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private PayloadListOfNotificationV2 payload;

	public RequestListOfNotificationV2() {
		super();
	}

	public RequestListOfNotificationV2(HeaderNew header, PayloadListOfNotificationV2 payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public PayloadListOfNotificationV2 getPayload() {
		return payload;
	}

	public void setPayload(PayloadListOfNotificationV2 payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestListOfNotificationV2 [header=" + header + ", payload=" + payload + "]";
	}

}
