package com.qc.api.request.csg.listOfNotificationV2;

import java.io.Serializable;

public class ApiRequestListOfNotificationV2 implements Serializable {
	private static final long serialVersionUID = 1L;
	private RequestListOfNotificationV2 request;

	public ApiRequestListOfNotificationV2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiRequestListOfNotificationV2(RequestListOfNotificationV2 request) {
		super();
		this.request = request;
	}

	public RequestListOfNotificationV2 getRequest() {
		return request;
	}

	public void setRequest(RequestListOfNotificationV2 request) {
		this.request = request;
	}

	@Override
	public String toString() {
		return "ApiRequestListOfNotificationV2 [request=" + request + "]";
	}

}
