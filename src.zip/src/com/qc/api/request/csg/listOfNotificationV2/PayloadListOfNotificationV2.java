package com.qc.api.request.csg.listOfNotificationV2;

import java.io.Serializable;

public class PayloadListOfNotificationV2 implements Serializable {

	private static final long serialVersionUID = 1L;
	private String agentId;
	private String appId;

	public PayloadListOfNotificationV2() {
		super();
	}

	@Override
	public String toString() {
		return "PayloadListOfNotificationV2 [agentId=" + agentId + ", appId=" + appId + "]";
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public PayloadListOfNotificationV2(String agentId, String appId) {
		super();
		this.agentId = agentId;
		this.appId = appId;
	}

}
