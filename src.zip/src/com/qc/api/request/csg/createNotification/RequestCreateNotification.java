package com.qc.api.request.csg.createNotification;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class RequestCreateNotification implements Serializable {

	private static final long serialVersionUID = 1L;

	private HeaderNew header;
	private CreateNotificationPayload payload;

	public RequestCreateNotification(HeaderNew header, CreateNotificationPayload payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public RequestCreateNotification() {
		super();
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public CreateNotificationPayload getPayload() {
		return payload;
	}

	public void setPayload(CreateNotificationPayload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestCreateNotification [header=" + header + ", payload=" + payload + "]";
	}

}
