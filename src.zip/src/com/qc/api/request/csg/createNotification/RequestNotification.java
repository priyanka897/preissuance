package com.qc.api.request.csg.createNotification;

import java.io.Serializable;
import java.util.List;

public class RequestNotification implements Serializable {

	private static final long serialVersionUID = 1L;

	private String summary;
	private String details;
	private List<RequestAgents> agents;

	public RequestNotification() {
		super();
	}

	public RequestNotification(String summary, String details, List<RequestAgents> agents) {
		super();
		this.summary = summary;
		this.details = details;
		this.agents = agents;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public List<RequestAgents> getAgents() {
		return agents;
	}

	public void setAgents(List<RequestAgents> agents) {
		this.agents = agents;
	}

	@Override
	public String toString() {
		return "RequestNotification [summary=" + summary + ", details=" + details + ", agents=" + agents + "]";
	}

}
