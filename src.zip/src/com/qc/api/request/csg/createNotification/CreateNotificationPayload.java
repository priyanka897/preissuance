package com.qc.api.request.csg.createNotification;

import java.io.Serializable;
import java.util.List;

public class CreateNotificationPayload implements Serializable {

	private static final long serialVersionUID = 1L;

	private String document;
	private String documentType;
	private String publishDate;
	private String status;
	private String appId;
	private String type;
	private List<RequestNotification> notification;

	public CreateNotificationPayload() {
		super();
	}

	public CreateNotificationPayload(String document, String documentType, String publishDate, String status, String appId, String type, List<RequestNotification> notification) {
		super();
		this.document = document;
		this.documentType = documentType;
		this.publishDate = publishDate;
		this.status = status;
		this.appId = appId;
		this.type = type;
		this.notification = notification;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<RequestNotification> getNotification() {
		return notification;
	}

	public void setNotification(List<RequestNotification> notification) {
		this.notification = notification;
	}

	@Override
	public String toString() {
		return "CreateNotificationPayload [document=" + document + ", documentType=" + documentType + ", publishDate=" + publishDate + ", status=" + status + ", appId=" + appId + ", type=" + type + ", notification=" + notification + "]";
	}

}
