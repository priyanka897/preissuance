package com.qc.api.request.csg.createNotification;

import java.io.Serializable;

public class RequestAgents implements Serializable {

	private static final long serialVersionUID = 1L;
	private String agentId;

	public RequestAgents() {
		super();
	}

	public RequestAgents(String agentId) {
		super();
		this.agentId = agentId;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	@Override
	public String toString() {
		return "RequestAgents [agentId=" + agentId + "]";
	}

}
