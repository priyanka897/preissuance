package com.qc.api.request.csg.createNotification;

import java.io.Serializable;

public class ApiRequestCreateNotification implements Serializable {

	private static final long serialVersionUID = 1L;

	private RequestCreateNotification request;

	public ApiRequestCreateNotification() {
		super();
	}

	public ApiRequestCreateNotification(RequestCreateNotification request) {
		super();
		this.request = request;
	}

	public RequestCreateNotification getRequest() {
		return request;
	}

	public void setRequest(RequestCreateNotification request) {
		this.request = request;
	}

	@Override
	public String toString() {
		return "RequestCreateNotification [request=" + request + "]";
	}

}
