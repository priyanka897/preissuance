package com.qc.api.request.csg.NotificationDetail;

import java.io.Serializable;

public class ApiRequestNotificationDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private RequestNotificationDetails request;

	public ApiRequestNotificationDetails() {
		super();
	}

	public ApiRequestNotificationDetails(RequestNotificationDetails request) {
		super();
		this.request = request;
	}

	public RequestNotificationDetails getRequest() {
		return request;
	}

	public void setRequest(RequestNotificationDetails request) {
		this.request = request;
	}

	@Override
	public String toString() {
		return "ApiRequestNotificationDetails [request=" + request + "]";
	}

}
