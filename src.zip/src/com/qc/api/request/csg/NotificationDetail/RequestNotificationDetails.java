package com.qc.api.request.csg.NotificationDetail;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class RequestNotificationDetails implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private RequestPayload payload;

	public RequestNotificationDetails() {
		super();
	}

	public RequestNotificationDetails(HeaderNew header, RequestPayload payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public RequestPayload getPayload() {
		return payload;
	}

	public void setPayload(RequestPayload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestNotificationDetails [header=" + header + ", payload=" + payload + "]";
	}

}
