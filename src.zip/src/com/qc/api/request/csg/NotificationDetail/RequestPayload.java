package com.qc.api.request.csg.NotificationDetail;

import java.io.Serializable;

public class RequestPayload implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String appId;

	public RequestPayload() {
		super();
	}

	@Override
	public String toString() {
		return "RequestPayload [id=" + id + ", appId=" + appId + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public RequestPayload(String id, String appId) {
		super();
		this.id = id;
		this.appId = appId;
	}

}
