package com.qc.api.request.csg.updateNotificationReadStatus;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class RequestUpdateNotificationReadStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private HeaderNew header;
	private PayloadUpdateNotificationReadStatus payload;

	public RequestUpdateNotificationReadStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RequestUpdateNotificationReadStatus(HeaderNew header, PayloadUpdateNotificationReadStatus payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public PayloadUpdateNotificationReadStatus getPayload() {
		return payload;
	}

	public void setPayload(PayloadUpdateNotificationReadStatus payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestUpdateNotificationReadStatus [header=" + header + ", payload=" + payload + "]";
	}

}
