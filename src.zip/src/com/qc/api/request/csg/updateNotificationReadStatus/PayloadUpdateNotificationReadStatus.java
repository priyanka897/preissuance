package com.qc.api.request.csg.updateNotificationReadStatus;

import java.io.Serializable;

public class PayloadUpdateNotificationReadStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private String agentId;
	private String id;
	private String appId;

	public PayloadUpdateNotificationReadStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayloadUpdateNotificationReadStatus(String agentId, String id, String appId) {
		super();
		this.agentId = agentId;
		this.id = id;
		this.appId = appId;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	@Override
	public String toString() {
		return "PayloadUpdateNotificationReadStatus [agentId=" + agentId + ", id=" + id + ", appId=" + appId + "]";
	}

}
