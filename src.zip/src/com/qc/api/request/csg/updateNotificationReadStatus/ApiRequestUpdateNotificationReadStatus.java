package com.qc.api.request.csg.updateNotificationReadStatus;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class ApiRequestUpdateNotificationReadStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private RequestUpdateNotificationReadStatus request;

	public ApiRequestUpdateNotificationReadStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiRequestUpdateNotificationReadStatus(RequestUpdateNotificationReadStatus request) {
		super();
		this.request = request;
	}

	public RequestUpdateNotificationReadStatus getRequest() {
		return request;
	}

	public void setRequest(RequestUpdateNotificationReadStatus request) {
		this.request = request;
	}

	@Override
	public String toString() {
		return "ApiRequestUpdateNotificationReadStatus [request=" + request + "]";
	}

}
