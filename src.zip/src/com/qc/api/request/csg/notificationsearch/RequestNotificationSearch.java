package com.qc.api.request.csg.notificationsearch;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class RequestNotificationSearch implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadNotificationSearch payload;

	public RequestNotificationSearch() {
		super();
	}

	public RequestNotificationSearch(HeaderNew header, MsgInfo msgInfo, PayloadNotificationSearch payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public PayloadNotificationSearch getPayload() {
		return payload;
	}

	public void setPayload(PayloadNotificationSearch payload) {
		this.payload = payload;
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	@Override
	public String toString() {
		return "RequestNotificationSearch [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}

}
