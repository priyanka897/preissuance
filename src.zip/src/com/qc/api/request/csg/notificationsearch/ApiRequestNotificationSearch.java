package com.qc.api.request.csg.notificationsearch;

import java.io.Serializable;

public class ApiRequestNotificationSearch implements Serializable {

	private static final long serialVersionUID = 1L;
	private RequestNotificationSearch request;

	public ApiRequestNotificationSearch() {
		super();
	}

	public ApiRequestNotificationSearch(RequestNotificationSearch request) {
		super();
		this.request = request;
	}

	public RequestNotificationSearch getRequest() {
		return request;
	}

	public void setRequest(RequestNotificationSearch request) {
		this.request = request;
	}

	@Override
	public String toString() {
		return "ApiRequestNotificationSearch [request=" + request + "]";
	}

}
