package com.qc.api.request.csg.updateNotification;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class ApiRequestUpdateNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	private RequestUpdateNotification request;
	private HeaderNew header;

	public ApiRequestUpdateNotification() {
		super();
	}

	public ApiRequestUpdateNotification(RequestUpdateNotification request, HeaderNew header) {
		super();
		this.request = request;
		this.header = header;
	}

	public RequestUpdateNotification getRequest() {
		return request;
	}

	public void setRequest(RequestUpdateNotification request) {
		this.request = request;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return "ApiRequestUpdateNotification [request=" + request + ", header=" + header + "]";
	}

}
