package com.qc.api.request.csg.updateNotification;

import java.io.Serializable;
import java.util.List;

public class UpdateNotificationPayload implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String document;
	private String documentType;
	private String publishDate;
	private String status;
	private String type;
	private String appId;
	private String creationType;
	private String notificationSummary;
	private String notificationDetails;
	private List<Agents> agents;

	public UpdateNotificationPayload() {
		super();
	}

	public UpdateNotificationPayload(String id, String document, String documentType, String publishDate, String status, String type, String appId, String creationType, String notificationSummary, String notificationDetails, List<Agents> agents) {
		super();
		this.id = id;
		this.document = document;
		this.documentType = documentType;
		this.publishDate = publishDate;
		this.status = status;
		this.type = type;
		this.appId = appId;
		this.creationType = creationType;
		this.notificationSummary = notificationSummary;
		this.notificationDetails = notificationDetails;
		this.agents = agents;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getCreationType() {
		return creationType;
	}

	public void setCreationType(String creationType) {
		this.creationType = creationType;
	}

	public String getNotificationSummary() {
		return notificationSummary;
	}

	public void setNotificationSummary(String notificationSummary) {
		this.notificationSummary = notificationSummary;
	}

	public String getNotificationDetails() {
		return notificationDetails;
	}

	public void setNotificationDetails(String notificationDetails) {
		this.notificationDetails = notificationDetails;
	}

	public List<Agents> getAgents() {
		return agents;
	}

	public void setAgents(List<Agents> agents) {
		this.agents = agents;
	}

	@Override
	public String toString() {
		return "UpdateNotificationPayload [id=" + id + ", document=" + document + ", documentType=" + documentType + ", publishDate=" + publishDate + ", status=" + status + ", type=" + type + ", appId=" + appId + ", creationType=" + creationType
				+ ", notificationSummary=" + notificationSummary + ", notificationDetails=" + notificationDetails + ", agents=" + agents + "]";
	}

}
