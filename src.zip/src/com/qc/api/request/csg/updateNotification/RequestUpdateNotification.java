package com.qc.api.request.csg.updateNotification;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;

public class RequestUpdateNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private UpdateNotificationPayload payload;

	public RequestUpdateNotification() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RequestUpdateNotification(HeaderNew header, UpdateNotificationPayload payload) {
		super();
		this.header = header;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public UpdateNotificationPayload getPayload() {
		return payload;
	}

	public void setPayload(UpdateNotificationPayload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestUpdateNotification [header=" + header + ", payload=" + payload + "]";
	}

}
