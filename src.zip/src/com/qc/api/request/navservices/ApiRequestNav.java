package com.qc.api.request.navservices;

import java.io.Serializable;

public class ApiRequestNav implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestNav request;
	public ApiRequestNav() {
		super();
	}
	public ApiRequestNav(RequestNav request) {
		super();
		this.request = request;
	}
	public RequestNav getRequest() {
		return request;
	}
	public void setRequest(RequestNav request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestNav [request=" + request + "]";
	}
}
