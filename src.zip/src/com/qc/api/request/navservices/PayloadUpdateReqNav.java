package com.qc.api.request.navservices;

import java.io.Serializable;

public class PayloadUpdateReqNav implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private String policyid;
	private String smsstatus;
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	public String getSmsstatus() {
		return smsstatus;
	}
	public void setSmsstatus(String smsstatus) {
		this.smsstatus = smsstatus;
	}
}
