package com.qc.api.request.navservices;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestNav implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqNav requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqNav getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqNav requestData) {
		this.requestData = requestData;
	}
}
