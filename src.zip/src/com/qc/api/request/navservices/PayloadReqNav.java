package com.qc.api.request.navservices;

import java.io.Serializable;

public class PayloadReqNav implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String  policyid;
	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	@Override
	public String toString() {
		return "PayloadReqNav [policyid=" + policyid + "]";
	}
}
