package com.qc.api.request.navservices;

import java.io.Serializable;

public class ApiUpdateRequestNav implements Serializable{
	private static final long serialVersionUID = 4063792359550302082L;
	private RequestUpdateNav request;
	public RequestUpdateNav getRequest() {
		return request;
	}
	public void setRequest(RequestUpdateNav request) {
		this.request = request;
	}
}
