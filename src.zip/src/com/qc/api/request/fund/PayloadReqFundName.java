package com.qc.api.request.fund;

import java.io.Serializable;

public class PayloadReqFundName implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	
}
