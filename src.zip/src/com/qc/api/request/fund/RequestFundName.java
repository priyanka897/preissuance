package com.qc.api.request.fund;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestFundName implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "RequestFundName [header=" + header + "]";
	}
}
