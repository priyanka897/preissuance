package com.qc.api.request.getmaxcities;

import java.io.Serializable;

public class ApiRequestGetMaxCities implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetMaxCities request;
	public ApiRequestGetMaxCities() {
		super();
	}
	public ApiRequestGetMaxCities(RequestGetMaxCities request) {
		super();
		this.request = request;
	}
	public RequestGetMaxCities getRequest() {
		return request;
	}
	public void setRequest(RequestGetMaxCities request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetMaxCities [request=" + request + "]";
	}
}
