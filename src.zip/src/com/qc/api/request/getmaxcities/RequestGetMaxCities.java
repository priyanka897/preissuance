package com.qc.api.request.getmaxcities;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetMaxCities implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqGetMaxCities requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetMaxCities getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetMaxCities requestData) {
		this.requestData = requestData;
	}
}
