package com.qc.api.request.upcomingdue;

import java.io.Serializable;

public class PayloadUpcomingDue implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String agentId;
	private String fromRec;
	private String toRec;
	

	public String getFromRec() {
		return fromRec;
	}
	public void setFromRec(String fromRec) {
		this.fromRec = fromRec;
	}
	public String getToRec() {
		return toRec;
	}
	public void setToRec(String toRec) {
		this.toRec = toRec;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	@Override
	public String toString() {
		return "PayloadUpcomingDue [agentId=" + agentId + ", fromRec=" + fromRec + ", toRec=" + toRec + "]";
	}
	
	
}
