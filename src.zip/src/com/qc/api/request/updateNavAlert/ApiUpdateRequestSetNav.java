package com.qc.api.request.updateNavAlert;

import java.io.Serializable;


public class ApiUpdateRequestSetNav implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private RequestSetNav request;
	public RequestSetNav getRequest() {
		return request;
	}
	public void setRequest(RequestSetNav request) {
		this.request = request;
	}

}
