package com.qc.api.request.updateNavAlert;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;

public class RequestSetNav implements Serializable {
	
	private static final long serialVersionUID = 4063792359550302082L;
	private HeaderNew header;
	private PayloadSetReqNav payload;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public PayloadSetReqNav getPayload() {
		return payload;
	}
	public void setPayload(PayloadSetReqNav payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestSetNav [header=" + header + ", payload=" + payload + "]";
	}
	public RequestSetNav(HeaderNew header, PayloadSetReqNav payload) {
		super();
		this.header = header;
		this.payload = payload;
	}
	public RequestSetNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
