package com.qc.api.request.updateNavAlert;

import java.io.Serializable;

public class PayloadSetReqNav implements Serializable{
	public PayloadSetReqNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PayloadSetReqNav(String transactionType, String policyNo) {
		super();
		this.transactionType = transactionType;
		this.policyNo = policyNo;
	}
	private static final long serialVersionUID = 8748777980811121938L;
	
	private String transactionType;
	private String policyNo;
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	@Override
	public String toString() {
		return "PayloadSetReqNav [transactionType=" + transactionType + ", policyNo=" + policyNo + "]";
	}
	

}
