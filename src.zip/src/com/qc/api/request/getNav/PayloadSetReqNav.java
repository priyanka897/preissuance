package com.qc.api.request.getNav;

import java.io.Serializable;

public class PayloadSetReqNav implements Serializable{
	
	
	private static final long serialVersionUID = 8748777980811121938L;
	
	public PayloadSetReqNav(String policyNo) {
		super();
		this.policyNo = policyNo;
	}

	private String policyNo;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Override
	public String toString() {
		return "PayloadSetReqNav [policyNo=" + policyNo + "]";
	}

	public PayloadSetReqNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
