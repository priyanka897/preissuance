package com.qc.api.request.getNav;

import java.io.Serializable;


public class ApiGetNav implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private RequestSetNav request;
	public ApiGetNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApiGetNav(RequestSetNav request) {
		super();
		this.request = request;
	}
	public RequestSetNav getRequest() {
		return request;
	}
	public void setRequest(RequestSetNav request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiGetNav [request=" + request + "]";
	}

}
