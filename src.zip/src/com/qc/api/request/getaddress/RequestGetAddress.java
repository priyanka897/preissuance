package com.qc.api.request.getaddress;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetAddress implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private Header header;
	private PayloadReqGetAddress requestData;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetAddress getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetAddress requestData) {
		this.requestData = requestData;
	}
	@Override
	public String toString() {
		return "RequestGetAddress [header=" + header + ", requestData=" + requestData + "]";
	}
	
}
