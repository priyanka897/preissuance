package com.qc.api.request.getaddress;

import java.io.Serializable;

public class ApiRequestGetAddress implements Serializable{

	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetAddress request;
	public ApiRequestGetAddress() {
		super();
	}
	public ApiRequestGetAddress(RequestGetAddress request) {
		super();
		this.request = request;
	}
	public RequestGetAddress getRequest() {
		return request;
	}
	public void setRequest(RequestGetAddress request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetAddress [request=" + request + "]";
	}
	
	
}
