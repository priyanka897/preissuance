package com.qc.api.request.getaddress;

import java.io.Serializable;

public class PayloadReqGetAddress implements Serializable 
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String state;
	private String city;
	private String pinCode;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "PayloadReqGetAddress [state=" + state + ", city=" + city + ", pinCode=" + pinCode + "]";
	}
}
