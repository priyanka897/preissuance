package com.qc.api.request.nav;

import java.io.Serializable;

public class PayloadReqNav implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	
	private String planName;
	private String fromDate;
	private String toDate;
	private String  policyid;

	public String getPolicyid() {
		return policyid;
	}
	public void setPolicyid(String policyid) {
		this.policyid = policyid;
	}
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	@Override
	public String toString() {
		return "PayloadReqNav [planName=" + planName + ", fromDate=" + fromDate + ", toDate=" + toDate + ", policyid="
				+ policyid + "]";
	}
	
}
