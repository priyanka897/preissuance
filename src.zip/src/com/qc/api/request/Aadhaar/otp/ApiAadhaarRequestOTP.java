package com.qc.api.request.Aadhaar.otp;

import java.io.Serializable;

import com.qc.api.request.navservices.RequestNav;

public class ApiAadhaarRequestOTP implements Serializable {
	
	private static final long serialVersionUID = -494503845107919013L;
	
	private RequestAadhaarotp request;

	public RequestAadhaarotp getRequest() {
		return request;
	}

	public void setRequest(RequestAadhaarotp request) {
		this.request = request;
	}

	public ApiAadhaarRequestOTP(RequestAadhaarotp request) {
		super();
		this.request = request;
	}

	public ApiAadhaarRequestOTP() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiAadhaarRequestOTP [request=" + request + "]";
	}



}
