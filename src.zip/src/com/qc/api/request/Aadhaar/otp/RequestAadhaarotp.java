package com.qc.api.request.Aadhaar.otp;

import java.io.Serializable;
import com.qc.api.common.Aadhaar.Header;

public class RequestAadhaarotp implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadAadhaarotp payload;
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadAadhaarotp getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaarotp payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestAadhaarotp [header=" + header + ", payload=" + payload + "]";
	} 
	
	
}
