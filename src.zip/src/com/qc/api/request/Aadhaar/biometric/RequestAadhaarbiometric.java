package com.qc.api.request.Aadhaar.biometric;

import java.io.Serializable;

import com.qc.api.common.Aadhaar.Header;

public class RequestAadhaarbiometric implements Serializable {
	
	private Header header;
	private PayloadAadhaarbiometric payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadAadhaarbiometric getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaarbiometric payload) {
		this.payload = payload;
	}
	
	
	@Override
	public String toString() {
		return "RequestAadhaarbiometric [header=" + header + ", payload=" + payload + "]";
	}
}
