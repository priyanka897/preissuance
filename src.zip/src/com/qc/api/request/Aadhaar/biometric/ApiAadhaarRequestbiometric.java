package com.qc.api.request.Aadhaar.biometric;

import java.io.Serializable;

import com.qc.api.request.Aadhaar.otp.RequestAadhaarotp;

public class ApiAadhaarRequestbiometric implements Serializable {
	private static final long serialVersionUID = -494503845107919013L;
	private RequestAadhaarbiometric request;
}
