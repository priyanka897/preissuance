package com.qc.api.request.Aadhaar.biometric;

import java.io.Serializable;

import com.qc.api.request.Aadhaar.otp.RequestAadhaarotp;

public class ApiAadhaarRequestbiometric implements Serializable {
	private static final long serialVersionUID = -494503845107919013L;
	private RequestAadhaarbiometric request;
	public RequestAadhaarbiometric getRequest() {
		return request;
	}
	public void setRequest(RequestAadhaarbiometric request) {
		this.request = request;
	}
	public ApiAadhaarRequestbiometric(RequestAadhaarbiometric request) {
		super();
		this.request = request;
	}
	public ApiAadhaarRequestbiometric() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ApiAadhaarRequestbiometric [request=" + request + "]";
	}
	
	
}
