package com.qc.api.request.countofnotification;

import java.io.Serializable;


import org.codehaus.jackson.annotate.JsonProperty;

import com.qc.api.common.Header;

public class ApiRequestCountOfNotification implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private Header header;
	@JsonProperty("requestData")
	private PayloadReqCountOfNotification request;
	public ApiRequestCountOfNotification() {
		super();
	}
	public ApiRequestCountOfNotification(Header header, PayloadReqCountOfNotification request) {
		super();
		this.header = header;
		this.request = request;
	}
	public PayloadReqCountOfNotification getRequest() {
		return request;
	}
	public void setRequest(PayloadReqCountOfNotification request) {
		this.request = request;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "ApiRequestCountOfNotification [header=" + header + ", request=" + request + "]";
	}
}
