package com.qc.api.request.countofnotification;

import java.io.Serializable;

public class PayloadReqCountOfNotification implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "PayloadReqCountOfNotification [userId=" + userId + "]";
	}
}
