package com.qc.api.request.getneftdetails;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;

public class PayloadReqNeftDetails implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	
	private String policyNo;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	
}
