package com.qc.api.request.getneftdetails;

import java.io.Serializable;


public class ApiRequestNeftDetails implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestNeftDetails request;
	public ApiRequestNeftDetails() {
		super();
	}
	public ApiRequestNeftDetails( RequestNeftDetails request) {
		super();
		this.request = request;
	}
	public RequestNeftDetails getRequest() {
		return request;
	}
	public void setRequest(RequestNeftDetails request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestPDFByte [ request=" + request + "]";
	}
}
