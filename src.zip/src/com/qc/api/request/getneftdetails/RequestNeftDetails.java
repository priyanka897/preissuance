package com.qc.api.request.getneftdetails;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;

public class RequestNeftDetails implements Serializable {

	
	private static final long serialVersionUID = 4063792359550302082L;
	
	private HeaderNew header;
	private PayloadReqNeftDetails payload;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public PayloadReqNeftDetails getPayload() {
		return payload;
	}
	public void setPayload(PayloadReqNeftDetails payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestPreissuance [header=" + header + ", payload=" + payload + "]";
	}
	
}
