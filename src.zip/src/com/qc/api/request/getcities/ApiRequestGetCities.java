package com.qc.api.request.getcities;

import java.io.Serializable;

public class ApiRequestGetCities implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestGetCities request;
	public ApiRequestGetCities() {
		super();
	}
	public ApiRequestGetCities(RequestGetCities request) {
		super();
		this.request = request;
	}
	public RequestGetCities getRequest() {
		return request;
	}
	public void setRequest(RequestGetCities request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestGetCities [request=" + request + "]";
	}
}
