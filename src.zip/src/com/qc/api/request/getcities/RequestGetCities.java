package com.qc.api.request.getcities;

import java.io.Serializable;

import com.qc.api.common.Header;

public class RequestGetCities implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqGetCities requestData;
	public Header getHeader()
	{
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadReqGetCities getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqGetCities requestData) {
		this.requestData = requestData;
	}
}
