package com.qc.api.request.getcities;

import java.io.Serializable;

public class PayloadReqGetCities implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	private String  state;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	@Override
	public String toString() {
		return "PayloadReqGetCities [state=" + state + "]";
	}
	
}
