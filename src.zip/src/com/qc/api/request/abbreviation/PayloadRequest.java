package com.qc.api.request.abbreviation;

import java.io.Serializable;

public class PayloadRequest implements Serializable{

	private static final long serialVersionUID = -5528549712306019582L;
	AbbreviationRequest transactions;
	
	public AbbreviationRequest getTransactions() {
		return transactions;
	}
	public void setTransactions(AbbreviationRequest transactions) {
		this.transactions = transactions;
	}
	
}
