package com.qc.api.request.abbreviation;

import java.io.Serializable;

public class AbbreviationRequest implements Serializable{

	private static final long serialVersionUID = -1308398421387455637L;
	private String ssoid;
	private String shortform;
	private String fullform;
	private String description;
	private String department;
	private String requestType;
	public String getSsoid() {
		ssoid=ssoid.toUpperCase();
		return ssoid;
	}
	public void setSsoid(String ssoid) {
		this.ssoid = ssoid;
	}
	public String getShortform() {
		shortform=shortform.toUpperCase();
		return shortform;
	}
	public void setShortform(String shortform) {
		this.shortform = shortform;
	}
	public String getFullform() {
		return fullform;
	}
	public void setFullform(String fullform) {
		this.fullform = fullform;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDepartment() {
		department=department.toUpperCase();
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getRequestType() {
		return requestType;
	}
	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	

	
	
}
