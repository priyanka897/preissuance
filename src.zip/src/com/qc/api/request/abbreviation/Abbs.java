package com.qc.api.request.abbreviation;

import java.io.Serializable;

public class Abbs implements Serializable{

	private static final long serialVersionUID = 5507582893905596218L;
	private String sn;
	private String shortform;
	private String fullform;
	private String department;
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getShortform() {
		return shortform;
	}
	public void setShortform(String shortform) {
		this.shortform = shortform;
	}
	public String getFullform() {
		return fullform;
	}
	public void setFullform(String fullform) {
		this.fullform = fullform;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Abbs() {
		super();
	}
	@Override
	public String toString() {
		return "Abbs [sn=" + sn + ", shortform=" + shortform + ", fullform=" + fullform + ", department=" + department
				+ "]";
	}
	
}
