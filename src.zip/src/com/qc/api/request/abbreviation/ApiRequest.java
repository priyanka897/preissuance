package com.qc.api.request.abbreviation;

import java.io.Serializable;

public class ApiRequest implements Serializable {

	private static final long serialVersionUID = 5005359232736592603L;
	HeaderRequest header;
	PayloadRequest payload;
	
	
	public ApiRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HeaderRequest getHeader() {
		return header;
	}
	public void setHeader(HeaderRequest header) {
		this.header = header;
	}
	public PayloadRequest getPayload() {
		return payload;
	}
	public void setPayload(PayloadRequest payload) {
		this.payload = payload;
	}
	public ApiRequest(HeaderRequest header, PayloadRequest payload) {
		super();
		this.header = header;
		this.payload = payload;
	}
	 
	
}
