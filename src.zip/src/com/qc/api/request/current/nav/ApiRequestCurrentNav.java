package com.qc.api.request.current.nav;

import java.io.Serializable;

import com.qc.api.request.plan.RequestPlanName;

public class ApiRequestCurrentNav implements Serializable
{
	private static final long serialVersionUID = -494503845107919013L;
	private RequestCurrentNav request;
	public ApiRequestCurrentNav() {
		super();
	}
	public ApiRequestCurrentNav(RequestCurrentNav request) {
		super();
		this.request = request;
	}
	public RequestCurrentNav getRequest() {
		return request;
	}
	public void setRequest(RequestCurrentNav request) {
		this.request = request;
	}
	@Override
	public String toString() {
		return "ApiRequestNav [request=" + request + "]";
	}
}