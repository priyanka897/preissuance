package com.qc.api.request.current.nav;

import java.io.Serializable;

public class PayloadReqCurrentNav implements Serializable
{
	private static final long serialVersionUID = -8326680316578158270L;
	
	private String planCode;
    private String navFromDate;
    private String navToDate;
    private String planName;
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getNavFromDate() {
		return navFromDate;
	}
	public void setNavFromDate(String navFromDate) {
		this.navFromDate = navFromDate;
	}
	public String getNavToDate() {
		return navToDate;
	}
	public void setNavToDate(String navToDate) {
		this.navToDate = navToDate;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	@Override
	public String toString() {
		return "PayloadReqCurrentNav [planCode=" + planCode + ", navFromDate=" + navFromDate + ", navToDate="
				+ navToDate + ", planName=" + planName + "]";
	}
}
