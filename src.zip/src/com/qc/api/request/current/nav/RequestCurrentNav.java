package com.qc.api.request.current.nav;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.request.plan.PayloadReqPlanName;

public class RequestCurrentNav implements Serializable
{
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadReqCurrentNav requestData;
	
	
	public PayloadReqCurrentNav getRequestData() {
		return requestData;
	}
	public void setRequestData(PayloadReqCurrentNav requestData) {
		this.requestData = requestData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	@Override
	public String toString() {
		return "RequestPlanName [header=" + header + ", requestData=" + requestData + "]";
	}
}
