package com.qc.api.request.Aadhaardemograph;

import java.io.Serializable;

public class ApiAadhaarRequestdemograph implements Serializable {
	private static final long serialVersionUID = -494503845107919013L;
	
	private RequestAadhaardemograph request;

	public RequestAadhaardemograph getRequest() {
		return request;
	}

	public void setRequest(RequestAadhaardemograph request) {
		this.request = request;
	}

	public ApiAadhaarRequestdemograph(RequestAadhaardemograph request) {
		super();
		this.request = request;
	}

	public ApiAadhaarRequestdemograph() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiAadhaarRequestdemograph [request=" + request + "]";
	}

	
	
}
