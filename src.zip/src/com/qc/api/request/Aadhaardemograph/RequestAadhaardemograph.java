package com.qc.api.request.Aadhaardemograph;

import java.io.Serializable;

import com.qc.api.common.Aadhaar.Header;


public class RequestAadhaardemograph implements Serializable {
	private static final long serialVersionUID = 4063792359550302082L;
	private Header header;
	private PayloadAadhaardemograph payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadAadhaardemograph getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaardemograph payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "RequestAadhaardemograph [header=" + header + ", payload=" + payload + "]";
	}
	
	
}
