package com.qc.api.request.Aadhaardemograph;

import java.io.Serializable;

public class PayloadAadhaardemograph implements Serializable{
	private static final long serialVersionUID = -8326680316578158270L;
	
	private String  aadhaarNumber;
	private String  name;
	private String  gender;
	private String  dob;
	private String  house;
	private String  street;
	private String  landmark ;
	private String  location;
	private String  pinCode;
	private String  postOffice;
	private String  villCity;
	private String  subDist;
	private String  dist;
	private String  state;
	private String  type;
	
	
	
	
	
	public PayloadAadhaardemograph() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PayloadAadhaardemograph(String aadhaarNumber, String name, String gender, String dob, String house, String street, String landmark, String location, String pinCode, String postOffice, String villCity, String subDist, String dist,
			String state, String type) {
		super();
		this.aadhaarNumber = aadhaarNumber;
		this.name = name;
		this.gender = gender;
		this.dob = dob;
		this.house = house;
		this.street = street;
		this.landmark = landmark;
		this.location = location;
		this.pinCode = pinCode;
		this.postOffice = postOffice;
		this.villCity = villCity;
		this.subDist = subDist;
		this.dist = dist;
		this.state = state;
		this.type = type;
	}
	public String getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPostOffice() {
		return postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public String getVillCity() {
		return villCity;
	}
	public void setVillCity(String villCity) {
		this.villCity = villCity;
	}
	public String getSubDist() {
		return subDist;
	}
	public void setSubDist(String subDist) {
		this.subDist = subDist;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "PayloadAadhaardemograph [aadhaarNumber=" + aadhaarNumber + ", name=" + name + ", gender=" + gender + ", dob=" + dob + ", house=" + house + ", street=" + street + ", landmark=" + landmark + ", location=" + location + ", pinCode="
				+ pinCode + ", postOffice=" + postOffice + ", villCity=" + villCity + ", subDist=" + subDist + ", dist=" + dist + ", state=" + state + ", type=" + type + "]";
	}
	
	
	
	
}
