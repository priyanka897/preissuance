package com.qc.api.dto;

public class PushNotificationBean {

	
	private String hrSSOId;
	private String managerSSOId;
	private String nomineeSSOId;
	
	private String hrDeviceId;
	private String managerDeviceId;
	private String nomineeDeviceId;
	
	private String hrDeviceType;
	private String managerDeviceType;
	private String nomineeDeviceType;
	
	
	
	public String getHrSSOId() {
		return hrSSOId;
	}
	public void setHrSSOId(String hrSSOId) {
		this.hrSSOId = hrSSOId;
	}
	public String getManagerSSOId() {
		return managerSSOId;
	}
	public void setManagerSSOId(String managerSSOId) {
		this.managerSSOId = managerSSOId;
	}
	public String getNomineeSSOId() {
		return nomineeSSOId;
	}
	public void setNomineeSSOId(String nomineeSSOId) {
		this.nomineeSSOId = nomineeSSOId;
	}
	public String getHrDeviceId() {
		return hrDeviceId;
	}
	public void setHrDeviceId(String hrDeviceId) {
		this.hrDeviceId = hrDeviceId;
	}
	public String getManagerDeviceId() {
		return managerDeviceId;
	}
	public void setManagerDeviceId(String managerDeviceId) {
		this.managerDeviceId = managerDeviceId;
	}
	public String getNomineeDeviceId() {
		return nomineeDeviceId;
	}
	public void setNomineeDeviceId(String nomineeDeviceId) {
		this.nomineeDeviceId = nomineeDeviceId;
	}
	public String getHrDeviceType() {
		return hrDeviceType;
	}
	public void setHrDeviceType(String hrDeviceType) {
		this.hrDeviceType = hrDeviceType;
	}
	public String getManagerDeviceType() {
		return managerDeviceType;
	}
	public void setManagerDeviceType(String managerDeviceType) {
		this.managerDeviceType = managerDeviceType;
	}
	public String getNomineeDeviceType() {
		return nomineeDeviceType;
	}
	public void setNomineeDeviceType(String nomineeDeviceType) {
		this.nomineeDeviceType = nomineeDeviceType;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PushNotificationBean [hrSSOId=");
		builder.append(hrSSOId);
		builder.append(", managerSSOId=");
		builder.append(managerSSOId);
		builder.append(", nomineeSSOId=");
		builder.append(nomineeSSOId);
		builder.append(", hrDeviceId=");
		builder.append(hrDeviceId);
		builder.append(", managerDeviceId=");
		builder.append(managerDeviceId);
		builder.append(", nomineeDeviceId=");
		builder.append(nomineeDeviceId);
		builder.append(", hrDeviceType=");
		builder.append(hrDeviceType);
		builder.append(", managerDeviceType=");
		builder.append(managerDeviceType);
		builder.append(", nomineeDeviceType=");
		builder.append(nomineeDeviceType);
		builder.append("]");
		return builder.toString();
	}
}
