package com.qc.api.dto;

public enum STATUSCODE {

}
