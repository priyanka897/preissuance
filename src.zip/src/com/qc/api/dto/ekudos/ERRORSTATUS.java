package com.qc.api.dto.ekudos;

public enum ERRORSTATUS {

	SUCCESS,FAILURE
}
