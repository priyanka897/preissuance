package com.qc.api.dto.ekudos;

public enum STATUSCODE {

}
