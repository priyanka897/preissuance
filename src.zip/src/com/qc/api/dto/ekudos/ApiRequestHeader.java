package com.qc.api.dto.ekudos;

import java.io.Serializable;

public class ApiRequestHeader implements Serializable 
{
	private static final long serialVersionUID = 1852507492942611519L;
	String soaMsgVersion = "";
	String soaAppId = "";
	String creationTime="";
	String soaCorrelationId = "";
	String soaUserId = "";
	String soaPassword = "";
	
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getSoaUserId() {
		return soaUserId;
	}
	public void setSoaUserId(String soaUserId) {
		this.soaUserId = soaUserId;
	}
	public String getSoaPassword() {
		return soaPassword;
	}
	public void setSoaPassword(String soaPassword) {
		this.soaPassword = soaPassword;
	}
	@Override
	public String toString() {
		return "ApiRequestHeader [soaMsgVersion=" + soaMsgVersion + ", soaAppId=" + soaAppId + ", creationTime="
				+ creationTime + ", soaCorrelationId=" + soaCorrelationId + ", soaUserId=" + soaUserId
				+ ", soaPassword=" + soaPassword + "]";
	}
	
}
