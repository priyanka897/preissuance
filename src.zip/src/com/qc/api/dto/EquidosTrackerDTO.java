package com.qc.api.dto;

public class EquidosTrackerDTO 
{
	private String soaCorrelationId;
	private String eventOccured; 
	private String createdDate;                    
	private String eventName;  
	private String userName;
	private String title;
	private String category;
	
	private String updated;
	private String eKudosEarned;
	private String appName;
	private String appType;
	
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
	public String getEventOccured() {
		return eventOccured;
	}
	public void setEventOccured(String eventOccured) {
		this.eventOccured = eventOccured;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getUpdated() {
		return updated;
	}
	public void setUpdated(String updated) {
		this.updated = updated;
	}
	
	public String geteKudosEarned() {
		return eKudosEarned;
	}
	public void seteKudosEarned(String eKudosEarned) {
		this.eKudosEarned = eKudosEarned;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppType() {
		return appType;
	}
	public void setAppType(String appType) {
		this.appType = appType;
	}
	@Override
	public String toString() {
		return "EquidosTrackerDTO [soaCorrelationId=" + soaCorrelationId + ", eventOccured=" + eventOccured
				+ ", createdDate=" + createdDate + ", eventName=" + eventName + ", userName=" + userName + ", title="
				+ title + ", category=" + category + ", updated=" + updated + ", eKudosEarned=" + eKudosEarned + ",appName="+appName+",appType="+appType+"]";
	}
}
