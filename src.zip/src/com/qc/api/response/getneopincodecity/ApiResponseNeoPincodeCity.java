package com.qc.api.response.getneopincodecity;

public class ApiResponseNeoPincodeCity {

	private ResponseNeoPincodeCity response;

	public ResponseNeoPincodeCity getResponse() {
		return response;
	}

	public void setResponse(ResponseNeoPincodeCity response) {
		this.response = response;
	}

	public ApiResponseNeoPincodeCity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseNeoPincodeCity(ResponseNeoPincodeCity response) {
		super();
		this.response = response;
	}

	
}
