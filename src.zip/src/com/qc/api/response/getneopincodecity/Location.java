package com.qc.api.response.getneopincodecity;

public class Location {

	private String city;
	private String stateCode;
	private String stateName;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	@Override
	public String toString() {
		return "Location [city=" + city + ", stateCode=" + stateCode + ", stateName=" + stateName + "]";
	}
	
	
	
}
