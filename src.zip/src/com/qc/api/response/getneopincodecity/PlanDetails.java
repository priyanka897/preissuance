package com.qc.api.response.getneopincodecity;

public class PlanDetails {

	private String planName;
	private String isPinCodeValid;
	private String medicalCentresAvailability;
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getIsPinCodeValid() {
		return isPinCodeValid;
	}
	public void setIsPinCodeValid(String isPinCodeValid) {
		this.isPinCodeValid = isPinCodeValid;
	}
	public String getMedicalCentresAvailability() {
		return medicalCentresAvailability;
	}
	public void setMedicalCentresAvailability(String medicalCentresAvailability) {
		this.medicalCentresAvailability = medicalCentresAvailability;
	}
	
	
	
	
}
