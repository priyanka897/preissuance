package com.qc.api.response.getneopincodecity;

import java.util.List;

public class PayloadNeoPincodeCity {
	
	private List<PlanDetails> planDetails;

	private String isNegativeArea;
	
	private List<Location> location;

	public List<PlanDetails> getPlanDetails() {
		return planDetails;
	}

	public void setPlanDetails(List<PlanDetails> planDetails) {
		this.planDetails = planDetails;
	}

	public String getIsNegativeArea() {
		return isNegativeArea;
	}

	public void setIsNegativeArea(String isNegativeArea) {
		this.isNegativeArea = isNegativeArea;
	}

	public List<Location> getLocation() {
		return location;
	}

	public void setLocation(List<Location> location) {
		this.location = location;
	}
	
	
}
