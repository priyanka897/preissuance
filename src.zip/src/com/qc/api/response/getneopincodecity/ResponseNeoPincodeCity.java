package com.qc.api.response.getneopincodecity;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponseNeoPincodeCity 
{
	
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadNeoPincodeCity payload;

	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadNeoPincodeCity getPayload() {
		return payload;
	}
	public void setPayload(PayloadNeoPincodeCity payload) {
		this.payload = payload;
	}
	
	public ResponseNeoPincodeCity(HeaderNew header, MsgInfo msgInfo, PayloadNeoPincodeCity payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	
	public ResponseNeoPincodeCity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
