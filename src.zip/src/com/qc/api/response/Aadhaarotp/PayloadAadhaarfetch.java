package com.qc.api.response.Aadhaarotp;

import java.io.Serializable;

public class PayloadAadhaarfetch  implements Serializable{
	private static final long serialVersionUID = -2407302032173574993L;
	
	private String statusCode;
	private String statusDesc;
	private String message;
	private String name;
	private String gender;
	private String tokenNo;
	private String status;
	private String aadharNo;
	private String dob;
	private String phone;
	private String email;
	private String careOf;
	private String house;
	private String street;
	private String landmark;
	private String location;
	private String pinCode;
	private String postOffice;
	private String villCity;
	private String subDist;
	private String dist;
	private String state;
	private String image;
	private String pdffile;
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getTokenNo() {
		return tokenNo;
	}
	public void setTokenNo(String tokenNo) {
		this.tokenNo = tokenNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCareOf() {
		return careOf;
	}
	public void setCareOf(String careOf) {
		this.careOf = careOf;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPostOffice() {
		return postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public String getVillCity() {
		return villCity;
	}
	public void setVillCity(String villCity) {
		this.villCity = villCity;
	}
	public String getSubDist() {
		return subDist;
	}
	public void setSubDist(String subDist) {
		this.subDist = subDist;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPdffile() {
		return pdffile;
	}
	public void setPdffile(String pdffile) {
		this.pdffile = pdffile;
	}
	public PayloadAadhaarfetch(String statusCode, String statusDesc, String message, String name, String gender, String tokenNo, String status, String aadharNo, String dob, String phone, String email, String careOf, String house, String street,
			String landmark, String location, String pinCode, String postOffice, String villCity, String subDist, String dist, String state, String image, String pdffile) {
		super();
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
		this.message = message;
		this.name = name;
		this.gender = gender;
		this.tokenNo = tokenNo;
		this.status = status;
		this.aadharNo = aadharNo;
		this.dob = dob;
		this.phone = phone;
		this.email = email;
		this.careOf = careOf;
		this.house = house;
		this.street = street;
		this.landmark = landmark;
		this.location = location;
		this.pinCode = pinCode;
		this.postOffice = postOffice;
		this.villCity = villCity;
		this.subDist = subDist;
		this.dist = dist;
		this.state = state;
		this.image = image;
		this.pdffile = pdffile;
	}
	public PayloadAadhaarfetch() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PayloadAadhaarfetch [statusCode=" + statusCode + ", statusDesc=" + statusDesc + ", message=" + message + ", name=" + name + ", gender=" + gender + ", tokenNo=" + tokenNo + ", status=" + status + ", aadharNo=" + aadharNo + ", dob="
				+ dob + ", phone=" + phone + ", email=" + email + ", careOf=" + careOf + ", house=" + house + ", street=" + street + ", landmark=" + landmark + ", location=" + location + ", pinCode=" + pinCode + ", postOffice=" + postOffice
				+ ", villCity=" + villCity + ", subDist=" + subDist + ", dist=" + dist + ", state=" + state + ", image=" + image + ", pdffile=" + pdffile + "]";
	}
	
	
	
	
}
