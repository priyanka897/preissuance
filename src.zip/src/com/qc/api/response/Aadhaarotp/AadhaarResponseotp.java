package com.qc.api.response.Aadhaarotp;

import java.io.Serializable;

import com.qc.api.common.Aadhaar.Header;
import com.qc.api.common.Aadhaar.MsgInfo;



public class AadhaarResponseotp implements Serializable {
	private static final long serialVersionUID = 8748777980811121938L;
	
	private Header header;
	private MsgInfo msgInfo;
	private PayloadAadhaarotp payload;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadAadhaarotp getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaarotp payload) {
		this.payload = payload;
	}
	public AadhaarResponseotp(Header header, MsgInfo msgInfo, PayloadAadhaarotp payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	public AadhaarResponseotp() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "AadhaarResponseotp [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
	
	
	
}
