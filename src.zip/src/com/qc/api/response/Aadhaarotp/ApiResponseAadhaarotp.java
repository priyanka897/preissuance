package com.qc.api.response.Aadhaarotp;

import java.io.Serializable;

public class ApiResponseAadhaarotp implements Serializable{
	
	private AadhaarResponseotp response;

	public AadhaarResponseotp getResponse() {
		return response;
	}

	public void setResponse(AadhaarResponseotp response) {
		this.response = response;
	}

	
	public ApiResponseAadhaarotp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseAadhaarotp(AadhaarResponseotp response) {
		super();
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseAadhaarotp [response=" + response + "]";
	}

	
	
}
