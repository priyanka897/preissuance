package com.qc.api.response.Aadhaarotp;

import java.io.Serializable;

public class PayloadAadhaarotp implements Serializable{

	private static final long serialVersionUID = -2407302032173574993L;
	
	private String statusCode;
	private String statusDesc;
	private String message;
	private String status;
	
	
	
	public PayloadAadhaarotp(String statusCode, String statusDesc, String message, String status) {
		super();
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
		this.message = message;
		this.status = status;
	}
	
	
	
	
	public PayloadAadhaarotp() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "PayloadAadhaarotp [statusCode=" + statusCode + ", statusDesc=" + statusDesc + ", message=" + message + ", status=" + status + "]";
	}
	
	
	
	
}
