package com.qc.api.response.getneftdetails;

import java.io.Serializable;

public class ApiResponseNeftDetails implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseNeftDetails response;

	public ApiResponseNeftDetails() {
		super();
	}
	public ApiResponseNeftDetails(ResponseNeftDetails response) {
		super();
		this.response = response;
	}
	public ResponseNeftDetails getResponse() {
		return response;
	}
	public void setResponse(ResponseNeftDetails response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponsePDFByte [response=" + response + "]";
	}
}
