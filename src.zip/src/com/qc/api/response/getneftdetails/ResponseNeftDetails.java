package com.qc.api.response.getneftdetails;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponseNeftDetails implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadResNeftDetails payload;
	
	public ResponseNeftDetails() {
		super();
	}
	public ResponseNeftDetails(HeaderNew header, MsgInfo msgInfo, PayloadResNeftDetails payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadResNeftDetails getPayload() {
		return payload;
	}
	public void setPayload(PayloadResNeftDetails payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponsePreissuance [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
}
