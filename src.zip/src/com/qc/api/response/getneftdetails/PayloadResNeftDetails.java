package com.qc.api.response.getneftdetails;

import java.io.Serializable;
import java.util.List;

public class PayloadResNeftDetails implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	
	private String policyNo;
	private String bankAccountNo;
	private String bankAccountType;
	private String micrCode;
	private String ifscCode;
	private String accountHolderName;
	private String ownerClientAccount;
	private String refundMethod;
	
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public String getBankAccountType() {
		return bankAccountType;
	}
	public void setBankAccountType(String bankAccountType) {
		this.bankAccountType = bankAccountType;
	}
	public String getMicrCode() {
		return micrCode;
	}
	public void setMicrCode(String micrCode) {
		this.micrCode = micrCode;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getOwnerClientAccount() {
		return ownerClientAccount;
	}
	public void setOwnerClientAccount(String ownerClientAccount) {
		this.ownerClientAccount = ownerClientAccount;
	}
	public String getRefundMethod() {
		return refundMethod;
	}
	public void setRefundMethod(String refundMethod) {
		this.refundMethod = refundMethod;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
}
