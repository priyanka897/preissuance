package com.qc.api.response.current.nav;

import java.io.Serializable;

import java.util.List;


public class PayloadResCurrentNav implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private List<ResCurrentNav> data;

	public List<ResCurrentNav> getData() {
		return data;
	}

	public void setData(List<ResCurrentNav> data) {
		this.data = data;
	}
	
}
