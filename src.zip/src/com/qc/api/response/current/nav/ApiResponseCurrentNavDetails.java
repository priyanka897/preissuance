package com.qc.api.response.current.nav;

import java.io.Serializable;



public class ApiResponseCurrentNavDetails implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseCurrentNavDetails response;

	public ApiResponseCurrentNavDetails() {
		super();
	}
	public ApiResponseCurrentNavDetails(ResponseCurrentNavDetails response) {
		super();
		this.response = response;
	}
	public ResponseCurrentNavDetails getResponse() {
		return response;
	}
	public void setResponse(ResponseCurrentNavDetails response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
