package com.qc.api.response.current.nav;

import java.io.Serializable;


import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponseCurrentNavDetails implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msginfo;
	private PayloadResCurrentNavDetails payload;
	
	public ResponseCurrentNavDetails(){
		super();
	}
	public ResponseCurrentNavDetails(Header header, MsgInfo msginfo, PayloadResCurrentNavDetails payload) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.payload = payload;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public PayloadResCurrentNavDetails getPayload() {
		return payload;
	}
	public void setPayload(PayloadResCurrentNavDetails payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponseNav [header=" + header + ", msginfo=" + msginfo + ", payload=" + payload + "]";
	}
	
}
