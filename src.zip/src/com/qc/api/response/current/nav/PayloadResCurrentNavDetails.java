package com.qc.api.response.current.nav;

import java.io.Serializable;

import java.util.List;


public class PayloadResCurrentNavDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7436776414708207056L;
	private List<ResCurrentNavDetails> data;

	public List<ResCurrentNavDetails> getData() {
		return data;
	}

	public void setData(List<ResCurrentNavDetails> data) {
		this.data = data;
	}
	
}
