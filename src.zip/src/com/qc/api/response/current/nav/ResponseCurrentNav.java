package com.qc.api.response.current.nav;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.response.plan.PayloadResPlanName;

public class ResponseCurrentNav implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msginfo;
	private PayloadResCurrentNav payload;
	
	public ResponseCurrentNav(){
		super();
	}
	public ResponseCurrentNav(Header header, MsgInfo msginfo, PayloadResCurrentNav payload) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.payload = payload;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public PayloadResCurrentNav getPayload() {
		return payload;
	}
	public void setPayload(PayloadResCurrentNav payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponseNav [header=" + header + ", msginfo=" + msginfo + ", payload=" + payload + "]";
	}
	
}
