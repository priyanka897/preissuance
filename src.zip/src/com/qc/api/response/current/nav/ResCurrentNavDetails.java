package com.qc.api.response.current.nav;

import java.io.Serializable;

public class ResCurrentNavDetails implements Serializable
{
	private static final long serialVersionUID = 7944256957582040213L;
	private String planCode;
	private String planName;
	private String planStartDate;
	private String fundName;
	private String fundStartDate;
	private String navSellingPrice;
	private String navPurchasePrice;
	private String navEffectiveDate;
    private String sfinNo;
	
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanStartDate() {
		return planStartDate;
	}
	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	public String getFundStartDate() {
		return fundStartDate;
	}
	public void setFundStartDate(String fundStartDate) {
		this.fundStartDate = fundStartDate;
	}
	public String getNavSellingPrice() {
		return navSellingPrice;
	}
	public void setNavSellingPrice(String navSellingPrice) {
		this.navSellingPrice = navSellingPrice;
	}
	public String getNavPurchasePrice() {
		return navPurchasePrice;
	}
	public void setNavPurchasePrice(String navPurchasePrice) {
		this.navPurchasePrice = navPurchasePrice;
	}
	public String getNavEffectiveDate() {
		return navEffectiveDate;
	}
	public void setNavEffectiveDate(String navEffectiveDate) {
		this.navEffectiveDate = navEffectiveDate;
	}
	public String getSfinNo() {
		return sfinNo;
	}
	public void setSfinNo(String sfinNo) {
		this.sfinNo = sfinNo;
	}
	@Override
	public String toString() {
		return "ResCurrentNavDetails [planCode=" + planCode + ", planName=" + planName + ", planStartDate="
				+ planStartDate + ", fundName=" + fundName + ", fundStartDate=" + fundStartDate + ", navSellingPrice="
				+ navSellingPrice + ", navPurchasePrice=" + navPurchasePrice + ", navEffectiveDate=" + navEffectiveDate
				+ "]";
	}

}
