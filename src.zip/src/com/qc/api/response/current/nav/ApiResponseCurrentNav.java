package com.qc.api.response.current.nav;

import java.io.Serializable;

import com.qc.api.response.plan.ResponsePlanName;

public class ApiResponseCurrentNav implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseCurrentNav response;

	public ApiResponseCurrentNav() {
		super();
	}
	public ApiResponseCurrentNav(ResponseCurrentNav response) {
		super();
		this.response = response;
	}
	public ResponseCurrentNav getResponse() {
		return response;
	}
	public void setResponse(ResponseCurrentNav response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
