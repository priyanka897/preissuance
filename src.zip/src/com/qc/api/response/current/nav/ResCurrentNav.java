package com.qc.api.response.current.nav;

import java.io.Serializable;  

public class ResCurrentNav implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;
	
	private String planName;
	private String planCode;
	private String latestNavDate;
	private String fundName;
	private String currentNav;
	private String fundStartDate;
	private String planStartDate;
	private String changeOverPreviousNav;

	//added by Ravi 
	private String sfinNo;

	
	
	
	public String getSfinNo() {
		return sfinNo;
	}
	public void setSfinNo(String sfinNo) {
		this.sfinNo = sfinNo;
	}
	
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	
	public String getFundStartDate() {
		return fundStartDate;
	}
	public void setFundStartDate(String fundStartDate) {
		this.fundStartDate = fundStartDate;
	}
	public String getPlanStartDate() {
		return planStartDate;
	}
	public String getLatestNavDate() {
		return latestNavDate;
	}
	public void setLatestNavDate(String latestNavDate) {
		this.latestNavDate = latestNavDate;
	}
	public String getCurrentNav() {
		return currentNav;
	}
	public void setCurrentNav(String currentNav) {
		this.currentNav = currentNav;
	}
	public String getChangeOverPreviousNav() {
		return changeOverPreviousNav;
	}
	public void setChangeOverPreviousNav(String changeOverPreviousNav) {
		this.changeOverPreviousNav = changeOverPreviousNav;
	}
	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}
	@Override
	public String toString() {
		return "ResCurrentNav [planName=" + planName + ", planCode=" + planCode + ", latestNavDate=" + latestNavDate
				+ ", fundName=" + fundName + ", currentNav=" + currentNav + ", fundStartDate=" + fundStartDate
				+ ", planStartDate=" + planStartDate + ", changeOverPreviousNav=" + changeOverPreviousNav + ", sfinNo="
				+ sfinNo + "]";
	}
	
	
	
}
