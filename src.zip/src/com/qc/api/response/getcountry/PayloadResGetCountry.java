package com.qc.api.response.getcountry;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetCountry implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResGetCountry> Country;
	private String soaStatusCode;
	private String soaMessage;
	private String soaDescription;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<ResGetCountry> getCountry() {
		return Country;
	}

	public void setCountry(List<ResGetCountry> country) {
		Country = country;
	}

	public String getSoaStatusCode() {
		return soaStatusCode;
	}

	public void setSoaStatusCode(String soaStatusCode) {
		this.soaStatusCode = soaStatusCode;
	}

	public String getSoaMessage() {
		return soaMessage;
	}

	public void setSoaMessage(String soaMessage) {
		this.soaMessage = soaMessage;
	}

	public String getSoaDescription() {
		return soaDescription;
	}

	public void setSoaDescription(String soaDescription) {
		this.soaDescription = soaDescription;
	}

	@Override
	public String toString() {
		return "PayloadResGetCountry [Country=" + Country + ", soaStatusCode=" + soaStatusCode
				+ ", soaMessage=" + soaMessage + ", soaDescription=" + soaDescription + "getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	

	}
