package com.qc.api.response.getcountry;

import java.io.Serializable;

public class ApiResponseGetCountry implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetCountry response;

	public ApiResponseGetCountry() {
		super();
	}
	public ApiResponseGetCountry(ResponseGetCountry response) {
		super();
		this.response = response;
	}
	public ResponseGetCountry getResponse() {
		return response;
	}
	public void setResponse(ResponseGetCountry response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetCountry [response=" + response + "]";
	}
}
