package com.qc.api.response.getcountry;

import java.io.Serializable;

public class ResGetCountry implements Serializable {

	private static final long serialVersionUID = 783979534649266820L;
	private String country;
	private String country_code;
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCountry_code() {
		return country_code;
	}
	public void setCountry_code(String country_code) {
		this.country_code = country_code;
	}
	@Override
	public String toString() {
		return "ResGetCountry [Country_Name=" + country + ", Country_Code=" + country_code + "]";
	}
}
