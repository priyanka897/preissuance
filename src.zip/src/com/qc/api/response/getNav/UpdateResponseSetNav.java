package com.qc.api.response.getNav;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class UpdateResponseSetNav implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadResGetNav payload;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadResGetNav getPayload() {
		return payload;
	}
	public void setPayload(PayloadResGetNav payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "UpdateResponseSetNav [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
	public UpdateResponseSetNav(HeaderNew header, MsgInfo msgInfo, PayloadResGetNav payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	public UpdateResponseSetNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
