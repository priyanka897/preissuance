package com.qc.api.response.getNav;

import java.io.Serializable;

public class PayloadResGetNav implements Serializable {

	
	private static final long serialVersionUID = -2407302032173574993L;
	private String navRegistrationStatus;
	private String navRegistrationValidity;
	public String getNavRegistrationStatus() {
		return navRegistrationStatus;
	}
	public void setNavRegistrationStatus(String navRegistrationStatus) {
		this.navRegistrationStatus = navRegistrationStatus;
	}
	public String getNavRegistrationValidity() {
		return navRegistrationValidity;
	}
	public PayloadResGetNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PayloadResGetNav(String navRegistrationStatus, String navRegistrationValidity) {
		super();
		this.navRegistrationStatus = navRegistrationStatus;
		this.navRegistrationValidity = navRegistrationValidity;
	}
	public void setNavRegistrationValidity(String navRegistrationValidity) {
		this.navRegistrationValidity = navRegistrationValidity;
	}
	@Override
	public String toString() {
		return "PayloadResGetNav [navRegistrationStatus=" + navRegistrationStatus + ", navRegistrationValidity="
				+ navRegistrationValidity + "]";
	}
	

}
