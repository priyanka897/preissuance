package com.qc.api.response.getNav;

import java.io.Serializable;


public class ApiResponseGetNavDetails implements Serializable{

	
	private UpdateResponseSetNav response;

	public UpdateResponseSetNav getResponse() {
		return response;
	}

	public ApiResponseGetNavDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseGetNavDetails(UpdateResponseSetNav response) {
		super();
		this.response = response;
	}

	public void setResponse(UpdateResponseSetNav response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseGetNavDetails [response=" + response + "]";
	}
	
}
