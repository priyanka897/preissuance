package com.qc.api.response.navservices;

import java.io.Serializable;

public class ResNav implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;

	
	private String smsStatus;
	public String getSmsStatus() {
		return smsStatus;
	}
	public void setSmsStatus(String smsStatus) {
		this.smsStatus = smsStatus;
	}
	@Override
	public String toString() {
		return "ResNav [smsStatus=" + smsStatus + "]";
	}
}
