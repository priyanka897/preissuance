package com.qc.api.response.navservices;

import java.io.Serializable;
import java.util.List;

public class PayloadResNav implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private ResNav navDetails;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public ResNav getNavDetails() {
		return navDetails;
	}

	public void setNavDetails(ResNav navDetails) {
		this.navDetails = navDetails;
	}

	@Override
	public String toString() {
		return "PayloadResNav [navDetails=" + navDetails + ", getNavDetails()=" + getNavDetails() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	

	}
