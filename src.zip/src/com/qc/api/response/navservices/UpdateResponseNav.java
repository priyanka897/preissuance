package com.qc.api.response.navservices;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class UpdateResponseNav  implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private Header header;
	private MsgInfo msginfo;
	private UpdateResNav responseData;
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public UpdateResNav getResponseData() {
		return responseData;
	}
	public void setResponseData(UpdateResNav responseData) {
		this.responseData = responseData;
	}
	public UpdateResponseNav(Header header, MsgInfo msginfo, UpdateResNav responseData) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.responseData = responseData;
	}
	public UpdateResponseNav() {
		super();
	}
	@Override
	public String toString() {
		return "UpdateResponseNav [header=" + header + ", msginfo=" + msginfo + ", responseData=" + responseData + "]";
	}
}
