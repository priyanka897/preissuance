package com.qc.api.response.navservices;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponseNav implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msginfo;
	private ResNav responseData;
	
	public ResponseNav() {
		super();
	}
	public ResponseNav(Header header, MsgInfo msginfo, ResNav responseData) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public ResNav getResponseData() {
		return responseData;
	}
	public void setResponseData(ResNav responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseNav [header=" + header + ", msginfo=" + msginfo + ", responseData=" + responseData + "]";
	}
}
