package com.qc.api.response.navservices;

import java.io.Serializable;

public class PayloadUpdateResNav implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private UpdateResNav navDetails;
	public UpdateResNav getNavDetails() {
		return navDetails;
	}
	public void setNavDetails(UpdateResNav navDetails) {
		this.navDetails = navDetails;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "PayloadUpdateResNav [navDetails=" + navDetails + "]";
	}
}
