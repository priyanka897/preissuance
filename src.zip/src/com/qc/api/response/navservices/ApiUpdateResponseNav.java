package com.qc.api.response.navservices;

import java.io.Serializable;

public class ApiUpdateResponseNav implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private UpdateResponseNav response;

	public ApiUpdateResponseNav() {
		super();
	}
	public ApiUpdateResponseNav(UpdateResponseNav response) {
		super();
		this.response = response;
	}
	public UpdateResponseNav getResponse() {
		return response;
	}
	public void setResponse(UpdateResponseNav response) {
		this.response = response;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "ApiUpdateResponseNav [response=" + response + ", getResponse()=" + getResponse() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
}
