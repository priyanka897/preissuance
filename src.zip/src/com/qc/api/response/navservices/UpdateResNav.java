package com.qc.api.response.navservices;

import java.io.Serializable;

public class UpdateResNav implements Serializable {
	private static final long serialVersionUID = 783979534649266820L;
	private String machineip;
	private String requestedby;
	private String source;
	private String uniquetransid;
	private String userid;
//	private String smsstatus;
//	private String smsfrequency;
	public String getMachineip() {
		return machineip;
	}
	public void setMachineip(String machineip) {
		this.machineip = machineip;
	}
	public String getRequestedby() {
		return requestedby;
	}
	public void setRequestedby(String requestedby) {
		this.requestedby = requestedby;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getUniquetransid() {
		return uniquetransid;
	}
	public void setUniquetransid(String uniquetransid) {
		this.uniquetransid = uniquetransid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
//	public String getSmsstatus() {
//		return smsstatus;
//	}
//	public void setSmsstatus(String smsstatus) {
//		this.smsstatus = smsstatus;
//	}
//	public String getSmsfrequency() {
//		return smsfrequency;
//	}
//	public void setSmsfrequency(String smsfrequency) {
//		this.smsfrequency = smsfrequency;
//	}
	@Override
	public String toString() {
		return "UpdateResNav [machineip=" + machineip + ", requestedby=" + requestedby + ", source=" + source
				+ ", uniquetransid=" + uniquetransid + ", userid=" + userid + " ]";
	}
	
}
