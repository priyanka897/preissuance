package com.qc.api.response.fund;

import java.io.Serializable;
import java.util.List;



public class ResFundName implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;
    
	private String fundId;
	private String fundName;
	private  String fundStartDate;
	//added by Ravi 
   private String sfinNo;

	
	
	
	public String getSfinNo() {
		return sfinNo;
	}
	public void setSfinNo(String sfinNo) {
		this.sfinNo = sfinNo;
	}
	public String getFundId() {
		return fundId;
	}
	public void setFundId(String fundId) {
		this.fundId = fundId;
	}
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	public String getFundStartDate() {
		return fundStartDate;
	}
	public void setFundStartDate(String fundStartDate) {
		this.fundStartDate = fundStartDate;
	}
	@Override
	public String toString() {
		return "ResFundName [fundId=" + fundId + ", fundName=" + fundName + ", fundStartDate=" + fundStartDate + "]";
	}

}
