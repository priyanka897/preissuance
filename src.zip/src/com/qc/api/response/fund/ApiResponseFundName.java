package com.qc.api.response.fund;

import java.io.Serializable;

public class ApiResponseFundName implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseFundName response;

	public ApiResponseFundName() {
		super();
	}
	public ApiResponseFundName(ResponseFundName response) {
		super();
		this.response = response;
	}
	public ResponseFundName getResponse() {
		return response;
	}
	public void setResponse(ResponseFundName response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
