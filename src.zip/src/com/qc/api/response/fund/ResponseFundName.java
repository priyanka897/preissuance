package com.qc.api.response.fund;

import java.io.Serializable;
import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponseFundName implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msginfo;
	private PayloadResFundName payload;
	
	
	public ResponseFundName(){
		super();
	}
	public ResponseFundName(Header header, MsgInfo msginfo, PayloadResFundName payload) {
		super();
		this.header = header;
		this.msginfo = msginfo;
		this.payload = payload;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsginfo() {
		return msginfo;
	}
	public void setMsginfo(MsgInfo msginfo) {
		this.msginfo = msginfo;
	}
	public PayloadResFundName getPayload() {
		return payload;
	}
	public void setPayload(PayloadResFundName payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ResponseNav [header=" + header + ", msginfo=" + msginfo + ", payload=" + payload + "]";
	}
	
}
