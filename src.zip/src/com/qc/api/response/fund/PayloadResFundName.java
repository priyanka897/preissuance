package com.qc.api.response.fund;

import java.io.Serializable;
import java.util.List;

public class PayloadResFundName implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private List<ResFundName> data;

	public List<ResFundName> getData() {
		return data;
	}

	public void setData(List<ResFundName> data) {
		this.data = data;
	}
	
}
