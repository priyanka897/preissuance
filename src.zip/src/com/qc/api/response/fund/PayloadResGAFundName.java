package com.qc.api.response.fund;

import java.io.Serializable;
import java.util.List;

public class PayloadResGAFundName implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private List<ResGAFundDetails> data;

	public List<ResGAFundDetails> getData() {
		return data;
	}

	public void setData(List<ResGAFundDetails> data) {
		this.data = data;
	}
	
}
