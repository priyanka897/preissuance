package com.qc.api.response.updateNavAlert;

import java.io.Serializable;


public class ApiUpdateResponseSetNav implements Serializable{

	public ApiUpdateResponseSetNav(UpdateResponseUpdateNav response) {
		super();
		this.response = response;
	}
	private static final long serialVersionUID = -135213338684677344L;
	private UpdateResponseUpdateNav response;
	public UpdateResponseUpdateNav getResponse() {
		return response;
	}
	public void setResponse(UpdateResponseUpdateNav response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiUpdateResponseSetNav [response=" + response + "]";
	}
	public ApiUpdateResponseSetNav() {
		super();
		// TODO Auto-generated constructor stub
	}
}
