package com.qc.api.response.updateNavAlert;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class UpdateResponseUpdateNav implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	public UpdateResponseUpdateNav() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UpdateResponseUpdateNav(HeaderNew header, MsgInfo msgInfo) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
	}
	private HeaderNew header;
	private MsgInfo msgInfo;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	@Override
	public String toString() {
		return "UpdateResponseUpdateNav [header=" + header + ", msgInfo=" + msgInfo + "]";
	}

}
