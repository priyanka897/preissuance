package com.qc.api.response.Aadhaardemograph;

import java.io.Serializable;

public class PayloadAadhaardemograph implements Serializable{
	private static final long serialVersionUID = -2407302032173574993L;
	
	private String statusCode;
	private String statusDesc;
	private String message;
	private String matchStatus;
	private String aadhaarNumber;
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusDesc() {
		return statusDesc;
	}
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getMatchStatus() {
		return matchStatus;
	}
	public void setMatchStatus(String matchStatus) {
		this.matchStatus = matchStatus;
	}
	public String getAadhaarNumber() {
		return aadhaarNumber;
	}
	public void setAadhaarNumber(String aadhaarNumber) {
		this.aadhaarNumber = aadhaarNumber;
	}
	public PayloadAadhaardemograph(String statusCode, String statusDesc, String message, String matchStatus, String aadhaarNumber) {
		super();
		this.statusCode = statusCode;
		this.statusDesc = statusDesc;
		this.message = message;
		this.matchStatus = matchStatus;
		this.aadhaarNumber = aadhaarNumber;
	}
	public PayloadAadhaardemograph() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PayloadAadhaardemograph [statusCode=" + statusCode + ", statusDesc=" + statusDesc + ", message=" + message + ", matchStatus=" + matchStatus + ", aadhaarNumber=" + aadhaarNumber + "]";
	}
	



}
	
	
