package com.qc.api.response.Aadhaardemograph;

import java.io.Serializable;

import com.qc.api.common.Aadhaar.Header;
import com.qc.api.common.Aadhaar.MsgInfo;


public class AadhaarResponsedemograph implements Serializable {
	private static final long serialVersionUID = 8748777980811121938L;

	private Header header;
	private MsgInfo msgInfo;
	private PayloadAadhaardemograph payload;
	public Header getHeader() {
		return header;
	}
	
	public AadhaarResponsedemograph() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public AadhaarResponsedemograph(Header header, MsgInfo msgInfo, PayloadAadhaardemograph payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadAadhaardemograph getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaardemograph payload) {
		this.payload = payload;
	}
	
	@Override
	public String toString() {
		return "AadhaarResponsedemograph [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
	
	
	
}
