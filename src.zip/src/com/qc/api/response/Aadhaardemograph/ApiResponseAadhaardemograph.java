package com.qc.api.response.Aadhaardemograph;

import java.io.Serializable;
public class ApiResponseAadhaardemograph  implements Serializable{

	private AadhaarResponsedemograph response;

	
	
	public ApiResponseAadhaardemograph() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseAadhaardemograph(AadhaarResponsedemograph response) {
		super();
		this.response = response;
	}

	public AadhaarResponsedemograph getResponse() {
		return response;
	}

	public void setResponse(AadhaarResponsedemograph response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseAadhaardemograph [response=" + response + "]";
	}
	
	
	
}
