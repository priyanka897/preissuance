package com.qc.api.response.getallcities;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.getmaxcities.PayloadReqGetMaxCities;

public class ResponseGetAllCities implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private PayloadResGetAllCities responseData;
	
	public ResponseGetAllCities() {
		super();
	}
	public ResponseGetAllCities(Header header, PayloadResGetAllCities responseData) {
		super();
		this.header = header;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	
	
	public PayloadResGetAllCities getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResGetAllCities responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseGetAllCities [header=" + header + ", responseData=" + responseData + "]";
	}
	
}
