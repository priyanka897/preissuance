package com.qc.api.response.getallcities;

import java.io.Serializable;

public class ResGetAllCities implements Serializable {

	private static final long serialVersionUID = 783979534649266820L;
	private String city;

	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "ResGetAllCities [city=" + city + "]";
	}

}
