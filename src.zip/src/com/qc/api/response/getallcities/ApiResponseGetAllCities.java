package com.qc.api.response.getallcities;

import java.io.Serializable;

public class ApiResponseGetAllCities implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetAllCities response;

	public ApiResponseGetAllCities() {
		super();
	}
	public ApiResponseGetAllCities(ResponseGetAllCities response) {
		super();
		this.response = response;
	}
	public ResponseGetAllCities getResponse() {
		return response;
	}
	public void setResponse(ResponseGetAllCities response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetAllCities [response=" + response + "]";
	}
}
