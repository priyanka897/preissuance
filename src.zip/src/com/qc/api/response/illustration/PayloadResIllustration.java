package com.qc.api.response.illustration;

import java.io.Serializable;
import java.util.Map;

public class PayloadResIllustration implements Serializable {

	
	private static final long serialVersionUID = -2407302032173574993L;
	private Map<String,Object> fundValueUpper;
	private Map<String,Object> fundValueLower;
	public PayloadResIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PayloadResIllustration(Map<String, Object> fundValueUpper, Map<String, Object> fundValueLower) {
		super();
		this.fundValueUpper = fundValueUpper;
		this.fundValueLower = fundValueLower;
	}
	public Map<String, Object> getFundValueUpper() {
		return fundValueUpper;
	}
	public void setFundValueUpper(Map<String, Object> fundValueUpper) {
		this.fundValueUpper = fundValueUpper;
	}
	public Map<String, Object> getFundValueLower() {
		return fundValueLower;
	}
	public void setFundValueLower(Map<String, Object> fundValueLower) {
		this.fundValueLower = fundValueLower;
	}
	@Override
	public String toString() {
		return "PayloadResIllustration [fundValueUpper=" + fundValueUpper + ", fundValueLower=" + fundValueLower + "]";
	}
	
	
	

}
