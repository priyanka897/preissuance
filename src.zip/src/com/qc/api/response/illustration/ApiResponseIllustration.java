package com.qc.api.response.illustration;

import java.io.Serializable;


public class ApiResponseIllustration implements Serializable{

	
	private UpdateResponseIllustration response;

	public UpdateResponseIllustration getResponse() {
		return response;
	}

	public ApiResponseIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseIllustration(UpdateResponseIllustration response) {
		super();
		this.response = response;
	}

	public void setResponse(UpdateResponseIllustration response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseGetNavDetails [response=" + response + "]";
	}
	
}
