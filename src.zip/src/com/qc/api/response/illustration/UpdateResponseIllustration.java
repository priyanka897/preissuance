package com.qc.api.response.illustration;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class UpdateResponseIllustration implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	
	public UpdateResponseIllustration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UpdateResponseIllustration(HeaderNew header, MsgInfo msgInfo, PayloadResIllustration payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadResIllustration payload;
	public HeaderNew getHeader() {
		return header;
	}
	public void setHeader(HeaderNew header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadResIllustration getPayload() {
		return payload;
	}
	public void setPayload(PayloadResIllustration payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "UpdateResponseIllustration [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}
	
	

}
