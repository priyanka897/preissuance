package com.qc.api.response.getstates;

import java.io.Serializable;

public class ApiResponseGetStates implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetStates response;

	public ApiResponseGetStates() {
		super();
	}
	public ApiResponseGetStates(ResponseGetStates response) {
		super();
		this.response = response;
	}
	public ResponseGetStates getResponse() {
		return response;
	}
	public void setResponse(ResponseGetStates response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetStates [response=" + response + "]";
	}
}
