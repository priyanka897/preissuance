package com.qc.api.response.getstates;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetStates implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResGetStates> states;
	private String soaStatusCode;
	private String soaMessage;
	private String soaDescription;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<ResGetStates> getStates() {
		return states;
	}
	public void setState(List<ResGetStates> states) {
		this.states = states;
	}

	public String getSoaStatusCode() {
		return soaStatusCode;
	}

	public void setSoaStatusCode(String soaStatusCode) {
		this.soaStatusCode = soaStatusCode;
	}

	public String getSoaMessage() {
		return soaMessage;
	}

	public void setSoaMessage(String soaMessage) {
		this.soaMessage = soaMessage;
	}

	public String getSoaDescription() {
		return soaDescription;
	}

	public void setSoaDescription(String soaDescription) {
		this.soaDescription = soaDescription;
	}

	@Override
	public String toString() {
		return "PayloadResGetStates [states=" + states + ", soaStatusCode=" + soaStatusCode
				+ ", soaMessage=" + soaMessage + ", soaDescription=" + soaDescription + "getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	

	}
