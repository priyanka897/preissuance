package com.qc.api.response.getstates;

import java.io.Serializable;

public class ResGetStates implements Serializable {

	private static final long serialVersionUID = 783979534649266820L;
	private String state;
	private String state_code;
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getState_code() {
		return state_code;
	}
	public void setState_code(String state_code) {
		this.state_code = state_code;
	}
	@Override
	public String toString() {
		return "ResGetStates [State_Name=" + state + ", State_Code=" + state_code + "]";
	}
}
