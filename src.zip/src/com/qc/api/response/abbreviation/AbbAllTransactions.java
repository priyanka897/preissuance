package com.qc.api.response.abbreviation;

import java.io.Serializable;
import java.util.List;

public class AbbAllTransactions implements Serializable{

	private static final long serialVersionUID = -6020657393412162691L;
	private String count;
	private List<AbbGetTransactions> abbsData;
	
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public List<AbbGetTransactions> getAbbsData() {
		return abbsData;
	}
	public void setAbbsData(List<AbbGetTransactions> abbsData) {
		this.abbsData = abbsData;
	}
	@Override
	public String toString() {
		return "AbbAllTransactions [count=" + count + ", abbsData=" + abbsData + "]";
	}
	
	
}
