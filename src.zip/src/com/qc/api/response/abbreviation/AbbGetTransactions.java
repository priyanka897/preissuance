package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class AbbGetTransactions implements Serializable{

	private static final long serialVersionUID = -1134728392032640827L;
	private String shortform;
	private String fullform;
	private String description;
	private String department;
	public String getShortform() {
		return shortform;
	}
	public void setShortform(String shortform) {
		this.shortform = shortform;
	}
	public String getFullform() {
		return fullform;
	}
	public void setFullform(String fullform) {
		this.fullform = fullform;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return "AbbGetResponse [shortform=" + shortform + ", fullform=" + fullform + ", description=" + description
				+ ", department=" + department + "]";
	}
	
	
}
