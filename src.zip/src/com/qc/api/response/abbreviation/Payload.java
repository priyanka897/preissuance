package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class Payload implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6899628442259172350L;
	Object transactions ;

	public Object getTransactions() {
		return transactions;
	}

	public void setTransactions(Object transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Payload [transactions=" + transactions + "]";
	}

	public Payload(Object transactions) {
		super();
		this.transactions = transactions;
	}

	public Payload() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
