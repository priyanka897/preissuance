package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class ErrorInfo implements Serializable {

	private static final long serialVersionUID = 7160709065213665345L;
	String code;
	String status;
	String message;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ErrorInfo [code=" + code + ", status=" + status + ", message=" + message + "]";
	}

}
