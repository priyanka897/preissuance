package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class HeaderResponse implements Serializable{

	
	private static final long serialVersionUID = 1032034012218218974L;
	private String soaMsgVersion = "";
	private String soaAppId = "";
	private String soaCorrelationId = "";
	
	public String getSoaMsgVersion() {
		return soaMsgVersion;
	}
	public void setSoaMsgVersion(String soaMsgVersion) {
		this.soaMsgVersion = soaMsgVersion;
	}
	public String getSoaAppId() {
		return soaAppId;
	}
	public void setSoaAppId(String soaAppId) {
		this.soaAppId = soaAppId;
	}
	public String getSoaCorrelationId() {
		return soaCorrelationId;
	}
	public void setSoaCorrelationId(String soaCorrelationId) {
		this.soaCorrelationId = soaCorrelationId;
	}
		
	
}
