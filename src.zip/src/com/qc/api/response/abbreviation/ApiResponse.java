package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class ApiResponse implements Serializable{

	private static final long serialVersionUID = 3735931987136744220L;
	HeaderResponse header;
	ErrorInfo errorInfo;
	Payload payload ;
	public HeaderResponse getHeader() {
		return header;
	}
	public void setHeader(HeaderResponse header) {
		this.header = header;
	}
	public ErrorInfo getErrorInfo() {
		return errorInfo;
	}
	public void setErrorInfo(ErrorInfo errorInfo) {
		this.errorInfo = errorInfo;
	}
	public Payload getPayload() {
		return payload;
	}
	public void setPayload(Payload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "ApiResponse [header=" + header + ", errorInfo=" + errorInfo + ", payload=" + payload + "]";
	}
	public ApiResponse(HeaderResponse header, ErrorInfo errorInfo, Payload payload) {
		super();
		this.header = header;
		this.errorInfo = errorInfo;
		this.payload = payload;
	}
	public ApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
}
