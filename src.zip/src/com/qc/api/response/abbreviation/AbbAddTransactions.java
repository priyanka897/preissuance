package com.qc.api.response.abbreviation;

import java.io.Serializable;

public class AbbAddTransactions  implements Serializable{
	private static final long serialVersionUID = -5724358252306901398L;
private String message;

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}

@Override
public String toString() {
	return "AbbAddTransactionResponse [message=" + message + "]";
}

}
