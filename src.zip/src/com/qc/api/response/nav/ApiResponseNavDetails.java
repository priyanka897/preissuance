package com.qc.api.response.nav;

import java.io.Serializable;

public class ApiResponseNavDetails implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseNavDetails response;

	public ApiResponseNavDetails() {
		super();
	}
	public ApiResponseNavDetails(ResponseNavDetails response) {
		super();
		this.response = response;
	}
	public ResponseNavDetails getResponse() {
		return response;
	}
	public void setResponse(ResponseNavDetails response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
