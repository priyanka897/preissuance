package com.qc.api.response.nav;

import java.io.Serializable;
import java.util.List;



public class ResNavDetails implements Serializable
{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3473958935927486214L;
	private String planCode;
	private String planName;
	private String planStartDate;
	private String fundName;
	private String fundStartDate;
	private String currentNav;
	private String latestNavDate;
	private String changeOverPreviousNav;
    private String sfinNo;
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanStartDate() {
		return planStartDate;
	}
	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	public String getFundStartDate() {
		return fundStartDate;
	}
	public void setFundStartDate(String fundStartDate) {
		this.fundStartDate = fundStartDate;
	}
	public String getCurrentNav() {
		return currentNav;
	}
	public void setCurrentNav(String currentNav) {
		this.currentNav = currentNav;
	}
	public String getLatestNavDate() {
		return latestNavDate;
	}
	public void setLatestNavDate(String latestNavDate) {
		this.latestNavDate = latestNavDate;
	}
	public String getChangeOverPreviousNav() {
		return changeOverPreviousNav;
	}
	public void setChangeOverPreviousNav(String changeOverPreviousNav) {
		this.changeOverPreviousNav = changeOverPreviousNav;
	}
	@Override
	public String toString() {
		return "ResNavDetails [planCode=" + planCode + ", planName=" + planName + ", planStartDate=" + planStartDate
				+ ", fundName=" + fundName + ", fundStartDate=" + fundStartDate + ", currentNav=" + currentNav
				+ ", latestNavDate=" + latestNavDate + ", changeOverPreviousNav=" + changeOverPreviousNav + "]";
	}
	
	public String getSfinNo() {
		return sfinNo;
	}
	public void setSfinNo(String sfinNo) {
		this.sfinNo = sfinNo;
	}

	
}
