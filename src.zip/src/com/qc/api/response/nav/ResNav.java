package com.qc.api.response.nav;

import java.io.Serializable;
import java.util.List;



public class ResNav implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;

	private String planName;
	private String planCode;
	private String navEffectiveDate;
	private String fundName;
	private String navSellingPrice;
	private String fundStartDate;
	private String planStartDate;
	//added by Ravi 
	private String sfinNo;

	
	
	
	public String getSfinNo() {
		return sfinNo;
	}
	public void setSfinNo(String sfinNo) {
		this.sfinNo = sfinNo;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getFundName() {
		return fundName;
	}
	public void setFundName(String fundName) {
		this.fundName = fundName;
	}
	public String getFundStartDate() {
		return fundStartDate;
	}
	public void setFundStartDate(String fundStartDate) {
		this.fundStartDate = fundStartDate;
	}
	public String getPlanStartDate() {
		return planStartDate;
	}
	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}
	public String getNavEffectiveDate() {
		return navEffectiveDate;
	}
	public void setNavEffectiveDate(String navEffectiveDate) {
		this.navEffectiveDate = navEffectiveDate;
	}
	public String getNavSellingPrice() {
		return navSellingPrice;
	}
	public void setNavSellingPrice(String navSellingPrice) {
		this.navSellingPrice = navSellingPrice;
	}
	@Override
	public String toString() {
		return "ResNav [planName=" + planName + ", planCode=" + planCode + ", navEffectiveDate=" + navEffectiveDate
				+ ", fundName=" + fundName + ", navSellingPrice=" + navSellingPrice + ", fundStartDate=" + fundStartDate
				+ ", planStartDate=" + planStartDate + ", sfinNo=" + sfinNo + "]";
	}
}
