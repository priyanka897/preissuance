package com.qc.api.response.nav;

import java.io.Serializable;
import java.util.List;

public class PayloadResNavDetails implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private List<ResNavDetails> data;

	public List<ResNavDetails> getData() {
		return data;
	}

	public void setData(List<ResNavDetails> data) {
		this.data = data;
	}
	
}
