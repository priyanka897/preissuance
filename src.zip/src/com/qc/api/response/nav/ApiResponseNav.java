package com.qc.api.response.nav;

import java.io.Serializable;

public class ApiResponseNav implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseNav response;

	public ApiResponseNav() {
		super();
	}
	public ApiResponseNav(ResponseNav response) {
		super();
		this.response = response;
	}
	public ResponseNav getResponse() {
		return response;
	}
	public void setResponse(ResponseNav response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
