package com.qc.api.response.getplanname;

import java.io.Serializable;

import com.qc.api.common.Header;

public class ResponseGetPlan implements Serializable {

	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private PayloadResGetPlan responseData;
	
	public ResponseGetPlan() {
		super();
	}
	public ResponseGetPlan(Header header, PayloadResGetPlan responseData) {
		super();
		this.header = header;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadResGetPlan getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResGetPlan responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseGetPlan [header=" + header + ", responseData=" + responseData + "]";
	}
	
	
}
