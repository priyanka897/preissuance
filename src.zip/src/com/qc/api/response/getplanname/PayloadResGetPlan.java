package com.qc.api.response.getplanname;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetPlan implements Serializable{

	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResGetPlan> plans;
	private String soaStatusCode;
	private String soaMessage;
	private String soaDescription;
	
	public List<ResGetPlan> getPlans() {
		return plans;
	}

	public void setPlans(List<ResGetPlan> plans) {
		this.plans = plans;
	}

	public String getSoaStatusCode() {
		return soaStatusCode;
	}

	public void setSoaStatusCode(String soaStatusCode) {
		this.soaStatusCode = soaStatusCode;
	}

	public String getSoaMessage() {
		return soaMessage;
	}

	public void setSoaMessage(String soaMessage) {
		this.soaMessage = soaMessage;
	}

	public String getSoaDescription() {
		return soaDescription;
	}

	public void setSoaDescription(String soaDescription) {
		this.soaDescription = soaDescription;
	}
	
	@Override
	public String toString() {
		return "PayloadResGetPlan [plans=" + plans + ", soaStatusCode=" + soaStatusCode
				+ ", soaMessage=" + soaMessage + ", soaDescription=" + soaDescription + ", getClass()="
		+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
