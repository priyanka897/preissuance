package com.qc.api.response.getplanname;

import java.io.Serializable;

public class ResGetPlan implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;
	private String planname;
	private String category;

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	@Override
	public String toString() {
		return "ResGetPlan [planname=" + planname + ", category=" + category + "]";
	}
}
