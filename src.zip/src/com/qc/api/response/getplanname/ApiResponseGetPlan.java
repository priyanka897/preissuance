package com.qc.api.response.getplanname;

import java.io.Serializable;

public class ApiResponseGetPlan implements Serializable{

	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetPlan response;

	public ApiResponseGetPlan() {
		super();
	}
	public ApiResponseGetPlan(ResponseGetPlan response) {
		super();
		this.response = response;
	}
	public ResponseGetPlan getResponse() {
		return response;
	}
	public void setResponse(ResponseGetPlan response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetPlan [response=" + response + "]";
	}
	
	
}
