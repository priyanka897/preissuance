package com.qc.api.response.Aadhaar.biometric;

import java.io.Serializable;
public class ApiResponseAadhaarbiometric implements Serializable{

	private AadhaarResponsebiometric response;

	public AadhaarResponsebiometric getResponse() {
		return response;
	}

	public void setResponse(AadhaarResponsebiometric response) {
		this.response = response;
	}

	public ApiResponseAadhaarbiometric() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseAadhaarbiometric(AadhaarResponsebiometric response) {
		super();
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseAadhaarbiometric [response=" + response + "]";
	}

	
	
	
}
