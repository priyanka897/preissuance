package com.qc.api.response.Aadhaar.biometric;

import java.io.Serializable;

import com.qc.api.common.Aadhaar.Header;
import com.qc.api.common.Aadhaar.MsgInfo;
import com.qc.api.response.Aadhaarotp.PayloadAadhaarotp;

public class AadhaarResponsebiometric implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private Header header;
	private MsgInfo msgInfo;
	private PayloadAadhaarbiometric payload;
	
	public AadhaarResponsebiometric() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public AadhaarResponsebiometric(Header header, MsgInfo msgInfo, PayloadAadhaarbiometric payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}
	
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadAadhaarbiometric getPayload() {
		return payload;
	}
	public void setPayload(PayloadAadhaarbiometric payload) {
		this.payload = payload;
	}
	
	
	@Override
	public String toString() {
		return "AadhaarResponsebiometric [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}





}
