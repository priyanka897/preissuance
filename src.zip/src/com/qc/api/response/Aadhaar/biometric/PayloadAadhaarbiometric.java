package com.qc.api.response.Aadhaar.biometric;

import java.io.Serializable;

public class PayloadAadhaarbiometric implements Serializable{
	private static final long serialVersionUID = -2407302032173574993L;
	
	private String key1;
	private String key2;
	private String key3;
	private String key4;
	private String key5;
	private String transTrackingID;
	private String tokenNo;
	private String name;
	private String aadhaarNo;
	private String DOB;
	private String phone;
	private String email;
	private String careOf;
	private String house;
	private String street;
	private String landmark;
	private String location;
	private String pinCode;
	private String postOffice;
	private String villCity;
	private String subDist;
	private String dist;
	private String state;
	private String gender;
	private String image;
	private String pdffile;
	
	
	public PayloadAadhaarbiometric() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public PayloadAadhaarbiometric(String key1, String key2, String key3, String key4, String key5, String transTrackingID, String tokenNo, String name, String aadhaarNo, String dOB, String phone, String email, String careOf, String house,
			String street, String landmark, String location, String pinCode, String postOffice, String villCity, String subDist, String dist, String state, String gender, String image, String pdffile) {
		super();
		this.key1 = key1;
		this.key2 = key2;
		this.key3 = key3;
		this.key4 = key4;
		this.key5 = key5;
		this.transTrackingID = transTrackingID;
		this.tokenNo = tokenNo;
		this.name = name;
		this.aadhaarNo = aadhaarNo;
		DOB = dOB;
		this.phone = phone;
		this.email = email;
		this.careOf = careOf;
		this.house = house;
		this.street = street;
		this.landmark = landmark;
		this.location = location;
		this.pinCode = pinCode;
		this.postOffice = postOffice;
		this.villCity = villCity;
		this.subDist = subDist;
		this.dist = dist;
		this.state = state;
		this.gender = gender;
		this.image = image;
		this.pdffile = pdffile;
	}
	
	
	
	public String getKey1() {
		return key1;
	}
	public void setKey1(String key1) {
		this.key1 = key1;
	}
	public String getKey2() {
		return key2;
	}
	public void setKey2(String key2) {
		this.key2 = key2;
	}
	public String getKey3() {
		return key3;
	}
	public void setKey3(String key3) {
		this.key3 = key3;
	}
	public String getKey4() {
		return key4;
	}
	public void setKey4(String key4) {
		this.key4 = key4;
	}
	public String getKey5() {
		return key5;
	}
	public void setKey5(String key5) {
		this.key5 = key5;
	}
	public String getTransTrackingID() {
		return transTrackingID;
	}
	public void setTransTrackingID(String transTrackingID) {
		this.transTrackingID = transTrackingID;
	}
	public String getTokenNo() {
		return tokenNo;
	}
	public void setTokenNo(String tokenNo) {
		this.tokenNo = tokenNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAadhaarNo() {
		return aadhaarNo;
	}
	public void setAadhaarNo(String aadhaarNo) {
		this.aadhaarNo = aadhaarNo;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String dOB) {
		DOB = dOB;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCareOf() {
		return careOf;
	}
	public void setCareOf(String careOf) {
		this.careOf = careOf;
	}
	public String getHouse() {
		return house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPostOffice() {
		return postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public String getVillCity() {
		return villCity;
	}
	public void setVillCity(String villCity) {
		this.villCity = villCity;
	}
	public String getSubDist() {
		return subDist;
	}
	public void setSubDist(String subDist) {
		this.subDist = subDist;
	}
	public String getDist() {
		return dist;
	}
	public void setDist(String dist) {
		this.dist = dist;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPdffile() {
		return pdffile;
	}
	public void setPdffile(String pdffile) {
		this.pdffile = pdffile;
	}
	
	@Override
	public String toString() {
		return "PayloadAadhaarbiometric [key1=" + key1 + ", key2=" + key2 + ", key3=" + key3 + ", key4=" + key4 + ", key5=" + key5 + ", transTrackingID=" + transTrackingID + ", tokenNo=" + tokenNo + ", name=" + name + ", aadhaarNo=" + aadhaarNo
				+ ", DOB=" + DOB + ", phone=" + phone + ", email=" + email + ", careOf=" + careOf + ", house=" + house + ", street=" + street + ", landmark=" + landmark + ", location=" + location + ", pinCode=" + pinCode + ", postOffice="
				+ postOffice + ", villCity=" + villCity + ", subDist=" + subDist + ", dist=" + dist + ", state=" + state + ", gender=" + gender + ", image=" + image + ", pdffile=" + pdffile + "]";
	}
	
	
	
	
}
