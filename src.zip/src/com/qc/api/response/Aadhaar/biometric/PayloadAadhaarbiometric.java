package com.qc.api.response.Aadhaar.biometric;

public class PayloadAadhaarbiometric {

}
