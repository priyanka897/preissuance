package com.qc.api.response.countofnotification;

import java.io.Serializable;


import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;

public class ResponseCountOfNotification implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private MsgInfo msgInfo;
	private PayloadResCountOfNotification responseData;
	
	public ResponseCountOfNotification() {
		super();
	}
	public ResponseCountOfNotification(Header header, MsgInfo msgInfo, PayloadResCountOfNotification responseData) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public MsgInfo getMsgInfo() {
		return msgInfo;
	}
	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}
	public PayloadResCountOfNotification getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResCountOfNotification responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseCountOfNotification [header=" + header + ", msgInfo=" + msgInfo + ", responseData="
				+ responseData + "]";
	}
	
}
