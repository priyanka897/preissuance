package com.qc.api.response.countofnotification;

import java.io.Serializable;
import java.util.List;

public class PayloadResCountOfNotification implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResCountOfNotification> countOfNotification;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public List<ResCountOfNotification> getCountOfNotification() {
		return countOfNotification;
	}
	public void setCountOfNotification(List<ResCountOfNotification> countOfNotification) {
		this.countOfNotification = countOfNotification;
	}
	@Override
	public String toString() {
		return "PayloadResCountOfNotification [countOfNotification=" + countOfNotification + ",getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
