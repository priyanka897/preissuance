package com.qc.api.response.countofnotification;

import java.io.Serializable;

public class ApiResponseCountOfNotification implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseCountOfNotification response;

	public ApiResponseCountOfNotification() {
		super();
	}
	public ApiResponseCountOfNotification(ResponseCountOfNotification response) {
		super();
		this.response = response;
	}
	public ResponseCountOfNotification getResponse() {
		return response;
	}
	public void setResponse(ResponseCountOfNotification response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseCountOfNotification [response=" + response + "]";
	}
}
