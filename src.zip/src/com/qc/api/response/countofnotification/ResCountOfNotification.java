package com.qc.api.response.countofnotification;

import java.io.Serializable;

public class ResCountOfNotification implements Serializable {

	private static final long serialVersionUID = 783979534649266820L;
	
	private String userId;
	private String notificationCount;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getNotificationCount() {
		return notificationCount;
	}
	public void setNotificationCount(String notificationCount) {
		this.notificationCount = notificationCount;
	}
	@Override
	public String toString() {
		return "ResCountOfNotification [userId=" + userId + ", notificationCount=" + notificationCount + "]";
	}
}
