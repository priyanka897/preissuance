package com.qc.api.response.getmaxcities;

import java.io.Serializable;

public class ApiResponseGetMaxCities implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetMaxCities response;

	public ApiResponseGetMaxCities() {
		super();
	}
	public ApiResponseGetMaxCities(ResponseGetMaxCities response) {
		super();
		this.response = response;
	}
	public ResponseGetMaxCities getResponse() {
		return response;
	}
	public void setResponse(ResponseGetMaxCities response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetMaxCities [response=" + response + "]";
	}
}
