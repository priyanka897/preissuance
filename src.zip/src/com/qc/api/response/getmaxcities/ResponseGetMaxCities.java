package com.qc.api.response.getmaxcities;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.getmaxcities.PayloadReqGetMaxCities;

public class ResponseGetMaxCities implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private PayloadResGetMaxCities responseData;
	
	public ResponseGetMaxCities() {
		super();
	}
	public ResponseGetMaxCities(Header header, PayloadResGetMaxCities responseData) {
		super();
		this.header = header;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	
	
	public PayloadResGetMaxCities getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResGetMaxCities responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseGetMaxCities [header=" + header + ", responseData=" + responseData + "]";
	}
	
}
