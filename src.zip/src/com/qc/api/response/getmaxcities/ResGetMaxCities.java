package com.qc.api.response.getmaxcities;

import java.io.Serializable;

public class ResGetMaxCities implements Serializable {

	private static final long serialVersionUID = 783979534649266820L;
	
	private String city;
	

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "ResGetMaxCities [city=" + city + "]";
	}

}
