package com.qc.api.response.plan;

import java.io.Serializable;

public class ResPlanName implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;
   
	private String planCode;
	private String planName;
	private  String planStartDate;
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanStartDate() {
		return planStartDate;
	}
	public void setPlanStartDate(String planStartDate) {
		this.planStartDate = planStartDate;
	}
	@Override
	public String toString() {
		return "ResPlanName [planCode=" + planCode + ", planName=" + planName + ", planStartDate=" + planStartDate
				+ "]";
	}
}
