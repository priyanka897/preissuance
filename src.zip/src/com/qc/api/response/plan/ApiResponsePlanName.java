package com.qc.api.response.plan;

import java.io.Serializable;

import com.qc.api.response.fund.ResponseFundName;

public class ApiResponsePlanName implements Serializable
{
	private static final long serialVersionUID = -135213338684677344L;
	private ResponsePlanName response;

	public ApiResponsePlanName() {
		super();
	}
	public ApiResponsePlanName(ResponsePlanName response) {
		super();
		this.response = response;
	}
	public ResponsePlanName getResponse() {
		return response;
	}
	public void setResponse(ResponsePlanName response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseNav [response=" + response + "]";
	}
}
