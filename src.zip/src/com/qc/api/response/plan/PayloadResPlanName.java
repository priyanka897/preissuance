package com.qc.api.response.plan;

import java.io.Serializable;
import java.util.List;

import com.qc.api.response.fund.ResFundName;

public class PayloadResPlanName implements Serializable{
	private static final long serialVersionUID = 8748777980811121938L;
	
	private List<ResPlanName> data;

	public List<ResPlanName> getData() {
		return data;
	}

	public void setData(List<ResPlanName> data) {
		this.data = data;
	}
	
}