package com.qc.api.response.getcities;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.getmaxcities.PayloadReqGetMaxCities;

public class ResponseGetCities implements Serializable
{
	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private PayloadResGetCities responseData;
	
	public ResponseGetCities() {
		super();
	}
	public ResponseGetCities(Header header, PayloadResGetCities responseData) {
		super();
		this.header = header;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	
	
	public PayloadResGetCities getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResGetCities responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseGetCities [header=" + header + ", responseData=" + responseData + "]";
	}
	
}
