package com.qc.api.response.getcities;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetCities implements Serializable
{
	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResGetCities> Cities;
	private String soaStatusCode;
	private String soaMessage;
	private String soaDescription;
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public List<ResGetCities> getCities() {
		return Cities;
	}

	public void setCities(List<ResGetCities> cities) {
		Cities = cities;
	}

	public String getSoaStatusCode() {
		return soaStatusCode;
	}

	public void setSoaStatusCode(String soaStatusCode) {
		this.soaStatusCode = soaStatusCode;
	}

	public String getSoaMessage() {
		return soaMessage;
	}

	public void setSoaMessage(String soaMessage) {
		this.soaMessage = soaMessage;
	}

	public String getSoaDescription() {
		return soaDescription;
	}

	public void setSoaDescription(String soaDescription) {
		this.soaDescription = soaDescription;
	}

	@Override
	public String toString() {
		return "PayloadResGetCities [Cities=" + Cities + ", soaStatusCode=" + soaStatusCode
				+ ", soaMessage=" + soaMessage + ", soaDescription=" + soaDescription + "getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	

	}
