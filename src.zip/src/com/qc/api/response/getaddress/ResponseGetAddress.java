package com.qc.api.response.getaddress;

import java.io.Serializable;

import com.qc.api.common.Header;

public class ResponseGetAddress implements Serializable {

	private static final long serialVersionUID = 8748777980811121938L;
	private Header header;
	private PayloadResGetAddress responseData;
	
	public ResponseGetAddress() {
		super();
	}
	public ResponseGetAddress(Header header, PayloadResGetAddress responseData) {
		super();
		this.header = header;
		this.responseData = responseData;
	}
	public Header getHeader() {
		return header;
	}
	public void setHeader(Header header) {
		this.header = header;
	}
	public PayloadResGetAddress getResponseData() {
		return responseData;
	}
	public void setResponseData(PayloadResGetAddress responseData) {
		this.responseData = responseData;
	}
	@Override
	public String toString() {
		return "ResponseGetAddress [header=" + header + ", responseData=" + responseData + "]";
	}
	
	
}
