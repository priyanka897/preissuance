package com.qc.api.response.getaddress;

import java.io.Serializable;

public class ApiResponseGetAddress implements Serializable{

	private static final long serialVersionUID = -135213338684677344L;
	private ResponseGetAddress response;

	public ApiResponseGetAddress() {
		super();
	}
	public ApiResponseGetAddress(ResponseGetAddress response) {
		super();
		this.response = response;
	}
	public ResponseGetAddress getResponse() {
		return response;
	}
	public void setResponse(ResponseGetAddress response) {
		this.response = response;
	}
	@Override
	public String toString() {
		return "ApiResponseGetPlan [response=" + response + "]";
	}
	
	
}
