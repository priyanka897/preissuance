package com.qc.api.response.getaddress;

import java.io.Serializable;
import java.util.List;

public class PayloadResGetAddress implements Serializable{

	private static final long serialVersionUID = -2407302032173574993L;
	private List<ResGetAddress> addressDetails;
	private String soaStatusCode;
	private String soaMessage;
	private String soaDescription;
	
	
	public List<ResGetAddress> getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(List<ResGetAddress> addressDetails) {
		this.addressDetails = addressDetails;
	}

	public String getSoaStatusCode() {
		return soaStatusCode;
	}

	public void setSoaStatusCode(String soaStatusCode) {
		this.soaStatusCode = soaStatusCode;
	}

	public String getSoaMessage() {
		return soaMessage;
	}

	public void setSoaMessage(String soaMessage) {
		this.soaMessage = soaMessage;
	}

	public String getSoaDescription() {
		return soaDescription;
	}

	public void setSoaDescription(String soaDescription) {
		this.soaDescription = soaDescription;
	}
	
	@Override
	public String toString() {
		return "PayloadResGetAddress [addressDetails=" + addressDetails + ", soaStatusCode=" + soaStatusCode
				+ ", soaMessage=" + soaMessage + ", soaDescription=" + soaDescription + ", getClass()="
		+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}
