package com.qc.api.response.getaddress;

import java.io.Serializable;

public class ResGetAddress implements Serializable
{
	private static final long serialVersionUID = 783979534649266820L;

	
	private String addrLine1;
	private String  addrLine2;
	private String addrLine3;
	private String pinCode;
	private String city;
	private String state;
	private String contactNo;
	private String latitude;
	private String longitude;
	
	public String getAddrLine1() {
		return addrLine1;
	}
	public void setAddrLine1(String addrLine1) {
		this.addrLine1 = addrLine1;
	}
	public String getAddrLine2() {
		return addrLine2;
	}
	public void setAddrLine2(String addrLine2) {
		this.addrLine2 = addrLine2;
	}
	public String getAddrLine3() {
		return addrLine3;
	}
	public void setAddrLine3(String addrLine3) {
		this.addrLine3 = addrLine3;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return "ResGetAddress [addrLine1=" + addrLine1 + ", addrLine2=" + addrLine2 + ", addrLine3=" + addrLine3
				+ ", pinCode=" + pinCode + ", city=" + city + ",state=" + state + ", contactNo=" + contactNo + ", latitude=" + latitude
				+ ", longitude=" + longitude + "]";
	}
	
}
