package com.qc.api.response.eKudos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BioApiResPayload implements Serializable
{
	private static final long serialVersionUID = 13822635038038665L;
	
	List<BioApiResTransaction> transactions = new ArrayList<>();

	public List<BioApiResTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<BioApiResTransaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "BioApiResPayload [transactions=" + transactions + "]";
	}
}
