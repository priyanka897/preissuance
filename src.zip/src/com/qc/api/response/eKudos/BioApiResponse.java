package com.qc.api.response.eKudos;

import java.io.Serializable;

import com.qc.api.dto.ApiErrorInfo;
import com.qc.api.dto.ApiResponseHeader;

public class BioApiResponse implements Serializable
{
	private static final long serialVersionUID = 5403564038406509746L;
	
	ApiResponseHeader header;
	ApiErrorInfo apiErrorInfo;
	BioApiResPayload payload;

	public ApiResponseHeader getHeader() {
		return header;
	}

	public void setHeader(ApiResponseHeader header) {
		this.header = header;
	}

	public ApiErrorInfo getErrorInfo() {
		return apiErrorInfo;
	}

	public void setErrorInfo(ApiErrorInfo apiErrorInfo) {
		this.apiErrorInfo = apiErrorInfo;
	}

	public BioApiResPayload getPayload() {
		return payload;
	}

	public void setPayload(BioApiResPayload payload) {
		this.payload = payload;
	}
	
	public BioApiResponse(ApiResponseHeader header, ApiErrorInfo apiErrorInfo, BioApiResPayload payload) {
		super();
		this.header = header;
		this.apiErrorInfo = apiErrorInfo;
		this.payload = payload;
	}
	
	public BioApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiResponse [header=" + header + ", errorInfo=" + apiErrorInfo + ", payload=" + payload + "]";
	}


	
}
