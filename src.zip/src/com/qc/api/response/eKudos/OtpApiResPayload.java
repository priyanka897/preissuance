package com.qc.api.response.eKudos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OtpApiResPayload implements Serializable
{
	private static final long serialVersionUID = 13822635038038665L;
	
	List<OtpApiResTransaction> transactions = new ArrayList<>();

	public List<OtpApiResTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<OtpApiResTransaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "OtpApiResPayload [transactions=" + transactions + "]";
	}

	
}
