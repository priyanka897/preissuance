package com.qc.api.response.eKudos;

import java.io.Serializable;

import com.qc.api.dto.ApiErrorInfo;
import com.qc.api.dto.ApiResponseHeader;

public class eKudosApiResponse implements Serializable
{
	private static final long serialVersionUID = 5403564038406509746L;
	
	ApiResponseHeader header;
	ApiErrorInfo apiErrorInfo;
	eKudosApiResPayload payload;
	
	public ApiResponseHeader getHeader() {
		return header;
	}
	public void setHeader(ApiResponseHeader header) {
		this.header = header;
	}
	public ApiErrorInfo getApiErrorInfo() {
		return apiErrorInfo;
	}
	public void setApiErrorInfo(ApiErrorInfo apiErrorInfo) {
		this.apiErrorInfo = apiErrorInfo;
	}
	public eKudosApiResPayload getPayload() {
		return payload;
	}
	public void setPayload(eKudosApiResPayload payload) {
		this.payload = payload;
	}
	@Override
	public String toString() {
		return "EkudosApiResponse [header=" + header + ", apiErrorInfo=" + apiErrorInfo + ", payload=" + payload + "]";
	}

}
