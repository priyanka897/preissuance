package com.qc.api.response.eKudos;

public class eKudosApiResTransaction {
	
	private int eKudos;
	private String empId;
	
	
	public int geteKudos() {
		return eKudos;
	}
	public void seteKudos(int eKudos) {
		this.eKudos = eKudos;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	@Override
	public String toString() {
		return "eKudosApiResTransaction [eKudos=" + eKudos + ", empId=" + empId + "]";
	}
}
