package com.qc.api.response.eKudos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class eKudosApiResPayload implements Serializable
{
	private static final long serialVersionUID = 13822635038038665L;
	
	List<eKudosApiResTransaction> transactions = new ArrayList<>();

	public List<eKudosApiResTransaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<eKudosApiResTransaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "EkudosApiResPayload [transactions=" + transactions + "]";
	}

}
