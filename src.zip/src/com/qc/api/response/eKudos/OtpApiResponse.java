package com.qc.api.response.eKudos;

import java.io.Serializable;

import com.qc.api.dto.ApiErrorInfo;
import com.qc.api.dto.ApiResponseHeader;

public class OtpApiResponse implements Serializable
{
	private static final long serialVersionUID = 5403564038406509746L;
	
	ApiResponseHeader header;
	ApiErrorInfo apiErrorInfo;
	OtpApiResPayload payload;

	public ApiResponseHeader getHeader() {
		return header;
	}

	public void setHeader(ApiResponseHeader header) {
		this.header = header;
	}

	public ApiErrorInfo getErrorInfo() {
		return apiErrorInfo;
	}

	public void setErrorInfo(ApiErrorInfo apiErrorInfo) {
		this.apiErrorInfo = apiErrorInfo;
	}

	public OtpApiResPayload getPayload() {
		return payload;
	}

	public void setPayload(OtpApiResPayload payload) {
		this.payload = payload;
	}
	
	public OtpApiResponse(ApiResponseHeader header, ApiErrorInfo apiErrorInfo, OtpApiResPayload payload) {
		super();
		this.header = header;
		this.apiErrorInfo = apiErrorInfo;
		this.payload = payload;
	}
	
	public OtpApiResponse() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ApiResponse [header=" + header + ", errorInfo=" + apiErrorInfo + ", payload=" + payload + "]";
	}


	
}
