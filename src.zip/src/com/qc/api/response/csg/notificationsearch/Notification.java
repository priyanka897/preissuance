package com.qc.api.response.csg.notificationsearch;

import java.io.Serializable;

public class Notification implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String creationDate;
	private String publishDate;
	private String summary;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public Notification(String id, String creationDate, String publishDate, String summary) {
		super();
		this.id = id;
		this.creationDate = creationDate;
		this.publishDate = publishDate;
		this.summary = summary;
	}

	public Notification() {
		super();
	}

	@Override
	public String toString() {
		return "Notification [id=" + id + ", creationDate=" + creationDate + ", publishDate=" + publishDate + ", summary=" + summary + "]";
	}

}
