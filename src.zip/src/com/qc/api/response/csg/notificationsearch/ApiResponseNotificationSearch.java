package com.qc.api.response.csg.notificationsearch;

import java.io.Serializable;

public class ApiResponseNotificationSearch implements Serializable {

	private static final long serialVersionUID = 1L;
	private ResponseNotificationSearch response;

	public ResponseNotificationSearch getResponse() {
		return response;
	}

	public void setResponse(ResponseNotificationSearch response) {
		this.response = response;
	}

	public ApiResponseNotificationSearch() {
		super();
	}

	public ApiResponseNotificationSearch(ResponseNotificationSearch response) {
		super();
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseNotificationSearch [response=" + response + "]";
	}

}
