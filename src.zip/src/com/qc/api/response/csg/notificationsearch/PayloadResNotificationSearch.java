package com.qc.api.response.csg.notificationsearch;

import java.io.Serializable;
import java.util.List;

public class PayloadResNotificationSearch implements Serializable {

	private static final long serialVersionUID = 1L;
	private List<Notification> notification;

	public List<Notification> getNotification() {
		return notification;
	}

	public void setNotification(List<Notification> notification) {
		this.notification = notification;
	}

	public PayloadResNotificationSearch(List<Notification> notification) {
		super();
		this.notification = notification;
	}

	public PayloadResNotificationSearch() {
		super();
	}

	@Override
	public String toString() {
		return "PayloadResNotificationSearch [notification=" + notification + "]";
	}

}
