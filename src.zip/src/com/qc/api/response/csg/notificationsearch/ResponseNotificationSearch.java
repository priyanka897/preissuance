package com.qc.api.response.csg.notificationsearch;

import java.io.Serializable;

import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponseNotificationSearch implements Serializable {

	private static final long serialVersionUID = 1L;

	private PayloadResNotificationSearch payload;
	private HeaderNew header;
	private MsgInfo msgInfo;

	public ResponseNotificationSearch(PayloadResNotificationSearch payload, HeaderNew header, MsgInfo msgInfo) {
		super();
		this.payload = payload;
		this.header = header;
		this.msgInfo = msgInfo;
	}

	public ResponseNotificationSearch() {
		super();
	}

	public PayloadResNotificationSearch getPayload() {
		return payload;
	}

	public void setPayload(PayloadResNotificationSearch payload) {
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	@Override
	public String toString() {
		return "ResponseNotificationSearch [payload=" + payload + ", header=" + header + ", msgInfo=" + msgInfo + "]";
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

}
