package com.qc.api.response.csg.listOfNotificationV2;

import java.io.Serializable;

public class ApiResponselistOfNotificationV2 implements Serializable {

	private static final long serialVersionUID = 1L;

	private ResponselistOfNotificationV2 response;

	public ApiResponselistOfNotificationV2() {
		super();
	}

	public ApiResponselistOfNotificationV2(ResponselistOfNotificationV2 response) {
		super();
		this.response = response;
	}

	public ResponselistOfNotificationV2 getResponse() {
		return response;
	}

	public void setResponse(ResponselistOfNotificationV2 response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponselistOfNotificationV2 [response=" + response + "]";
	}

}
