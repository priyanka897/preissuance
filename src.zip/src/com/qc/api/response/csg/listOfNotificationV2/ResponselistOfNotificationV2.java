package com.qc.api.response.csg.listOfNotificationV2;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponselistOfNotificationV2 implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadListOfNotificationV2 payload;

	public ResponselistOfNotificationV2() {
		super();
	}

	public ResponselistOfNotificationV2(HeaderNew header, MsgInfo msgInfo, PayloadListOfNotificationV2 payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	public PayloadListOfNotificationV2 getPayload() {
		return payload;
	}

	public void setPayload(PayloadListOfNotificationV2 payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "ResponselistOfNotificationV2 [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}

}
