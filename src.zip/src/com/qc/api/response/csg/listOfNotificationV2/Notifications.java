package com.qc.api.response.csg.listOfNotificationV2;

import java.io.Serializable;

public class Notifications implements Serializable {

	private static final long serialVersionUID = 1L;

	private String summary;
	private String details;
	private String publishDate;
	private String document;
	private String documentType;

	public Notifications() {
		super();
	}

	public Notifications(String summary, String details, String publishDate, String document, String documentType) {
		super();
		this.summary = summary;
		this.details = details;
		this.publishDate = publishDate;
		this.document = document;
		this.documentType = documentType;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	@Override
	public String toString() {
		return "Notifications [summary=" + summary + ", details=" + details + ", publishDate=" + publishDate + ", document=" + document + ", documentType=" + documentType + "]";
	}

}
