package com.qc.api.response.csg.listOfNotificationV2;

import java.io.Serializable;
import java.util.List;

public class PayloadListOfNotificationV2 implements Serializable {

	private static final long serialVersionUID = 1L;

	private String count;
	private String isRead;
	private List<Notifications> notifications;

	public PayloadListOfNotificationV2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayloadListOfNotificationV2(String count, String isRead, List<Notifications> notifications) {
		super();
		this.count = count;
		this.isRead = isRead;
		this.notifications = notifications;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getIsRead() {
		return isRead;
	}

	public void setIsRead(String isRead) {
		this.isRead = isRead;
	}

	public List<Notifications> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<Notifications> notifications) {
		this.notifications = notifications;
	}

	@Override
	public String toString() {
		return "PayloadListOfNotificationV2 [count=" + count + ", isRead=" + isRead + ", notifications=" + notifications + "]";
	}

}
