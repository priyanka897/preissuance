package com.qc.api.response.csg.createNotification;

import java.io.Serializable;

public class ApiResponseCreateNotification implements Serializable {

	private static final long serialVersionUID = 1L;

	private ResponseCreateNotification response;

	public ApiResponseCreateNotification() {
		super();
	}

	public ApiResponseCreateNotification(ResponseCreateNotification response) {
		super();
		this.response = response;
	}

	public ResponseCreateNotification getResponse() {
		return response;
	}

	public void setResponse(ResponseCreateNotification response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseCreateNotification [response=" + response + "]";
	}

}
