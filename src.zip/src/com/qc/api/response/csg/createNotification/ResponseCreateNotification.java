package com.qc.api.response.csg.createNotification;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponseCreateNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadCreateNotification payload;

	@Override
	public String toString() {
		return "ResponseCreateNotification [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	public PayloadCreateNotification getPayload() {
		return payload;
	}

	public void setPayload(PayloadCreateNotification payload) {
		this.payload = payload;
	}

	public ResponseCreateNotification(HeaderNew header, MsgInfo msgInfo, PayloadCreateNotification payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public ResponseCreateNotification() {
		super();
	}

}
