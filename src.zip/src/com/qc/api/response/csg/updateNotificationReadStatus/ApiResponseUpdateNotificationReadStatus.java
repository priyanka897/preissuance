package com.qc.api.response.csg.updateNotificationReadStatus;

import java.io.Serializable;

public class ApiResponseUpdateNotificationReadStatus implements Serializable {
	private static final long serialVersionUID = 1L;

	private ResponseUpdateNotificationReadStatus response;

	public ApiResponseUpdateNotificationReadStatus() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseUpdateNotificationReadStatus(ResponseUpdateNotificationReadStatus response) {
		super();
		this.response = response;
	}

	public ResponseUpdateNotificationReadStatus getResponse() {
		return response;
	}

	public void setResponse(ResponseUpdateNotificationReadStatus response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseUpdateNotificationReadStatus [response=" + response + "]";
	}

}
