package com.qc.api.response.csg.updateNotificationReadStatus;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.csg.updateNotificationReadStatus.PayloadUpdateNotificationReadStatus;

public class ResponseUpdateNotificationReadStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	private HeaderNew header;
	private MsgInfo msgInfo;
	private PayloadUpdateNotificationReadStatus payload;

	public ResponseUpdateNotificationReadStatus() {
		super();
	}

	public ResponseUpdateNotificationReadStatus(HeaderNew header, MsgInfo msgInfo, PayloadUpdateNotificationReadStatus payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	public PayloadUpdateNotificationReadStatus getPayload() {
		return payload;
	}

	public void setPayload(PayloadUpdateNotificationReadStatus payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "ResponseUpdateNotificationReadStatus [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}

}
