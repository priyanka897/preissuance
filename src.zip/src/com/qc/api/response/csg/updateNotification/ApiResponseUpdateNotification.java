package com.qc.api.response.csg.updateNotification;

import java.io.Serializable;

public class ApiResponseUpdateNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	private ResponseUpdateNotification response;

	public ApiResponseUpdateNotification() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApiResponseUpdateNotification(ResponseUpdateNotification response) {
		super();
		this.response = response;
	}

	public ResponseUpdateNotification getResponse() {
		return response;
	}

	public void setResponse(ResponseUpdateNotification response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseUpdateNotification [response=" + response + "]";
	}

}
