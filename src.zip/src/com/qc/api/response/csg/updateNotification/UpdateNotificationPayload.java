package com.qc.api.response.csg.updateNotification;

import java.io.Serializable;

public class UpdateNotificationPayload implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;

	public UpdateNotificationPayload() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UpdateNotificationPayload(String id) {
		super();
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "UpdateNotificationPayload [id=" + id + "]";
	}

}
