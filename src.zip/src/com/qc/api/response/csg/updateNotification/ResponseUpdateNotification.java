package com.qc.api.response.csg.updateNotification;

import java.io.Serializable;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;

public class ResponseUpdateNotification implements Serializable {

	private static final long serialVersionUID = 1L;
	private HeaderNew header;
	private MsgInfo msgInfo;
	private UpdateNotificationPayload payload;

	public ResponseUpdateNotification() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResponseUpdateNotification(HeaderNew header, MsgInfo msgInfo, UpdateNotificationPayload payload) {
		super();
		this.header = header;
		this.msgInfo = msgInfo;
		this.payload = payload;
	}

	public HeaderNew getHeader() {
		return header;
	}

	public void setHeader(HeaderNew header) {
		this.header = header;
	}

	public MsgInfo getMsgInfo() {
		return msgInfo;
	}

	public void setMsgInfo(MsgInfo msgInfo) {
		this.msgInfo = msgInfo;
	}

	public UpdateNotificationPayload getPayload() {
		return payload;
	}

	public void setPayload(UpdateNotificationPayload payload) {
		this.payload = payload;
	}

	@Override
	public String toString() {
		return "RequestUpdateNotification [header=" + header + ", msgInfo=" + msgInfo + ", payload=" + payload + "]";
	}

}
