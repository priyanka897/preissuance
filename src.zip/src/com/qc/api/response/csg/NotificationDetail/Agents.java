package com.qc.api.response.csg.NotificationDetail;

import java.io.Serializable;

public class Agents implements Serializable {

	private static final long serialVersionUID = 1L;
	private String agentId;

	public Agents() {
		super();
	}

	public Agents(String agentId) {
		super();
		this.agentId = agentId;
	}

	public String getAgentId() {
		return agentId;
	}

	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}

	@Override
	public String toString() {
		return "Agents [agentId=" + agentId + "]";
	}

}
