package com.qc.api.response.csg.NotificationDetail;

import java.io.Serializable;
import java.util.List;

public class NotificationDetailsPayload implements Serializable {

	private static final long serialVersionUID = 1L;
	private String summary;
	private String detail;
	private String document;
	private String documnetType;
	private String publishDate;
	private String status;
	private String type;
	private List<Agents> agents;

	public NotificationDetailsPayload() {
		super();
	}

	public NotificationDetailsPayload(String summary, String detail, String document, String documnetType, String publishDate, String status, String type, List<Agents> agents) {
		super();
		this.summary = summary;
		this.detail = detail;
		this.document = document;
		this.documnetType = documnetType;
		this.publishDate = publishDate;
		this.status = status;
		this.type = type;
		this.agents = agents;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	public String getDocument() {
		return document;
	}

	public void setDocument(String document) {
		this.document = document;
	}

	public String getDocumnetType() {
		return documnetType;
	}

	public void setDocumnetType(String documnetType) {
		this.documnetType = documnetType;
	}

	public String getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Agents> getAgents() {
		return agents;
	}

	public void setAgents(List<Agents> agents) {
		this.agents = agents;
	}

	@Override
	public String toString() {
		return "NotificationDetailsPayload [summary=" + summary + ", detail=" + detail + ", document=" + document + ", documnetType=" + documnetType + ", publishDate=" + publishDate + ", status=" + status + ", type=" + type + ", agents=" + agents
				+ "]";
	}

}
