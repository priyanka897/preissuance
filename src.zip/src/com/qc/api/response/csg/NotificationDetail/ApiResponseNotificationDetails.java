package com.qc.api.response.csg.NotificationDetail;

import java.io.Serializable;

public class ApiResponseNotificationDetails implements Serializable {
	private static final long serialVersionUID = 1L;
	private ResponseNotificationDetails response;

	public ApiResponseNotificationDetails() {
		super();
	}

	public ApiResponseNotificationDetails(ResponseNotificationDetails response) {
		super();
		this.response = response;
	}

	public ResponseNotificationDetails getResponse() {
		return response;
	}

	public void setResponse(ResponseNotificationDetails response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "ApiResponseNotificationDetails [response=" + response + "]";
	}

}
