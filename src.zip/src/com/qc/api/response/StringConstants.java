package com.qc.api.response;

public class StringConstants 
{
	public static final String SUCCESS = "Success";
	public static final String FAILURE = "Failure";
	
	public static final String C200 = "200";
	public static final String C200DESC = "Response Generated Successfully";
	public static final String C201DESC = "Updated Successfuly";
	public static final String C202DESC = "Updated Successfuly";
	
	public static final String C400 = "400";
	public static final String C400DESC = "Data could not save!";
	public static final String C400IDDESC="Invalid details!";
	
	public static final String C500 = "500";
	public static final String C500DESC = "Sorry could not fetch the details. Try after some time";
	
	
	public static final String C600 = "600";
	public static final String C600DESC = "Sorry could not fetch the details. Try after some time";
	
	public static final String C601 = "601";
	public static final String C601DESC = "Nav service unavailable";
	
	public static final String C603DESC = "getneopincodecity service unavailable";
	public static final String C604DESC = "slotconfirmation service unavailable";
	
	//////////////DB related Error code/////////////
	public static final String C700 = "700";
	public static final String C700DESC = "Data not found from backend";
	
	public static final String C701 = "701";
	public static final String C701DESC = "There seems to be something wrong at backend.";
	
	public static final String C203DESC = "Transaction Timeout";
	
	public static final String C203BDESC = "Updated Successfully";
	
	public static final String C702 = "702";
	public static final String C702DESC = "Already activated/deactivated";
	
	public static final String C601DESC2 = "Invalid transaction type";
}
