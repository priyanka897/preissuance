package com.qc.api.response.eCube;

import java.io.Serializable;

import com.qc.common.dto.AchievementProcDTO;
import com.qc.common.dto.ActivationProcDTO;
import com.qc.common.dto.AppliedProcDTO;
import com.qc.common.dto.CaseSizeProcDTO;
import com.qc.common.dto.GpaProcDTO;
import com.qc.common.dto.GrowthProcDTO;
import com.qc.common.dto.LpcPerformanceProcDTO;
import com.qc.common.dto.MiscProcDTO;
import com.qc.common.dto.ModeMixProcDTO;
import com.qc.common.dto.PaidProcDTO;
import com.qc.common.dto.PenetrationProcDTO;
import com.qc.common.dto.ProtectionProcDTO;
import com.qc.common.dto.RecProcDTO;
import com.qc.common.dto.SsoValidationProcDto;
import com.qc.common.dto.WipProcDTO;

public class ChatbotPayloadResponse implements Serializable
{

	private static final long serialVersionUID = 1L;
	private SsoValidationProcDto ssovalidation;
	private GrowthProcDTO Growth;
	private AchievementProcDTO Achievement;
	private PenetrationProcDTO Penetration;
    private WipProcDTO WIP;
    private LpcPerformanceProcDTO LPCPerformance;
    private RecProcDTO REC;
    private CaseSizeProcDTO CASESize;
    private ModeMixProcDTO MODEMix;
    private GpaProcDTO GPA;
    private ActivationProcDTO Activation;
    private AppliedProcDTO Applied;
    private PaidProcDTO Paid;
    private ProtectionProcDTO Protection;
    private MiscProcDTO misc;
    
	public SsoValidationProcDto getSsovalidation()
	{
		return ssovalidation;
	}
	public void setSsovalidation(SsoValidationProcDto ssovalidation) {
		this.ssovalidation = ssovalidation;
	}
	public GrowthProcDTO getGrowth() {
		return Growth;
	}
	public void setGrowth(GrowthProcDTO growth) {
		Growth = growth;
	}
	public AchievementProcDTO getAchievement() {
		return Achievement;
	}
	public void setAchievement(AchievementProcDTO achievement) {
		Achievement = achievement;
	}
	public PenetrationProcDTO getPenetration() {
		return Penetration;
	}
	public void setPenetration(PenetrationProcDTO penetration) {
		Penetration = penetration;
	}
	public WipProcDTO getWIP() {
		return WIP;
	}
	public void setWIP(WipProcDTO wIP) {
		WIP = wIP;
	}
	public LpcPerformanceProcDTO getLPCPerformance() {
		return LPCPerformance;
	}
	public void setLPCPerformance(LpcPerformanceProcDTO lPCPerformance) {
		LPCPerformance = lPCPerformance;
	}
	public RecProcDTO getREC() {
		return REC;
	}
	public void setREC(RecProcDTO rEC) {
		REC = rEC;
	}
	public CaseSizeProcDTO getCASESize() {
		return CASESize;
	}
	public void setCASESize(CaseSizeProcDTO cASESize) {
		CASESize = cASESize;
	}
	public ModeMixProcDTO getMODEMix() {
		return MODEMix;
	}
	public void setMODEMix(ModeMixProcDTO mODEMix) {
		MODEMix = mODEMix;
	}
	public GpaProcDTO getGPA() {
		return GPA;
	}
	public void setGPA(GpaProcDTO gPA) {
		GPA = gPA;
	}
	public ActivationProcDTO getActivation() {
		return Activation;
	}
	public void setActivation(ActivationProcDTO activation) {
		Activation = activation;
	}
	public AppliedProcDTO getApplied() {
		return Applied;
	}
	public void setApplied(AppliedProcDTO applied) {
		Applied = applied;
	}
	public PaidProcDTO getPaid() {
		return Paid;
	}
	public void setPaid(PaidProcDTO paid) {
		Paid = paid;
	}
	public ProtectionProcDTO getProtection() {
		return Protection;
	}
	public void setProtection(ProtectionProcDTO protection) {
		Protection = protection;
	}
	public MiscProcDTO getMisc() {
		return misc;
	}
	public void setMisc(MiscProcDTO misc) {
		this.misc = misc;
	}
}
