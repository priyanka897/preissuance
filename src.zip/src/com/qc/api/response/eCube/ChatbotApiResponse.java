package com.qc.api.response.eCube;

import java.io.Serializable;

import com.qc.common.dto.ApiResponseHeader;
import com.qc.common.dto.ErrorInfo;

public class ChatbotApiResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6631609449836870476L;
	private ApiResponseHeader header;
	private ErrorInfo errorInfo;
	private ChatbotPayloadResponse payload;

	public ChatbotApiResponse() {
		// TODO Auto-generated constructor stub
	}

	public ChatbotApiResponse(ApiResponseHeader header, ErrorInfo errorInfo, ChatbotPayloadResponse payload) {
		super();
		this.header = header;
		this.errorInfo = errorInfo;
		this.payload = payload;
	}

	public ApiResponseHeader getHeader() {
		return header;
	}

	public void setHeader(ApiResponseHeader header) {
		this.header = header;
	}

	public ErrorInfo getErrorInfo() {
		return errorInfo;
	}

	public void setErrorInfo(ErrorInfo errorInfo) {
		this.errorInfo = errorInfo;
	}

	public ChatbotPayloadResponse getPayload() {
		return payload;
	}

	public void setPayload(ChatbotPayloadResponse payload) {
		this.payload = payload;
	}

}
