package com.qc.daoImpl;

import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.dao.GetCitiesDao;
import com.qc.dao.GetStateDao;
import com.qc.entity.PR_GETCITIES_DTLS;
import com.qc.entity.PR_GETSTATE_DTLS;

@Repository
@Transactional
public class GetStateDaoImpl implements GetStateDao
{
	private static Logger logger = LogManager.getLogger(GetStateDaoImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private  LocalSessionFactoryBean sessionFactory;

	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getStateService(PR_GETSTATE_DTLS req) {
		logger.info("Inside  getStateService Dao  :: Method Execution :: Start");
		 @SuppressWarnings("unchecked")
		 List<Object[]> result = null;
				try 
				{
					logger.info("Inside getStateService :: PROC :- PR_SOA_STATE_DETAILS :: STARTS" );
					getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
					getSession().getTransaction().begin();
					ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_STATE_DETAILS");
					call.registerParameter(1, Class.class,ParameterMode.REF_CURSOR); 
					Output output = call.getOutputs().getCurrent();
					getSession().getTransaction().commit();
					if (output.isResultSet()) 
					{
						result = ((ResultSetOutput) output).getResultList();
					    logger.info("OutSide getStateService :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result );
					}
				}
				catch (Exception e)
				{
					logger.error("Error while calling Select getStateService Query : " + e);
				}
		logger.info("Inside getStateService Dao :: select query :- :: End");
		return result;
	}

	
}
