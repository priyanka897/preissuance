package com.qc.daoImpl;

import java.util.Collections;
import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.eCube.ChatbotPayloadRequest;
import com.qc.dao.ChatbotDbDao;

@Repository
@Transactional
public class ChatbotDbDaoImpl implements ChatbotDbDao{

private static Logger logger = LogManager.getLogger(ChatbotDbDaoImpl.class);
	
@Autowired
Environment env;

	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private  LocalSessionFactoryBean sessionFactory;
	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}
	
	@Override
	public List<Object[]> getSsoValidationProcList(String segment, String ssoid) {
		logger.info("Inside getSsoValidationProcList :: PROC :- PR_SOA_SSO_HRCHY_BOT2_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_SSO_HRCHY_BOT2_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((ssoid == null)?"":ssoid);
			call.registerParameter(2, Class.class,ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getSsoValidationProcList :: PROC :- PR_SOA_SSO_HRCHY_BOT2_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getSsoValidationProcList :: PROC :- PR_SOA_SSO_HRCHY_BOT2_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getSsoValidationProcList : Exception while executing procedure : PR_SOA_SSO_HRCHY_BOT2_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	@Override
	public List<Object[]> getGrowthProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getGrowthProcList :: PROC :- PR_SOA_GROWTH_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_GROWTH_BOT22_DTLS");
			
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getGrowthProcList :: PROC :- PR_SOA_GROWTH_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getGrowthProcList :: PROC :- PR_SOA_GROWTH_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getGrowthProcList : Exception while executing procedure : PR_SOA_GROWTH_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<Object[]> getAchievementProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getAchievementProcList :: PROC :- PR_SOA_ACHIEVEMENT_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ACHIEVEMENT_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getAchievementProcList :: PROC :- PR_SOA_ACHIEVEMENT_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getAchievementProcList :: PROC :- PR_SOA_ACHIEVEMENT_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getAchievementProcList : Exception while executing procedure : PR_SOA_ACHIEVEMENT_BOT2_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getPenetrationProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getPenetrationProcList :: PROC :- PR_SOA_PENETRATION_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_PENETRATION_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, String.class,ParameterMode.IN).bindValue((payload.getPlanType() == null)?"":payload.getPlanType().toString());
			call.registerParameter(12, Class.class,ParameterMode.REF_CURSOR); 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getPenetrationProcList :: PROC :- PR_SOA_PENETRATION_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getPenetrationProcList :: PROC :- PR_SOA_PENETRATION_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getPenetrationProcList : Exception while executing procedure : PR_SOA_PENETRATION_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getWipList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getWipList :: PROC :- PR_ECUBE_SCORECARD_WIP_V2 :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_ECUBE_SCORECARD_WIP_V2");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue("MLI".equalsIgnoreCase(channel)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getWipList :: PROC :- PR_ECUBE_SCORECARD_WIP_V2 :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getWipList :: PROC :- PR_ECUBE_SCORECARD_WIP_V2 :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getWipList : Exception while executing procedure : PR_ECUBE_SCORECARD_WIP_V2 : ",e);
		}
		return Collections.emptyList();
	}

	@Override
	public List<Object[]> getLpcPerformanceProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getLpcPerformanceProcList :: PROC :- PR_SOA_LPC_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_LPC_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getLpcPerformanceProcList :: PROC :- PR_SOA_LPC_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getLpcPerformanceProcList :: PROC :- PR_SOA_LPC_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getLpcPerformanceProcList : Exception while executing procedure : PR_SOA_LPC_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getRecProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getRecProcList :: PROC :- PR_SOA_RECRUITMENT_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_RECRUITMENT_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getRecProcList :: PROC :- PR_SOA_RECRUITMENT_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getRecProcList :: PROC :- PR_SOA_RECRUITMENT_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
		      logger.error("Inside getRecProcList : Exception while executing procedure : PR_SOA_RECRUITMENT_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getCaseSizeProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getCaseSizeProcList :: PROC :- PR_SOA_CASE_SIZE_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_CASE_SIZE_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getCaseSizeProcList :: PROC :- PR_SOA_CASE_SIZE_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getCaseSizeProcList :: PROC :- PR_SOA_CASE_SIZE_BOT22_DTLS :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getCaseSizeProcList : Exception while executing procedure : PR_SOA_CASE_SIZE_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getModeMixProcList(String segment, String channel, ChatbotPayloadRequest payload) {
		logger.info("Inside getModeMixProcList :: PROC :- PR_SOA_MODE_MIX_BOT22_DTLS :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_MODE_MIX_BOT22_DTLS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			 
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getModeMixProcList :: PROC :- PR_SOA_MODE_MIX_BOT22_DTLS :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getModeMixProcList :: PROC :- PR_SOA_MODE_MIX_BOT22_DTLS :: END" );
			
		}
		catch(Exception e)
		{
			logger.error("Inside getModeMixProcList : Exception while executing procedure : PR_SOA_MODE_MIX_BOT22_DTLS : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getAppliedProcList(String segment, String channel, ChatbotPayloadRequest payload) 
	{
		logger.info("Inside getAppliedProcList :: PROC :- PR_ECUBE_SCORECARD_APPLIED_V22  :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_ECUBE_SCORECARD_APPLIED_V22");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue("MLI".equalsIgnoreCase(channel)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getAppliedProcList :: PROC :- PR_ECUBE_SCORECARD_APPLIED_V22 :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getAppliedProcList :: PROC :- PR_ECUBE_SCORECARD_APPLIED_V22 :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getAppliedProcList : Exception while executing procedure : PR_ECUBE_SCORECARD_APPLIED_V22 : ",e);
		}
		return Collections.emptyList();
	}
	
	@Override
	public List<Object[]> getPaidProcList(String segment, String channel, ChatbotPayloadRequest payload)
	{
		logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_INFORCED_V2 :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_ECUBE_SCORECARD_INFORCED_V2");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((payload.getDesignationDesc()== null)?"":payload.getDesignationDesc().toString());
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue("MLI".equalsIgnoreCase(channel)?"":channel);
			call.registerParameter(3, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(4, String.class,ParameterMode.IN).bindValue((payload.getZone() == null)?"":payload.getZone().toString());
			call.registerParameter(5, String.class,ParameterMode.IN).bindValue((payload.getRegion() == null)?"":payload.getRegion().toString());
			call.registerParameter(6, String.class,ParameterMode.IN).bindValue((payload.getCircle() == null)?"":payload.getCircle().toString());
			call.registerParameter(7, String.class,ParameterMode.IN).bindValue((payload.getCluster() == null)?"":payload.getCluster().toString());
			call.registerParameter(8, String.class,ParameterMode.IN).bindValue((payload.getGo() == null)?"":payload.getGo().toString());
			call.registerParameter(9, String.class,ParameterMode.IN).bindValue((payload.getCmo() == null)?"":payload.getCmo().toString());
			call.registerParameter(10, String.class,ParameterMode.IN).bindValue((payload.getAmo() == null)?"":payload.getAmo().toString());
			call.registerParameter(11, Class.class,ParameterMode.REF_CURSOR); 
			
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_INFORCED_V2 :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_INFORCED_V2 :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getPaidProcList : Exception while executing procedure : PR_ECUBE_SCORECARD_INFORCED_V2 : ",e);
		}
		return Collections.emptyList();
	}


	@Override
	public List<Object[]> getMiscProcList(String segment, String channel, ChatbotPayloadRequest payload) 
	{
		logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_GA_MISC :: STARTS" );
		try
		{
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			ProcedureCall call = getSession().createStoredProcedureCall("PR_ECUBE_SCORECARD_GA_MISC");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue((channel == null)?"":channel);
			call.registerParameter(2, String.class,ParameterMode.IN).bindValue((payload.getSubChannel() == null)?"":payload.getSubChannel().toString());
			call.registerParameter(3, Class.class,ParameterMode.REF_CURSOR); 
			
			Output output = call.getOutputs().getCurrent();
			getSession().getTransaction().commit();
			if (output.isResultSet()) 
			{
			    @SuppressWarnings("unchecked")
				List<Object[]> result = ((ResultSetOutput) output).getResultList();
			    logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_GA_MISC :: SUCCESS :: ENDS" );
			    return result;
			}
			logger.info("Inside getPaidProcList :: PROC :- PR_ECUBE_SCORECARD_GA_MISC :: END" );
		}
		catch(Exception e)
		{
			logger.error("Inside getPaidProcList : Exception while executing procedure : PR_ECUBE_SCORECARD_GA_MISC : ",e);
		}
		return Collections.emptyList();
	}
}
