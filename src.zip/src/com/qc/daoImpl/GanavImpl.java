package com.qc.daoImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.response.current.nav.ResCurrentNav;
import com.qc.api.response.fund.ResFundName;
import com.qc.api.response.nav.ResNav;
import com.qc.api.response.plan.ResPlanName;
import com.qc.dao.FundDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;

@Repository
@Transactional
public class GanavImpl implements FundDao
{
	private static Logger logger = LogManager.getLogger(GanavImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory")
	private  LocalSessionFactoryBean sessionFactory;
	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}

	@Override
	public List<ResFundName> getFundDetails()
	{  
		logger.info("Inside Fundname DaoImpl  :: Method Execution :: Start");
		try 
		{       logger.info("Inside Fundname DaoImpl   :: Select Query  :: START");
				SQLQuery sqlQuery = getSession().createSQLQuery("SELECT DISTINCT Fund_id,FUND_NAME,FUND_START_DT,SFIN_NO  from NAV_REPORT_TAB_FINAL_INC");
				sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				@SuppressWarnings("unchecked")
				List<ResFundName> results = sqlQuery.list();
				logger.info("Inside Fundname DaoImpl   :: Select Query  :: SUCCESS :: ENDS");
				if (results != null && !results.isEmpty())
				{   
					logger.info("Got success in result and list size is ::Fundname "+results.size());
					return results;
				}
		}
		catch (Exception e)
		{
			logger.error("Error while excuting  Select query : : Fundname service : " + e);
		}
		logger.info("Inside Fundname DaoImpl :: Method Execution :: End");
		return null;
	}

	@Override
	public List<ResNav> getNavDetails(PR_GETAGNTINFO_TPP_NAV_DTLS req) {
		
				logger.info("Inside Get Nav DaoImpl  :: Method Execution :: Start");
				try 
				{       logger.info("Inside Nav DaoImpl  :: Select Query  :: START ");
						SQLQuery sqlQuery = getSession().createSQLQuery("SELECT Plan_name,PLAN_CODE,Effective_Date,Fund_name,ROUND(Selling_Price_NAV,2),FUND_START_DT,PLAN_START_DT,SFIN_NO from NAV_REPORT_TAB_FINAL_INC where Plan_name=:Plan_name and Effective_Date between :Effective_Date1 and :Effective_Date2");
						sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
					    sqlQuery.setParameter("Plan_name",req.getPlanName());
						sqlQuery.setParameter("Effective_Date1", req.getFromDate());
						sqlQuery.setParameter("Effective_Date2", req.getToDate());
						@SuppressWarnings("unchecked")
						List<ResNav> results = sqlQuery.list();
						logger.info("Inside Nav DaoImpl  :: Select Query  :: SUCCESS :: ENDS"+sqlQuery);
						if (results != null && !results.isEmpty())
						{
							logger.info("Got success in result and list size is :: Nav service "+results.size());
							return results;
						}
				}
				catch (Exception e)
				{
					logger.error("Error while calling Select Nav Query : " + e);
				}
				logger.info("Inside get Nav DaoImpl ::  Method Execution:- :: End");
				return null;
	}

	@Override
	public List<ResPlanName> getPlanDetails()
	{  
		logger.info("Inside Planname DaoImpl  :: Method Execution :: Start");
		try 
		{        logger.info("Inside Planname DaoImpl   :: Select Query  :: START");
				SQLQuery sqlQuery = getSession().createSQLQuery("SELECT DISTINCT PLAN_CODE,Plan_name,PLAN_START_DT from NAV_REPORT_TAB_FINAL_INC");
				sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				@SuppressWarnings("unchecked")
				List<ResPlanName> results = sqlQuery.list();
				logger.info("Inside Planname DaoImpl   :: Select Query  :: SUCCESS :: ENDS");
				if (results != null && !results.isEmpty())
				{   
					logger.info("Got success in result and list size is ::Planname "+results.size());
					return results;
				}
		}
		catch (Exception e)
		{
			logger.error("Error while excuting  Select query : : Planname DaoImpl : " + e);
		}
		logger.info("Inside Planname DaoImpl :: Method Execution :: End");
		return null;
	}

	@Override
	public List<ResCurrentNav> getCurrentNavDetails(PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req) {
		
		logger.info("Inside CurrentNav DaoImpl  :: Method Execution :: Start");
		try 
		{       logger.info("Inside CurrentNav DaoImpl  :: Select Query  :: START ");
				SQLQuery sqlQuery = getSession().createSQLQuery("SELECT A.Plan_name, A.PLAN_CODE, A.Effective_Date, A.Fund_name, round(A.Selling_Price_NAV,2), A.FUND_START_DT, A.PLAN_START_DT,trunc((((A.Selling_Price_NAV - B.Selling_Price_NAV)/B.Selling_Price_NAV)/100),2) SELLING_DIFF_CHANGE,A.SFIN_NO FROM NAV_REPORT_TAB_FINAL_INC A,  NAV_REPORT_TAB_FINAL_INC B WHERE A.Plan_name = B.Plan_name AND  A.PLAN_CODE = B.PLAN_CODE AND A.Plan_name=:Plan_name AND  A.Fund_name = B.Fund_name AND  A.PLAN_START_DT = B.PLAN_START_DT AND  A.Effective_Date = ( SELECT MAX(Effective_Date)  FROM NAV_REPORT_TAB_FINAL_INC ) AND B.Effective_Date = ( SELECT MAX(Effective_Date)  FROM NAV_REPORT_TAB_FINAL_INC WHERE Effective_Date <>(SELECT MAX(Effective_Date) FROM NAV_REPORT_TAB_FINAL_INC))");
				sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				sqlQuery.setParameter("Plan_name", req.getPlanName().trim());
				@SuppressWarnings("unchecked")
				List<ResCurrentNav> results = sqlQuery.list();
				logger.info("Inside CurrentNav DaoImpl  :: Select Query  :: SUCCESS :: ENDS");
				if (results != null && !results.isEmpty())
				{
					logger.info("Got success in result and list size is :: CurrentNav service "+results.size());
					return results;
				}
		}
		catch (Exception e)
		{
			logger.error("Error while calling Select CurrentNav Query : " + e);
		}
		logger.info("Inside Current Nav DaoImpl ::  Method Execution:- :: End");
		return null;
}	
}
