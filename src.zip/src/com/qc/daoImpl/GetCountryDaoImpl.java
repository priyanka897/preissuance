package com.qc.daoImpl;

import java.util.List;


import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.dao.GetCountryDao;
import com.qc.entity.PR_GETCOUNTRY_DTLS;

@Repository
@Transactional
public class GetCountryDaoImpl implements GetCountryDao
{
	private static Logger logger = LogManager.getLogger(GetCountryDaoImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private  LocalSessionFactoryBean sessionFactory;

	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getCountryService(PR_GETCOUNTRY_DTLS req) {
		logger.info("Inside  getCountryService Dao  :: Method Execution :: Start");
		 @SuppressWarnings("unchecked")
		 List<Object[]> result = null;
				try 
				{
					logger.info("Inside getCountryService :: PROC :- PR_SOA_COUNTRY_DETAILS :: STARTS" );
					getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
					getSession().getTransaction().begin();
					ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_COUNTRY_DETAILS");
					call.registerParameter(1, Class.class,ParameterMode.REF_CURSOR); 
					Output output = call.getOutputs().getCurrent();
					getSession().getTransaction().commit();
					if (output.isResultSet()) 
					{
						result = ((ResultSetOutput) output).getResultList();
					    logger.info("OutSide getCountryService :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result );
					}
				}
				catch (Exception e)
				{
					logger.error("Error while calling Select getCountryService Query : " + e);
				}
		logger.info("Inside getCountryService Dao :: select query :- :: End");
		return result;
	}

	
}
