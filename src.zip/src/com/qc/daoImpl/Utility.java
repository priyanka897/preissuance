package com.qc.daoImpl;



import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;




public class Utility {
	
	private static Logger logger = LogManager.getLogger(Utility.class);
	public static void main(String[] args) {
		Date d=new Utility().getDateToStringInFormat("2016-04-11");
		System.out.println(d);
	}
	 public Date getDateToStringInFormat(String str)
		{
			
			Date curDate=null;
			try{
				//String str = "2016-04-11"; 
				SimpleDateFormat parserSDF = new SimpleDateFormat("yyyy-MM-dd");
				curDate = parserSDF.parse(str);
				Calendar cal = Calendar.getInstance();
				cal.setTime(curDate);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return curDate;
		}
		public static Date getStringToDate(String date)
		{
			java.util.Date curDate=null;
			SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
			try{
				
				
				curDate = df.parse(date);
				System.out.println("String to Date: " + curDate);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return curDate;
		}
		public static Date getStringToDate2(String date)
		{
			java.util.Date curDate=null;
			SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			try{
				
				
				curDate = df.parse(date);
				System.out.println("String to Date: " + curDate);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			return curDate;
		}
		
		public static Integer calculateMonthDiff(Date begining, Date end) throws Exception {

	        if (begining.compareTo(end) > 0) {
	            throw new Exception("Beginning date is greater than the ending date");
	        }

	        if (begining.compareTo(end) == 0) {
	            return 0;
	        }

	        Calendar cEndCheckDate = Calendar.getInstance();
	        cEndCheckDate.setTime(begining);
	        int add = 0;
	        while (true) {
	            cEndCheckDate.add(Calendar.MONTH, 1);
	            add++;
	            if (cEndCheckDate.getTime().compareTo(end) > 0) {
	                return add - 1;
	            }
	        }
	    }

		public static java.sql.Date stringtoSqlDateFormat1(String strDate){
				
			   SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MMM-yyyy");
			   java.util.Date date=null;
			try {
				date = sdf1.parse(strDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			   java.sql.Date sqlStartDate = (java.sql.Date) new java.sql.Date(date.getTime()); 
			   return sqlStartDate;
		} 
		
		public static java.sql.Date stringtoSqlDateFormat2(String strDate){
			strDate=strDate.substring(0, 10);
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date=null;
			try {
				date = sdf1.parse(strDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date sqlStartDate = (java.sql.Date) new java.sql.Date(date.getTime()); 
			return sqlStartDate;
		} 
		public static java.sql.Date stringtoSqlDateFormatNAV(String strDate){
			strDate=strDate.substring(0, 10);
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date=null;
			try {
				date = sdf1.parse(strDate);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			java.sql.Date sqlStartDate = (java.sql.Date) new java.sql.Date(date.getTime()); 
			
			return stringtoSqlDateFormat2(sqlStartDate.toString());
		} 
	
}
