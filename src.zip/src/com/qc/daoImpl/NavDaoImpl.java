package com.qc.daoImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.dao.NavDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_PLCY_DTLS;
import com.qc.entity.PR_GETNAVINFO_TPP_PLCY_DTLS;
import com.qc.utils.Commons;

@Repository
@Transactional
public class NavDaoImpl implements NavDao
{
	private static Logger logger = LogManager.getLogger(NavDaoImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory3")
	private  LocalSessionFactoryBean sessionFactory;

	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}

	@Override
	public String getNavService(PR_GETAGNTINFO_TPP_PLCY_DTLS req)
	{  
		String Status = "Failed";
		String requesttype = "Selection";
		logger.info("Inside Get Nav service  :: Method Execution :: Start");
		PR_GETNAVINFO_TPP_PLCY_DTLS req1 = new PR_GETNAVINFO_TPP_PLCY_DTLS();
		try 
		{
			req1.setPolicyid(req.getPolicyid());
		}
		catch (Exception e)
		{
			// added by vinay
			logger.error("Error while setting been data : " + e);
		}
		try 
		{

			if(this.checkValidPoilcyNumber(req.getPolicyid()))
			{

				SQLQuery sqlQuery = getSession()
						.createSQLQuery("SELECT NAVSMS_STATUS FROM OPT_NAVSMS_MST WHERE POL_ID =:POL_ID");
				sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				sqlQuery.setParameter("POL_ID", req.getPolicyid());
				@SuppressWarnings("unchecked")
				List<Object> results = sqlQuery.list();

				if (results != null && !results.isEmpty())
				{
					Status = "Success";
					logger.info("Inside Nav service  :: Select Query  :: SUCCESS :: ENDS");
					saveRequestInLoggerTable(req1, Status, requesttype);
					return results.get(0).toString();
				}
			}
			else
			{
				logger.info("Policy Id is not valid =: "+req.getPolicyid());
				return null;
			}
		}
		catch (Exception e)
		{
			logger.error("Error while calling Select Nav Query : " + e);
			saveRequestInLoggerTable(req1, Status, requesttype);
		}
		logger.info("Inside getNav Details :: select query :- :: End");
		return null;
	}

	
	public String executeUpdate(final String query,final String[] param) throws SQLException
	{
		logger.debug("Comes to DBConnection in ExecuteUpdate Method : ");
		final Map<String,String> msg = new HashMap<String,String>();
		msg.put("msg", "");
		try
		{
			Work work = new Work()
			{
				@Override
				public void execute(Connection con) throws SQLException
				{
					String message="";
					int i=0;
					int count=-999;
					if(con!=null)
					{
						PreparedStatement stmt =null;
						try
						{
							con.setAutoCommit(true);
							stmt = con.prepareStatement(query);	
							stmt.setQueryTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
							if(param.length>0)
							{
								logger.info("SQL query to be executed : "+query +" with Parameters :-"+Arrays.toString(param));
								while(i<param.length)
								{
									stmt.setString(i+1,param[i]);
									i++;
								}
							}
							else
							{
								logger.info("SQL query to be executed : "+query);
							}
							count=stmt.executeUpdate();
							logger.debug("After Executing query total change count is:-"+count);
						}
						catch(Exception e)
						{
							logger.error("Error while executing query:"+e,new Throwable());
						}   
						try
						{
							if(stmt!=null)
							{
								stmt.close();
							}
						}
						catch(Exception e)
						{				
							logger.error("SQL exception while closing resources in getPlanDetailData Method: "+e);
						}
					}
					else
					{
						logger.error("Connection is Not Available Service unavailable.");		
					}
					if(count!=-999)
					{
						message=String.valueOf(count);
					}
					logger.debug("Getting out from DBConnection in ExecuteUpdate Method : ");
					msg.put("msg", message);
				}
			};
			getSession().doWork(work);
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
		}	
		return msg.get("msg");
	}

	
	
	@Override
	public int getUpdateNavDetails(PR_GETNAVINFO_TPP_PLCY_DTLS req) 
	{
		String Status = null;
		String requesttype = "Updation";
		logger.info("Inside Get Nav service  Update :: Method Execution :: Start");
		try 
		{
			if(this.checkValidPoilcyNumber(req.getPolicyid()))
			{
				
				SQLQuery getDateQuery = getSession().createSQLQuery("select TO_CHAR(cvg_ori_mat_xpry_dt,'DD-mon-YY') from tcvg where pol_id='"+req.getPolicyid()+"' and co_id='CP' and cvg_num='01'  and rownum<=1		");
				getDateQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				List list = getDateQuery.list();
				String[] param = new String[2];
				param[0]=req.getSmsstatus();
				param[1]=req.getPolicyid();
				String resultMsg="0";
				if(list!=null && !list.isEmpty())
				{
					resultMsg = this.executeUpdate("UPDATE OPT_NAVSMS_MST SET NAVSMS_STATUS = ?, NAVSMS_FRQNCY = 'Daily', SMS_VALID_DATE=to_DATE('"+list.get(0).toString()+"','DD-MON-RR')  WHERE POL_ID =?", param);
				}
				else
				{
					resultMsg = this.executeUpdate("UPDATE OPT_NAVSMS_MST SET NAVSMS_STATUS = ?, NAVSMS_FRQNCY = 'Daily', SMS_VALID_DATE=null  WHERE POL_ID =?", param);
				}
				logger.info("Update Status is : "+resultMsg);
				int row=Integer.valueOf(resultMsg);
				if(row>0)
				{
					Status = "Success";
					saveRequestInLoggerTable(req, Status, requesttype);
					return row;
				}
				else if(row==0)
				{
					StringBuilder sb = new StringBuilder();
					sb.append(" 	 INSERT	 ");
					sb.append(" 	   INTO OPT_NAVSMS_MST	 ");
					sb.append(" 	  (	 ");
					sb.append(" 	    NAVSMS_ID     ,	 ");
					sb.append(" 	    POL_ID        ,	 ");
					sb.append(" 	    NAVSMS_STATUS ,	 ");
					sb.append(" 	    CREATEDBY     ,	 ");
					sb.append(" 	    DTCREATED     ,	 ");
					sb.append(" 	    SMS_VALID_DATE,	 ");
					sb.append(" 	    NAVSMS_FRQNCY	 ");
					sb.append(" 	  )	 ");
					sb.append(" 	  VALUES	 ");
					sb.append(" 	  (	 ");
					sb.append(" 	    (SELECT MAX(NAVSMS_ID+1) FROM OPT_NAVSMS_MST ),	 ");
					sb.append(" 	    :POL_ID        ,	 ");
					sb.append(" 	    :NAVSMS_STATUS ,	 ");
					sb.append(" 	    :CREATEDBY     ,	 ");
					sb.append(" 	    sysdate        ,	 ");
					sb.append(" 	    (select cvg_ori_mat_xpry_dt from tcvg where pol_id=:POL_ID and co_id='CP' and cvg_num='01'),	 ");
					sb.append(" 	    :NAVSMS_FRQNCY       ");
					sb.append("		   )  ");

					SQLQuery sql = getSession()
							.createSQLQuery(sb.toString());
					sql.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
					sql.setParameter("POL_ID", req.getPolicyid());
					sql.setParameter("NAVSMS_STATUS", req.getSmsstatus());
					sql.setParameter("CREATEDBY", "");
					sql.setParameter("NAVSMS_FRQNCY","Daily");
					int result = sql.executeUpdate();
					Status = "Success";
					saveRequestInLoggerTable(req, Status, requesttype);
					return 1;
				}
				else
				{
					Status = "Failed";
					saveRequestInLoggerTable(req, Status, requesttype);
				}
			}
			else
			{
				logger.info("Policy Id is not valid in update case "+req.getPolicyid());
			}
		}
		catch (Exception e)
		{
			Status = "Failed";
			saveRequestInLoggerTable(req, Status, requesttype);
			logger.error("Error while update nav service: " + e);
		}
		finally
		{
			logger.info("NAVDaoImpl || updateNavSmsStatus || :-END");
		}
		return 0;
	}
	@Override
	public boolean checkValidPoilcyNumber(String policynum) 
	{
		try 
		{
			SQLQuery sqlQuery = getSession()
					.createSQLQuery("SELECT COUNT(1) CNT FROM OPT_NAVSMS_MST WHERE POL_ID = :POL_ID");
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			sqlQuery.setParameter("POL_ID", policynum);
			@SuppressWarnings("unchecked")
			List<Object> results = sqlQuery.list();
			
			if (Integer.valueOf(results.get(0).toString())!=0 && !results.isEmpty() && results != null)
			
			{
				logger.info("policy id is valid "+policynum);
				return true;
			}
		}
		catch (Exception e)
		{
			logger.error("Error while cheking poilcy id validation : " + e);
			return false;
		}
		return false;

	}

	public  String saveRequestInLoggerTable(PR_GETNAVINFO_TPP_PLCY_DTLS bean, String requesttype, String status2)
	{
		logger.info("WebDBLogger || saveRequestInLoggerTable || :-START" );
		String status=null;
		String machineIp="";
		try
		{    
			SQLQuery sqlQuery = getSession().createSQLQuery("INSERT INTO SCOOPREST_NAV_DBLOGS(TRANSACTION_ID, POLICY_ID ,USER_ID ,MACHINE_IP ,UNIQUETRANS_ID ,REQUESTEDBY ,STATUS ,REQUESTDATE, SOURCE ,REQUEST_TYPE) VALUES (concat('M',lpad(SCOOP_NAV_SEQ.nextval,10,'0')),:POLICY_ID,:USER_ID, :MACHINE_IP,:UNIQUETRANS_ID,:REQUESTEDBY,:STATUS,:REQUESTDATE,:SOURCE,:REQUEST_TYPE)");
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			sqlQuery.setParameter("POLICY_ID", bean.getPolicyid());
			sqlQuery.setParameter("USER_ID", "22112");
			sqlQuery.setParameter("MACHINE_IP", 212121);
			sqlQuery.setParameter("UNIQUETRANS_ID","21");
			sqlQuery.setParameter("REQUESTEDBY","abc");
			sqlQuery.setParameter("STATUS", status2 );
			sqlQuery.setParameter("REQUESTDATE",new java.sql.Date(new Date().getTime()));
			sqlQuery.setParameter("SOURCE","web");
			sqlQuery.setParameter("REQUEST_TYPE", requesttype);

			int i=sqlQuery.executeUpdate();
			if(i>0)
			{
				status="Insertion completed";
				logger.debug("Status : "+status);
			}
		} 
		catch (Exception e) 
		{
			logger.error("Exception occured : "+e);
		}
		finally
		{
			logger.info("WebDBLogger || saveRequestInLoggerTable || :-END" );
		}
		return status;
	}
	@SuppressWarnings("unchecked")
	@Override
	public String getUpdateAlertNav(String policyNumber, String transactionType) {
		List results = null;
		String navSmsStatus = "Failed";
		String response = null;
		String str = null;
		if (transactionType.equalsIgnoreCase("Activate")) {
			navSmsStatus = "N";
		} else if (transactionType.equalsIgnoreCase("Deactivate")) {
			navSmsStatus = "Y";
		} else {
			response = "Invalid transaction type";
			return response;
		}
		try {
			if (navSmsStatus.equalsIgnoreCase("N") || navSmsStatus.equalsIgnoreCase("Y")) {
				SQLQuery sqlQuery = getSession().createSQLQuery("SELECT POL_ID FROM tcvg where cvg_num = '01' and POL_ID =:POL_ID");
				sqlQuery.setLong("POL_ID", Long.parseLong(policyNumber));
				List queryResult = sqlQuery.list();

				if (queryResult.size() > 0) {

					sqlQuery = getSession().createSQLQuery("select to_char(cvg_mat_xpry_dt, 'DD-MM-YYYY') as cvg_mat_xpry_dt from tcvg where cvg_num = '01' and POL_ID = :POL_ID");
					sqlQuery.setLong("POL_ID", Long.parseLong(policyNumber));
					List results2 = sqlQuery.list();
					str = results2.get(0).toString().trim();
					Date date1 = new SimpleDateFormat("dd-MM-yyyy").parse(str);

					sqlQuery = getSession().createSQLQuery("SELECT * FROM OPT_NAVSMS_MST WHERE POL_ID = :POL_ID");
					sqlQuery.setParameter("POL_ID", policyNumber);
					results = sqlQuery.list();

					if (results.size() == 1) {
						sqlQuery = getSession().createSQLQuery("SELECT NAVSMS_STATUS FROM OPT_NAVSMS_MST WHERE POL_ID = :POL_ID");
						sqlQuery.setParameter("POL_ID", policyNumber);
						results.add(sqlQuery.list());
						String polStatus = results.get(1).toString().substring(1, results.get(1).toString().length() - 1);
						if (!polStatus.equalsIgnoreCase(navSmsStatus)) {
							sqlQuery = getSession().createSQLQuery("UPDATE OPT_NAVSMS_MST SET NAVSMS_STATUS =:NAVSMS_STATUS , NAVSMS_FRQNCY = 'DAILY', SMS_VALID_DATE =:SMS_VALID_DATE WHERE POL_ID =:POL_ID");
							sqlQuery.setParameter("NAVSMS_STATUS", navSmsStatus);
							sqlQuery.setDate("SMS_VALID_DATE", date1);
							sqlQuery.setParameter("POL_ID", policyNumber);
							int status = sqlQuery.executeUpdate();
							if (status == 1) {
								response = "Updated successfully";
							} else {
								return response;
							}
						} else {
							response = "Already activated/deactivated";
							return response;
						}
					} else {
						sqlQuery = getSession().createSQLQuery("select max(NAVSMS_ID+1) from OPT_NAVSMS_MST");
						List<Object> results1 = sqlQuery.list();
						sqlQuery = getSession().createSQLQuery("insert into OPT_NAVSMS_MST (NAVSMS_ID, POL_ID, NAVSMS_STATUS, CREATEDBY,DTCREATED,SMS_VALID_DATE,NAVSMS_FRQNCY) values (:NAVSMS_ID,:POL_ID,:NAVSMS_STATUS,:CREATEDBY,sysdate,:SMS_VALID_DATE,:NAVSMS_FRQNCY)");
						sqlQuery.setParameter("NAVSMS_ID", results1.get(0));
						sqlQuery.setParameter("POL_ID", policyNumber);
						sqlQuery.setParameter("NAVSMS_STATUS", navSmsStatus);
						sqlQuery.setParameter("CREATEDBY", "NEOWS");
						sqlQuery.setDate("SMS_VALID_DATE", date1);
						sqlQuery.setParameter("NAVSMS_FRQNCY", "DAILY");
						int status = sqlQuery.executeUpdate();
						if (status == 1) {
							response = "Inserted successfully";
						} else {
							return response;
						}
					}
				}
			} else {
				return response;
			}
		} catch (Exception e) {
			logger.error("Error while cheking poilcy id validation : " + e);
			return response;
		}
		return response;

	}
	public List<Object> getNavDetailDao(String policyNumber) {
		logger.info("Inside Get Nav service  :: Method Execution :: Start");
		try {

			SQLQuery sqlQuery = getSession().createSQLQuery("SELECT NAVSMS_STATUS FROM OPT_NAVSMS_MST WHERE POL_ID =:POL_ID");
			sqlQuery.setParameter("POL_ID", policyNumber);
			@SuppressWarnings("unchecked")
			List<Object> results = sqlQuery.list();
			sqlQuery = getSession().createSQLQuery("select to_char(cvg_mat_xpry_dt, 'DD-MM-YYYY') as cvg_mat_xpry_dt from tcvg where cvg_num = '01' and POL_ID =:POL_ID");
			sqlQuery.setLong("POL_ID", Long.parseLong(policyNumber));
			results.add(sqlQuery.list());
			if (results.size() == 2) {
				if (!results.get(0).toString().isEmpty() && !results.get(1).toString().isEmpty() && results.get(0) != null && results.get(1) != null) {

					// Status = "Success";
					logger.info("Inside Nav service  :: Select Query  :: SUCCESS :: ENDS");
					return results;
				}
			} else {
				logger.info("Policy Id is not valid =: " + policyNumber);
				return null;
			}
		} catch (Exception e) {
			logger.error("Error while calling Select Nav Query : " + e);
		}
		logger.info("Inside getNav Details :: select query :- :: End");
		return null;
	}

	@Override
	public List<Map> illustrationDao(String policyNumber) {
		logger.info("Inside Get Nav service  :: Method Execution :: Start");
		String status = "";
		String StrImageByteArray = "";
		int count = 20;
		StringBuilder fundvalueupper = new StringBuilder();
		StringBuilder fundvaluelower = new StringBuilder();
		List<Map> result = new ArrayList<Map>();
		try {
			SQLQuery sqlQuery = getSession().createSQLQuery("SELECT DOC_PRM_XML FROM TDOCFUNDVALUEDATA WHERE DOC_REC_ID =:DOC_REC_ID");
			sqlQuery.setParameter("DOC_REC_ID", policyNumber);

			sqlQuery.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP);
			List statusRes = sqlQuery.list();
			if (statusRes != null) {
				for (Object object : statusRes) {
					Map row = (Map) object;
					java.sql.Clob clobValue = (java.sql.Clob) row.get("DOC_PRM_XML");
					status = clobValue.getSubString(1, (int) clobValue.length());
				}
			}

			if (!status.isEmpty()) {
				JSONObject xmlJSONObj = XML.toJSONObject(status);
				String jsonPrettyPrintString = xmlJSONObj.toString(4);
				Map requestData = Commons.getGsonData(jsonPrettyPrintString);
				Map fundValue = (Map) requestData.get("FUNDVALUE");
				Map FVBLME10 = (Map) fundValue.get("FVBLME10");
				Map FVBLME06 = (Map) fundValue.get("FVBLME06");

				//
				result.add(FVBLME10);
				result.add(FVBLME06);
			}
			return result;
		} catch (Exception e) {
			logger.error("Error while calling Select Nav Query : " + e);
		}
		logger.info("Inside getNav Details :: select query :- :: End");
		return null;
	}
}
