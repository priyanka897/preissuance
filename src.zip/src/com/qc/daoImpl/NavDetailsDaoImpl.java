package com.qc.daoImpl;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.jdbc.Work;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.response.current.nav.ResCurrentNav;
import com.qc.api.response.fund.ResFundName;
import com.qc.api.response.nav.ResNav;
import com.qc.api.response.plan.ResPlanName;
import com.qc.dao.FundDao;
import com.qc.dao.FundNavDao;
import com.qc.entity.PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS;
import com.qc.entity.PR_GETAGNTINFO_TPP_NAV_DTLS;

@Repository
@Transactional
public class NavDetailsDaoImpl implements FundNavDao
{
	private static Logger logger = LogManager.getLogger(NavDetailsDaoImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private  LocalSessionFactoryBean sessionFactory;
	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}

	@Override
	public List<Object[]>  getFundDetails()
	{  
		
		logger.info("navdetails :: NavDetailsDaoImpl :: getFundDetails : Start");
		try 
		{  
			logger.info("navdetails :: NavDetailsDaoImpl ::getFundDetails :: PROC :: Start" );
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
			   ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_FUND_NAME");
		       call.registerParameter(1, Class.class,ParameterMode.REF_CURSOR);
		       Output output = call.getOutputs().getCurrent();
		       getSession().getTransaction().commit();
		       if (output.isResultSet()) 
				{
					List<Object[]> result = ((ResultSetOutput) output).getResultList();
					logger.info("navdetails :: NavDetailsDaoImpl ::getFundDetails :: PROC ::Success: End" );
					return result;
				}
		}
		catch (Exception e)
		{
			logger.error("creating Exception  navdetails :: NavDetailsDaoImpl :: getFundDetails : " + e);
		}
		logger.info("navdetails :: NavDetailsDaoImpl :: getFundDetails : End");
		return null;
	}
	
	@Override
	public List<Object[]> getPlanDetails()
	{  
		logger.info("navdetails :: NavDetailsDaoImpl :: getPlanDetails : Start");
		try 
		{  
			logger.info("navdetails :: NavDetailsDaoImpl ::getPlanDetails :: PROC :: Start" );
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
		    ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_PLAN_NAME");
	       call.registerParameter(1, Class.class,ParameterMode.REF_CURSOR);
	       Output output = call.getOutputs().getCurrent();
	       getSession().getTransaction().commit();
	       if (output.isResultSet()) 
	       {
		   List<Object[]> result = ((ResultSetOutput) output).getResultList();
		   logger.info("navdetails :: NavDetailsDaoImpl ::getPlanDetails :: PROC :: Success: End" );
		   return result;
	       }
		}
		catch (Exception e)
		{
			logger.error("creating Exception  navdetails :: NavDetailsDaoImpl :: getPlanDetails : " + e);
		}
		logger.info("Inside Planname DaoImpl :: Method Execution :: End");
		return null;
	}


	@Override
	public List<Object[]> getNavDetails(PR_GETAGNTINFO_TPP_NAV_DTLS req) {
		
				logger.info("Inside Get Nav DaoImpl  :: Method Execution :: Start");
				try 
				{
				logger.info("navdetails :: NavDetailsDaoImpl ::getNavDetails :: PROC :: Start");
				getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
				getSession().getTransaction().begin();
			    ProcedureCall call = getSession().createStoredProcedureCall("GET_NAV_DTLS_SOA");
				call.registerParameter(1, String.class,ParameterMode.IN).bindValue(req.getPlanName());
				call.registerParameter(2, Class.class,ParameterMode.REF_CURSOR);
				Output output = call.getOutputs().getCurrent();
				getSession().getTransaction().commit();
				if (output.isResultSet()) 
				{
					List<Object[]> result = ((ResultSetOutput) output).getResultList();
					logger.info("navdetails :: NavDetailsDaoImpl ::getNavDetails :: PROC :: Success :End" );
					return result;
				}
				}
				catch (Exception e)
				{
					logger.error("creating Exception  navdetails :: NavDetailsDaoImpl :: getNavDetails : " + e);
				}
				logger.info("Inside get Nav DaoImpl ::  Method Execution:- :: End");
				return null;
	}


	@Override
	public List<Object[]> getCurrentNavDetails(PR_GETAGNTINFO_TPP_CURRENT_NAV_DTLS req) {
		
		logger.info("Inside CurrentNav DaoImpl  :: Method Execution :: Start");
		try 
		{  
			logger.info("navdetails :: NavDetailsDaoImpl ::getCurrentNavDetails :: PROC :: Start" );
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession().getTransaction().begin();
		ProcedureCall call = getSession().createStoredProcedureCall("GET_PLAN_FUND_DTLS_SOA");
		call.registerParameter(1, String.class,ParameterMode.IN).bindValue(req.getPlanCode());
		call.registerParameter(2, String.class,ParameterMode.IN).bindValue(req.getNavFromDate());
		call.registerParameter(3, String.class,ParameterMode.IN).bindValue(req.getNavToDate());
		call.registerParameter(4, String.class,ParameterMode.IN).bindValue(req.getPlanName());
		call.registerParameter(5, Class.class,ParameterMode.REF_CURSOR);
		Output output = call.getOutputs().getCurrent();
		getSession().getTransaction().commit();
		if (output.isResultSet()) 
		{
			List<Object[]> result = ((ResultSetOutput) output).getResultList();
			logger.info("navdetails :: NavDetailsDaoImpl ::getCurrentNavDetails :: PROC ::Success : End" );
			return result;
		}
		}
		catch (Exception e)
		{
			logger.error("creating Exception  navdetails :: NavDetailsDaoImpl :: getCurrentNavDetails : " + e);
		}
		logger.info("navdetails :: NavDetailsDaoImpl :: getPlanDetails : Start");
		return null;
}	
}
