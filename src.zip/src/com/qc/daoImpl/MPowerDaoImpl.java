package com.qc.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.dao.MPowerDao;
import com.qc.entity.PR_COUNTOFNOTIFICATION_DTLS;




@Repository
@Transactional
public class MPowerDaoImpl implements MPowerDao{

	private static Logger logger = LogManager.getLogger(MPowerDaoImpl.class);

	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory5")
	private  LocalSessionFactoryBean sessionFactory;

	protected  Session getSession() 
	{
		return sessionFactory.getObject().getCurrentSession();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> countOfNotificationService(PR_COUNTOFNOTIFICATION_DTLS req) {
		
		logger.info("Inside countOfNotificationService Dao  :: Method Execution :: Start");
		 List result = null;
				try 
				{
					logger.info("Inside countOfNotificationService :: PROC :- PR_NOTIFICATION_COUNT :: STARTS" );
					getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
					getSession().getTransaction().begin();
					ProcedureCall call = getSession().createStoredProcedureCall("PR_NOTIFICATION_COUNT");
					call.registerParameter(1, String.class,ParameterMode.IN).bindValue(req.getUserId());
					call.registerParameter(2, Class.class,ParameterMode.REF_CURSOR); 
					//call.setTimeout(30);
					Output output = call.getOutputs().getCurrent();
					getSession().getTransaction().commit();
					if (output.isResultSet()) 
					{
						result = ((ResultSetOutput) output).getResultList();
					    logger.info("OutSide countOfNotificationService :: PROC :- PR_NOTIFICATION_COUNT :: SUCCESS with result:: " + result );
					}
				}
				catch (Exception e)
				{
					result =new ArrayList();
				    if("transaction timeout expired".contains(e.getMessage()))
				    {
				    	logger.info("connection time out "+e.getMessage() );
				    	result.add("transaction timeout expired");
				    }
					logger.error("Error while calling Select countOfNotificationService Query : " + e);
				}
		logger.info("Inside countOfNotificationService Dao :: select query :- :: End");
		return result;
	}
	
}
