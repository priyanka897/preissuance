package com.qc.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;

import com.qc.api.request.abbreviation.AbbreviationRequest;
import com.qc.api.request.abbreviation.Abbs;
import com.qc.api.response.abbreviation.AbbAllTransactions;
import com.qc.api.response.abbreviation.AbbGetTransactions;
import com.qc.dao.AbbsJdbcDao;

@Repository
@Transactional
public class AbbsJdbcDaoImpl implements AbbsJdbcDao {

	private static Logger logger = LogManager.getLogger(AbbsJdbcDaoImpl.class);
	
	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory5")
	private LocalSessionFactoryBean hibernateSessionFactory5;

	protected Session getSession() {
		return hibernateSessionFactory5.getObject().getCurrentSession();
	}

	@Override
	public String addAbbreviationDao(AbbreviationRequest abbreviationRequest)
	{
		logger.info("Inside EAppDaoImpl --->AddAbbreviationDao ::Processing STARTS");
		StringBuilder script = new StringBuilder();
		String result="";
		int resultSet = 0;
		try 
		{
			String ssoid=abbreviationRequest.getSsoid();
			String shrtform=abbreviationRequest.getShortform().toUpperCase();
			String fullform=abbreviationRequest.getFullform();
			String description=abbreviationRequest.getDescription();
			String department=abbreviationRequest.getDepartment();
			
			script.append("Insert into GET_ABBREVIATION (SHORT_FORM,FULL_FORM,");
			script.append("DESCRIPTION,DEPARTMENT,DTCREATED,CREATEDBY,DTUPDATED,");
			script.append("UPDATEDBY,SN) values (:short_form,:full_form,");
			script.append(":description,:department,SYSDATE,:createdby,null,null,");
			script.append("ADD_ABBREVIATION.nextval)");
			
			SQLQuery sqlQuery = getSession().createSQLQuery(script.toString());
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			sqlQuery.setParameter("short_form", shrtform);
			sqlQuery.setParameter("full_form", fullform);
			sqlQuery.setParameter("description", description);
			sqlQuery.setParameter("department", department);
			sqlQuery.setParameter("createdby", ssoid);
			resultSet = sqlQuery.executeUpdate();
				if (resultSet > 0) 
				{
					result = "SUCCESS";
				} 
		} 
		catch (Exception e) 
		{
			logger.error("AddAbbreviationDao--> Error Occured connecting Database!::" + e);
		}
		logger.info("Inside EAppDaoImpl --->AddAbbreviationDao ::Processing ENDS");
		return result;
	}

	@Override
	public List<AbbGetTransactions> getAbbreviationDao(String shrtform) 
	{
		logger.info("Inside EAppDaoImpl --->getAbbreviationDao ::Processing STARTS");
		StringBuilder script = new StringBuilder();
		List<AbbGetTransactions> list=new ArrayList<>();
		AbbGetTransactions resList=null;
		try 
		{
			script.append(" Select short_form, full_form, description,department ");
			script.append("from GET_ABBREVIATION where upper(short_form) like :shortform ");
			
			SQLQuery sqlQuery;
			sqlQuery = getSession().createSQLQuery(script.toString());
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			sqlQuery.setParameter("shortform", shrtform.toUpperCase()+"%");
			List<Object[]> rows = sqlQuery.list();
			for (Object[] objects : rows) {
				resList=new AbbGetTransactions();
				resList.setShortform(objects[0] + "");
				resList.setFullform(objects[1] + "");
				resList.setDescription(objects[2] + "");
				resList.setDepartment(objects[3] + "");
				list.add(resList);	
			}
		} 
		catch (Exception e)
		{
			logger.error("getAbbreviationDao--> Error Occured connecting Database!::" + e);
		} 
		logger.info("Inside EAppDaoImpl --->getAbbreviationDao ::Processing ENDS");
		return list;

	}


	@Override
	public List<AbbAllTransactions> allAbbreviationDao() {
		logger.info("Inside EAppDaoImpl --->allAbbreviationDao ::Processing STARTS");
		StringBuilder script = new StringBuilder();
		List<AbbGetTransactions> list=new ArrayList<>();
		List<AbbAllTransactions> allAbbList=new ArrayList<>();
		AbbAllTransactions allAbbRes=null;
		AbbGetTransactions resList=null;
		int i=0;
		String count="";
		try 
		{
			script.append(" Select short_form, full_form, description,");
			script.append("department from GET_ABBREVIATION");
			
			SQLQuery sqlQuery;
			sqlQuery = getSession().createSQLQuery(script.toString());
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			List<Object[]> rows = sqlQuery.list();
			for (Object[] objects : rows) {
				resList=new AbbGetTransactions();
				resList.setShortform(objects[0] + "");
				resList.setFullform(objects[1] + "");
				resList.setDescription(objects[2] + "");
				resList.setDepartment(objects[3] + "");
				list.add(resList);	
			}
				count=""+i;
				allAbbRes=new AbbAllTransactions();
				allAbbRes.setCount(count);
				allAbbRes.setAbbsData(list);
				allAbbList.add(allAbbRes);
		} 
		catch (Exception e)
		{
			logger.error("allAbbreviationDao--> Error Occured connecting Database!::" + e);
		} 
		logger.info("Inside AbbsJdbcDaoImpl --->allAbbreviationDao ::Processing ENDS");
		return allAbbList;
	}

	@Override
	public List<Abbs> searchAbbreviationDao(String shrtform) {
		logger.info("Inside EAppDaoImpl --->searchAbbreviationDao ::Processing STARTS");
		StringBuilder script = new StringBuilder();
		List<Abbs> list=new ArrayList<>();
		Abbs resList=null;
		try 
		{
			script.append(" Select sn,short_form, full_form,department from ");
			script.append("GET_ABBREVIATION where upper(short_form) like :shortform");	
				
				SQLQuery sqlQuery;
				sqlQuery = getSession().createSQLQuery(script.toString());
				sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
				sqlQuery.setParameter("shortform", shrtform.toUpperCase()+"%");
				List<Object[]> rows = sqlQuery.list();
				for (Object[] objects : rows) {
					resList=new Abbs();
					resList.setSn(objects[0] + "");
					resList.setShortform(objects[1] + "");
					resList.setFullform(objects[2] + "");
					resList.setDepartment(objects[3] + "");
					list.add(resList);	
				}
		} 
		catch (Exception e)
		{
			logger.error("searchAbbreviationDao--> Error Occured connecting Database!::" + e);
		} 
		logger.info("Inside EAppDaoImpl --->searchAbbreviationDao ::Processing ENDS");
		return list;
	}

	@Override
	public String deleteAbbreviationDao(String sn) {
		logger.info("Inside AbbsJdbcDaoImpl --->deleteAbbreviationDao ::Processing STARTS");
		String script = " ";
		int status=0;
		String message="";
		try 
		{
			script = "DELETE FROM GET_ABBREVIATION WHERE SN=:sn";
			SQLQuery sqlQuery = getSession().createSQLQuery(script);
			sqlQuery.setTimeout(Integer.parseInt(env.getProperty("query.timeout.time")));
			sqlQuery.setParameter("sn", sn);
			status = sqlQuery.executeUpdate();
				if (status > 0) 
				{
					message = "SUCCESS";
				}
		} 
		catch (Exception e)
		{
			message="Error Occured connecting Database";
			logger.error("deleteAbbreviationDao--> Error Occured connecting Database!::" + e);
		} 
		logger.info("Inside AbbsJdbcDaoImpl --->deleteAbbreviationDao ::Processing ENDS");
		return message;
	}
	

}
