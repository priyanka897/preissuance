package com.qc.daoImpl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.request.getneopincodecity.ApiRequestNeoPincodeCity;
import com.qc.dao.NeoDao;

@Repository
@Transactional
public class NeoDaoImpl implements NeoDao {

	private static final Logger logger = LogManager.getLogger(NeoDaoImpl.class);
	
	@Autowired
	Environment env;
	
	@Autowired
	@Qualifier("hibernateSessionFactory6")
	private LocalSessionFactoryBean sessionFactory6;
	
	protected Session getSession6() {
		return sessionFactory6.getObject().getCurrentSession();
	}
	
	
	//for production testing neo 2.0 after testing this remove and pointing will be gbhastl
	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private LocalSessionFactoryBean sessionFactory2;
	
	protected Session getSession2() {
		return sessionFactory2.getObject().getCurrentSession();
	}

	@Override
	public List<Object[]> callPincodeDetails(ApiRequestNeoPincodeCity apiRequest) {
	
		logger.info("Inside NeoDaoImpl :: PROC :- callPincodeDetails :: STARTS" );
		
		List result = null;
		try{
		String pincode = apiRequest.getRequest().getPayload().getPincode();
		List<String> policyNos = apiRequest.getRequest().getPayload().getProductCode();
		String policy="";
		for(int i=0; i<policyNos.size();i++)
		{
			if(i==0){
				policy=policyNos.get(i);
			}else{
				policy=policy +"," + policyNos.get(i);}
		}
		
		getSession6().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
		getSession6().getTransaction().begin();
		ProcedureCall call = getSession6().createStoredProcedureCall("PR_GET_PIN_PLAN_DTLS");
		call.registerParameter(1, String.class,ParameterMode.IN).bindValue(pincode);
		call.registerParameter(2, String.class,ParameterMode.IN).bindValue(policy);
		call.registerParameter(3, Class.class,ParameterMode.REF_CURSOR);
		Output output = call.getOutputs().getCurrent();
		getSession6().getTransaction().commit();
		if (output.isResultSet()) 
		{
			result = ((ResultSetOutput) output).getResultList();
			logger.info("Outside NeoDaoImpl :: PROC :- callPincodeDetails :: SUCCESS :: ENDS" );
			return result;
		}
		}catch(Exception e){
			result =new ArrayList();
		    if("transaction timeout expired".contains(e.getMessage()))
		    {
		    	// Added by vinay
		    	logger.error("connection time out "+e.getMessage() );
		    	result.add("transaction timeout expired");
		    }
			logger.error("Error while calling Select callPincodeDetails Query : " + e);
		}
		logger.info("Outside NeoDaoImpl :: PROC :- callPincodeDetails :: END" );
		return result;
	}
	
	@Override
	public List<Object[]> callNeftdetails(ApiRequestNeftDetails apiRequest) {
		logger.info("Inside NeoDaoImpl :: PROC :- callNeftdetails :: STARTS" );
		List result = null;
		try{
			String policyNo = apiRequest.getRequest().getPayload().getPolicyNo();
			
			/*getSession6().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession6().getTransaction().begin();
			ProcedureCall call = getSession6().createStoredProcedureCall("PR_SOA_POL_NEFT_DETAILS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue(policyNo);
			call.registerParameter(2, Class.class,ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			getSession6().getTransaction().commit();*/
			
			
			//for production testing neo 2.0 after testing this remove and pointing will be gbhastl
			getSession2().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			getSession2().getTransaction().begin();
			ProcedureCall call = getSession2().createStoredProcedureCall("PR_SOA_POL_NEFT_DETAILS");
			call.registerParameter(1, String.class,ParameterMode.IN).bindValue(policyNo);
			call.registerParameter(2, Class.class,ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			getSession2().getTransaction().commit();
			if (output.isResultSet()) 
			{
				result = ((ResultSetOutput) output).getResultList();
				logger.info("Outside NeoDaoImpl :: PROC :- callNeftdetails :: SUCCESS :: ENDS" );
				return result;
			}
		}catch(Exception e){
			result =new ArrayList();
		    if("transaction timeout expired".contains(e.getMessage()))
		    {
		    	// Added by vinay
		    	logger.error("connection time out "+e.getMessage() );
		    	result.add("transaction timeout expired");
		    }
			logger.error("Error while calling Select callNeftdetails Query : " + e);
		}
		logger.info("Outside NeoDaoImpl :: PROC :- callNeftdetails :: END" );
		return result;
	}

}
