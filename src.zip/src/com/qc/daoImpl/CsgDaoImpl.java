package com.qc.daoImpl;

import java.util.List;

import javax.persistence.ParameterMode;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.procedure.ProcedureCall;
import org.hibernate.result.Output;
import org.hibernate.result.ResultSetOutput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.createNotification.ApiRequestCreateNotification;
import com.qc.api.request.csg.listOfNotificationV2.ApiRequestListOfNotificationV2;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.csg.updateNotification.ApiRequestUpdateNotification;
import com.qc.api.request.csg.updateNotificationReadStatus.ApiRequestUpdateNotificationReadStatus;
import com.qc.dao.CsgDao;

@Repository
@Transactional
public class CsgDaoImpl implements CsgDao {
	private static Logger logger = LogManager.getLogger(CsgDaoImpl.class);
	@Autowired
	Environment env;

	@Autowired
	@Qualifier("hibernateSessionFactory2")
	private LocalSessionFactoryBean sessionFactory;

	protected Session getSession() {
		return sessionFactory.getObject().getCurrentSession();
	}

	@SuppressWarnings("unchecked")

	@Override
	public List<Object[]> getNotificationSearch(ApiRequestNotificationSearch apirequestnotificationsearch) {

		logger.info("Inside getNotificationSearch Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		try {
			logger.info("Inside getNotificationSearch :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apirequestnotificationsearch.getRequest().getPayload().getFromDate());
			call.registerParameter(2, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				logger.info("OutSide getNotificationSearch :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select notificationsearch Query : " + e);
		}
		logger.info("Inside getNotificationSearch Dao :: select query :- :: End");
		return result;
	}

	@Override
	public String createNotification(ApiRequestCreateNotification apireq) {
		logger.info("Inside createNotificationSearch Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		String id = null;
		try {
			logger.info("Inside createNotificationSearch :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getStatus());
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(3, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getType());
			call.registerParameter(4, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(5, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getNotification().get(0).getDetails());
			call.registerParameter(6, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				id = result.get(0).toString();
				logger.info("OutSide createNotificationSearch :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select createNotificationSearch Query : " + e);
		}
		logger.info("Inside createNotificationSearch Dao :: select query :- :: End");
		return id;
	}

	@Override
	public List<Object[]> notificationDetails(ApiRequestNotificationDetails apireq) {
		logger.info("Inside getNotificationSearch Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		String id = null;
		try {
			logger.info("Inside notificationDetails :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getId());
			call.registerParameter(3, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				logger.info("OutSide notificationDetails :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select notificationDetails Query : " + e);
		}
		logger.info("Inside notificationDetails Dao :: select query :- :: End");
		return result;
	}

	@Override
	public List<Object[]> listOfNotificationsV2(ApiRequestListOfNotificationV2 apireq) {
		logger.info("Inside getNotificationSearch Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		String id = null;
		try {
			logger.info("Inside listOfNotificationsV2 :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAgentId());
			call.registerParameter(3, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				logger.info("OutSide listOfNotificationsV2 :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select listOfNotificationsV2 Query : " + e);
		}
		logger.info("Inside listOfNotificationsV2 Dao :: select query :- :: End");
		return result;
	}

	@Override
	public String updateNotificationReadStatus(ApiRequestUpdateNotificationReadStatus apireq) {
		logger.info("Inside updateNotificationReadStatus Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		String id = null;
		try {
			logger.info("Inside updateNotificationReadStatus :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAgentId());
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(3, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getId());
			call.registerParameter(4, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				id = result.get(0).toString();
				logger.info("OutSide updateNotificationReadStatus :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select updateNotificationReadStatus Query : " + e);
		}
		logger.info("Inside updateNotificationReadStatus Dao :: select query :- :: End");
		return id;
	}

	@Override
	public String updateNotification(ApiRequestUpdateNotification apireq) {
		logger.info("Inside updateNotification Dao  :: Method Execution :: Start");
		@SuppressWarnings("unchecked")
		List<Object[]> result = null;
		String id = null;
		try {
			logger.info("Inside updateNotification :: PROC :- PR_SOA_ALL_STATWEWISE :: STARTS");
			getSession().getTransaction().setTimeout(Integer.valueOf(env.getProperty("query.timeout.time")));
			ProcedureCall call = getSession().createStoredProcedureCall("PR_SOA_ALL_STATWEWISE");
			call.registerParameter(1, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getAppId());
			call.registerParameter(2, String.class, ParameterMode.IN).bindValue(apireq.getRequest().getPayload().getId());
			call.registerParameter(3, Class.class, ParameterMode.REF_CURSOR);
			Output output = call.getOutputs().getCurrent();
			if (output.isResultSet()) {
				result = ((ResultSetOutput) output).getResultList();
				id = result.get(0).toString();
				logger.info("OutSide updateNotification :: PROC :- PR_SOA_CITY_INFO :: SUCCESS with result:: " + result);
			}
		} catch (Exception e) {
			logger.error("Error while calling Select updateNotification Query : " + e);
		}
		logger.info("Inside updateNotification Dao :: select query :- :: End");
		return id;
	}
}
