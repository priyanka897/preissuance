package com.qc.service;

import java.util.Map;

public interface CommonService 
{
	public String getOtpResponse();
	public Map<String,String> getMapFromStringJson(String otpResponseJson);
}
