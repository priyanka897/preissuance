package com.qc.service;

import com.qc.api.request.eKudos.OtpApiRequest;
import com.qc.api.response.eKudos.OtpApiResponse;


public interface AadhaarServiceOtp 
{
    public OtpApiResponse otpService(OtpApiRequest otpApiRequest);
    
}
