package com.qc.service;

import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.request.navservices.ApiUpdateRequestNav;
import com.qc.api.request.updateNavAlert.ApiUpdateRequestSetNav;
import com.qc.api.response.getNav.ApiResponseGetNavDetails;
import com.qc.api.response.illustration.ApiResponseIllustration;
import com.qc.api.response.updateNavAlert.ApiUpdateResponseSetNav;


public interface NavService 
{
	public com.qc.api.response.navservices.ApiResponseNav getNavDetails(ApiRequestNav apiRequest);
	public com.qc.api.response.navservices.ApiUpdateResponseNav getUpdateNavDetails(ApiUpdateRequestNav apiRequest);
	public ApiUpdateResponseSetNav getUpdateNavAlert(ApiUpdateRequestSetNav apiRequest);
	public boolean checkValidPolicyNumber(String policyNum);
	public ApiResponseGetNavDetails getNavPolicyDetails(String policyNumber);
	public ApiResponseIllustration getIllustration(String policyNumber);
}
