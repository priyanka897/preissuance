package com.qc.service;

import com.qc.api.request.getcities.ApiRequestGetCities;
import com.qc.api.request.getcountry.ApiRequestGetCountry;
import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.response.getcities.ApiResponseGetCities;
import com.qc.api.response.getcountry.ApiResponseGetCountry;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;

public interface GetCountryService 
{
	public ApiResponseGetCountry getCountryDetails(ApiRequestGetCountry apiRequest);
	
}
