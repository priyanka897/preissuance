package com.qc.service;

import com.qc.api.request.eKudos.eKudosApiRequest;
import com.qc.api.response.eKudos.eKudosApiResponse;


public interface eKudosService 
{
    public eKudosApiResponse eKudosServicepoints(eKudosApiRequest ekudosApiRequest);
    public eKudosApiResponse geteKudospoints(eKudosApiRequest ekudosApiRequest);
    
}
