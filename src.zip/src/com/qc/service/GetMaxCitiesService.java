package com.qc.service;

import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;

public interface GetMaxCitiesService 
{
	public ApiResponseGetMaxCities getMaxCitiesDetails(ApiRequestGetMaxCities apiRequest);
	
}
