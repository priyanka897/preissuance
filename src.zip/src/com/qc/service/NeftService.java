package com.qc.service;

import org.springframework.stereotype.Service;

import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.response.getneftdetails.ApiResponseNeftDetails;

@Service
public interface NeftService {

	public ApiResponseNeftDetails getNeftdetails(ApiRequestNeftDetails apiRequest);
}
