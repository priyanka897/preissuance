package com.qc.service;

import com.qc.api.request.getplanname.ApiRequestGetPlan;
import com.qc.api.response.getplanname.ApiResponseGetPlan;

public interface GetPlanService {

	public ApiResponseGetPlan getPlanDetails(ApiRequestGetPlan apiRequest);
	
}
