package com.qc.service;

import java.util.List;

import com.qc.api.request.abbreviation.Abbs;
import com.qc.api.request.abbreviation.ApiRequest;
import com.qc.api.response.abbreviation.ApiResponse;


public interface AbbsJdbcService {

	public com.qc.api.response.abbreviation.ApiResponse getAbbService(ApiRequest apiRequest);
	public ApiResponse addAbbService(com.qc.api.request.abbreviation.ApiRequest apiRequest);
	public ApiResponse allAbbService(ApiRequest apiRequest);
	public List<Abbs> serachService(String short_form);
	public String deletesService(String sn);
}
