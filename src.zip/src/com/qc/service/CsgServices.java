package com.qc.service;

import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.createNotification.ApiRequestCreateNotification;
import com.qc.api.request.csg.listOfNotificationV2.ApiRequestListOfNotificationV2;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.csg.updateNotification.ApiRequestUpdateNotification;
import com.qc.api.request.csg.updateNotificationReadStatus.ApiRequestUpdateNotificationReadStatus;
import com.qc.api.response.csg.NotificationDetail.ApiResponseNotificationDetails;
import com.qc.api.response.csg.createNotification.ApiResponseCreateNotification;
import com.qc.api.response.csg.listOfNotificationV2.ApiResponselistOfNotificationV2;
import com.qc.api.response.csg.notificationsearch.ApiResponseNotificationSearch;
import com.qc.api.response.csg.updateNotification.ApiResponseUpdateNotification;
import com.qc.api.response.csg.updateNotificationReadStatus.ApiResponseUpdateNotificationReadStatus;

public interface CsgServices {
	
	public ApiResponseNotificationSearch getNotificationSearch(ApiRequestNotificationSearch apiRequest);
	public ApiResponseCreateNotification createNotificationSearch(ApiRequestCreateNotification apiRequest);
	public ApiResponseNotificationDetails notificationDetails(ApiRequestNotificationDetails apiRequest);
	public ApiResponselistOfNotificationV2 listOfNotificationsV2(ApiRequestListOfNotificationV2 apiRequest);
	public ApiResponseUpdateNotificationReadStatus updateNotificationReadStatus(ApiRequestUpdateNotificationReadStatus apiRequest);
	public ApiResponseUpdateNotification updateNotification(ApiRequestUpdateNotification apiRequest);

}
