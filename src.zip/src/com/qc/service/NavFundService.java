package com.qc.service;

import com.qc.api.request.current.nav.ApiRequestCurrentNav;

import com.qc.api.request.fund.ApiRequestFundName;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.request.plan.ApiRequestPlanName;
import com.qc.api.response.current.nav.ApiResponseCurrentNavDetails;
import com.qc.api.response.fund.ApiResponseFundName;
import com.qc.api.response.nav.ApiResponseNavDetails;
import com.qc.api.response.plan.ApiResponsePlanName;

public interface NavFundService 
{
	public ApiResponseFundName getFundDetails(ApiRequestFundName apiRequest);
	public ApiResponseNavDetails getNavDetails(ApiRequestNav apiRequest);
	public ApiResponsePlanName getPlanDetails(ApiRequestPlanName apiRequest);
	public ApiResponseCurrentNavDetails getCurrentNavDetails(ApiRequestCurrentNav apiRequest);
	

}
