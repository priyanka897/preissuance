package com.qc.service;

import com.qc.api.request.countofnotification.ApiRequestCountOfNotification;
import com.qc.api.response.countofnotification.ApiResponseCountOfNotification;

public interface MPowerService {

	public ApiResponseCountOfNotification countOfNotification(ApiRequestCountOfNotification apiRequest);
}
