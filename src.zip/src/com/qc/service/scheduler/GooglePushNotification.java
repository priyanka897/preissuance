package com.qc.service.scheduler;

import java.io.File;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.ResourceBundle;


import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Sender;
import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class GooglePushNotification {
//	static Logger logger = LogManager.getLogger(GooglePushNotification.class.getName());
//
//
//	static  ResourceBundle rs = ResourceBundle.getBundle("com.qc.resource.application");
//	static  String  certificate	= rs.getString("ios_certificate");
//	static  String  pass   	    = rs.getString("ios_certificate.password");
//
//
//	public static void main(String[] args) {
//
//
//		/*String deviceID="dOqmGZZQkXw:APA91bFgOanrlFRpt6lXZa92sACPYVbB3cnyfgSzd_oJevn0F4fdgwtz9FmSzcQkgwNTc1KxV-kaV0vr2W7bE1IVH5m8jvBGgwZY0Q2U_mp9B5TvoUSBv4u4K0DuSkhUbWMb0tHdNVk6";
//		String msg="This is final testing";
//		String senderID="AIzaSyC8ma3hzobs1D9yTF4lZVKQovutHZpT3-Q";
//		 */
//		//String res= sendNotification(deviceID, msg,senderID,"1");
//		//String res= sendNotificationIOS(deviceID, msg, senderID, "1");
//
//		//System.out.println(res);
//
//		/*//SERVER ID
//        final String SENDER_ID = "AIzaSyC8ma3hzobs1D9yTF4lZVKQovutHZpT3-Q";
//
//
//        //SAMPLE DEVICE REGISTRATION ID
//        final String SAMPLE_DEVICE_REG_ID = " dOqmGZZQkXw:APA91bFgOanrlFRpt6lXZa92sACPYVbB3cnyfgSzd_oJevn0F4fdgwtz9FmSzcQkgwNTc1KxV-kaV0vr2W7bE1IVH5m8jvBGgwZY0Q2U_mp9B5TvoUSBv4u4K0DuSkhUbWMb0tHdNVk6";
//
//        //LIST OF ALL DEVICES TO SEND NOTIFICATOINS TO
//        ArrayList<String> androidTargets = new ArrayList<String>();
//
//        //ADD FIRST DEVICE TO THE LIST
//        androidTargets.add(SAMPLE_DEVICE_REG_ID);
//
//        //SENDER OBJECT
//        Sender sender = new Sender(SENDER_ID);
//
//        //FORM THE PAYLOAD TO SEND
//        String collapseKey = "null";
//        String msg = "Testing seconddff";
//        String title = "title";
//        Message message = (new com.google.android.gcm.server.Message.Builder())
//                .collapseKey(collapseKey)
//                .timeToLive(30)
//                .delayWhileIdle(true)
//                .addData("message", msg)
//                .addData("title", title)
//                .build();
//
//        //SEND THE NOTIFICATION!
//        try 
//        {
//            MulticastResult result = sender.send(message, androidTargets, 1);
//            System.out.println( result );
//        }
//        catch (IOException e)
//        {
//            System.out.println("nothing");
//            e.printStackTrace();
//        }*/
//	}
//
//
//	public static  String sendNotification(String deviceID, String msg,String SenderID,String uniqueId)
//	{
//		logger.info("START: Send Notification to ANDROID ");
//		MulticastResult result=null;
//		String sendStatus="";
//		String title="empapp";
//		Sender sender=null;
//
//		try{
//			//SERVER ID
//			String SENDER_ID = SenderID;
//
//			//SAMPLE DEVICE REGISTRATION ID
//			final String SAMPLE_DEVICE_REG_ID = deviceID;
//
//			//LIST OF ALL DEVICES TO SEND NOTIFICATOINS TO
//			ArrayList<String> androidTargets = new ArrayList<String>();
//
//			//ADD FIRST DEVICE TO THE LIST
//			androidTargets.add(SAMPLE_DEVICE_REG_ID);
//
//			//SENDER OBJECT
//			try
//			{
//				sender = new Sender(SENDER_ID);
//			}
//			catch(Exception ex)
//			{
//				System.out.println("-------"+ex);
//			}
//
//			//FORM THE PAYLOAD TO SEND
//			Message message = (new com.google.android.gcm.server.Message.Builder())
//					.collapseKey("1")
//					.timeToLive(30)
//					.delayWhileIdle(true)
//					.addData("message", msg)
//					.addData("title", title)
//					.addData("notId", uniqueId)
//					.build(); 
//			//SEND THE NOTIFICATION!
//			logger.info("Send Notification title  "+title);
//			logger.info("Send Notification message  "+msg);
//			logger.info("Send Notification notId  "+uniqueId);
//			try 
//			{
//				//MulticastResult
//				result = sender.send(message, androidTargets, 1);
//				logger.info("Send Notification to Android Response Code:  "+result);
//				sendStatus = result!=null?"Android_Send_Notification : Pass : "+result.toString():"Android_Send_Notification : Failure : Null";
//			}
//			catch (IOException e)
//			{
//				sendStatus="Android_Send_Notification : Failure";
//				logger.error("Send Notification to Android Response Code:  "+result);
//			}
//		}catch(Exception e){
//			logger.error("Send Notification to Android Response Code:  "+e);
//			System.out.println(e);
//		}
//		return sendStatus;
//	}
//
//	public static  String sendNotificationIOS(String deviceID, String msg,String SenderID,String uniqueId){
//
//		logger.info("START: Send Notification to IOS ");
//		MulticastResult result=null;
//		String sendStatus="0";
//		ApnsService pushService = null;
//		String path     = certificate;
//		String password = pass;
//		int count=1;
//
//		try{
//			File certFile = new File(path);
//			InputStream fis = new FileInputStream(certFile);
//
//			if(rs.getString("isProd").equalsIgnoreCase("N"))
//			{
//				/***********  FOR UAT**************************/
//				pushService = APNS.newService().withCert(fis, password).withSandboxDestination().build();
//				sendStatus="1";
//			}
//			else
//			{
//				/***********  FOR PROD ************************/
//				pushService = APNS.newService().withCert(fis, password).withProductionDestination().build();
//				sendStatus="1";
//			}
//
//			/*** START UPDATE NOTIFICATION COUNT **/
//			logger.info("START: pushService Notification to IOS "+pushService);
//
//			count  = new EappAnalyticDaoImpl().updateNotificationCount(deviceID);
//
//			logger.info("NotificationService --> Update  Notification count res:"+deviceID);
//			/***** END UPDATE NOTIFICATION COUNT **/
//
//			logger.info("SET BADGE COUNT FOR IOS NOTIFICATION :"+count+" FOR :"+msg);
//
//			//String payload = APNS.newPayload().alertBody(msg).badge(count).sound("default").customField("content-available", 1).build();
//			String payload="{\"aps\":{\"badge\":"+count+",\"alert\":\""+msg+"\",\"sound\":\"default\",\"content-available\":\"1\"}}";
//
//			pushService.push(deviceID, payload);
//			logger.info("IOS SEND NOTIFICATION SUCCESSFULLY..");
//
//		}
//		catch (IOException e)
//		{
//			sendStatus="0";
//			logger.error("ERROR: IOS SEND NOTIFICATION "+e);
//		}
//
//		logger.info("END: Send Notification to IOS ");
//		return sendStatus;
//	}
//
//
//
//
}
