package com.qc.service;

import com.qc.api.request.getneopincodecity.ApiRequestNeoPincodeCity;

import com.qc.api.response.getneopincodecity.ApiResponseNeoPincodeCity;

public interface PincodeCityService {

	ApiResponseNeoPincodeCity getPincodeDetails(ApiRequestNeoPincodeCity apiRequest);
}
