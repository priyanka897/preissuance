package com.qc.service;

import com.qc.api.request.current.nav.ApiRequestCurrentNav;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.response.current.nav.ApiResponseCurrentNav;
import com.qc.api.response.fund.ApiResponseGAFundName;
import com.qc.api.response.nav.ApiResponseNav;
import com.qc.api.response.plan.ApiResponsePlanName;

public interface GanavFundService 
{
	public ApiResponseGAFundName getFundDetails();
	public ApiResponseNav getNavDetails(ApiRequestNav apiRequest);
	public ApiResponsePlanName getPlanDetails();
	public ApiResponseCurrentNav getCurrentNavDetails(ApiRequestCurrentNav apiRequest);
	

}
