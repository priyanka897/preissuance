package com.qc.service.mail;

import java.net.URL;
import java.util.Date;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.qc.mailservice.MailServiceInterface;
import com.qc.mailserviceImpl.MailWebServiceLocator;
import com.qc.utils.XTrustProvider;



public class MailSender {

	static ResourceBundle res=ResourceBundle.getBundle("application");
	final String SEND_MAIL_URL = res.getString("com.qc.mail.url");
	Gson gson = new Gson();
	private static Logger logger = LogManager.getLogger(MailSender.class);	
	
	static String sub ="IAU";
	public String[] sendMail(String mailcontent,String mailTo,String subject, String from)
	{
		String[] sendresponse=new String[2];
		logger.info("sendMail for IAU :: Start");
		logger.debug("Calling Mail Soap API :: Starts :: ");
		
		MailWebServiceLocator locator = new MailWebServiceLocator();
		com.qc.mailservice.Common common = new com.qc.mailservice.Common();
		com.qc.mailservice.Request request=new com.qc.mailservice.Request();
		try {
			URL url = new URL(SEND_MAIL_URL);
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			MailServiceInterface interfac1= locator.getMailService_Port(url);

			request.setMailIdTo(mailTo);
			logger.debug("Real User mail id :: "+ mailTo);

			request.setMailSubject(subject);
			request.setFromName("I Appreciate You");
			request.setFromEmail(from);
			request.setMailBody(mailcontent);
			common.setRequest(request);
			
			logger.debug("Sending MAIL to EmailId :: "+mailTo);
			logger.debug("Sending MAIL CONTENT ::  "+mailcontent);
			
			com.qc.mailservice.Common commonResponse=interfac1.generateMail(common);
			String status=commonResponse.getResponse().getStatusDescription();
			sendresponse[0]="SUCCESS";
			sendresponse[1]="Mail send successfully";
			logger.debug("Mail has been sent to ::"+mailTo);
			
		}catch(Exception e)
		{
			sendresponse[0]="FAILURE";
			sendresponse[1]=e.getMessage();
			logger.error("Exception in send mail ::"+e.getMessage());
			logger.error("Mail could not sent to ::"+mailTo);
		}
		logger.info("SendMailToRepresentedPerson :: Ends");
		

		return sendresponse;

	}
	public String[] sendMailBKP(String mailcontent,String mailTo,String subject, String from)
	{
		logger.info("Inside sendmail method");
		String strHost = res.getString("HOSTNAME");		
		String strFrom = from!=null && !from.isEmpty() ? from : res.getString("FROM"); 
		
		String[] sendresponse=new String[2];
		try{
			boolean BlSessionDebug = true;
			Properties props = System.getProperties();
			props.put("mail.host", strHost);
			props.put("mail.transport.protocol", "smtp");
			Session mailSession = Session.getDefaultInstance(props, null);
			mailSession.setDebug(BlSessionDebug);
			MimeMessage msg = new MimeMessage(mailSession);
			msg.setFrom(new InternetAddress(strFrom));		
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailTo));	
			msg.setSubject(subject);
			msg.setContent(mailcontent,"text/html");
			msg.setSentDate(new Date());
			logger.debug("Sending...");
			Transport.send(msg);
			sendresponse[0]="SUCCESS";
			sendresponse[1]="Mail send successfully";
			logger.debug("Mail has been sent to ::"+mailTo);
		}catch(Exception e)
		{
			sendresponse[0]="FAILURE";
			sendresponse[1]=e.getMessage();
			logger.error("Exception in send mail ::"+e.getMessage());
			logger.error("Mail could not sent to ::"+mailTo);
		}
		
		return sendresponse;
		
	}
	
	public String[] sendMailTest(String mailcontent,String mailTo,String subject)
	{
		logger.info("Inside sendmail method");
		String strHost = res.getString("HOSTNAME");		
		String strFrom =  res.getString("FROM"); 
		String[] sendresponse=new String[2];
		try{
			boolean BlSessionDebug = false;
			Properties props = System.getProperties();
			props.put("mail.host", strHost);
			props.put("mail.transport.protocol", "smtp");
			Session mailSession = Session.getDefaultInstance(props, null);
			mailSession.setDebug(BlSessionDebug);
			MimeMessage msg = new MimeMessage(mailSession);
			msg.setContent(mailcontent,"text/html");
			msg.setFrom(new InternetAddress(strFrom));		
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(mailTo));	
			//subject ="Test";
			msg.setSubject(subject);
			msg.setSentDate(new Date());
			logger.info("Sending...");
			Transport.send(msg);
			sendresponse[0]="SUCCESS";
			sendresponse[1]="Mail send successfully";
			logger.info("Mail has been sent to ::"+mailTo);
		}catch(Exception e)
		{
			sendresponse[0]="FAILURE";
			sendresponse[1]=e.getMessage();
			logger.error("Exception in send mail ::"+e.getMessage());
			logger.error("Mail could not sent to ::"+mailTo);
		}
		logger.info("Going outside sendmail method");
		return sendresponse;
		
		
		
	}

}
