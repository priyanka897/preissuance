package com.qc.service;

import com.qc.api.request.getallcities.ApiRequestGetAllCities;

import com.qc.api.response.getallcities.ApiResponseGetAllCities;

public interface GetAllCitiesService 
{
	public ApiResponseGetAllCities getAllCitiesDetails(ApiRequestGetAllCities apiRequest);
	
}
