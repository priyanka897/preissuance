package com.qc.service;

import com.qc.api.request.getstates.ApiRequestGetStates;
import com.qc.api.response.getstates.ApiResponseGetStates;

public interface GetStateService {

	public ApiResponseGetStates getStateDetails(ApiRequestGetStates apiRequest);
	
}
