package com.qc.service;

import com.qc.api.request.getaddress.ApiRequestGetAddress;
import com.qc.api.response.getaddress.ApiResponseGetAddress;

public interface GetAddressService {

	public ApiResponseGetAddress getAddressDetails(ApiRequestGetAddress apiRequest);
}
