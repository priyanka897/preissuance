package com.qc.service;

import com.qc.api.request.eCube.ChatbotPayloadRequest;
import com.qc.api.response.eCube.ChatbotApiResponse;

public interface ChatbotApiService {

	public ChatbotApiResponse getProceduresData(ChatbotPayloadRequest payload);
}
