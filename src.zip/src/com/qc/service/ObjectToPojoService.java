package com.qc.service;

import java.util.List;
import java.util.Map;

public interface ObjectToPojoService 
{
	public List<Map<String , String>> getCustomClass(List<Object[]> objectList);
}
