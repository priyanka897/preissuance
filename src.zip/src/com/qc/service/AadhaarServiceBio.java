package com.qc.service;

import com.qc.api.request.eKudos.BioApiRequest;
import com.qc.api.response.eKudos.BioApiResponse;


public interface AadhaarServiceBio 
{
    public BioApiResponse bioService(BioApiRequest bioApiRequest);
    
}
