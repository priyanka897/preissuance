package com.qc.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringUtility {

	public static String checkStringNullOrBlank(String s) {
		
		if (s != null && !s.equals("")) {
			return s.trim();
		} else {
			return "";
		}
	}
	
	
	public static boolean isValidFormat(String format, String value) {
        Date date = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            date = sdf.parse(value);
            if (!value.equals(sdf.format(date))) {
                date = null;
            }
        } catch (ParseException ex) {
        	return false;
        }
        return date != null;
    }
	
	public static String getOlderDate(){
		
		return "15-Aug-1947 11:28:32";
	}
}
