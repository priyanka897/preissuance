package com.qc.utils;

import java.net.HttpURLConnection;
import java.util.ResourceBundle;
import javax.net.ssl.HttpsURLConnection;
import javax.ws.rs.core.MediaType;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.net.URL;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;


public class CallWebservice
{

	static ResourceBundle  res= ResourceBundle.getBundle("application");
	private static Logger logger = LogManager.getLogger(CallWebservice.class);


	String pUrl= res.getString("URL");
	String mode= res.getString("MODE");

	String output = new String();
	StringBuilder result = new StringBuilder();

	HttpURLConnection conn = null;
	HttpsURLConnection con = null;


	public static void main(String[] args)
	{

		new CallWebservice().callWebservice("HOM1164","hello","shdkjfhkjsf97889sdf","IOS");

	}


	public String callWebservice(String ssoId, String msg, String deviceId,String deviceType)
	{
		logger.info("Start callWebservice method");
		XTrustProvider.install();
		URL url;
		String response="";
		String req="{\"sso_id\":\""+ssoId+"\", \"message\":\""+msg+"\",\"deviceId\":\""+deviceId+"\",\"deviceType\":\""+deviceType+"\"}";

		try 
		{
			url = new URL(pUrl);
			if(mode.equals("UAT"))
			{
				con =  (HttpsURLConnection) url.openConnection();
				conn= con;
			}
			else
			{
				conn =  (HttpURLConnection) url.openConnection();
			}
			logger.info("Push req :"+req);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", MediaType.APPLICATION_JSON);
			conn.setDoInput(true);
			conn.setDoOutput(true);			
			conn.setConnectTimeout(100000);

			OutputStream out = conn.getOutputStream();
			out.write(req.getBytes());
			out.flush();

			BufferedReader io = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			String output;

			while ((output = io.readLine()) != null) {
				response += output;
			}
			conn.disconnect();

			int apiResponseCode = conn.getResponseCode();

			if(apiResponseCode == 200){
				/*BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) {
					result.append(output);
				}
				conn.disconnect();
				br.close();*/
				logger.info("Response request for mail read :"+response.toString());
			}
			else
			{

				logger.info("Response request for mail read failed:"+response.toString());
			}

		} 
		catch (Exception e)
		{
			logger.error("Exception to send IAU notification :"+e);
		}

		return response.toString();
	}	
}
