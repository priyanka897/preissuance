package com.qc.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
//import org.apache.log4j.Logger;

import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ProtectMyPDF {
	
	static Logger logger = LogManager.getLogger(ProtectMyPDF.class.getName());
	static ResourceBundle res = ResourceBundle.getBundle("application");
	
	public static void main(String[] args) {
		int filesProccessed = 0;
		try {
			System.out.println("Started.....................");
			String protectedFileName = "";
			String existedFileName = "";
			String pass1 = res.getString("com.qualtech.pdf.pass1");
			String pass2 = "";
			//String emplid = ""; //String year = ""; String month = "";

		//	File srcFolder = new File(res.getString("com.qualtech.pdf.source"));
			File destFolder = new File(res.getString("com.qualtech.pdf.dest"));
			File srcFolder = new File(res.getString("com.qualtech.pdf.source"));
			
			//File[] fileList = srcFolder.listFiles();
			
			//for (File f : fileList) {
			//	protectedFileName = srcFolder.getName();
			//	existedFileName = srcFolder.getAbsolutePath();
			protectedFileName = "encryptedpdf";
				existedFileName = srcFolder+"\\abc.pdf";
				
				try{
					File file = new File(existedFileName);

					FileInputStream fis = new FileInputStream(file);
					//if(protectedFileName.contains("_")){
						logger.info("Valid file to process.......");
					//	emplid = protectedFileName.substring(0, protectedFileName.indexOf('_'));
						
					//	pass2 = getPassword(emplid);
						pass2 = "1234567";
					
						if(pass2.equalsIgnoreCase("EMPLOYEENOTFOUND")){
							//logger.info("Not an MLI employee. PDF can't be Protected for -> " + protectedFileName + " Employee Id: " + emplid);					
						}else{
							try{
							//if (srcFolder.isFile()) {
								encryptPdf(existedFileName, destFolder.toString() + "\\" + protectedFileName, pass1, pass2);
								//System.out.println("Processed for :: " + emplid);
								//logger.info("PDF Protected for -> " + protectedFileName + " Employee Id: " + emplid);
								//srcFolder.delete();
								filesProccessed++;
//							}else{
//								System.out.println("file not exist");
//							}
							}catch(Exception e){
								System.out.println(e);
							}
						}
						
						//emplid = "";					
					/*}else{
						logger.info("Not a valid file to process.......");
					}*/
				}catch(Exception ex){
					logger.error("Error occurred!!! File name: " + protectedFileName + " .... \n Error: " + ex);
				}
			//}
		} catch (Exception e) {
			logger.error("Some error occurred!!!.... \n Error: " + e);
		}
		
		System.out.println("Completed.....................");
		System.out.println("Files Processed :-> " + filesProccessed);
	}

	public static void encryptPdf(String src, String dest, String userPassword, String ownerPassword)
			throws DocumentException, IOException 
	{
		PdfReader reader = new PdfReader(src);
		PdfStamper stamper = new PdfStamper(reader, new FileOutputStream(dest));

		stamper.setEncryption(userPassword.getBytes(), ownerPassword.getBytes(), PdfWriter.ALLOW_PRINTING,
				PdfWriter.ENCRYPTION_AES_128 | PdfWriter.DO_NOT_ENCRYPT_METADATA);

		stamper.close();
		reader.close();
	}
	
	
	public static String getPassword(String EPLMID) throws SQLException{
		//logger.info("In ExecuteQuery getPassword.");
		
		//String GET_DATA = "SELECT LOWER(SUBSTR(REGEXP_REPLACE(FIRST_NAME || LAST_NAME, '[^0-9A-Za-z]', ''),1,4)) || TO_CHAR(BIRTHDATE, 'DDMMYYYY') AS PASSWORD FROM syadm.ps_z_mli_bd_pan_tbl where EMPLID=?";
		String GET_DATA = "SELECT LOWER(SUBSTR(REGEXP_REPLACE(FIRST_NAME || MIDDLE_NAME || LAST_NAME, '[^0-9A-Za-z]', ''),1,4)) || TO_CHAR(BIRTHDATE, 'DDMMYYYY') AS PASSWORD FROM syadm.PS_Z_MLI_BD_PAN_VW where EMPLID=?";
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		String password = "EMPLOYEENOTFOUND";
		
		try{
			//con  = DBHelperD1.getInstance().getSourceConnection();
			logger.info("Got DB connection.");
			
			if (con != null){
				pstmt = con.prepareStatement(GET_DATA);
				pstmt.setString(1, EPLMID);
				
				rs = pstmt.executeQuery();
				while (rs.next()) {
					password = rs.getString("PASSWORD");
					logger.info("Employee data fetched for " + EPLMID);
				}
			}else{
				logger.error("Data Base Connection is Not Available.");
			}
		}catch (Exception e){
			logger.error("Some exception occured while fetching records : " + e, new Throwable());
			try{
				logger.info("Trying to close Resources DBConnection in getIAUReportData Method.");
				if (rs != null){
					rs.close(); rs = null;
				}				
				if (pstmt != null){
					pstmt.close(); pstmt = null;
				}
				if (con != null){
					con.close(); con = null;
				}
				logger.info("Successfully closed Resources DBConnection in getPassword Method");
			}catch (Exception ew){
				logger.error("SQL exception while closing resources DBConnection in getPassword Method. " + ew, new Throwable());
			}
		}finally{
			try{
				logger.info("Trying to close Resources DBConnection in getPassword Method.");
				if (rs != null){
					rs.close(); rs = null;
				}
				if (pstmt != null){
					pstmt.close(); pstmt = null;
				}
				
				if (con != null){
					con.close(); con = null;
				}
				logger.info("Successfully closed Resources DBConnection in getPassword Method.");
			}catch (Exception e) {
				logger.error("SQL exception while closing resources DBConnection in getPassword Method. " + e, new Throwable());
			}
		logger.info("Getting out from DBConnection in getPassword Method.");
		//return password;
		}
		return password;
	}
}
