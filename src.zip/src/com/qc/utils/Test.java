package com.qc.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Test 
{
	private static Logger logger = LogManager.getLogger(Test.class);
//	public static void main(String... arr)
//	{
//		System.out.println();
//	}
}
