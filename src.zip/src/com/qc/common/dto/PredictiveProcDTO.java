package com.qc.common.dto;

import java.io.Serializable;

public class PredictiveProcDTO implements Serializable 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2387786941699054667L;

	private	String	APL_TO_ACHV_PAID_TGT;
	private	String	BTCH_TIMSTAMP;
	private	String	REAL_TIM_TIMSTAMP;
	
	public PredictiveProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getAPL_TO_ACHV_PAID_TGT() {
		return APL_TO_ACHV_PAID_TGT;
	}

	public void setAPL_TO_ACHV_PAID_TGT(String aPL_TO_ACHV_PAID_TGT) {
		APL_TO_ACHV_PAID_TGT = aPL_TO_ACHV_PAID_TGT;
	}

	public String getBTCH_TIMSTAMP() {
		return BTCH_TIMSTAMP;
	}

	public void setBTCH_TIMSTAMP(String bTCH_TIMSTAMP) {
		BTCH_TIMSTAMP = bTCH_TIMSTAMP;
	}

	public String getREAL_TIM_TIMSTAMP() {
		return REAL_TIM_TIMSTAMP;
	}

	public void setREAL_TIM_TIMSTAMP(String rEAL_TIM_TIMSTAMP) {
		REAL_TIM_TIMSTAMP = rEAL_TIM_TIMSTAMP;
	}
	
}