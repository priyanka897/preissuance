package com.qc.common.dto;

import java.io.Serializable;

public class PenetrationProcDTO implements Serializable {

	/**
	 * 
	 */

	private static final long serialVersionUID = -8094626407284463507L;
	private String	designation_desc	;
	private String	channel	;
	private String	sub_channel	;
	private String	zone	;
	private String	region	;
	private String	circle	;
	private String	clusters	;
	private String	go	;
	private String  cmo;
	private String  amo;
	private String  planType;
	private String	mtd_inforced_count	;
	private String	mtd_inforced_afyp	;
	private String	ytd_inforced_afyp	;
	private String	ytd_inforced_count	;
	private String	trad_penet_mtd_afyp ;     
	private String	trad_penet_ytd_afyp;
	private String	trad_penet_mtd_pol_cnt;
	private String	trad_penet_ytd_pol_cnt;
	private String	trad_mtd_afyp;
	private String	trad_ytd_afyp;
	private String	trad_mtd_pol_cnt;
	private String	trad_ytd_pol_cnt;
	private String	ul_penet_mtd_afyp      	;
	private String	ul_penet_ytd_afyp	;
	private String	ul_penet_mtd_pol_cnt	;
	private String	ul_penet_ytd_pol_cnt	;
	private String	ul_mtd_afyp	;
	private String	ul_ytd_afyp	;
	private String	ul_mtd_pol_cnt	;
	private String	ul_ytd_pol_cnt	;
	private String	par_penet_mtd_afyp	;
	private String	par_penet_ytd_afyp	;
	private String	par_penet_mtd_pol_cnt	;
	private String	par_penet_ytd_pol_cnt	;
	private String	par_mtd_afyp	;
	private String	par_ytd_afyp	;
	private String	par_mtd_pol_cnt	;
	private String	par_ytd_pol_cnt	;
	private String	nonpar_penet_mtd_afyp	;
	private String	nonpar_penet_ytd_afyp	;
	private String	nonpar_penet_mtd_pol_cnt	;
	private String	nonpar_penet_ytd_pol_cnt	;
	private String	nonpar_mtd_afyp	;
	private String	nonpar_ytd_afyp	;
	private String	nonpar_mtd_pol_cnt	;
	private String	nonpar_ytd_pol_cnt	;
	private String	protec_penet_mtd_afyp	;
	private String	protec_penet_ytd_afyp	;
	private String	protec_penet_mtd_pol_cnt	;
	private String	protec_penet_ytd_pol_cnt	;
	private String	protec_mtd_afyp	;
	private String	protec_ytd_afyp	;
	private String	protec_mtd_pol_cnt	;
	private String	protec_ytd_pol_cnt	;
	private String	btch_timstamp	;
	private String	real_tim_timstamp	;
	private String	mtd_inforced_adj_mfyp	;
	private String	ytd_inforced_adj_mfyp	;
	private String	ul_penet_mtd_adj_mfyp	;
	private String	ul_penet_ytd_adj_mfyp	;
	private String	ul_mtd_adj_mfyp	;
	private String	ul_ytd_adj_mfyp	;
	private String	par_penet_mtd_adj_mfyp	;
	private String	par_penet_ytd_adj_mfyp	;
	private String	par_mtd_adj_mfyp	;
	private String	par_ytd_adj_mfyp	;
	private String	nonpar_penet_mtd_adj_mfyp	;
	private String	nonpar_penet_ytd_adj_mfyp	;
	private String	nonpar_mtd_adj_mfyp	;
	private String	nonpar_ytd_adj_mfyp	;
	private String	protec_penet_mtd_adj_mfyp	;
	private String	protec_penet_ytd_adj_mfyp	;
	private String	protec_mtd_adj_mfyp	;
	private String	protec_ytd_adj_mfyp	;

	public String getMtd_inforced_adj_mfyp() {
		return mtd_inforced_adj_mfyp;
	}
	public void setMtd_inforced_adj_mfyp(String mtd_inforced_adj_mfyp) {
		this.mtd_inforced_adj_mfyp = mtd_inforced_adj_mfyp;
	}
	public String getYtd_inforced_adj_mfyp() {
		return ytd_inforced_adj_mfyp;
	}
	public void setYtd_inforced_adj_mfyp(String ytd_inforced_adj_mfyp) {
		this.ytd_inforced_adj_mfyp = ytd_inforced_adj_mfyp;
	}
	public String getUl_penet_mtd_adj_mfyp() {
		return ul_penet_mtd_adj_mfyp;
	}
	public void setUl_penet_mtd_adj_mfyp(String ul_penet_mtd_adj_mfyp) {
		this.ul_penet_mtd_adj_mfyp = ul_penet_mtd_adj_mfyp;
	}
	public String getUl_penet_ytd_adj_mfyp() {
		return ul_penet_ytd_adj_mfyp;
	}
	public void setUl_penet_ytd_adj_mfyp(String ul_penet_ytd_adj_mfyp) {
		this.ul_penet_ytd_adj_mfyp = ul_penet_ytd_adj_mfyp;
	}
	public String getUl_mtd_adj_mfyp() {
		return ul_mtd_adj_mfyp;
	}
	public void setUl_mtd_adj_mfyp(String ul_mtd_adj_mfyp) {
		this.ul_mtd_adj_mfyp = ul_mtd_adj_mfyp;
	}
	public String getUl_ytd_adj_mfyp() {
		return ul_ytd_adj_mfyp;
	}
	public void setUl_ytd_adj_mfyp(String ul_ytd_adj_mfyp) {
		this.ul_ytd_adj_mfyp = ul_ytd_adj_mfyp;
	}
	public String getPar_penet_mtd_adj_mfyp() {
		return par_penet_mtd_adj_mfyp;
	}
	public void setPar_penet_mtd_adj_mfyp(String par_penet_mtd_adj_mfyp) {
		this.par_penet_mtd_adj_mfyp = par_penet_mtd_adj_mfyp;
	}
	public String getPar_penet_ytd_adj_mfyp() {
		return par_penet_ytd_adj_mfyp;
	}
	public void setPar_penet_ytd_adj_mfyp(String par_penet_ytd_adj_mfyp) {
		this.par_penet_ytd_adj_mfyp = par_penet_ytd_adj_mfyp;
	}
	public String getPar_mtd_adj_mfyp() {
		return par_mtd_adj_mfyp;
	}
	public void setPar_mtd_adj_mfyp(String par_mtd_adj_mfyp) {
		this.par_mtd_adj_mfyp = par_mtd_adj_mfyp;
	}
	public String getPar_ytd_adj_mfyp() {
		return par_ytd_adj_mfyp;
	}
	public void setPar_ytd_adj_mfyp(String par_ytd_adj_mfyp) {
		this.par_ytd_adj_mfyp = par_ytd_adj_mfyp;
	}
	public String getNonpar_penet_mtd_adj_mfyp() {
		return nonpar_penet_mtd_adj_mfyp;
	}
	public void setNonpar_penet_mtd_adj_mfyp(String nonpar_penet_mtd_adj_mfyp) {
		this.nonpar_penet_mtd_adj_mfyp = nonpar_penet_mtd_adj_mfyp;
	}
	public String getNonpar_penet_ytd_adj_mfyp() {
		return nonpar_penet_ytd_adj_mfyp;
	}
	public void setNonpar_penet_ytd_adj_mfyp(String nonpar_penet_ytd_adj_mfyp) {
		this.nonpar_penet_ytd_adj_mfyp = nonpar_penet_ytd_adj_mfyp;
	}
	public String getNonpar_mtd_adj_mfyp() {
		return nonpar_mtd_adj_mfyp;
	}
	public void setNonpar_mtd_adj_mfyp(String nonpar_mtd_adj_mfyp) {
		this.nonpar_mtd_adj_mfyp = nonpar_mtd_adj_mfyp;
	}
	public String getNonpar_ytd_adj_mfyp() {
		return nonpar_ytd_adj_mfyp;
	}
	public void setNonpar_ytd_adj_mfyp(String nonpar_ytd_adj_mfyp) {
		this.nonpar_ytd_adj_mfyp = nonpar_ytd_adj_mfyp;
	}
	public String getProtec_penet_mtd_adj_mfyp() {
		return protec_penet_mtd_adj_mfyp;
	}
	public void setProtec_penet_mtd_adj_mfyp(String protec_penet_mtd_adj_mfyp) {
		this.protec_penet_mtd_adj_mfyp = protec_penet_mtd_adj_mfyp;
	}
	public String getProtec_penet_ytd_adj_mfyp() {
		return protec_penet_ytd_adj_mfyp;
	}
	public void setProtec_penet_ytd_adj_mfyp(String protec_penet_ytd_adj_mfyp) {
		this.protec_penet_ytd_adj_mfyp = protec_penet_ytd_adj_mfyp;
	}
	public String getProtec_mtd_adj_mfyp() {
		return protec_mtd_adj_mfyp;
	}
	public void setProtec_mtd_adj_mfyp(String protec_mtd_adj_mfyp) {
		this.protec_mtd_adj_mfyp = protec_mtd_adj_mfyp;
	}
	public String getProtec_ytd_adj_mfyp() {
		return protec_ytd_adj_mfyp;
	}
	public void setProtec_ytd_adj_mfyp(String protec_ytd_adj_mfyp) {
		this.protec_ytd_adj_mfyp = protec_ytd_adj_mfyp;
	}
	
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public String getMtd_inforced_count() {
		return mtd_inforced_count;
	}
	public void setMtd_inforced_count(String mtd_inforced_count) {
		this.mtd_inforced_count = mtd_inforced_count;
	}
	public String getMtd_inforced_afyp() {
		return mtd_inforced_afyp;
	}
	public void setMtd_inforced_afyp(String mtd_inforced_afyp) {
		this.mtd_inforced_afyp = mtd_inforced_afyp;
	}
	public String getYtd_inforced_afyp() {
		return ytd_inforced_afyp;
	}
	public void setYtd_inforced_afyp(String ytd_inforced_afyp) {
		this.ytd_inforced_afyp = ytd_inforced_afyp;
	}
	public String getYtd_inforced_count() {
		return ytd_inforced_count;
	}
	public void setYtd_inforced_count(String ytd_inforced_count) {
		this.ytd_inforced_count = ytd_inforced_count;
	}
	public String getUl_penet_mtd_afyp() {
		return ul_penet_mtd_afyp;
	}
	public void setUl_penet_mtd_afyp(String ul_penet_mtd_afyp) {
		this.ul_penet_mtd_afyp = ul_penet_mtd_afyp;
	}
	public String getUl_penet_ytd_afyp() {
		return ul_penet_ytd_afyp;
	}
	public void setUl_penet_ytd_afyp(String ul_penet_ytd_afyp) {
		this.ul_penet_ytd_afyp = ul_penet_ytd_afyp;
	}
	public String getUl_penet_mtd_pol_cnt() {
		return ul_penet_mtd_pol_cnt;
	}
	public void setUl_penet_mtd_pol_cnt(String ul_penet_mtd_pol_cnt) {
		this.ul_penet_mtd_pol_cnt = ul_penet_mtd_pol_cnt;
	}
	public String getUl_penet_ytd_pol_cnt() {
		return ul_penet_ytd_pol_cnt;
	}
	public void setUl_penet_ytd_pol_cnt(String ul_penet_ytd_pol_cnt) {
		this.ul_penet_ytd_pol_cnt = ul_penet_ytd_pol_cnt;
	}
	public String getUl_mtd_afyp() {
		return ul_mtd_afyp;
	}
	public void setUl_mtd_afyp(String ul_mtd_afyp) {
		this.ul_mtd_afyp = ul_mtd_afyp;
	}
	public String getUl_ytd_afyp() {
		return ul_ytd_afyp;
	}
	public void setUl_ytd_afyp(String ul_ytd_afyp) {
		this.ul_ytd_afyp = ul_ytd_afyp;
	}
	public String getUl_mtd_pol_cnt() {
		return ul_mtd_pol_cnt;
	}
	public void setUl_mtd_pol_cnt(String ul_mtd_pol_cnt) {
		this.ul_mtd_pol_cnt = ul_mtd_pol_cnt;
	}
	public String getUl_ytd_pol_cnt() {
		return ul_ytd_pol_cnt;
	}
	public void setUl_ytd_pol_cnt(String ul_ytd_pol_cnt) {
		this.ul_ytd_pol_cnt = ul_ytd_pol_cnt;
	}
	public String getPar_penet_mtd_afyp() {
		return par_penet_mtd_afyp;
	}
	public void setPar_penet_mtd_afyp(String par_penet_mtd_afyp) {
		this.par_penet_mtd_afyp = par_penet_mtd_afyp;
	}
	public String getPar_penet_ytd_afyp() {
		return par_penet_ytd_afyp;
	}
	public void setPar_penet_ytd_afyp(String par_penet_ytd_afyp) {
		this.par_penet_ytd_afyp = par_penet_ytd_afyp;
	}
	public String getPar_penet_mtd_pol_cnt() {
		return par_penet_mtd_pol_cnt;
	}
	public void setPar_penet_mtd_pol_cnt(String par_penet_mtd_pol_cnt) {
		this.par_penet_mtd_pol_cnt = par_penet_mtd_pol_cnt;
	}
	public String getPar_penet_ytd_pol_cnt() {
		return par_penet_ytd_pol_cnt;
	}
	public void setPar_penet_ytd_pol_cnt(String par_penet_ytd_pol_cnt) {
		this.par_penet_ytd_pol_cnt = par_penet_ytd_pol_cnt;
	}
	public String getPar_mtd_afyp() {
		return par_mtd_afyp;
	}
	public void setPar_mtd_afyp(String par_mtd_afyp) {
		this.par_mtd_afyp = par_mtd_afyp;
	}
	public String getPar_ytd_afyp() {
		return par_ytd_afyp;
	}
	public void setPar_ytd_afyp(String par_ytd_afyp) {
		this.par_ytd_afyp = par_ytd_afyp;
	}
	public String getPar_mtd_pol_cnt() {
		return par_mtd_pol_cnt;
	}
	public void setPar_mtd_pol_cnt(String par_mtd_pol_cnt) {
		this.par_mtd_pol_cnt = par_mtd_pol_cnt;
	}
	public String getPar_ytd_pol_cnt() {
		return par_ytd_pol_cnt;
	}
	public void setPar_ytd_pol_cnt(String par_ytd_pol_cnt) {
		this.par_ytd_pol_cnt = par_ytd_pol_cnt;
	}
	public String getNonpar_penet_mtd_afyp() {
		return nonpar_penet_mtd_afyp;
	}
	public void setNonpar_penet_mtd_afyp(String nonpar_penet_mtd_afyp) {
		this.nonpar_penet_mtd_afyp = nonpar_penet_mtd_afyp;
	}
	public String getNonpar_penet_ytd_afyp() {
		return nonpar_penet_ytd_afyp;
	}
	public void setNonpar_penet_ytd_afyp(String nonpar_penet_ytd_afyp) {
		this.nonpar_penet_ytd_afyp = nonpar_penet_ytd_afyp;
	}
	public String getNonpar_penet_mtd_pol_cnt() {
		return nonpar_penet_mtd_pol_cnt;
	}
	public void setNonpar_penet_mtd_pol_cnt(String nonpar_penet_mtd_pol_cnt) {
		this.nonpar_penet_mtd_pol_cnt = nonpar_penet_mtd_pol_cnt;
	}
	public String getNonpar_penet_ytd_pol_cnt() {
		return nonpar_penet_ytd_pol_cnt;
	}
	public void setNonpar_penet_ytd_pol_cnt(String nonpar_penet_ytd_pol_cnt) {
		this.nonpar_penet_ytd_pol_cnt = nonpar_penet_ytd_pol_cnt;
	}
	public String getNonpar_mtd_afyp() {
		return nonpar_mtd_afyp;
	}
	public void setNonpar_mtd_afyp(String nonpar_mtd_afyp) {
		this.nonpar_mtd_afyp = nonpar_mtd_afyp;
	}
	public String getNonpar_ytd_afyp() {
		return nonpar_ytd_afyp;
	}
	public void setNonpar_ytd_afyp(String nonpar_ytd_afyp) {
		this.nonpar_ytd_afyp = nonpar_ytd_afyp;
	}
	public String getNonpar_mtd_pol_cnt() {
		return nonpar_mtd_pol_cnt;
	}
	public void setNonpar_mtd_pol_cnt(String nonpar_mtd_pol_cnt) {
		this.nonpar_mtd_pol_cnt = nonpar_mtd_pol_cnt;
	}
	public String getNonpar_ytd_pol_cnt() {
		return nonpar_ytd_pol_cnt;
	}
	public void setNonpar_ytd_pol_cnt(String nonpar_ytd_pol_cnt) {
		this.nonpar_ytd_pol_cnt = nonpar_ytd_pol_cnt;
	}
	public String getProtec_penet_mtd_afyp() {
		return protec_penet_mtd_afyp;
	}
	public void setProtec_penet_mtd_afyp(String protec_penet_mtd_afyp) {
		this.protec_penet_mtd_afyp = protec_penet_mtd_afyp;
	}
	public String getProtec_penet_ytd_afyp() {
		return protec_penet_ytd_afyp;
	}
	public void setProtec_penet_ytd_afyp(String protec_penet_ytd_afyp) {
		this.protec_penet_ytd_afyp = protec_penet_ytd_afyp;
	}
	public String getProtec_penet_mtd_pol_cnt() {
		return protec_penet_mtd_pol_cnt;
	}
	public void setProtec_penet_mtd_pol_cnt(String protec_penet_mtd_pol_cnt) {
		this.protec_penet_mtd_pol_cnt = protec_penet_mtd_pol_cnt;
	}
	public String getProtec_penet_ytd_pol_cnt() {
		return protec_penet_ytd_pol_cnt;
	}
	public void setProtec_penet_ytd_pol_cnt(String protec_penet_ytd_pol_cnt) {
		this.protec_penet_ytd_pol_cnt = protec_penet_ytd_pol_cnt;
	}
	public String getProtec_mtd_afyp() {
		return protec_mtd_afyp;
	}
	public void setProtec_mtd_afyp(String protec_mtd_afyp) {
		this.protec_mtd_afyp = protec_mtd_afyp;
	}
	public String getProtec_ytd_afyp() {
		return protec_ytd_afyp;
	}
	public void setProtec_ytd_afyp(String protec_ytd_afyp) {
		this.protec_ytd_afyp = protec_ytd_afyp;
	}
	public String getProtec_mtd_pol_cnt() {
		return protec_mtd_pol_cnt;
	}
	public void setProtec_mtd_pol_cnt(String protec_mtd_pol_cnt) {
		this.protec_mtd_pol_cnt = protec_mtd_pol_cnt;
	}
	public String getProtec_ytd_pol_cnt() {
		return protec_ytd_pol_cnt;
	}
	public void setProtec_ytd_pol_cnt(String protec_ytd_pol_cnt) {
		this.protec_ytd_pol_cnt = protec_ytd_pol_cnt;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public String getTrad_penet_mtd_afyp() {
		return trad_penet_mtd_afyp;
	}
	public void setTrad_penet_mtd_afyp(String trad_penet_mtd_afyp) {
		this.trad_penet_mtd_afyp = trad_penet_mtd_afyp;
	}
	public String getTrad_penet_ytd_afyp() {
		return trad_penet_ytd_afyp;
	}
	public void setTrad_penet_ytd_afyp(String trad_penet_ytd_afyp) {
		this.trad_penet_ytd_afyp = trad_penet_ytd_afyp;
	}
	public String getTrad_penet_mtd_pol_cnt() {
		return trad_penet_mtd_pol_cnt;
	}
	public void setTrad_penet_mtd_pol_cnt(String trad_penet_mtd_pol_cnt) {
		this.trad_penet_mtd_pol_cnt = trad_penet_mtd_pol_cnt;
	}
	public String getTrad_penet_ytd_pol_cnt() {
		return trad_penet_ytd_pol_cnt;
	}
	public void setTrad_penet_ytd_pol_cnt(String trad_penet_ytd_pol_cnt) {
		this.trad_penet_ytd_pol_cnt = trad_penet_ytd_pol_cnt;
	}
	public String getTrad_mtd_afyp() {
		return trad_mtd_afyp;
	}
	public void setTrad_mtd_afyp(String trad_mtd_afyp) {
		this.trad_mtd_afyp = trad_mtd_afyp;
	}
	public String getTrad_ytd_afyp() {
		return trad_ytd_afyp;
	}
	public void setTrad_ytd_afyp(String trad_ytd_afyp) {
		this.trad_ytd_afyp = trad_ytd_afyp;
	}
	public String getTrad_mtd_pol_cnt() {
		return trad_mtd_pol_cnt;
	}
	public void setTrad_mtd_pol_cnt(String trad_mtd_pol_cnt) {
		this.trad_mtd_pol_cnt = trad_mtd_pol_cnt;
	}
	public String getTrad_ytd_pol_cnt() {
		return trad_ytd_pol_cnt;
	}
	public void setTrad_ytd_pol_cnt(String trad_ytd_pol_cnt) {
		this.trad_ytd_pol_cnt = trad_ytd_pol_cnt;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
