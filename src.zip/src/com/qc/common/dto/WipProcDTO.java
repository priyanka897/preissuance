package com.qc.common.dto;

import java.io.Serializable;

public class WipProcDTO implements Serializable 
{
	private static final long serialVersionUID = 1L;
	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String wip_count;
	private String wip_afyp;
	private String ho_wip_afyp;
	private String go_wip_afyp;
	private String it_wip_afyp;
	private String fin_wip_afyp;
	private String misc_wip_afyp;
	private String welcome_wip_afyp;
	private String ho_wip_count;
	private String go_wip_count;
	private String it_wip_count;
	private String fin_wip_count;
	private String misc_wip_count;
	private String welcome_wip_count;
	private String btch_timstamp;
	private String real_tim_timstamp;
	private String ho_wip_adj_mfyp;
	private String go_wip_adj_mfyp;
	private String it_wip_adj_mfyp;
	private String fin_wip_adj_mfyp;
	private String misc_wip_adj_mfyp;
	private String welcome_wip_adj_mfyp;
	private String wip_adj_mfyp;
	
	
	
	public WipProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getCmo() {
		return cmo;
	}

	public void setCmo(String cmo) {
		this.cmo = cmo;
	}

	public String getAmo() {
		return amo;
	}

	public void setAmo(String amo) {
		this.amo = amo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getClusters() {
		return clusters;
	}

	public void setClusters(String clusters) {
		this.clusters = clusters;
	}

	public String getGo() {
		return go;
	}

	public void setGo(String go) {
		this.go = go;
	}

	public String getWip_count() {
		return wip_count;
	}

	public void setWip_count(String wip_count) {
		this.wip_count = wip_count;
	}

	public String getWip_afyp() {
		return wip_afyp;
	}

	public void setWip_afyp(String wip_afyp) {
		this.wip_afyp = wip_afyp;
	}

	public String getHo_wip_afyp() {
		return ho_wip_afyp;
	}

	public void setHo_wip_afyp(String ho_wip_afyp) {
		this.ho_wip_afyp = ho_wip_afyp;
	}

	public String getGo_wip_afyp() {
		return go_wip_afyp;
	}

	public void setGo_wip_afyp(String go_wip_afyp) {
		this.go_wip_afyp = go_wip_afyp;
	}

	public String getIt_wip_afyp() {
		return it_wip_afyp;
	}

	public void setIt_wip_afyp(String it_wip_afyp) {
		this.it_wip_afyp = it_wip_afyp;
	}

	public String getFin_wip_afyp() {
		return fin_wip_afyp;
	}

	public void setFin_wip_afyp(String fin_wip_afyp) {
		this.fin_wip_afyp = fin_wip_afyp;
	}

	public String getMisc_wip_afyp() {
		return misc_wip_afyp;
	}

	public void setMisc_wip_afyp(String misc_wip_afyp) {
		this.misc_wip_afyp = misc_wip_afyp;
	}

	public String getWelcome_wip_afyp() {
		return welcome_wip_afyp;
	}

	public void setWelcome_wip_afyp(String welcome_wip_afyp) {
		this.welcome_wip_afyp = welcome_wip_afyp;
	}

	public String getHo_wip_count() {
		return ho_wip_count;
	}

	public void setHo_wip_count(String ho_wip_count) {
		this.ho_wip_count = ho_wip_count;
	}

	public String getGo_wip_count() {
		return go_wip_count;
	}

	public void setGo_wip_count(String go_wip_count) {
		this.go_wip_count = go_wip_count;
	}

	public String getIt_wip_count() {
		return it_wip_count;
	}

	public void setIt_wip_count(String it_wip_count) {
		this.it_wip_count = it_wip_count;
	}

	public String getFin_wip_count() {
		return fin_wip_count;
	}

	public void setFin_wip_count(String fin_wip_count) {
		this.fin_wip_count = fin_wip_count;
	}

	public String getMisc_wip_count() {
		return misc_wip_count;
	}

	public void setMisc_wip_count(String misc_wip_count) {
		this.misc_wip_count = misc_wip_count;
	}

	public String getWelcome_wip_count() {
		return welcome_wip_count;
	}

	public void setWelcome_wip_count(String welcome_wip_count) {
		this.welcome_wip_count = welcome_wip_count;
	}

	public String getBtch_timstamp() {
		return btch_timstamp;
	}

	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}

	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}

	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public String getHo_wip_adj_mfyp() {
		return ho_wip_adj_mfyp;
	}
	public void setHo_wip_adj_mfyp(String ho_wip_adj_mfyp) {
		this.ho_wip_adj_mfyp = ho_wip_adj_mfyp;
	}
	public String getGo_wip_adj_mfyp() {
		return go_wip_adj_mfyp;
	}
	public void setGo_wip_adj_mfyp(String go_wip_adj_mfyp) {
		this.go_wip_adj_mfyp = go_wip_adj_mfyp;
	}
	public String getIt_wip_adj_mfyp() {
		return it_wip_adj_mfyp;
	}
	public void setIt_wip_adj_mfyp(String it_wip_adj_mfyp) {
		this.it_wip_adj_mfyp = it_wip_adj_mfyp;
	}
	public String getFin_wip_adj_mfyp() {
		return fin_wip_adj_mfyp;
	}
	public void setFin_wip_adj_mfyp(String fin_wip_adj_mfyp) {
		this.fin_wip_adj_mfyp = fin_wip_adj_mfyp;
	}
	public String getMisc_wip_adj_mfyp() {
		return misc_wip_adj_mfyp;
	}
	public void setMisc_wip_adj_mfyp(String misc_wip_adj_mfyp) {
		this.misc_wip_adj_mfyp = misc_wip_adj_mfyp;
	}
	public String getWelcome_wip_adj_mfyp() {
		return welcome_wip_adj_mfyp;
	}
	public void setWelcome_wip_adj_mfyp(String welcome_wip_adj_mfyp) {
		this.welcome_wip_adj_mfyp = welcome_wip_adj_mfyp;
	}
	public String getWip_adj_mfyp() {
		return wip_adj_mfyp;
	}
	public void setWip_adj_mfyp(String wip_adj_mfyp) {
		this.wip_adj_mfyp = wip_adj_mfyp;
	}
	
}
