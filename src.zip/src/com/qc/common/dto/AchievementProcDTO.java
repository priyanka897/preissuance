package com.qc.common.dto;

import java.io.Serializable;

public class AchievementProcDTO implements Serializable
{
	private static final long serialVersionUID = 1L;
	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String achiev_ytd_paid_case;
	private String ytd_paid_case_pln;
	private String ytd_paid_case_act;
	private String achiev_ytd_adj_mfyp;
	private String ytd_adj_mfyp_pln;
	private String ytd_adj_mfyp_act;
	private String achiev_ytd_adj_afyp;
	private String ytd_adj_afyp_pln;
	private String ytd_adj_afyp_act;
	private String achiev_ytd_afyp;
	private String ytd_afyp_pln;
	private String ytd_afyp_act;
	private String achiev_ytd_weighted_fyp;
	private String ytd_weighted_fyp_pln;
	private String ytd_weighted_fyp_act;
	private String achiev_ytd_case_size;
	private String ytd_case_size_pln;
	private String ytd_case_size_act;
	private String achiev_ytd_recruitment;
	private String ytd_recruitment_pln;
	private String ytd_recruitment_act;
	private String achiev_mtd_paid_case;
	private String mtd_paid_case_pln;
	private String mtd_paid_case_act;
	private String achiev_mtd_adj_mfyp;
	private String mtd_adj_mfyp_pln;
	private String mtd_adj_mfyp_act;
	private String achiev_mtd_adj_afyp;
	private String mtd_adj_afyp_pln;
	private String mtd_adj_afyp_act;
	private String achiev_mtd_afyp;
	private String mtd_afyp_pln;
	private String mtd_afyp_act;
	private String achiev_mtd_weighted_fyp;
	private String mtd_weighted_fyp_pln;
	private String mtd_weighted_fyp_act;
	private String achiev_mtd_case_size;
	private String mtd_case_size_pln;
	private String mtd_case_size_act;
	private String achiev_mtd_recruitment;
	private String mtd_recruitment_pln;
	private String mtd_recruitment_act;
	private String btch_timstamp;
	private String real_tim_timstamp;
	private String achiev_mtd_case_active_mtd;
	private String case_active_mtd_pln;
	private String case_active_mtd_act;
	private String achiev_mtd_case_active_ytd;
	private String case_active_ytd_pln;
	private String case_active_ytd_act;
	private String achiev_proactive_agents_mtd;
	private String proactive_agents_mtd_pln;
	private String proactive_agents_mtd_act;
	private String achiev_proactive_agents_ytd;
	private String proactive_agents_ytd_pln;
	private String proactive_agents_ytd_act;
	
	public AchievementProcDTO() {
		super();
	}

	public String getAchiev_mtd_case_active_mtd() {
		return achiev_mtd_case_active_mtd;
	}

	public void setAchiev_mtd_case_active_mtd(String achiev_mtd_case_active_mtd) {
		this.achiev_mtd_case_active_mtd = achiev_mtd_case_active_mtd;
	}

	public String getCase_active_mtd_pln() {
		return case_active_mtd_pln;
	}

	public void setCase_active_mtd_pln(String case_active_mtd_pln) {
		this.case_active_mtd_pln = case_active_mtd_pln;
	}

	public String getCase_active_mtd_act() {
		return case_active_mtd_act;
	}

	public void setCase_active_mtd_act(String case_active_mtd_act) {
		this.case_active_mtd_act = case_active_mtd_act;
	}

	public String getAchiev_mtd_case_active_ytd() {
		return achiev_mtd_case_active_ytd;
	}

	public void setAchiev_mtd_case_active_ytd(String achiev_mtd_case_active_ytd) {
		this.achiev_mtd_case_active_ytd = achiev_mtd_case_active_ytd;
	}

	public String getCase_active_ytd_pln() {
		return case_active_ytd_pln;
	}

	public void setCase_active_ytd_pln(String case_active_ytd_pln) {
		this.case_active_ytd_pln = case_active_ytd_pln;
	}

	public String getCase_active_ytd_act() {
		return case_active_ytd_act;
	}

	public void setCase_active_ytd_act(String case_active_ytd_act) {
		this.case_active_ytd_act = case_active_ytd_act;
	}

	public String getAchiev_proactive_agents_mtd() {
		return achiev_proactive_agents_mtd;
	}

	public void setAchiev_proactive_agents_mtd(String achiev_proactive_agents_mtd) {
		this.achiev_proactive_agents_mtd = achiev_proactive_agents_mtd;
	}

	public String getProactive_agents_mtd_pln() {
		return proactive_agents_mtd_pln;
	}

	public void setProactive_agents_mtd_pln(String proactive_agents_mtd_pln) {
		this.proactive_agents_mtd_pln = proactive_agents_mtd_pln;
	}

	public String getProactive_agents_mtd_act() {
		return proactive_agents_mtd_act;
	}

	public void setProactive_agents_mtd_act(String proactive_agents_mtd_act) {
		this.proactive_agents_mtd_act = proactive_agents_mtd_act;
	}

	public String getAchiev_proactive_agents_ytd() {
		return achiev_proactive_agents_ytd;
	}

	public void setAchiev_proactive_agents_ytd(String achiev_proactive_agents_ytd) {
		this.achiev_proactive_agents_ytd = achiev_proactive_agents_ytd;
	}

	public String getProactive_agents_ytd_pln() {
		return proactive_agents_ytd_pln;
	}

	public void setProactive_agents_ytd_pln(String proactive_agents_ytd_pln) {
		this.proactive_agents_ytd_pln = proactive_agents_ytd_pln;
	}

	public String getProactive_agents_ytd_act() {
		return proactive_agents_ytd_act;
	}

	public void setProactive_agents_ytd_act(String proactive_agents_ytd_act) {
		this.proactive_agents_ytd_act = proactive_agents_ytd_act;
	}

	public String getDesignation_desc() {
		return designation_desc;
	}

	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}

	public String getCmo() {
		return cmo;
	}

	public void setCmo(String cmo) {
		this.cmo = cmo;
	}

	public String getAmo() {
		return amo;
	}

	public void setAmo(String amo) {
		this.amo = amo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getClusters() {
		return clusters;
	}

	public void setClusters(String clusters) {
		this.clusters = clusters;
	}

	public String getGo() {
		return go;
	}

	public void setGo(String go) {
		this.go = go;
	}

	public String getAchiev_ytd_paid_case() {
		return achiev_ytd_paid_case;
	}

	public void setAchiev_ytd_paid_case(String achiev_ytd_paid_case) {
		this.achiev_ytd_paid_case = achiev_ytd_paid_case;
	}

	public String getYtd_paid_case_pln() {
		return ytd_paid_case_pln;
	}

	public void setYtd_paid_case_pln(String ytd_paid_case_pln) {
		this.ytd_paid_case_pln = ytd_paid_case_pln;
	}

	public String getYtd_paid_case_act() {
		return ytd_paid_case_act;
	}

	public void setYtd_paid_case_act(String ytd_paid_case_act) {
		this.ytd_paid_case_act = ytd_paid_case_act;
	}

	public String getAchiev_ytd_adj_mfyp() {
		return achiev_ytd_adj_mfyp;
	}

	public void setAchiev_ytd_adj_mfyp(String achiev_ytd_adj_mfyp) {
		this.achiev_ytd_adj_mfyp = achiev_ytd_adj_mfyp;
	}

	public String getYtd_adj_mfyp_pln() {
		return ytd_adj_mfyp_pln;
	}

	public void setYtd_adj_mfyp_pln(String ytd_adj_mfyp_pln) {
		this.ytd_adj_mfyp_pln = ytd_adj_mfyp_pln;
	}

	public String getYtd_adj_mfyp_act() {
		return ytd_adj_mfyp_act;
	}

	public void setYtd_adj_mfyp_act(String ytd_adj_mfyp_act) {
		this.ytd_adj_mfyp_act = ytd_adj_mfyp_act;
	}

	public String getAchiev_ytd_adj_afyp() {
		return achiev_ytd_adj_afyp;
	}

	public void setAchiev_ytd_adj_afyp(String achiev_ytd_adj_afyp) {
		this.achiev_ytd_adj_afyp = achiev_ytd_adj_afyp;
	}

	public String getYtd_adj_afyp_pln() {
		return ytd_adj_afyp_pln;
	}

	public void setYtd_adj_afyp_pln(String ytd_adj_afyp_pln) {
		this.ytd_adj_afyp_pln = ytd_adj_afyp_pln;
	}

	public String getYtd_adj_afyp_act() {
		return ytd_adj_afyp_act;
	}

	public void setYtd_adj_afyp_act(String ytd_adj_afyp_act) {
		this.ytd_adj_afyp_act = ytd_adj_afyp_act;
	}

	public String getAchiev_ytd_afyp() {
		return achiev_ytd_afyp;
	}

	public void setAchiev_ytd_afyp(String achiev_ytd_afyp) {
		this.achiev_ytd_afyp = achiev_ytd_afyp;
	}

	public String getYtd_afyp_pln() {
		return ytd_afyp_pln;
	}

	public void setYtd_afyp_pln(String ytd_afyp_pln) {
		this.ytd_afyp_pln = ytd_afyp_pln;
	}

	public String getYtd_afyp_act() {
		return ytd_afyp_act;
	}

	public void setYtd_afyp_act(String ytd_afyp_act) {
		this.ytd_afyp_act = ytd_afyp_act;
	}

	public String getAchiev_ytd_weighted_fyp() {
		return achiev_ytd_weighted_fyp;
	}

	public void setAchiev_ytd_weighted_fyp(String achiev_ytd_weighted_fyp) {
		this.achiev_ytd_weighted_fyp = achiev_ytd_weighted_fyp;
	}

	public String getYtd_weighted_fyp_pln() {
		return ytd_weighted_fyp_pln;
	}

	public void setYtd_weighted_fyp_pln(String ytd_weighted_fyp_pln) {
		this.ytd_weighted_fyp_pln = ytd_weighted_fyp_pln;
	}

	public String getYtd_weighted_fyp_act() {
		return ytd_weighted_fyp_act;
	}

	public void setYtd_weighted_fyp_act(String ytd_weighted_fyp_act) {
		this.ytd_weighted_fyp_act = ytd_weighted_fyp_act;
	}

	public String getAchiev_ytd_case_size() {
		return achiev_ytd_case_size;
	}

	public void setAchiev_ytd_case_size(String achiev_ytd_case_size) {
		this.achiev_ytd_case_size = achiev_ytd_case_size;
	}

	public String getYtd_case_size_pln() {
		return ytd_case_size_pln;
	}

	public void setYtd_case_size_pln(String ytd_case_size_pln) {
		this.ytd_case_size_pln = ytd_case_size_pln;
	}

	public String getYtd_case_size_act() {
		return ytd_case_size_act;
	}

	public void setYtd_case_size_act(String ytd_case_size_act) {
		this.ytd_case_size_act = ytd_case_size_act;
	}

	public String getAchiev_ytd_recruitment() {
		return achiev_ytd_recruitment;
	}

	public void setAchiev_ytd_recruitment(String achiev_ytd_recruitment) {
		this.achiev_ytd_recruitment = achiev_ytd_recruitment;
	}

	public String getYtd_recruitment_pln() {
		return ytd_recruitment_pln;
	}

	public void setYtd_recruitment_pln(String ytd_recruitment_pln) {
		this.ytd_recruitment_pln = ytd_recruitment_pln;
	}

	public String getYtd_recruitment_act() {
		return ytd_recruitment_act;
	}

	public void setYtd_recruitment_act(String ytd_recruitment_act) {
		this.ytd_recruitment_act = ytd_recruitment_act;
	}

	public String getAchiev_mtd_paid_case() {
		return achiev_mtd_paid_case;
	}

	public void setAchiev_mtd_paid_case(String achiev_mtd_paid_case) {
		this.achiev_mtd_paid_case = achiev_mtd_paid_case;
	}

	public String getMtd_paid_case_pln() {
		return mtd_paid_case_pln;
	}

	public void setMtd_paid_case_pln(String mtd_paid_case_pln) {
		this.mtd_paid_case_pln = mtd_paid_case_pln;
	}

	public String getMtd_paid_case_act() {
		return mtd_paid_case_act;
	}

	public void setMtd_paid_case_act(String mtd_paid_case_act) {
		this.mtd_paid_case_act = mtd_paid_case_act;
	}

	public String getAchiev_mtd_adj_mfyp() {
		return achiev_mtd_adj_mfyp;
	}

	public void setAchiev_mtd_adj_mfyp(String achiev_mtd_adj_mfyp) {
		this.achiev_mtd_adj_mfyp = achiev_mtd_adj_mfyp;
	}

	public String getMtd_adj_mfyp_pln() {
		return mtd_adj_mfyp_pln;
	}

	public void setMtd_adj_mfyp_pln(String mtd_adj_mfyp_pln) {
		this.mtd_adj_mfyp_pln = mtd_adj_mfyp_pln;
	}

	public String getMtd_adj_mfyp_act() {
		return mtd_adj_mfyp_act;
	}

	public void setMtd_adj_mfyp_act(String mtd_adj_mfyp_act) {
		this.mtd_adj_mfyp_act = mtd_adj_mfyp_act;
	}

	public String getAchiev_mtd_adj_afyp() {
		return achiev_mtd_adj_afyp;
	}

	public void setAchiev_mtd_adj_afyp(String achiev_mtd_adj_afyp) {
		this.achiev_mtd_adj_afyp = achiev_mtd_adj_afyp;
	}

	public String getMtd_adj_afyp_pln() {
		return mtd_adj_afyp_pln;
	}

	public void setMtd_adj_afyp_pln(String mtd_adj_afyp_pln) {
		this.mtd_adj_afyp_pln = mtd_adj_afyp_pln;
	}

	public String getMtd_adj_afyp_act() {
		return mtd_adj_afyp_act;
	}

	public void setMtd_adj_afyp_act(String mtd_adj_afyp_act) {
		this.mtd_adj_afyp_act = mtd_adj_afyp_act;
	}

	public String getAchiev_mtd_afyp() {
		return achiev_mtd_afyp;
	}

	public void setAchiev_mtd_afyp(String achiev_mtd_afyp) {
		this.achiev_mtd_afyp = achiev_mtd_afyp;
	}

	public String getMtd_afyp_pln() {
		return mtd_afyp_pln;
	}

	public void setMtd_afyp_pln(String mtd_afyp_pln) {
		this.mtd_afyp_pln = mtd_afyp_pln;
	}

	public String getMtd_afyp_act() {
		return mtd_afyp_act;
	}

	public void setMtd_afyp_act(String mtd_afyp_act) {
		this.mtd_afyp_act = mtd_afyp_act;
	}

	public String getAchiev_mtd_weighted_fyp() {
		return achiev_mtd_weighted_fyp;
	}

	public void setAchiev_mtd_weighted_fyp(String achiev_mtd_weighted_fyp) {
		this.achiev_mtd_weighted_fyp = achiev_mtd_weighted_fyp;
	}

	public String getMtd_weighted_fyp_pln() {
		return mtd_weighted_fyp_pln;
	}

	public void setMtd_weighted_fyp_pln(String mtd_weighted_fyp_pln) {
		this.mtd_weighted_fyp_pln = mtd_weighted_fyp_pln;
	}

	public String getMtd_weighted_fyp_act() {
		return mtd_weighted_fyp_act;
	}

	public void setMtd_weighted_fyp_act(String mtd_weighted_fyp_act) {
		this.mtd_weighted_fyp_act = mtd_weighted_fyp_act;
	}

	public String getAchiev_mtd_case_size() {
		return achiev_mtd_case_size;
	}

	public void setAchiev_mtd_case_size(String achiev_mtd_case_size) {
		this.achiev_mtd_case_size = achiev_mtd_case_size;
	}

	public String getMtd_case_size_pln() {
		return mtd_case_size_pln;
	}

	public void setMtd_case_size_pln(String mtd_case_size_pln) {
		this.mtd_case_size_pln = mtd_case_size_pln;
	}

	public String getMtd_case_size_act() {
		return mtd_case_size_act;
	}

	public void setMtd_case_size_act(String mtd_case_size_act) {
		this.mtd_case_size_act = mtd_case_size_act;
	}

	public String getAchiev_mtd_recruitment() {
		return achiev_mtd_recruitment;
	}

	public void setAchiev_mtd_recruitment(String achiev_mtd_recruitment) {
		this.achiev_mtd_recruitment = achiev_mtd_recruitment;
	}

	public String getMtd_recruitment_pln() {
		return mtd_recruitment_pln;
	}

	public void setMtd_recruitment_pln(String mtd_recruitment_pln) {
		this.mtd_recruitment_pln = mtd_recruitment_pln;
	}

	public String getMtd_recruitment_act() {
		return mtd_recruitment_act;
	}

	public void setMtd_recruitment_act(String mtd_recruitment_act) {
		this.mtd_recruitment_act = mtd_recruitment_act;
	}

	public String getBtch_timstamp() {
		return btch_timstamp;
	}

	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}

	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}

	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}

}
