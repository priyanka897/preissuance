package com.qc.common.dto;

import java.io.Serializable;

public class MiscProcDTO implements Serializable 
{
	private static final long serialVersionUID = 1L;
	
	private String channel;
	private String sub_channel;
	private String group_mtd;
	private String group_qtd;
	private String group_ytd;
	private String paid_count_mtd;
	private String paid_adj_mfyp_mtd;
	private String paid_count_qtd;
	private String paid_adj_mfyp_qtd;
	private String paid_count_ytd;
	private String paid_adj_mfyp_ytd;
	private String o_banca_paid_count;
	private String o_banca_paid_adj_mfyp;
	private String o_banca_applied_count;
	private String o_banca_applied_adj_ifyp;
	private String o_banca_wip_count;
	private String o_banca_wip_afyp;
	private String misc_paid_count;
	private String misc_paid_adj_mfyp;
	private String misc_applied_count;
	private String misc_applied_adj_ifyp;
	private String misc_wip_count;
	private String misc_wip_afyp;
	private String pd_paid_count;
	private String pd_paid_adj_mfyp;
	private String pd_applied_count;
	private String pd_applied_adj_ifyp;
	private String pd_wip_count;
	private String pd_wip_afyp;
	private String o_banca_paid_count_ftd;
	private String o_banca_paid_adj_mfyp_ftd;
	private String o_banca_applied_count_ftd;
	private String o_banca_applied_adj_ifyp_ftd;
	private String misc_paid_count_ftd;
	private String misc_paid_adj_mfyp_ftd;
	private String misc_applied_count_ftd;
	private String misc_applied_adj_ifyp_ftd;
	private String pd_paid_count_ftd;
	private String pd_paid_adj_mfyp_ftd;
	private String pd_applied_count_ftd;
	private String pd_applied_adj_ifyp_ftd;
	private String real_tim_timstamp;
	private String growth_mtd;
	private String growth_qtd;
	private String growth_ytd;
	private String curr_adj_mfyp_mtd;
	private String prev_adj_mfyp_mtd;
	private String curr_adj_mfyp_qtd;
	private String prev_adj_mfyp_qtd;
	private String curr_adj_mfyp_ytd;
	private String prev_adj_mfyp_ytd;
	private String pd_wip_adj_mfyp;
	private String misc_wip_adj_mfyp;
	private String o_banca_wip_adj_mfyp;

	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getGroup_mtd() {
		return group_mtd;
	}
	public void setGroup_mtd(String group_mtd) {
		this.group_mtd = group_mtd;
	}
	public String getGroup_qtd() {
		return group_qtd;
	}
	public void setGroup_qtd(String group_qtd) {
		this.group_qtd = group_qtd;
	}
	public String getGroup_ytd() {
		return group_ytd;
	}
	public void setGroup_ytd(String group_ytd) {
		this.group_ytd = group_ytd;
	}
	public String getPaid_count_mtd() {
		return paid_count_mtd;
	}
	public void setPaid_count_mtd(String paid_count_mtd) {
		this.paid_count_mtd = paid_count_mtd;
	}
	public String getPaid_adj_mfyp_mtd() {
		return paid_adj_mfyp_mtd;
	}
	public void setPaid_adj_mfyp_mtd(String paid_adj_mfyp_mtd) {
		this.paid_adj_mfyp_mtd = paid_adj_mfyp_mtd;
	}
	public String getPaid_count_qtd() {
		return paid_count_qtd;
	}
	public void setPaid_count_qtd(String paid_count_qtd) {
		this.paid_count_qtd = paid_count_qtd;
	}
	public String getPaid_adj_mfyp_qtd() {
		return paid_adj_mfyp_qtd;
	}
	public void setPaid_adj_mfyp_qtd(String paid_adj_mfyp_qtd) {
		this.paid_adj_mfyp_qtd = paid_adj_mfyp_qtd;
	}
	public String getPaid_count_ytd() {
		return paid_count_ytd;
	}
	public void setPaid_count_ytd(String paid_count_ytd) {
		this.paid_count_ytd = paid_count_ytd;
	}
	public String getPaid_adj_mfyp_ytd() {
		return paid_adj_mfyp_ytd;
	}
	public void setPaid_adj_mfyp_ytd(String paid_adj_mfyp_ytd) {
		this.paid_adj_mfyp_ytd = paid_adj_mfyp_ytd;
	}
	public String getO_banca_paid_count() {
		return o_banca_paid_count;
	}
	public void setO_banca_paid_count(String o_banca_paid_count) {
		this.o_banca_paid_count = o_banca_paid_count;
	}
	public String getO_banca_paid_adj_mfyp() {
		return o_banca_paid_adj_mfyp;
	}
	public void setO_banca_paid_adj_mfyp(String o_banca_paid_adj_mfyp) {
		this.o_banca_paid_adj_mfyp = o_banca_paid_adj_mfyp;
	}
	public String getO_banca_applied_count() {
		return o_banca_applied_count;
	}
	public void setO_banca_applied_count(String o_banca_applied_count) {
		this.o_banca_applied_count = o_banca_applied_count;
	}
	public String getO_banca_applied_adj_ifyp() {
		return o_banca_applied_adj_ifyp;
	}
	public void setO_banca_applied_adj_ifyp(String o_banca_applied_adj_ifyp) {
		this.o_banca_applied_adj_ifyp = o_banca_applied_adj_ifyp;
	}
	public String getO_banca_wip_count() {
		return o_banca_wip_count;
	}
	public void setO_banca_wip_count(String o_banca_wip_count) {
		this.o_banca_wip_count = o_banca_wip_count;
	}
	public String getO_banca_wip_afyp() {
		return o_banca_wip_afyp;
	}
	public void setO_banca_wip_afyp(String o_banca_wip_afyp) {
		this.o_banca_wip_afyp = o_banca_wip_afyp;
	}
	public String getMisc_paid_count() {
		return misc_paid_count;
	}
	public void setMisc_paid_count(String misc_paid_count) {
		this.misc_paid_count = misc_paid_count;
	}
	public String getMisc_paid_adj_mfyp() {
		return misc_paid_adj_mfyp;
	}
	public void setMisc_paid_adj_mfyp(String misc_paid_adj_mfyp) {
		this.misc_paid_adj_mfyp = misc_paid_adj_mfyp;
	}
	public String getMisc_applied_count() {
		return misc_applied_count;
	}
	public void setMisc_applied_count(String misc_applied_count) {
		this.misc_applied_count = misc_applied_count;
	}
	public String getMisc_applied_adj_ifyp() {
		return misc_applied_adj_ifyp;
	}
	public void setMisc_applied_adj_ifyp(String misc_applied_adj_ifyp) {
		this.misc_applied_adj_ifyp = misc_applied_adj_ifyp;
	}
	public String getMisc_wip_count() {
		return misc_wip_count;
	}
	public void setMisc_wip_count(String misc_wip_count) {
		this.misc_wip_count = misc_wip_count;
	}
	public String getMisc_wip_afyp() {
		return misc_wip_afyp;
	}
	public void setMisc_wip_afyp(String misc_wip_afyp) {
		this.misc_wip_afyp = misc_wip_afyp;
	}
	public String getPd_paid_count() {
		return pd_paid_count;
	}
	public void setPd_paid_count(String pd_paid_count) {
		this.pd_paid_count = pd_paid_count;
	}
	public String getPd_paid_adj_mfyp() {
		return pd_paid_adj_mfyp;
	}
	public void setPd_paid_adj_mfyp(String pd_paid_adj_mfyp) {
		this.pd_paid_adj_mfyp = pd_paid_adj_mfyp;
	}
	public String getPd_applied_count() {
		return pd_applied_count;
	}
	public void setPd_applied_count(String pd_applied_count) {
		this.pd_applied_count = pd_applied_count;
	}
	public String getPd_applied_adj_ifyp() {
		return pd_applied_adj_ifyp;
	}
	public void setPd_applied_adj_ifyp(String pd_applied_adj_ifyp) {
		this.pd_applied_adj_ifyp = pd_applied_adj_ifyp;
	}
	public String getPd_wip_count() {
		return pd_wip_count;
	}
	public void setPd_wip_count(String pd_wip_count) {
		this.pd_wip_count = pd_wip_count;
	}
	public String getPd_wip_afyp() {
		return pd_wip_afyp;
	}
	public void setPd_wip_afyp(String pd_wip_afyp) {
		this.pd_wip_afyp = pd_wip_afyp;
	}
	public String getO_banca_paid_count_ftd() {
		return o_banca_paid_count_ftd;
	}
	public void setO_banca_paid_count_ftd(String o_banca_paid_count_ftd) {
		this.o_banca_paid_count_ftd = o_banca_paid_count_ftd;
	}
	public String getO_banca_paid_adj_mfyp_ftd() {
		return o_banca_paid_adj_mfyp_ftd;
	}
	public void setO_banca_paid_adj_mfyp_ftd(String o_banca_paid_adj_mfyp_ftd) {
		this.o_banca_paid_adj_mfyp_ftd = o_banca_paid_adj_mfyp_ftd;
	}
	public String getO_banca_applied_count_ftd() {
		return o_banca_applied_count_ftd;
	}
	public void setO_banca_applied_count_ftd(String o_banca_applied_count_ftd) {
		this.o_banca_applied_count_ftd = o_banca_applied_count_ftd;
	}
	public String getO_banca_applied_adj_ifyp_ftd() {
		return o_banca_applied_adj_ifyp_ftd;
	}
	public void setO_banca_applied_adj_ifyp_ftd(String o_banca_applied_adj_ifyp_ftd) {
		this.o_banca_applied_adj_ifyp_ftd = o_banca_applied_adj_ifyp_ftd;
	}
	public String getMisc_paid_count_ftd() {
		return misc_paid_count_ftd;
	}
	public void setMisc_paid_count_ftd(String misc_paid_count_ftd) {
		this.misc_paid_count_ftd = misc_paid_count_ftd;
	}
	public String getMisc_paid_adj_mfyp_ftd() {
		return misc_paid_adj_mfyp_ftd;
	}
	public void setMisc_paid_adj_mfyp_ftd(String misc_paid_adj_mfyp_ftd) {
		this.misc_paid_adj_mfyp_ftd = misc_paid_adj_mfyp_ftd;
	}
	public String getMisc_applied_count_ftd() {
		return misc_applied_count_ftd;
	}
	public void setMisc_applied_count_ftd(String misc_applied_count_ftd) {
		this.misc_applied_count_ftd = misc_applied_count_ftd;
	}
	public String getMisc_applied_adj_ifyp_ftd() {
		return misc_applied_adj_ifyp_ftd;
	}
	public void setMisc_applied_adj_ifyp_ftd(String misc_applied_adj_ifyp_ftd) {
		this.misc_applied_adj_ifyp_ftd = misc_applied_adj_ifyp_ftd;
	}
	public String getPd_paid_count_ftd() {
		return pd_paid_count_ftd;
	}
	public void setPd_paid_count_ftd(String pd_paid_count_ftd) {
		this.pd_paid_count_ftd = pd_paid_count_ftd;
	}
	public String getPd_paid_adj_mfyp_ftd() {
		return pd_paid_adj_mfyp_ftd;
	}
	public void setPd_paid_adj_mfyp_ftd(String pd_paid_adj_mfyp_ftd) {
		this.pd_paid_adj_mfyp_ftd = pd_paid_adj_mfyp_ftd;
	}
	public String getPd_applied_count_ftd() {
		return pd_applied_count_ftd;
	}
	public void setPd_applied_count_ftd(String pd_applied_count_ftd) {
		this.pd_applied_count_ftd = pd_applied_count_ftd;
	}
	public String getPd_applied_adj_ifyp_ftd() {
		return pd_applied_adj_ifyp_ftd;
	}
	public void setPd_applied_adj_ifyp_ftd(String pd_applied_adj_ifyp_ftd) {
		this.pd_applied_adj_ifyp_ftd = pd_applied_adj_ifyp_ftd;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public String getGrowth_mtd() {
		return growth_mtd;
	}
	public void setGrowth_mtd(String growth_mtd) {
		this.growth_mtd = growth_mtd;
	}
	public String getGrowth_qtd() {
		return growth_qtd;
	}
	public void setGrowth_qtd(String growth_qtd) {
		this.growth_qtd = growth_qtd;
	}
	public String getGrowth_ytd() {
		return growth_ytd;
	}
	public void setGrowth_ytd(String growth_ytd) {
		this.growth_ytd = growth_ytd;
	}
	public String getCurr_adj_mfyp_mtd() {
		return curr_adj_mfyp_mtd;
	}
	public void setCurr_adj_mfyp_mtd(String curr_adj_mfyp_mtd) {
		this.curr_adj_mfyp_mtd = curr_adj_mfyp_mtd;
	}
	public String getPrev_adj_mfyp_mtd() {
		return prev_adj_mfyp_mtd;
	}
	public void setPrev_adj_mfyp_mtd(String prev_adj_mfyp_mtd) {
		this.prev_adj_mfyp_mtd = prev_adj_mfyp_mtd;
	}
	public String getCurr_adj_mfyp_qtd() {
		return curr_adj_mfyp_qtd;
	}
	public void setCurr_adj_mfyp_qtd(String curr_adj_mfyp_qtd) {
		this.curr_adj_mfyp_qtd = curr_adj_mfyp_qtd;
	}
	public String getPrev_adj_mfyp_qtd() {
		return prev_adj_mfyp_qtd;
	}
	public void setPrev_adj_mfyp_qtd(String prev_adj_mfyp_qtd) {
		this.prev_adj_mfyp_qtd = prev_adj_mfyp_qtd;
	}
	public String getCurr_adj_mfyp_ytd() {
		return curr_adj_mfyp_ytd;
	}
	public void setCurr_adj_mfyp_ytd(String curr_adj_mfyp_ytd) {
		this.curr_adj_mfyp_ytd = curr_adj_mfyp_ytd;
	}
	public String getPrev_adj_mfyp_ytd() {
		return prev_adj_mfyp_ytd;
	}
	public void setPrev_adj_mfyp_ytd(String prev_adj_mfyp_ytd) {
		this.prev_adj_mfyp_ytd = prev_adj_mfyp_ytd;
	}
	public String getPd_wip_adj_mfyp() {
		return pd_wip_adj_mfyp;
	}
	public void setPd_wip_adj_mfyp(String pd_wip_adj_mfyp) {
		this.pd_wip_adj_mfyp = pd_wip_adj_mfyp;
	}
	public String getMisc_wip_adj_mfyp() {
		return misc_wip_adj_mfyp;
	}
	public void setMisc_wip_adj_mfyp(String misc_wip_adj_mfyp) {
		this.misc_wip_adj_mfyp = misc_wip_adj_mfyp;
	}
	public String getO_banca_wip_adj_mfyp() {
		return o_banca_wip_adj_mfyp;
	}
	public void setO_banca_wip_adj_mfyp(String o_banca_wip_adj_mfyp) {
		this.o_banca_wip_adj_mfyp = o_banca_wip_adj_mfyp;
	}
}
