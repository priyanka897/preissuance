package com.qc.common.dto;

import java.io.Serializable;
public class SsoValidationProcDto implements Serializable{

	
	private static final long serialVersionUID = 6183907104881985779L;
	private String ssoid;
	private String	channel	;
	private String	sub_channel	;
	private String	designation_desc	;
	private String	zone	;
	private String	region	;
	private String	circle	;
	private String	clusters	;
	private String	go	;
	private String  cmo;
	private String  amo;
	public String getSsoid() {
		return ssoid;
	}
	public void setSsoid(String ssoid) {
		this.ssoid = ssoid;
	}
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public SsoValidationProcDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
