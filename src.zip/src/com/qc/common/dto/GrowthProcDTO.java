package com.qc.common.dto;

import java.io.Serializable;

public class GrowthProcDTO implements Serializable{

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 6183907104881985779L;
	private String	designation_desc	;
	private String	channel	;
	private String	sub_channel	;
	private String	zone	;
	private String	region	;
	private String	circle	;
	private String	clusters	;
	private String	go	;
	private String  cmo;
	private String  amo;
	private String	grth_lst_yr_inforced_cnt_ytd	;
	private String	ytd_inforced_cnt	;
	private String	prev_year_inforced_cnt_ytd	;
	private String	grth_lst_yr_inforced_cnt_mtd	;
	private String	mtd_inforced_cnt	;
	private String	prev_year_inforced_cnt_mtd	;
	private String	grth_lst_yr_sm_adj_mfyp_ytd	;
	private String	ytd_inforced_adj_mfyp	;
	private String	prev_year_adj_mfyp_ytd	;
	private String	grth_lst_yr_sm_adj_mfyp_mtd	;
	private String	mtd_inforced_adj_mfyp	;
	private String	prev_year_adj_mfyp_mtd	;
	private String	grth_lst_yr_sm_adj_afyp_ytd	;
	private String	ytd_inforced_adj_afyp	;
	private String	prev_year_adj_afyp_ytd	;
	private String	grth_lst_yr_sm_adj_afyp_mtd	;
	private String	mtd_inforced_adj_afyp	;
	private String	prev_year_adj_afyp_mtd	;
	private String	btch_timstamp	;
	private String	real_tim_timstamp	;
	private String	grth_applied_afyp_mtd	;
	private String	prev_applied_afyp_mtd	;
	private String	applied_afyp_mtd	;
	private String	grth_applied_adj_ifyp_mtd	;
	private String	applied_adj_ifyp_mtd	;
	private String	rpev_applied_adj_ifyp_mtd	;
	private String	grth_applied_cases_mtd	;
	private String	applied_cases_mtd	;
	private String	prev_applied_cases_mtd	;
	private String	grth_lpc_applied_cases_mtd	;
	private String	lpc_applied_cases_mtd	;
	private String	prev_lpc_applied_cases_mtd	;
	private String	grth_lpc_applied_adj_ifyp_mtd	;
	private String	lpc_applied_adj_ifyp_mtd	;
	private String	prev_lpc_applied_adj_ifyp_mtd	;
	private String	grth_lpc_applied_afyp_mtd	;
	private String	curr_lpc_applied_afyp_mtd	;
	private String	prev_lpc_applied_afyp_mtd	;
	private String	grth_lpc_paid_cases_mtd	;
	private String	lpc_paid_cases_mtd	;
	private String	prev_lpc_paid_cases_mtd	;
	private String	grth_lpc_paid_adj_mfyp_mtd	;
	private String	lpc_paid_adj_mfyp_mtd	;
	private String	prev_lpc_paid_adj_mfyp_mtd	;
	private String	grth_recruitment_mtd	;
	private String	recruitment_mtd	;
	private String	prev_recruitment_mtd	;
	private String	grth_case_size_afyp_mtd	;
	private String	case_size_afyp_mtd	;
	private String	prev_case_size_afyp_mtd	;
	private String	grth_prod_mix_adj_mfyp_mtd	;
	private String	prod_mix_adj_mfyp_mtd	;
	private String	prev_prod_mix_adj_mfyp_mtd	;
	private String	grth_prod_mix_paid_cases_mtd	;
	private String	prod_mix_paid_cases_mtd	;
	private String	prev_prod_mix_paid_cases_mtd	;
	private String	grth_mode_mix_adj_mfyp_mtd	;
	private String  mode_mix_adj_mfyp_mtd;
	private String  prev_mode_mix_adj_mfyp_mtd;
	private String	grth_applied_afyp_ytd	;
	private String	prev_applied_afyp_ytd	;
	private String	applied_afyp_ytd	;
	private String	grth_applied_adj_ifyp_ytd	;
	private String	applied_adj_ifyp_ytd	;
	private String	rpev_applied_adj_ifyp_ytd	;
	private String	grth_applied_cases_ytd	;
	private String	applied_cases_ytd	;
	private String	prev_applied_cases_ytd	;
	private String	grth_lpc_applied_cases_ytd	;
	private String	lpc_applied_cases_ytd	;
	private String	prev_lpc_applied_cases_ytd	;
	private String	grth_lpc_applied_adj_ifyp_ytd	;
	private String	lpc_applied_adj_ifyp_ytd	;
	private String	prev_lpc_applied_adj_ifyp_ytd	;
	private String	grth_lpc_applied_afyp_ytd	;
	private String	curr_lpc_applied_afyp_ytd	;
	private String	prev_lpc_applied_afyp_ytd	;
	private String	grth_lpc_paid_cases_ytd	;
	private String	lpc_paid_cases_ytd	;
	private String	prev_lpc_paid_cases_ytd	;
	private String	grth_lpc_paid_adj_mfyp_ytd	;
	private String	lpc_paid_adj_mfyp_ytd	;
	private String	prev_lpc_paid_adj_mfyp_ytd	;
	private String	grth_recruitment_ytd	;
	private String	recruitment_ytd	;
	private String	prev_recruitment_ytd	;
	private String	grth_case_size_afyp_ytd	;
	private String	case_size_afyp_ytd	;
	private String	prev_case_size_afyp_ytd	;
	private String	grth_prod_mix_adj_mfyp_ytd	;
	private String	prod_mix_adj_mfyp_ytd	;
	private String	prev_prod_mix_adj_mfyp_ytd	;
	private String	grth_prod_mix_paid_cases_ytd	;
	private String	prod_mix_paid_cases_ytd	;
	private String	prev_prod_mix_paid_cases_ytd	;
	private String	grth_mode_mix_adj_mfyp_ytd	;
	private String	mode_mix_adj_mfyp_ytd	;
	private String	prev_mode_mix_adj_mfyp_ytd	;

	public String getGrth_applied_afyp_mtd() {
		return grth_applied_afyp_mtd;
	}


	public void setGrth_applied_afyp_mtd(String grth_applied_afyp_mtd) {
		this.grth_applied_afyp_mtd = grth_applied_afyp_mtd;
	}


	public String getPrev_applied_afyp_mtd() {
		return prev_applied_afyp_mtd;
	}


	public void setPrev_applied_afyp_mtd(String prev_applied_afyp_mtd) {
		this.prev_applied_afyp_mtd = prev_applied_afyp_mtd;
	}


	public String getApplied_afyp_mtd() {
		return applied_afyp_mtd;
	}


	public void setApplied_afyp_mtd(String applied_afyp_mtd) {
		this.applied_afyp_mtd = applied_afyp_mtd;
	}


	public String getGrth_applied_adj_ifyp_mtd() {
		return grth_applied_adj_ifyp_mtd;
	}


	public void setGrth_applied_adj_ifyp_mtd(String grth_applied_adj_ifyp_mtd) {
		this.grth_applied_adj_ifyp_mtd = grth_applied_adj_ifyp_mtd;
	}


	public String getApplied_adj_ifyp_mtd() {
		return applied_adj_ifyp_mtd;
	}


	public void setApplied_adj_ifyp_mtd(String applied_adj_ifyp_mtd) {
		this.applied_adj_ifyp_mtd = applied_adj_ifyp_mtd;
	}


	public String getRpev_applied_adj_ifyp_mtd() {
		return rpev_applied_adj_ifyp_mtd;
	}


	public void setRpev_applied_adj_ifyp_mtd(String rpev_applied_adj_ifyp_mtd) {
		this.rpev_applied_adj_ifyp_mtd = rpev_applied_adj_ifyp_mtd;
	}


	public String getGrth_applied_cases_mtd() {
		return grth_applied_cases_mtd;
	}


	public void setGrth_applied_cases_mtd(String grth_applied_cases_mtd) {
		this.grth_applied_cases_mtd = grth_applied_cases_mtd;
	}


	public String getApplied_cases_mtd() {
		return applied_cases_mtd;
	}


	public void setApplied_cases_mtd(String applied_cases_mtd) {
		this.applied_cases_mtd = applied_cases_mtd;
	}


	public String getPrev_applied_cases_mtd() {
		return prev_applied_cases_mtd;
	}


	public void setPrev_applied_cases_mtd(String prev_applied_cases_mtd) {
		this.prev_applied_cases_mtd = prev_applied_cases_mtd;
	}


	public String getGrth_lpc_applied_cases_mtd() {
		return grth_lpc_applied_cases_mtd;
	}


	public void setGrth_lpc_applied_cases_mtd(String grth_lpc_applied_cases_mtd) {
		this.grth_lpc_applied_cases_mtd = grth_lpc_applied_cases_mtd;
	}


	public String getLpc_applied_cases_mtd() {
		return lpc_applied_cases_mtd;
	}


	public void setLpc_applied_cases_mtd(String lpc_applied_cases_mtd) {
		this.lpc_applied_cases_mtd = lpc_applied_cases_mtd;
	}


	public String getPrev_lpc_applied_cases_mtd() {
		return prev_lpc_applied_cases_mtd;
	}


	public void setPrev_lpc_applied_cases_mtd(String prev_lpc_applied_cases_mtd) {
		this.prev_lpc_applied_cases_mtd = prev_lpc_applied_cases_mtd;
	}


	public String getGrth_lpc_applied_adj_ifyp_mtd() {
		return grth_lpc_applied_adj_ifyp_mtd;
	}


	public void setGrth_lpc_applied_adj_ifyp_mtd(String grth_lpc_applied_adj_ifyp_mtd) {
		this.grth_lpc_applied_adj_ifyp_mtd = grth_lpc_applied_adj_ifyp_mtd;
	}


	public String getLpc_applied_adj_ifyp_mtd() {
		return lpc_applied_adj_ifyp_mtd;
	}


	public void setLpc_applied_adj_ifyp_mtd(String lpc_applied_adj_ifyp_mtd) {
		this.lpc_applied_adj_ifyp_mtd = lpc_applied_adj_ifyp_mtd;
	}


	public String getPrev_lpc_applied_adj_ifyp_mtd() {
		return prev_lpc_applied_adj_ifyp_mtd;
	}


	public void setPrev_lpc_applied_adj_ifyp_mtd(String prev_lpc_applied_adj_ifyp_mtd) {
		this.prev_lpc_applied_adj_ifyp_mtd = prev_lpc_applied_adj_ifyp_mtd;
	}


	public String getGrth_lpc_applied_afyp_mtd() {
		return grth_lpc_applied_afyp_mtd;
	}


	public void setGrth_lpc_applied_afyp_mtd(String grth_lpc_applied_afyp_mtd) {
		this.grth_lpc_applied_afyp_mtd = grth_lpc_applied_afyp_mtd;
	}


	public String getCurr_lpc_applied_afyp_mtd() {
		return curr_lpc_applied_afyp_mtd;
	}


	public void setCurr_lpc_applied_afyp_mtd(String curr_lpc_applied_afyp_mtd) {
		this.curr_lpc_applied_afyp_mtd = curr_lpc_applied_afyp_mtd;
	}


	public String getPrev_lpc_applied_afyp_mtd() {
		return prev_lpc_applied_afyp_mtd;
	}


	public void setPrev_lpc_applied_afyp_mtd(String prev_lpc_applied_afyp_mtd) {
		this.prev_lpc_applied_afyp_mtd = prev_lpc_applied_afyp_mtd;
	}


	public String getGrth_lpc_paid_cases_mtd() {
		return grth_lpc_paid_cases_mtd;
	}


	public void setGrth_lpc_paid_cases_mtd(String grth_lpc_paid_cases_mtd) {
		this.grth_lpc_paid_cases_mtd = grth_lpc_paid_cases_mtd;
	}


	public String getLpc_paid_cases_mtd() {
		return lpc_paid_cases_mtd;
	}


	public void setLpc_paid_cases_mtd(String lpc_paid_cases_mtd) {
		this.lpc_paid_cases_mtd = lpc_paid_cases_mtd;
	}


	public String getPrev_lpc_paid_cases_mtd() {
		return prev_lpc_paid_cases_mtd;
	}


	public void setPrev_lpc_paid_cases_mtd(String prev_lpc_paid_cases_mtd) {
		this.prev_lpc_paid_cases_mtd = prev_lpc_paid_cases_mtd;
	}


	public String getGrth_lpc_paid_adj_mfyp_mtd() {
		return grth_lpc_paid_adj_mfyp_mtd;
	}


	public void setGrth_lpc_paid_adj_mfyp_mtd(String grth_lpc_paid_adj_mfyp_mtd) {
		this.grth_lpc_paid_adj_mfyp_mtd = grth_lpc_paid_adj_mfyp_mtd;
	}


	public String getLpc_paid_adj_mfyp_mtd() {
		return lpc_paid_adj_mfyp_mtd;
	}


	public void setLpc_paid_adj_mfyp_mtd(String lpc_paid_adj_mfyp_mtd) {
		this.lpc_paid_adj_mfyp_mtd = lpc_paid_adj_mfyp_mtd;
	}


	public String getPrev_lpc_paid_adj_mfyp_mtd() {
		return prev_lpc_paid_adj_mfyp_mtd;
	}


	public void setPrev_lpc_paid_adj_mfyp_mtd(String prev_lpc_paid_adj_mfyp_mtd) {
		this.prev_lpc_paid_adj_mfyp_mtd = prev_lpc_paid_adj_mfyp_mtd;
	}


	public String getGrth_recruitment_mtd() {
		return grth_recruitment_mtd;
	}


	public void setGrth_recruitment_mtd(String grth_recruitment_mtd) {
		this.grth_recruitment_mtd = grth_recruitment_mtd;
	}


	public String getRecruitment_mtd() {
		return recruitment_mtd;
	}


	public void setRecruitment_mtd(String recruitment_mtd) {
		this.recruitment_mtd = recruitment_mtd;
	}


	public String getPrev_recruitment_mtd() {
		return prev_recruitment_mtd;
	}


	public void setPrev_recruitment_mtd(String prev_recruitment_mtd) {
		this.prev_recruitment_mtd = prev_recruitment_mtd;
	}


	public String getGrth_case_size_afyp_mtd() {
		return grth_case_size_afyp_mtd;
	}


	public void setGrth_case_size_afyp_mtd(String grth_case_size_afyp_mtd) {
		this.grth_case_size_afyp_mtd = grth_case_size_afyp_mtd;
	}


	public String getCase_size_afyp_mtd() {
		return case_size_afyp_mtd;
	}


	public void setCase_size_afyp_mtd(String case_size_afyp_mtd) {
		this.case_size_afyp_mtd = case_size_afyp_mtd;
	}


	public String getPrev_case_size_afyp_mtd() {
		return prev_case_size_afyp_mtd;
	}


	public void setPrev_case_size_afyp_mtd(String prev_case_size_afyp_mtd) {
		this.prev_case_size_afyp_mtd = prev_case_size_afyp_mtd;
	}


	public String getGrth_prod_mix_adj_mfyp_mtd() {
		return grth_prod_mix_adj_mfyp_mtd;
	}


	public void setGrth_prod_mix_adj_mfyp_mtd(String grth_prod_mix_adj_mfyp_mtd) {
		this.grth_prod_mix_adj_mfyp_mtd = grth_prod_mix_adj_mfyp_mtd;
	}


	public String getProd_mix_adj_mfyp_mtd() {
		return prod_mix_adj_mfyp_mtd;
	}


	public void setProd_mix_adj_mfyp_mtd(String prod_mix_adj_mfyp_mtd) {
		this.prod_mix_adj_mfyp_mtd = prod_mix_adj_mfyp_mtd;
	}


	public String getPrev_prod_mix_adj_mfyp_mtd() {
		return prev_prod_mix_adj_mfyp_mtd;
	}


	public void setPrev_prod_mix_adj_mfyp_mtd(String prev_prod_mix_adj_mfyp_mtd) {
		this.prev_prod_mix_adj_mfyp_mtd = prev_prod_mix_adj_mfyp_mtd;
	}


	public String getGrth_prod_mix_paid_cases_mtd() {
		return grth_prod_mix_paid_cases_mtd;
	}


	public void setGrth_prod_mix_paid_cases_mtd(String grth_prod_mix_paid_cases_mtd) {
		this.grth_prod_mix_paid_cases_mtd = grth_prod_mix_paid_cases_mtd;
	}


	public String getProd_mix_paid_cases_mtd() {
		return prod_mix_paid_cases_mtd;
	}


	public void setProd_mix_paid_cases_mtd(String prod_mix_paid_cases_mtd) {
		this.prod_mix_paid_cases_mtd = prod_mix_paid_cases_mtd;
	}


	public String getPrev_prod_mix_paid_cases_mtd() {
		return prev_prod_mix_paid_cases_mtd;
	}


	public void setPrev_prod_mix_paid_cases_mtd(String prev_prod_mix_paid_cases_mtd) {
		this.prev_prod_mix_paid_cases_mtd = prev_prod_mix_paid_cases_mtd;
	}


	public String getGrth_mode_mix_adj_mfyp_mtd() {
		return grth_mode_mix_adj_mfyp_mtd;
	}


	public void setGrth_mode_mix_adj_mfyp_mtd(String grth_mode_mix_adj_mfyp_mtd) {
		this.grth_mode_mix_adj_mfyp_mtd = grth_mode_mix_adj_mfyp_mtd;
	}


	public String getGrth_applied_afyp_ytd() {
		return grth_applied_afyp_ytd;
	}


	public void setGrth_applied_afyp_ytd(String grth_applied_afyp_ytd) {
		this.grth_applied_afyp_ytd = grth_applied_afyp_ytd;
	}


	public String getPrev_applied_afyp_ytd() {
		return prev_applied_afyp_ytd;
	}


	public void setPrev_applied_afyp_ytd(String prev_applied_afyp_ytd) {
		this.prev_applied_afyp_ytd = prev_applied_afyp_ytd;
	}


	public String getApplied_afyp_ytd() {
		return applied_afyp_ytd;
	}


	public void setApplied_afyp_ytd(String applied_afyp_ytd) {
		this.applied_afyp_ytd = applied_afyp_ytd;
	}


	public String getGrth_applied_adj_ifyp_ytd() {
		return grth_applied_adj_ifyp_ytd;
	}


	public void setGrth_applied_adj_ifyp_ytd(String grth_applied_adj_ifyp_ytd) {
		this.grth_applied_adj_ifyp_ytd = grth_applied_adj_ifyp_ytd;
	}


	public String getApplied_adj_ifyp_ytd() {
		return applied_adj_ifyp_ytd;
	}


	public void setApplied_adj_ifyp_ytd(String applied_adj_ifyp_ytd) {
		this.applied_adj_ifyp_ytd = applied_adj_ifyp_ytd;
	}


	public String getRpev_applied_adj_ifyp_ytd() {
		return rpev_applied_adj_ifyp_ytd;
	}


	public void setRpev_applied_adj_ifyp_ytd(String rpev_applied_adj_ifyp_ytd) {
		this.rpev_applied_adj_ifyp_ytd = rpev_applied_adj_ifyp_ytd;
	}


	public String getGrth_applied_cases_ytd() {
		return grth_applied_cases_ytd;
	}


	public void setGrth_applied_cases_ytd(String grth_applied_cases_ytd) {
		this.grth_applied_cases_ytd = grth_applied_cases_ytd;
	}


	public String getApplied_cases_ytd() {
		return applied_cases_ytd;
	}


	public void setApplied_cases_ytd(String applied_cases_ytd) {
		this.applied_cases_ytd = applied_cases_ytd;
	}


	public String getPrev_applied_cases_ytd() {
		return prev_applied_cases_ytd;
	}


	public void setPrev_applied_cases_ytd(String prev_applied_cases_ytd) {
		this.prev_applied_cases_ytd = prev_applied_cases_ytd;
	}


	public String getGrth_lpc_applied_cases_ytd() {
		return grth_lpc_applied_cases_ytd;
	}


	public void setGrth_lpc_applied_cases_ytd(String grth_lpc_applied_cases_ytd) {
		this.grth_lpc_applied_cases_ytd = grth_lpc_applied_cases_ytd;
	}


	public String getLpc_applied_cases_ytd() {
		return lpc_applied_cases_ytd;
	}


	public void setLpc_applied_cases_ytd(String lpc_applied_cases_ytd) {
		this.lpc_applied_cases_ytd = lpc_applied_cases_ytd;
	}


	public String getPrev_lpc_applied_cases_ytd() {
		return prev_lpc_applied_cases_ytd;
	}


	public void setPrev_lpc_applied_cases_ytd(String prev_lpc_applied_cases_ytd) {
		this.prev_lpc_applied_cases_ytd = prev_lpc_applied_cases_ytd;
	}


	public String getGrth_lpc_applied_adj_ifyp_ytd() {
		return grth_lpc_applied_adj_ifyp_ytd;
	}


	public void setGrth_lpc_applied_adj_ifyp_ytd(String grth_lpc_applied_adj_ifyp_ytd) {
		this.grth_lpc_applied_adj_ifyp_ytd = grth_lpc_applied_adj_ifyp_ytd;
	}


	public String getLpc_applied_adj_ifyp_ytd() {
		return lpc_applied_adj_ifyp_ytd;
	}


	public void setLpc_applied_adj_ifyp_ytd(String lpc_applied_adj_ifyp_ytd) {
		this.lpc_applied_adj_ifyp_ytd = lpc_applied_adj_ifyp_ytd;
	}


	public String getPrev_lpc_applied_adj_ifyp_ytd() {
		return prev_lpc_applied_adj_ifyp_ytd;
	}


	public void setPrev_lpc_applied_adj_ifyp_ytd(String prev_lpc_applied_adj_ifyp_ytd) {
		this.prev_lpc_applied_adj_ifyp_ytd = prev_lpc_applied_adj_ifyp_ytd;
	}


	public String getGrth_lpc_applied_afyp_ytd() {
		return grth_lpc_applied_afyp_ytd;
	}


	public void setGrth_lpc_applied_afyp_ytd(String grth_lpc_applied_afyp_ytd) {
		this.grth_lpc_applied_afyp_ytd = grth_lpc_applied_afyp_ytd;
	}


	public String getCurr_lpc_applied_afyp_ytd() {
		return curr_lpc_applied_afyp_ytd;
	}


	public void setCurr_lpc_applied_afyp_ytd(String curr_lpc_applied_afyp_ytd) {
		this.curr_lpc_applied_afyp_ytd = curr_lpc_applied_afyp_ytd;
	}


	public String getPrev_lpc_applied_afyp_ytd() {
		return prev_lpc_applied_afyp_ytd;
	}


	public void setPrev_lpc_applied_afyp_ytd(String prev_lpc_applied_afyp_ytd) {
		this.prev_lpc_applied_afyp_ytd = prev_lpc_applied_afyp_ytd;
	}


	public String getGrth_lpc_paid_cases_ytd() {
		return grth_lpc_paid_cases_ytd;
	}


	public void setGrth_lpc_paid_cases_ytd(String grth_lpc_paid_cases_ytd) {
		this.grth_lpc_paid_cases_ytd = grth_lpc_paid_cases_ytd;
	}


	public String getLpc_paid_cases_ytd() {
		return lpc_paid_cases_ytd;
	}


	public void setLpc_paid_cases_ytd(String lpc_paid_cases_ytd) {
		this.lpc_paid_cases_ytd = lpc_paid_cases_ytd;
	}


	public String getPrev_lpc_paid_cases_ytd() {
		return prev_lpc_paid_cases_ytd;
	}


	public void setPrev_lpc_paid_cases_ytd(String prev_lpc_paid_cases_ytd) {
		this.prev_lpc_paid_cases_ytd = prev_lpc_paid_cases_ytd;
	}


	public String getGrth_lpc_paid_adj_mfyp_ytd() {
		return grth_lpc_paid_adj_mfyp_ytd;
	}


	public void setGrth_lpc_paid_adj_mfyp_ytd(String grth_lpc_paid_adj_mfyp_ytd) {
		this.grth_lpc_paid_adj_mfyp_ytd = grth_lpc_paid_adj_mfyp_ytd;
	}


	public String getLpc_paid_adj_mfyp_ytd() {
		return lpc_paid_adj_mfyp_ytd;
	}


	public void setLpc_paid_adj_mfyp_ytd(String lpc_paid_adj_mfyp_ytd) {
		this.lpc_paid_adj_mfyp_ytd = lpc_paid_adj_mfyp_ytd;
	}


	public String getPrev_lpc_paid_adj_mfyp_ytd() {
		return prev_lpc_paid_adj_mfyp_ytd;
	}


	public void setPrev_lpc_paid_adj_mfyp_ytd(String prev_lpc_paid_adj_mfyp_ytd) {
		this.prev_lpc_paid_adj_mfyp_ytd = prev_lpc_paid_adj_mfyp_ytd;
	}


	public String getGrth_recruitment_ytd() {
		return grth_recruitment_ytd;
	}


	public void setGrth_recruitment_ytd(String grth_recruitment_ytd) {
		this.grth_recruitment_ytd = grth_recruitment_ytd;
	}


	public String getRecruitment_ytd() {
		return recruitment_ytd;
	}


	public void setRecruitment_ytd(String recruitment_ytd) {
		this.recruitment_ytd = recruitment_ytd;
	}


	public String getPrev_recruitment_ytd() {
		return prev_recruitment_ytd;
	}


	public void setPrev_recruitment_ytd(String prev_recruitment_ytd) {
		this.prev_recruitment_ytd = prev_recruitment_ytd;
	}


	public String getGrth_case_size_afyp_ytd() {
		return grth_case_size_afyp_ytd;
	}


	public void setGrth_case_size_afyp_ytd(String grth_case_size_afyp_ytd) {
		this.grth_case_size_afyp_ytd = grth_case_size_afyp_ytd;
	}


	public String getCase_size_afyp_ytd() {
		return case_size_afyp_ytd;
	}


	public void setCase_size_afyp_ytd(String case_size_afyp_ytd) {
		this.case_size_afyp_ytd = case_size_afyp_ytd;
	}


	public String getPrev_case_size_afyp_ytd() {
		return prev_case_size_afyp_ytd;
	}


	public void setPrev_case_size_afyp_ytd(String prev_case_size_afyp_ytd) {
		this.prev_case_size_afyp_ytd = prev_case_size_afyp_ytd;
	}


	public String getGrth_prod_mix_adj_mfyp_ytd() {
		return grth_prod_mix_adj_mfyp_ytd;
	}


	public void setGrth_prod_mix_adj_mfyp_ytd(String grth_prod_mix_adj_mfyp_ytd) {
		this.grth_prod_mix_adj_mfyp_ytd = grth_prod_mix_adj_mfyp_ytd;
	}


	public String getProd_mix_adj_mfyp_ytd() {
		return prod_mix_adj_mfyp_ytd;
	}


	public void setProd_mix_adj_mfyp_ytd(String prod_mix_adj_mfyp_ytd) {
		this.prod_mix_adj_mfyp_ytd = prod_mix_adj_mfyp_ytd;
	}


	public String getPrev_prod_mix_adj_mfyp_ytd() {
		return prev_prod_mix_adj_mfyp_ytd;
	}


	public void setPrev_prod_mix_adj_mfyp_ytd(String prev_prod_mix_adj_mfyp_ytd) {
		this.prev_prod_mix_adj_mfyp_ytd = prev_prod_mix_adj_mfyp_ytd;
	}


	public String getGrth_prod_mix_paid_cases_ytd() {
		return grth_prod_mix_paid_cases_ytd;
	}


	public void setGrth_prod_mix_paid_cases_ytd(String grth_prod_mix_paid_cases_ytd) {
		this.grth_prod_mix_paid_cases_ytd = grth_prod_mix_paid_cases_ytd;
	}


	public String getProd_mix_paid_cases_ytd() {
		return prod_mix_paid_cases_ytd;
	}


	public void setProd_mix_paid_cases_ytd(String prod_mix_paid_cases_ytd) {
		this.prod_mix_paid_cases_ytd = prod_mix_paid_cases_ytd;
	}


	public String getPrev_prod_mix_paid_cases_ytd() {
		return prev_prod_mix_paid_cases_ytd;
	}


	public void setPrev_prod_mix_paid_cases_ytd(String prev_prod_mix_paid_cases_ytd) {
		this.prev_prod_mix_paid_cases_ytd = prev_prod_mix_paid_cases_ytd;
	}


	public String getGrth_mode_mix_adj_mfyp_ytd() {
		return grth_mode_mix_adj_mfyp_ytd;
	}


	public void setGrth_mode_mix_adj_mfyp_ytd(String grth_mode_mix_adj_mfyp_ytd) {
		this.grth_mode_mix_adj_mfyp_ytd = grth_mode_mix_adj_mfyp_ytd;
	}


	public String getMode_mix_adj_mfyp_ytd() {
		return mode_mix_adj_mfyp_ytd;
	}


	public void setMode_mix_adj_mfyp_ytd(String mode_mix_adj_mfyp_ytd) {
		this.mode_mix_adj_mfyp_ytd = mode_mix_adj_mfyp_ytd;
	}


	public String getPrev_mode_mix_adj_mfyp_ytd() {
		return prev_mode_mix_adj_mfyp_ytd;
	}


	public void setPrev_mode_mix_adj_mfyp_ytd(String prev_mode_mix_adj_mfyp_ytd) {
		this.prev_mode_mix_adj_mfyp_ytd = prev_mode_mix_adj_mfyp_ytd;
	}

	
	

	public String getDesignation_desc() {
		return designation_desc;
	}


	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}


	public String getCmo() {
		return cmo;
	}


	public void setCmo(String cmo) {
		this.cmo = cmo;
	}


	public String getAmo() {
		return amo;
	}


	public void setAmo(String amo) {
		this.amo = amo;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getSub_channel() {
		return sub_channel;
	}


	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}


	public String getZone() {
		return zone;
	}


	public void setZone(String zone) {
		this.zone = zone;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public String getCircle() {
		return circle;
	}


	public void setCircle(String circle) {
		this.circle = circle;
	}


	public String getClusters() {
		return clusters;
	}


	public void setClusters(String clusters) {
		this.clusters = clusters;
	}


	public String getGo() {
		return go;
	}


	public void setGo(String go) {
		this.go = go;
	}


	/*public String getBranch_code() {
		return branch_code;
	}


	public void setBranch_code(String branch_code) {
		this.branch_code = branch_code;
	}*/


	public String getGrth_lst_yr_inforced_cnt_ytd() {
		return grth_lst_yr_inforced_cnt_ytd;
	}


	public void setGrth_lst_yr_inforced_cnt_ytd(String grth_lst_yr_inforced_cnt_ytd) {
		this.grth_lst_yr_inforced_cnt_ytd = grth_lst_yr_inforced_cnt_ytd;
	}


	public String getYtd_inforced_cnt() {
		return ytd_inforced_cnt;
	}


	public void setYtd_inforced_cnt(String ytd_inforced_cnt) {
		this.ytd_inforced_cnt = ytd_inforced_cnt;
	}


	public String getPrev_year_inforced_cnt_ytd() {
		return prev_year_inforced_cnt_ytd;
	}


	public void setPrev_year_inforced_cnt_ytd(String prev_year_inforced_cnt_ytd) {
		this.prev_year_inforced_cnt_ytd = prev_year_inforced_cnt_ytd;
	}


	public String getGrth_lst_yr_inforced_cnt_mtd() {
		return grth_lst_yr_inforced_cnt_mtd;
	}


	public void setGrth_lst_yr_inforced_cnt_mtd(String grth_lst_yr_inforced_cnt_mtd) {
		this.grth_lst_yr_inforced_cnt_mtd = grth_lst_yr_inforced_cnt_mtd;
	}


	public String getMtd_inforced_cnt() {
		return mtd_inforced_cnt;
	}


	public void setMtd_inforced_cnt(String mtd_inforced_cnt) {
		this.mtd_inforced_cnt = mtd_inforced_cnt;
	}


	public String getPrev_year_inforced_cnt_mtd() {
		return prev_year_inforced_cnt_mtd;
	}


	public void setPrev_year_inforced_cnt_mtd(String prev_year_inforced_cnt_mtd) {
		this.prev_year_inforced_cnt_mtd = prev_year_inforced_cnt_mtd;
	}


	public String getGrth_lst_yr_sm_adj_mfyp_ytd() {
		return grth_lst_yr_sm_adj_mfyp_ytd;
	}


	public void setGrth_lst_yr_sm_adj_mfyp_ytd(String grth_lst_yr_sm_adj_mfyp_ytd) {
		this.grth_lst_yr_sm_adj_mfyp_ytd = grth_lst_yr_sm_adj_mfyp_ytd;
	}


	public String getYtd_inforced_adj_mfyp() {
		return ytd_inforced_adj_mfyp;
	}


	public void setYtd_inforced_adj_mfyp(String ytd_inforced_adj_mfyp) {
		this.ytd_inforced_adj_mfyp = ytd_inforced_adj_mfyp;
	}


	public String getPrev_year_adj_mfyp_ytd() {
		return prev_year_adj_mfyp_ytd;
	}


	public void setPrev_year_adj_mfyp_ytd(String prev_year_adj_mfyp_ytd) {
		this.prev_year_adj_mfyp_ytd = prev_year_adj_mfyp_ytd;
	}


	public String getGrth_lst_yr_sm_adj_mfyp_mtd() {
		return grth_lst_yr_sm_adj_mfyp_mtd;
	}


	public void setGrth_lst_yr_sm_adj_mfyp_mtd(String grth_lst_yr_sm_adj_mfyp_mtd) {
		this.grth_lst_yr_sm_adj_mfyp_mtd = grth_lst_yr_sm_adj_mfyp_mtd;
	}


	public String getMtd_inforced_adj_mfyp() {
		return mtd_inforced_adj_mfyp;
	}


	public void setMtd_inforced_adj_mfyp(String mtd_inforced_adj_mfyp) {
		this.mtd_inforced_adj_mfyp = mtd_inforced_adj_mfyp;
	}


	public String getPrev_year_adj_mfyp_mtd() {
		return prev_year_adj_mfyp_mtd;
	}


	public void setPrev_year_adj_mfyp_mtd(String prev_year_adj_mfyp_mtd) {
		this.prev_year_adj_mfyp_mtd = prev_year_adj_mfyp_mtd;
	}


	public String getGrth_lst_yr_sm_adj_afyp_ytd() {
		return grth_lst_yr_sm_adj_afyp_ytd;
	}


	public void setGrth_lst_yr_sm_adj_afyp_ytd(String grth_lst_yr_sm_adj_afyp_ytd) {
		this.grth_lst_yr_sm_adj_afyp_ytd = grth_lst_yr_sm_adj_afyp_ytd;
	}


	public String getYtd_inforced_adj_afyp() {
		return ytd_inforced_adj_afyp;
	}


	public void setYtd_inforced_adj_afyp(String ytd_inforced_adj_afyp) {
		this.ytd_inforced_adj_afyp = ytd_inforced_adj_afyp;
	}


	public String getPrev_year_adj_afyp_ytd() {
		return prev_year_adj_afyp_ytd;
	}


	public void setPrev_year_adj_afyp_ytd(String prev_year_adj_afyp_ytd) {
		this.prev_year_adj_afyp_ytd = prev_year_adj_afyp_ytd;
	}


	public String getGrth_lst_yr_sm_adj_afyp_mtd() {
		return grth_lst_yr_sm_adj_afyp_mtd;
	}


	public void setGrth_lst_yr_sm_adj_afyp_mtd(String grth_lst_yr_sm_adj_afyp_mtd) {
		this.grth_lst_yr_sm_adj_afyp_mtd = grth_lst_yr_sm_adj_afyp_mtd;
	}


	public String getMtd_inforced_adj_afyp() {
		return mtd_inforced_adj_afyp;
	}


	public void setMtd_inforced_adj_afyp(String mtd_inforced_adj_afyp) {
		this.mtd_inforced_adj_afyp = mtd_inforced_adj_afyp;
	}


	public String getPrev_year_adj_afyp_mtd() {
		return prev_year_adj_afyp_mtd;
	}


	public void setPrev_year_adj_afyp_mtd(String prev_year_adj_afyp_mtd) {
		this.prev_year_adj_afyp_mtd = prev_year_adj_afyp_mtd;
	}


	public String getBtch_timstamp() {
		return btch_timstamp;
	}


	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}


	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}


	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public String getMode_mix_adj_mfyp_mtd() {
		return mode_mix_adj_mfyp_mtd;
	}


	public void setMode_mix_adj_mfyp_mtd(String mode_mix_adj_mfyp_mtd) {
		this.mode_mix_adj_mfyp_mtd = mode_mix_adj_mfyp_mtd;
	}


	public String getPrev_mode_mix_adj_mfyp_mtd() {
		return prev_mode_mix_adj_mfyp_mtd;
	}


	public void setPrev_mode_mix_adj_mfyp_mtd(String prev_mode_mix_adj_mfyp_mtd) {
		this.prev_mode_mix_adj_mfyp_mtd = prev_mode_mix_adj_mfyp_mtd;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public GrowthProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}





