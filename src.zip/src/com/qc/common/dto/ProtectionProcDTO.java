package com.qc.common.dto;

import java.io.Serializable;
public class ProtectionProcDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	private String	designation_code	;
	private String	channel	;
	private	String	sub_channel	;
	private String	zone	;
	private String	region	;
	private String	circle	;
	private String	clusters	;
	private String	go	;
	private String	branch_code	;
	private String	protec_achiv_adj_mfyp_ytd	;
	private String	protec_achiv_adj_mfyp_ytd_pln	;
	private String	protec_achiv_adj_mfyp_ytd_act	;
	private String	protec_achiv_adj_mfyp_mtd	;
	private String	protec_achiv_adj_mfyp_mtd_pln	;
	private String	protec_achiv_adj_mfyp_mtd_act	;
	private String	btch_timstamp	;
	private String	real_tim_timstamp	;
	public String getDesignation_code() {
		return designation_code;
	}


	public void setDesignation_code(String designation_code) {
		this.designation_code = designation_code;
	}


	public String getChannel() {
		return channel;
	}


	public void setChannel(String channel) {
		this.channel = channel;
	}


	public String getSub_channel() {
		return sub_channel;
	}


	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}


	public String getZone() {
		return zone;
	}


	public void setZone(String zone) {
		this.zone = zone;
	}


	public String getRegion() {
		return region;
	}


	public void setRegion(String region) {
		this.region = region;
	}


	public String getCircle() {
		return circle;
	}


	public void setCircle(String circle) {
		this.circle = circle;
	}


	public String getClusters() {
		return clusters;
	}


	public void setClusters(String clusters) {
		this.clusters = clusters;
	}


	public String getGo() {
		return go;
	}


	public void setGo(String go) {
		this.go = go;
	}


	public String getBranch_code() {
		return branch_code;
	}


	public void setBranch_code(String branch_code) {
		this.branch_code = branch_code;
	}


	public String getProtec_achiv_adj_mfyp_ytd() {
		return protec_achiv_adj_mfyp_ytd;
	}


	public void setProtec_achiv_adj_mfyp_ytd(String protec_achiv_adj_mfyp_ytd) {
		this.protec_achiv_adj_mfyp_ytd = protec_achiv_adj_mfyp_ytd;
	}


	public String getProtec_achiv_adj_mfyp_ytd_pln() {
		return protec_achiv_adj_mfyp_ytd_pln;
	}


	public void setProtec_achiv_adj_mfyp_ytd_pln(String protec_achiv_adj_mfyp_ytd_pln) {
		this.protec_achiv_adj_mfyp_ytd_pln = protec_achiv_adj_mfyp_ytd_pln;
	}


	public String getProtec_achiv_adj_mfyp_ytd_act() {
		return protec_achiv_adj_mfyp_ytd_act;
	}


	public void setProtec_achiv_adj_mfyp_ytd_act(String protec_achiv_adj_mfyp_ytd_act) {
		this.protec_achiv_adj_mfyp_ytd_act = protec_achiv_adj_mfyp_ytd_act;
	}


	public String getProtec_achiv_adj_mfyp_mtd() {
		return protec_achiv_adj_mfyp_mtd;
	}


	public void setProtec_achiv_adj_mfyp_mtd(String protec_achiv_adj_mfyp_mtd) {
		this.protec_achiv_adj_mfyp_mtd = protec_achiv_adj_mfyp_mtd;
	}


	public String getProtec_achiv_adj_mfyp_mtd_pln() {
		return protec_achiv_adj_mfyp_mtd_pln;
	}


	public void setProtec_achiv_adj_mfyp_mtd_pln(String protec_achiv_adj_mfyp_mtd_pln) {
		this.protec_achiv_adj_mfyp_mtd_pln = protec_achiv_adj_mfyp_mtd_pln;
	}


	public String getProtec_achiv_adj_mfyp_mtd_act() {
		return protec_achiv_adj_mfyp_mtd_act;
	}


	public void setProtec_achiv_adj_mfyp_mtd_act(String protec_achiv_adj_mfyp_mtd_act) {
		this.protec_achiv_adj_mfyp_mtd_act = protec_achiv_adj_mfyp_mtd_act;
	}


	public String getBtch_timstamp() {
		return btch_timstamp;
	}


	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}


	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}


	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	
	public ProtectionProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
