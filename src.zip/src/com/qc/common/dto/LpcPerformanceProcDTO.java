package com.qc.common.dto;

import java.io.Serializable;

public class LpcPerformanceProcDTO implements Serializable {

	private static final long serialVersionUID = -8094626407284463507L;
	private String	designation_desc	;
	private	String	channel	;
	private	String	sub_channel	;
	private	String	zone	;
	private	String	region	;
	private	String	circle	;
	private	String	clusters	;
	private	String	go	;
	private String  cmo;
	private String  amo;
	private	String	lpc_applied_cases_mtd	;
	private	String	lpc_applied_adj_ifyp_mtd	;
	private	String	lpc_applied_afyp_mtd	;
	private	String	lpc_paid_cases_mtd	;
	private	String	lpc_paid_adj_mfyp_mtd	;
	private	String	lpc_applied_cases_ytd	;
	private	String	lpc_applied_adj_ifyp_ytd	;
	private	String	lpc_applied_afyp_ytd	;
	private	String	lpc_paid_cases_ytd	;
	private	String	lpc_paid_adj_mfyp_ytd	;
	private	String	btch_timstamp	;
	private	String	real_tim_timstamp	;

	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getLpc_applied_cases_mtd() {
		return lpc_applied_cases_mtd;
	}
	public void setLpc_applied_cases_mtd(String lpc_applied_cases_mtd) {
		this.lpc_applied_cases_mtd = lpc_applied_cases_mtd;
	}
	public String getLpc_applied_adj_ifyp_mtd() {
		return lpc_applied_adj_ifyp_mtd;
	}
	public void setLpc_applied_adj_ifyp_mtd(String lpc_applied_adj_ifyp_mtd) {
		this.lpc_applied_adj_ifyp_mtd = lpc_applied_adj_ifyp_mtd;
	}
	public String getLpc_applied_afyp_mtd() {
		return lpc_applied_afyp_mtd;
	}
	public void setLpc_applied_afyp_mtd(String lpc_applied_afyp_mtd) {
		this.lpc_applied_afyp_mtd = lpc_applied_afyp_mtd;
	}
	public String getLpc_paid_cases_mtd() {
		return lpc_paid_cases_mtd;
	}
	public void setLpc_paid_cases_mtd(String lpc_paid_cases_mtd) {
		this.lpc_paid_cases_mtd = lpc_paid_cases_mtd;
	}
	public String getLpc_paid_adj_mfyp_mtd() {
		return lpc_paid_adj_mfyp_mtd;
	}
	public void setLpc_paid_adj_mfyp_mtd(String lpc_paid_adj_mfyp_mtd) {
		this.lpc_paid_adj_mfyp_mtd = lpc_paid_adj_mfyp_mtd;
	}
	public String getLpc_applied_cases_ytd() {
		return lpc_applied_cases_ytd;
	}
	public void setLpc_applied_cases_ytd(String lpc_applied_cases_ytd) {
		this.lpc_applied_cases_ytd = lpc_applied_cases_ytd;
	}
	public String getLpc_applied_adj_ifyp_ytd() {
		return lpc_applied_adj_ifyp_ytd;
	}
	public void setLpc_applied_adj_ifyp_ytd(String lpc_applied_adj_ifyp_ytd) {
		this.lpc_applied_adj_ifyp_ytd = lpc_applied_adj_ifyp_ytd;
	}
	public String getLpc_applied_afyp_ytd() {
		return lpc_applied_afyp_ytd;
	}
	public void setLpc_applied_afyp_ytd(String lpc_applied_afyp_ytd) {
		this.lpc_applied_afyp_ytd = lpc_applied_afyp_ytd;
	}
	public String getLpc_paid_adj_mfyp_ytd() {
		return lpc_paid_adj_mfyp_ytd;
	}
	public void setLpc_paid_adj_mfyp_ytd(String lpc_paid_adj_mfyp_ytd) {
		this.lpc_paid_adj_mfyp_ytd = lpc_paid_adj_mfyp_ytd;
	}
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getLpc_paid_cases_ytd() {
		return lpc_paid_cases_ytd;
	}
	public void setLpc_paid_cases_ytd(String lpc_paid_cases_ytd) {
		this.lpc_paid_cases_ytd = lpc_paid_cases_ytd;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
		public LpcPerformanceProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}


