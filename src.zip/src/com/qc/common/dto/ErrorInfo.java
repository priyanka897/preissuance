package com.qc.common.dto;

import java.io.Serializable;

public class ErrorInfo implements Serializable 
{
	private static final long serialVersionUID = -2183001514591673307L;
	private Integer code;
	private ERRORSTATUS status;
	private String message;
	private String description;

	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public ERRORSTATUS getStatus() {
		return status;
	}

	public void setStatus(ERRORSTATUS status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "ErrorInfo [code=" + code + ", status=" + status + ", message=" + message + ", description="
				+ description + "]";
	}

}
