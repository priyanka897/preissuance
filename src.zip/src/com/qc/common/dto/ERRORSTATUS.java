package com.qc.common.dto;

public enum ERRORSTATUS {

	SUCCESS,FAILURE
}
