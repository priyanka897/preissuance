package com.qc.common.dto;

import java.io.Serializable;

public class PaidProcDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String daily_inforced_afyp;
	private String daily_inforced_count;
	private String daily_adj_mfyp;
	private String mtd_inforced_afyp;
	private String mtd_inforced_count;
	private String mtd_adj_mfyp;
	private String ytd_inforced_afyp;
	private String ytd_inforced_count;
	private String ytd_adj_mfyp;
	private String btch_timstamp;
	private String real_tim_timstamp;

	public String getDesignation_desc() {
		return designation_desc;
	}

	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}

	public String getCmo() {
		return cmo;
	}

	public void setCmo(String cmo) {
		this.cmo = cmo;
	}

	public String getAmo() {
		return amo;
	}

	public void setAmo(String amo) {
		this.amo = amo;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getClusters() {
		return clusters;
	}

	public void setClusters(String clusters) {
		this.clusters = clusters;
	}

	public String getGo() {
		return go;
	}

	public void setGo(String go) {
		this.go = go;
	}

	public String getDaily_inforced_afyp() {
		return daily_inforced_afyp;
	}

	public void setDaily_inforced_afyp(String daily_inforced_afyp) {
		this.daily_inforced_afyp = daily_inforced_afyp;
	}

	public String getDaily_inforced_count() {
		return daily_inforced_count;
	}

	public void setDaily_inforced_count(String daily_inforced_count) {
		this.daily_inforced_count = daily_inforced_count;
	}

	public String getDaily_adj_mfyp() {
		return daily_adj_mfyp;
	}

	public void setDaily_adj_mfyp(String daily_adj_mfyp) {
		this.daily_adj_mfyp = daily_adj_mfyp;
	}

	public String getMtd_inforced_afyp() {
		return mtd_inforced_afyp;
	}

	public void setMtd_inforced_afyp(String mtd_inforced_afyp) {
		this.mtd_inforced_afyp = mtd_inforced_afyp;
	}

	public String getMtd_inforced_count() {
		return mtd_inforced_count;
	}

	public void setMtd_inforced_count(String mtd_inforced_count) {
		this.mtd_inforced_count = mtd_inforced_count;
	}

	public String getMtd_adj_mfyp() {
		return mtd_adj_mfyp;
	}

	public void setMtd_adj_mfyp(String mtd_adj_mfyp) {
		this.mtd_adj_mfyp = mtd_adj_mfyp;
	}

	public String getYtd_inforced_afyp() {
		return ytd_inforced_afyp;
	}

	public void setYtd_inforced_afyp(String ytd_inforced_afyp) {
		this.ytd_inforced_afyp = ytd_inforced_afyp;
	}

	public String getYtd_inforced_count() {
		return ytd_inforced_count;
	}

	public void setYtd_inforced_count(String ytd_inforced_count) {
		this.ytd_inforced_count = ytd_inforced_count;
	}

	public String getYtd_adj_mfyp() {
		return ytd_adj_mfyp;
	}

	public void setYtd_adj_mfyp(String ytd_adj_mfyp) {
		this.ytd_adj_mfyp = ytd_adj_mfyp;
	}

	public String getBtch_timstamp() {
		return btch_timstamp;
	}

	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}

	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}

	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public PaidProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
