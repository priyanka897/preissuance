package com.qc.common.dto;

import java.io.Serializable;

public class AppliedProcDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private String designation_desc;
	private String channel;
	private String sub_channel;
	private String zone;
	private String region;
	private String circle;
	private String clusters;
	private String go;
	private String cmo;
	private String amo;
	private String daily_applied_afyp;
	private String daily_applied_count;
	private String mtd_applied_afyp;
	private String mtd_applied_count;
	private String ytd_applied_afyp;
	private String ytd_applied_count;
	private String btch_timstamp;
	private String real_tim_timstamp;
	private String mtd_applied_adj_ifyp;
	private String ytd_applied_adj_ifyp;
	private String daily_applied_adj_ifyp;

	public String getMtd_applied_adj_ifyp() {
		return mtd_applied_adj_ifyp;
	}

	public void setMtd_applied_adj_ifyp(String mtd_applied_adj_ifyp) {
		this.mtd_applied_adj_ifyp = mtd_applied_adj_ifyp;
	}

	public String getYtd_applied_adj_ifyp() {
		return ytd_applied_adj_ifyp;
	}

	public void setYtd_applied_adj_ifyp(String ytd_applied_adj_ifyp) {
		this.ytd_applied_adj_ifyp = ytd_applied_adj_ifyp;
	}

	public String getDesignation_desc() {
		return designation_desc;
	}

	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}

	public String getCmo() {
		return cmo;
	}

	public void setCmo(String cmo) {
		this.cmo = cmo;
	}

	public String getAmo() {
		return amo;
	}

	public void setAmo(String amo) {
		this.amo = amo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getSub_channel() {
		return sub_channel;
	}

	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public String getClusters() {
		return clusters;
	}

	public void setClusters(String clusters) {
		this.clusters = clusters;
	}

	public String getGo() {
		return go;
	}

	public void setGo(String go) {
		this.go = go;
	}

	public String getDaily_applied_afyp() {
		return daily_applied_afyp;
	}

	public void setDaily_applied_afyp(String daily_applied_afyp) {
		this.daily_applied_afyp = daily_applied_afyp;
	}

	public String getDaily_applied_count() {
		return daily_applied_count;
	}

	public void setDaily_applied_count(String daily_applied_count) {
		this.daily_applied_count = daily_applied_count;
	}

	public String getMtd_applied_afyp() {
		return mtd_applied_afyp;
	}

	public void setMtd_applied_afyp(String mtd_applied_afyp) {
		this.mtd_applied_afyp = mtd_applied_afyp;
	}

	public String getMtd_applied_count() {
		return mtd_applied_count;
	}

	public void setMtd_applied_count(String mtd_applied_count) {
		this.mtd_applied_count = mtd_applied_count;
	}

	public String getYtd_applied_afyp() {
		return ytd_applied_afyp;
	}

	public void setYtd_applied_afyp(String ytd_applied_afyp) {
		this.ytd_applied_afyp = ytd_applied_afyp;
	}

	public String getYtd_applied_count() {
		return ytd_applied_count;
	}

	public void setYtd_applied_count(String ytd_applied_count) {
		this.ytd_applied_count = ytd_applied_count;
	}

	public String getBtch_timstamp() {
		return btch_timstamp;
	}

	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}

	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}

	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}

	public String getDaily_applied_adj_ifyp() {
		return daily_applied_adj_ifyp;
	}

	public void setDaily_applied_adj_ifyp(String daily_applied_adj_ifyp) {
		this.daily_applied_adj_ifyp = daily_applied_adj_ifyp;
	}

	public AppliedProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}
