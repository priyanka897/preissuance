package com.qc.common.dto;

import java.io.Serializable;
public class ModeMixProcDTO implements Serializable{

	private static final long serialVersionUID = 6183907104881985779L;	
	private	String	designation_desc	;
	private	String	channel	;
	private	String	sub_channel	;
	private	String	zone	;
	private	String	region	;
	private	String	circle	;
	private	String	clusters	;
	private	String	go	;
	private	String	cmo	;
	private	String	amo	;
	private	String	annual_adj_mfyp_mtd	;
	private	String	semi_annual_adj_mfyp_mtd	;
	private	String	quarterly_adj_mfyp_mtd	;
	private	String	monthly_adj_mfyp_mtd	;
	private	String	single_adj_mfyp_mtd	;
	private	String	annual_adj_mfyp_ytd	;
	private	String	semi_annual_adj_mfyp_ytd	;
	private	String	quarterly_adj_mfyp_ytd	;
	private	String	monthly_adj_mfyp_ytd	;
	private	String	single_adj_mfyp_ytd	;
	private	String	btch_timstamp	;
	private	String	real_tim_timstamp	;
	
	public String getDesignation_desc() {
		return designation_desc;
	}
	public void setDesignation_desc(String designation_desc) {
		this.designation_desc = designation_desc;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getSub_channel() {
		return sub_channel;
	}
	public void setSub_channel(String sub_channel) {
		this.sub_channel = sub_channel;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getClusters() {
		return clusters;
	}
	public void setClusters(String clusters) {
		this.clusters = clusters;
	}
	public String getGo() {
		return go;
	}
	public void setGo(String go) {
		this.go = go;
	}
	public String getCmo() {
		return cmo;
	}
	public void setCmo(String cmo) {
		this.cmo = cmo;
	}
	public String getAmo() {
		return amo;
	}
	public void setAmo(String amo) {
		this.amo = amo;
	}
	public String getAnnual_adj_mfyp_mtd() {
		return annual_adj_mfyp_mtd;
	}
	public void setAnnual_adj_mfyp_mtd(String annual_adj_mfyp_mtd) {
		this.annual_adj_mfyp_mtd = annual_adj_mfyp_mtd;
	}
	public String getSemi_annual_adj_mfyp_mtd() {
		return semi_annual_adj_mfyp_mtd;
	}
	public void setSemi_annual_adj_mfyp_mtd(String semi_annual_adj_mfyp_mtd) {
		this.semi_annual_adj_mfyp_mtd = semi_annual_adj_mfyp_mtd;
	}
	public String getQuarterly_adj_mfyp_mtd() {
		return quarterly_adj_mfyp_mtd;
	}
	public void setQuarterly_adj_mfyp_mtd(String quarterly_adj_mfyp_mtd) {
		this.quarterly_adj_mfyp_mtd = quarterly_adj_mfyp_mtd;
	}
	public String getMonthly_adj_mfyp_mtd() {
		return monthly_adj_mfyp_mtd;
	}
	public void setMonthly_adj_mfyp_mtd(String monthly_adj_mfyp_mtd) {
		this.monthly_adj_mfyp_mtd = monthly_adj_mfyp_mtd;
	}
	public String getSingle_adj_mfyp_mtd() {
		return single_adj_mfyp_mtd;
	}
	public void setSingle_adj_mfyp_mtd(String single_adj_mfyp_mtd) {
		this.single_adj_mfyp_mtd = single_adj_mfyp_mtd;
	}
	public String getAnnual_adj_mfyp_ytd() {
		return annual_adj_mfyp_ytd;
	}
	public void setAnnual_adj_mfyp_ytd(String annual_adj_mfyp_ytd) {
		this.annual_adj_mfyp_ytd = annual_adj_mfyp_ytd;
	}
	public String getSemi_annual_adj_mfyp_ytd() {
		return semi_annual_adj_mfyp_ytd;
	}
	public void setSemi_annual_adj_mfyp_ytd(String semi_annual_adj_mfyp_ytd) {
		this.semi_annual_adj_mfyp_ytd = semi_annual_adj_mfyp_ytd;
	}
	public String getQuarterly_adj_mfyp_ytd() {
		return quarterly_adj_mfyp_ytd;
	}
	public void setQuarterly_adj_mfyp_ytd(String quarterly_adj_mfyp_ytd) {
		this.quarterly_adj_mfyp_ytd = quarterly_adj_mfyp_ytd;
	}
	public String getMonthly_adj_mfyp_ytd() {
		return monthly_adj_mfyp_ytd;
	}
	public void setMonthly_adj_mfyp_ytd(String monthly_adj_mfyp_ytd) {
		this.monthly_adj_mfyp_ytd = monthly_adj_mfyp_ytd;
	}
	public String getSingle_adj_mfyp_ytd() {
		return single_adj_mfyp_ytd;
	}
	public void setSingle_adj_mfyp_ytd(String single_adj_mfyp_ytd) {
		this.single_adj_mfyp_ytd = single_adj_mfyp_ytd;
	}
	public String getBtch_timstamp() {
		return btch_timstamp;
	}
	public void setBtch_timstamp(String btch_timstamp) {
		this.btch_timstamp = btch_timstamp;
	}
	public String getReal_tim_timstamp() {
		return real_tim_timstamp;
	}
	public void setReal_tim_timstamp(String real_tim_timstamp) {
		this.real_tim_timstamp = real_tim_timstamp;
	}
	

	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public ModeMixProcDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}

