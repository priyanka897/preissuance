package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.request.getneopincodecity.ApiRequestNeoPincodeCity;
import com.qc.api.response.StringConstants;
import com.qc.api.response.getneftdetails.ApiResponseNeftDetails;
import com.qc.api.response.getneftdetails.ResponseNeftDetails;
import com.qc.api.response.getneopincodecity.ApiResponseNeoPincodeCity;
import com.qc.api.response.getneopincodecity.ResponseNeoPincodeCity;
import com.qc.service.NeftService;
import com.qc.service.PincodeCityService;
import com.qc.utils.UniqueId;

import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/api")
public class UtilityControllerRest {

	private static Logger logger = LogManager.getLogger(UtilityControllerRest.class);
	
	@Autowired NeftService neftService;
	
	@Autowired PincodeCityService pincodeCityService;
	
	
	@ApiOperation(notes = "This service is useful to fetch all neft related details on behalf of  policyNo.", value = "Fetching  neft related details on behalf of  policyNo.!", nickname = "")
	@RequestMapping(value = "/v1/getneftdetails", method = RequestMethod.POST,consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNeftDetails neftdetails(@Valid @RequestBody ApiRequestNeftDetails apiRequest)
	{
		
		logger.info( "maxservice::NeoControllerRest:: getneftdetails : Start");
		ApiResponseNeftDetails apiResponse = new ApiResponseNeftDetails();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		
		try
		{
			ThreadContext.push("getneftdetails : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			
			if(apiRequest.getRequest().getPayload().getPolicyNo()!=null &&
					   !apiRequest.getRequest().getPayload().getPolicyNo().isEmpty())	
			{
				
				logger.debug("Controller to service call : Start");
				apiResponse = neftService.getNeftdetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
 				logger.debug("Controller to service call : End");
			}
			else
			{
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseNeftDetails(new ResponseNeftDetails(header, msgInfo, null));
			}
		} 
		catch (Exception e) 
		{
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			// added by vinay
			logger.error(StringConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: maxservice::NeoControllerRest:: getneftdetails : "+StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNeftDetails(new ResponseNeftDetails(header, msgInfo, null));
		}
		finally 
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info( "maxservice::NeoControllerRest:: getneftdetails : End");
		return apiResponse;
	}
	
	@ApiOperation(notes = "This service is useful to get medical Centres Availability details on behalf of pincode", value = "productCode and pincode", nickname = "")
	@RequestMapping(value = "/v1/getneopincodecity", method = RequestMethod.POST,consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNeoPincodeCity pincodeCity(@Valid @RequestBody ApiRequestNeoPincodeCity apiRequest)
	{
		logger.info( "maxservice::NeoControllerRest:: pincodeCity : Start");
		
		ApiResponseNeoPincodeCity apiResponse = new ApiResponseNeoPincodeCity();
		MsgInfo msgInfo = new MsgInfo();
		HeaderNew header = null;
		try 
		{
			ThreadContext.push("pincodeCity : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			logger.info("RequestJson :: "+gson.toJson(apiRequest));
			
//			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//			logger.info("RequestJson :: " + ow.writeValueAsString(apiRequest));
		} 
		catch (Exception ex) 
		{
			logger.info("Error While mapping response header : " + ex);
		}
		try
		{
			
			if (apiRequest != null &&  apiRequest.getRequest()!=null
					&&  apiRequest.getRequest().getPayload() != null
					&& apiRequest.getRequest().getPayload().getPincode()!= null 
					&& !apiRequest.getRequest().getPayload().getPincode().equalsIgnoreCase("") 
					&& apiRequest.getRequest().getPayload().getProductCode()!= null
					&& apiRequest.getRequest().getPayload().getProductCode().size()>0)
			{
				logger.info("Controller to service call :: Start");
				apiResponse = pincodeCityService.getPincodeDetails(apiRequest);
				logger.info("Return to Controller from Service Impl");
				apiResponse.getResponse().setHeader(header);
				
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.info("RequestJson :: "+gson.toJson(apiRequest));
				
//				ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//				logger.info("ResponseJson :: " + ow.writeValueAsString(apiResponse));
				logger.info("Controller to service call : End");
			}
			else
			{
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse =  new ApiResponseNeoPincodeCity(new ResponseNeoPincodeCity(header, msgInfo, null));
			}
		} 
		catch (Exception e) 
		{
			
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			// added by vinay
			logger.error(StringConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: maxservice::NeoControllerRest:: pincodeCity : "+StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNeoPincodeCity(new ResponseNeoPincodeCity(header, msgInfo, null));
		}
		try 
		{
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			logger.info("RequestJson :: "+gson.toJson(apiRequest));
			
//			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//			logger.info("ResponseJson :: "+ow.writeValueAsString(apiResponse));
		}
		catch (Exception ex) 
		{
			logger.error("Error While converting response data to json : "+ex);
		}
		finally 
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info( "maxservice::NeoControllerRest:: pincodeCity : End");
		return apiResponse;
	}
}
