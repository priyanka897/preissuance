package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import com.qc.api.common.Header;
import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.abbreviation.ApiRequest;
import com.qc.api.request.countofnotification.ApiRequestCountOfNotification;
import com.qc.api.request.countofnotification.PayloadReqCountOfNotification;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.current.nav.ApiRequestCurrentNav;
import com.qc.api.request.fund.ApiRequestFundName;
import com.qc.api.request.getNav.ApiGetNav;
import com.qc.api.request.getaddress.ApiRequestGetAddress;
import com.qc.api.request.getallcities.ApiRequestGetAllCities;
import com.qc.api.request.getcities.ApiRequestGetCities;
import com.qc.api.request.getcountry.ApiRequestGetCountry;
import com.qc.api.request.getmaxcities.ApiRequestGetMaxCities;
import com.qc.api.request.getneftdetails.ApiRequestNeftDetails;
import com.qc.api.request.getplanname.ApiRequestGetPlan;
import com.qc.api.request.getstates.ApiRequestGetStates;
import com.qc.api.request.illustration.ApiIllustration;
import com.qc.api.request.nav.ApiRequestNav;
import com.qc.api.request.navservices.ApiUpdateRequestNav;
import com.qc.api.request.plan.ApiRequestPlanName;
import com.qc.api.request.updateNavAlert.ApiUpdateRequestSetNav;
import com.qc.api.response.StringConstants;
import com.qc.api.response.abbreviation.ApiResponse;
import com.qc.api.response.abbreviation.ErrorInfo;
import com.qc.api.response.abbreviation.HeaderResponse;
import com.qc.api.response.abbreviation.Payload;
import com.qc.api.response.countofnotification.ApiResponseCountOfNotification;
import com.qc.api.response.countofnotification.ResponseCountOfNotification;
import com.qc.api.response.csg.notificationsearch.ApiResponseNotificationSearch;
import com.qc.api.response.current.nav.ApiResponseCurrentNav;
import com.qc.api.response.current.nav.ApiResponseCurrentNavDetails;
import com.qc.api.response.current.nav.ResponseCurrentNav;
import com.qc.api.response.current.nav.ResponseCurrentNavDetails;
import com.qc.api.response.fund.ApiResponseFundName;
import com.qc.api.response.fund.ApiResponseGAFundName;
import com.qc.api.response.fund.ResponseFundName;
import com.qc.api.response.fund.ResponseGAFundName;
import com.qc.api.response.getNav.ApiResponseGetNavDetails;
import com.qc.api.response.getNav.UpdateResponseSetNav;
import com.qc.api.response.getaddress.ApiResponseGetAddress;
import com.qc.api.response.getaddress.PayloadResGetAddress;
import com.qc.api.response.getaddress.ResponseGetAddress;
import com.qc.api.response.getallcities.ApiResponseGetAllCities;
import com.qc.api.response.getallcities.PayloadResGetAllCities;
import com.qc.api.response.getallcities.ResponseGetAllCities;
import com.qc.api.response.getcities.ApiResponseGetCities;
import com.qc.api.response.getcities.PayloadResGetCities;
import com.qc.api.response.getcities.ResponseGetCities;
import com.qc.api.response.getcountry.ApiResponseGetCountry;
import com.qc.api.response.getcountry.PayloadResGetCountry;
import com.qc.api.response.getcountry.ResponseGetCountry;
import com.qc.api.response.getmaxcities.ApiResponseGetMaxCities;
import com.qc.api.response.getmaxcities.PayloadResGetMaxCities;
import com.qc.api.response.getmaxcities.ResponseGetMaxCities;
import com.qc.api.response.getneftdetails.ApiResponseNeftDetails;
import com.qc.api.response.getneftdetails.ResponseNeftDetails;
import com.qc.api.response.getplanname.ApiResponseGetPlan;
import com.qc.api.response.getplanname.PayloadResGetPlan;
import com.qc.api.response.getplanname.ResponseGetPlan;
import com.qc.api.response.getstates.ApiResponseGetStates;
import com.qc.api.response.getstates.PayloadResGetStates;
import com.qc.api.response.getstates.ResponseGetStates;
import com.qc.api.response.illustration.ApiResponseIllustration;
import com.qc.api.response.illustration.UpdateResponseIllustration;
import com.qc.api.response.nav.ApiResponseNav;
import com.qc.api.response.nav.ApiResponseNavDetails;
import com.qc.api.response.nav.ResponseNav;
import com.qc.api.response.nav.ResponseNavDetails;
import com.qc.api.response.navservices.ApiUpdateResponseNav;
import com.qc.api.response.navservices.UpdateResponseNav;
import com.qc.api.response.plan.ApiResponsePlanName;
import com.qc.api.response.plan.ResponsePlanName;
import com.qc.api.response.updateNavAlert.ApiUpdateResponseSetNav;
import com.qc.api.response.updateNavAlert.UpdateResponseUpdateNav;
import com.qc.service.AbbsJdbcService;
import com.qc.service.GanavFundService;
import com.qc.service.GetAddressService;
import com.qc.service.GetAllCitiesService;
import com.qc.service.GetCitiesService;
import com.qc.service.GetCountryService;
import com.qc.service.GetMaxCitiesService;
import com.qc.service.GetPlanService;
import com.qc.service.GetStateService;
import com.qc.service.MPowerService;
import com.qc.service.NavFundService;
import com.qc.service.NavService;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 *
 **/
@RestController
@RequestMapping(value = "/api")
@Api(value = "ganav", description = "GA Nav Details service for maxlifeinsurance.com", tags = { "ga navservices" })
public class ControllerRest {
	private static Logger logger = LogManager.getLogger(ControllerRest.class);

	@Autowired
	GanavFundService otpService;

	@Autowired
	NavFundService navDetails;

	@Autowired
	NavService navService;

	@Autowired
	GetMaxCitiesService maxcitiesService;

	@Autowired
	GetAddressService addressService;

	@Autowired
	GetPlanService planService;

	@Autowired
	MPowerService mPowerService;

	@Autowired
	GetAllCitiesService allCitiesService;

	@Autowired
	GetCitiesService citiesService;

	@Autowired
	GetCountryService countryService;

	@Autowired
	GetStateService stateService;

	@Autowired
	AbbsJdbcService abbsJdbcService;

	@ApiOperation(notes = "This service is used to get Fundname details from fund id bases", value = "A fund id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/gafunddetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseGAFundName generateGAFundNameRequest(@Valid @RequestBody ApiRequestFundName apiRequest) {
		logger.info("ControllerRest :: generateGAFundNameRequest :: Start");
		ApiResponseGAFundName apiResponse = new ApiResponseGAFundName();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav FundName: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			// Added by vinay
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getHeader() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = otpService.getFundDetails();

				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C500);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
				apiResponse = new ApiResponseGAFundName(new ResponseGAFundName(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in rest controller :: Fund Name service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGAFundName(new ResponseGAFundName(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("ControllerRest :: generateGAFundNameRequest :: End");
		return apiResponse;
	}

	// second nav service
	@ApiOperation(notes = "This service is used to get gnav details from planname,from date, to date", value = "A policy id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/ganavdetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNav generateGANavRequest(@Valid @RequestBody ApiRequestNav apiRequest) {
		logger.info("ControllerRest :: generateGANavRequest :: Start");
		ApiResponseNav apiResponse = new ApiResponseNav();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			// Added by vinay
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			// Added by vinay
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getPlanName() != null && !apiRequest.getRequest().getRequestData().getPlanName().isEmpty()
					&& apiRequest.getRequest().getRequestData().getFromDate() != null && !apiRequest.getRequest().getRequestData().getFromDate().isEmpty() && apiRequest.getRequest().getRequestData().getToDate() != null
					&& !apiRequest.getRequest().getRequestData().getToDate().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = otpService.getNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C500);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
				apiResponse = new ApiResponseNav(new ResponseNav(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception Restcontroller ::Nav service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNav(new ResponseNav(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("ControllerRest :: generateGANavRequest :: End");
		return apiResponse;
	}

	// third plan service
	@ApiOperation(notes = "This service is used to get plan name details ", value = "A fund id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/gaplandetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponsePlanName generateGAPlanNameRequest(@Valid @RequestBody ApiRequestPlanName apiRequest) {
		logger.info("ControllerRest :: generateGAPlanNameRequest :: Start");
		ApiResponsePlanName apiResponse = new ApiResponsePlanName();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("Plan Name: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			// Added by vinay
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			// Added by vinay
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getHeader() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = otpService.getPlanDetails();
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C500);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
				apiResponse = new ApiResponsePlanName(new ResponsePlanName(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in rest controller :: PlanName Service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponsePlanName(new ResponsePlanName(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("ControllerRest :: generateGAPlanNameRequest :: End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get plan name details ", value = "A fund id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/gacurrentnavdetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseCurrentNav generateGACurrentNavRequest(@Valid @RequestBody ApiRequestCurrentNav apiRequest) {
		logger.info("ControllerRest :: generateGACurrentNavRequest :: Start");
		ApiResponseCurrentNav apiResponse = new ApiResponseCurrentNav();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("Current Nav: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getPlanName() != null && !apiRequest.getRequest().getRequestData().getPlanName().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = otpService.getCurrentNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);

				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C500);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C500DESC);
				logger.info(StringConstants.C500DESC);
				apiResponse = new ApiResponseCurrentNav(new ResponseCurrentNav(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in rest controller :: Current Nav Service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseCurrentNav(new ResponseCurrentNav(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("ControllerRest :: generateGACurrentNavRequest :: End");
		return apiResponse;
	}

	// Navdetails

	@ApiOperation(notes = "This service is used to get Fundname details from fund id bases", value = "A fund id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/funddetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseFundName generateNavFundNameRequest(@Valid @RequestBody ApiRequestFundName apiRequest) {
		logger.info(" :: ConrollerRest :: generateNavFundNameRequest Start");
		ApiResponseFundName apiResponse = new ApiResponseFundName();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("navdetails FundName: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getHeader() != null) {
				logger.debug("Controller to service call : Start");

				apiResponse = navDetails.getFundDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseFundName(new ResponseFundName(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in navdetails :: ConrollerRest :: funddetails" + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseFundName(new ResponseFundName(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: generateNavFundNameRequest End");
		return apiResponse;
	}

	/* NavDetails---1 */

	// second nav service
	@ApiOperation(notes = "This service is used to get gnav details from planname,from date, to date", value = "A policy id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/navdetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNavDetails generateNavRequest(@Valid @RequestBody ApiRequestNav apiRequest) {
		logger.info(" :: ConrollerRest :: navdetails Start");
		ApiResponseNavDetails apiResponse = new ApiResponseNavDetails();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getPlanName() != null && !apiRequest.getRequest().getRequestData().getPlanName().isEmpty()

			) {
				logger.debug("Controller to service call : Start");
				apiResponse = navDetails.getNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);

				Gson gson = new GsonBuilder().setPrettyPrinting().create();

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseNavDetails(new ResponseNavDetails(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception Restcontroller ::Nav service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNavDetails(new ResponseNavDetails(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: navdetails End");
		return apiResponse;
	}

	// third plan service
	@ApiOperation(notes = "This service is used to get plan name details ", value = "No parameter required  get the details!", nickname = "")
	@RequestMapping(value = "/v1/plandetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponsePlanName generateNavPlanNameRequest(@Valid @RequestBody ApiRequestPlanName apiRequest) {
		logger.info(" :: ConrollerRest :: plandetails Start");
		ApiResponsePlanName apiResponse = new ApiResponsePlanName();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("navdetails PlanName: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();

			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getHeader() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = navDetails.getPlanDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponsePlanName(new ResponsePlanName(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in rest controller :: PlanName Service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponsePlanName(new ResponsePlanName(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: plandetails End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get plan name details ", value = "A fund id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/currentnavdetails", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseCurrentNavDetails generateCurrentNavRequest(@Valid @RequestBody ApiRequestCurrentNav apiRequest) {

		logger.info(" :: ConrollerRest :: currentnavdetails Start");
		ApiResponseCurrentNavDetails apiResponse = new ApiResponseCurrentNavDetails();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("Current Nav: " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getNavFromDate() != null && !apiRequest.getRequest().getRequestData().getNavFromDate().isEmpty()
					&& apiRequest.getRequest().getRequestData().getNavToDate() != null && !apiRequest.getRequest().getRequestData().getNavToDate().isEmpty() && apiRequest.getRequest().getRequestData().getPlanName() != null
					&& !apiRequest.getRequest().getRequestData().getPlanName().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navDetails.getCurrentNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseCurrentNavDetails(new ResponseCurrentNavDetails(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error("creating exception in rest controller :: Current Nav Service " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseCurrentNavDetails(new ResponseCurrentNavDetails(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: currentnavdetails End");
		return apiResponse;
	}

	// Navservices *****1

	@ApiOperation(notes = "This service is used to get Nav details from policy id bases", value = "A policy id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getnavdata", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public com.qc.api.response.navservices.ApiResponseNav generateNavServicesRequest(@Valid @RequestBody ApiRequestNav apiRequest) {
		logger.info(" :: ConrollerRest :: generateNavServicesRequest Start");
		com.qc.api.response.navservices.ApiResponseNav apiResponse = new com.qc.api.response.navservices.ApiResponseNav();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getPolicyid() != null && !apiRequest.getRequest().getRequestData().getPolicyid().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navService.getNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new com.qc.api.response.navservices.ApiResponseNav(new com.qc.api.response.navservices.ResponseNav(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new com.qc.api.response.navservices.ApiResponseNav(new com.qc.api.response.navservices.ResponseNav(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: generateNavServicesRequest End");
		return apiResponse;
	}

	// update service

	@ApiOperation(notes = "This service is used to Update  NAVSMS_STATUS and NAVSMS_FRQNCY details ", value = "A unique policy id is required to update the details!", nickname = "")
	@RequestMapping(value = "/v1/updatenavdata", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiUpdateResponseNav updateNavRequest(@Valid @RequestBody ApiUpdateRequestNav apiRequest) {
		logger.info(" :: ConrollerRest :: updateNavRequest Start");
		ApiUpdateResponseNav apiResponse = new ApiUpdateResponseNav();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null && apiRequest.getRequest().getRequestData().getPolicyid() != null && !apiRequest.getRequest().getRequestData().getPolicyid().isEmpty()
					&& apiRequest.getRequest().getRequestData().getSmsstatus() != null && !apiRequest.getRequest().getRequestData().getSmsstatus().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navService.getUpdateNavDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiUpdateResponseNav(new UpdateResponseNav(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiUpdateResponseNav(new UpdateResponseNav(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" :: ConrollerRest :: updateNavRequest End");
		return apiResponse;
	}

	// maxAddress

	@ApiOperation(notes = "This service is used to Get city that cities have max office details ", value = "state is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getmaxcity", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetMaxCities generateMaxCityRequest(@Valid @RequestBody ApiRequestGetMaxCities apiRequest) {

		logger.info(" generateMaxCityRequest Controller : Start");
		ApiResponseGetMaxCities apiResponse = new ApiResponseGetMaxCities();
		Header header = null;
		PayloadResGetMaxCities msgInfo = new PayloadResGetMaxCities();
		try {
			ThreadContext.push("getcity : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = maxcitiesService.getMaxCitiesDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetMaxCities(new ResponseGetMaxCities(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetMaxCities(new ResponseGetMaxCities(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateMaxCityRequest Controller : End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to Get Address details ", value = "state,city and pin code is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getaddress", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetAddress generateMaxAddressRequest(@Valid @RequestBody ApiRequestGetAddress apiRequest) {

		logger.info(" generateMaxAddressRequest Controller : Start");
		ApiResponseGetAddress apiResponse = new ApiResponseGetAddress();
		Header header = null;
		PayloadResGetAddress msgInfo = new PayloadResGetAddress();
		try {
			ThreadContext.push("getAddress : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.info("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = addressService.getAddressDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetAddress(new ResponseGetAddress(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetAddress(new ResponseGetAddress(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateMaxAddressRequest Controller : End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to Get plan name details ", value = "plan category is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getplan", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetPlan generatePlanNameRequest(@Valid @RequestBody ApiRequestGetPlan apiRequest) {

		logger.info(" generatePlanNameRequest Controller : Start");
		ApiResponseGetPlan apiResponse = new ApiResponseGetPlan();
		Header header = null;
		PayloadResGetPlan msgInfo = new PayloadResGetPlan();
		try {
			ThreadContext.push("getplan : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = planService.getPlanDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetPlan(new ResponseGetPlan(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetPlan(new ResponseGetPlan(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generatePlanNameRequest Controller : End");
		return apiResponse;
	}

	// ---

	@ApiOperation(notes = "This service is used to Get city details ", value = "state is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getallcity", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetAllCities generateAllCityRequest(@Valid @RequestBody ApiRequestGetAllCities apiRequest) {

		logger.info(" generateAllCityRequest Controller : Start");
		ApiResponseGetAllCities apiResponse = new ApiResponseGetAllCities();
		Header header = null;
		PayloadResGetAllCities msgInfo = new PayloadResGetAllCities();
		try {
			ThreadContext.push("getcity : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = allCitiesService.getAllCitiesDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);

				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetAllCities(new ResponseGetAllCities(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetAllCities(new ResponseGetAllCities(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateAllCityRequest Controller : End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to Get city details ", value = "state is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getcity", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetCities generateCityRequest(@Valid @RequestBody ApiRequestGetCities apiRequest) {

		logger.info(" generateCityRequest Controller : Start");
		ApiResponseGetCities apiResponse = new ApiResponseGetCities();
		Header header = null;
		PayloadResGetCities msgInfo = new PayloadResGetCities();
		try {
			ThreadContext.push("getcity : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = citiesService.getCitiesDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetCities(new ResponseGetCities(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetCities(new ResponseGetCities(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateCityRequest Controller : End");
		return (ApiResponseGetCities) apiResponse;
	}

	@ApiOperation(notes = "This service is used to Get city details ", value = "state is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getcountry", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetCountry generateCountryRequest(@Valid @RequestBody ApiRequestGetCountry apiRequest) {

		logger.info(" generateCountryRequest Controller : Start");
		ApiResponseGetCountry apiResponse = new ApiResponseGetCountry();
		Header header = null;
		PayloadResGetCountry msgInfo = new PayloadResGetCountry();
		try {
			ThreadContext.push("getcountry : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = countryService.getCountryDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetCountry(new ResponseGetCountry(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetCountry(new ResponseGetCountry(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateAllCountry Controller : End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to Get state details ", value = "country is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/getstate", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	@Transactional
	public ApiResponseGetStates generateStateRequest(@Valid @RequestBody ApiRequestGetStates apiRequest) {

		logger.info(" generateStateRequest Controller : Start");
		ApiResponseGetStates apiResponse = new ApiResponseGetStates();
		Header header = null;
		PayloadResGetStates msgInfo = new PayloadResGetStates();
		try {
			ThreadContext.push("getstate : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (JsonSyntaxException e1) {
			logger.error("Error While converting request data to json : " + e1);
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getRequestData() != null) {
				logger.debug("Controller to service call : Start");
				apiResponse = stateService.getStateDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);
				Gson gson = new GsonBuilder().setPrettyPrinting().create();
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setSoaStatusCode(StringConstants.C600);
				msgInfo.setSoaMessage(StringConstants.FAILURE);
				msgInfo.setSoaDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetStates(new ResponseGetStates(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setSoaStatusCode(StringConstants.C500);
			msgInfo.setSoaMessage(StringConstants.FAILURE);
			msgInfo.setSoaMessage(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetStates(new ResponseGetStates(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateStateRequest Controller : End");
		return apiResponse;
	}

	// MPower service

	@ApiOperation(notes = "This service is used to Get CountOfNotification details ", value = "User Id is required to get the details!", nickname = "")
	@RequestMapping(value = "/v1/countofnotification", method = RequestMethod.GET, consumes = { "text/plain" }, produces = { "application/json" })
	// @Transactional
	public ApiResponseCountOfNotification generateCountOfNotificationRequest(@Valid @RequestParam(value = "userId", required = false) String userId, @RequestHeader("soaCorrelationId") String soaCorrelationId,
			@RequestHeader("soaAppId") String soaAppId, @RequestHeader("soaMsgVersion") String soaMsgVersion) {

		logger.info(" generateCountOfNotificationRequest Controller : Start");
		ApiRequestCountOfNotification apiRequest = null;
		ApiResponseCountOfNotification apiResponse = new ApiResponseCountOfNotification();
		Header header = null;
		MsgInfo msgInfo = new MsgInfo();
		PayloadReqCountOfNotification payloadReq = null;
		try {
			header = new Header();
			header.setSoaAppId(soaAppId);
			header.setSoaCorrelationId(soaCorrelationId);
			header.setSoaMsgVersion(soaMsgVersion);
			payloadReq = new PayloadReqCountOfNotification();
			payloadReq.setUserId(userId);
			apiRequest = new ApiRequestCountOfNotification();
			apiRequest.setHeader(header);
			apiRequest.setRequest(payloadReq);
		} catch (Exception e) {
			logger.info("creating exception while set Header values " + e);
		}
		try {
			ThreadContext.push("generateCountOfNotificationRequest : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getHeader().getSoaCorrelationId());
			header = apiRequest.getHeader();
			try {
				ApiRequestCountOfNotification modifiedApirequest = apiRequest;
				new Thread(new Runnable() {
					public void run() {
						try {
							logger.debug("Run Method Start");
							// ObjectWriter ow = new
							// ObjectMapper().writer().withDefaultPrettyPrinter();
							// logger.debug("RequestJson :: " +
							// ow.writeValueAsString(modifiedApirequest));
						} catch (Exception e) {
							logger.error("Request logger Run Method have some error ::generateCountOfNotificationRequest" + e);
						}
					}
				}).start();
			} catch (Exception e) {
				logger.error("Request logger Run Method have some error :: generateCountOfNotificationRequest" + e);
			}
			// ObjectWriter ow = new
			// ObjectMapper().writer().withDefaultPrettyPrinter();
			// logger.info("RequestJson :: " +
			// ow.writeValueAsString(apiRequest));
		} catch (Exception ex) {
			logger.info("Error While mapping response header : " + ex);
		}
		try {
			if ((apiRequest.getRequest().getUserId()) != null && !(apiRequest.getRequest().getUserId()).isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = mPowerService.countOfNotification(apiRequest);
				apiResponse.getResponse().setHeader(header);
				try {
					ApiResponseCountOfNotification modifiedResponse = apiResponse;
					new Thread(new Runnable() {
						public void run() {
							try {
								// logger.info("Run Method Start");
								// ObjectWriter ow = new
								// ObjectMapper().writer().withDefaultPrettyPrinter();
								// logger.info("ResponseJson :: " +
								// ow.writeValueAsString(modifiedResponse));

								logger.debug("Run Method Start");
								// ObjectWriter ow = new
								// ObjectMapper().writer().withDefaultPrettyPrinter();
								// logger.debug("ResponseJson :: " +
								// ow.writeValueAsString(modifiedResponse));
							} catch (Exception e) {
								logger.error("Responce logger Run Method have some error ::generateCountOfNotificationRequest" + e);
							}
						}
					}).start();
				} catch (Exception e) {
					logger.error("Responce logger Run Method have some error :: generateCountOfNotificationRequest" + e);
				}
				// ObjectWriter ow = new
				// ObjectMapper().writer().withDefaultPrettyPrinter();
				// logger.info("ResponseJson :: " +
				// ow.writeValueAsString(apiResponse));
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseCountOfNotification(new ResponseCountOfNotification(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			logger.error("we are in exception :: MPower::ControllerRest:: generateCountOfNotificationRequest : " + StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseCountOfNotification(new ResponseCountOfNotification(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info(" generateCountOfNotificationRequest Controller : End");
		return apiResponse;
	}

	@ApiOperation(notes = "This service is add Abbreviation  for given request.", value = "Creating Abbriviation with given request!", nickname = "")
	@RequestMapping(value = "/v1/addabbsrequest", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponse abbAddAction(@Valid @RequestBody ApiRequest abbRequest) {
		String code = "500";
		String status = "FAILURE";
		String message;
		ApiResponse response;
		HeaderResponse header = new HeaderResponse();
		logger.info("addAbbsRequest : Start");
		Payload payload = new Payload();
		ErrorInfo errorInfo = new ErrorInfo();
		try {
			ThreadContext.push("addAbbsRequest : " + System.currentTimeMillis());
			ThreadContext.push(abbRequest.getHeader().getSoaCorrelationId());
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} catch (Exception e)

		{
			message = "Invalid Request Json";
			payload.setTransactions("Invalid Request Json");
			errorInfo.setCode(code);
			errorInfo.setMessage(message);
			errorInfo.setStatus(status);
			logger.info("Error While converting it to Json : " + e);
			response = new ApiResponse(header, errorInfo, payload);
		}
		try {
			response = new ApiResponse(header, errorInfo, payload);
			response = abbsJdbcService.addAbbService(abbRequest);
		} catch (Exception e) {
			message = "Something went wrong while processing response!";
			errorInfo.setCode(code);
			errorInfo.setMessage(message);
			errorInfo.setStatus(status);
			response = new ApiResponse(header, errorInfo, payload);
			logger.error("Invalid Request Json");
			logger.error("500");
			logger.error("Something went wrong while processing request!");
			logger.error("error occured during calling addAbbsRequest Service" + e);
		}
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} catch (Exception e) {
			logger.info("Error While converting it to Json : " + e);
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("addAbbsRequest : End");
		return response;
	}

	@ApiOperation(notes = "This service is fetched  for all Abbreviation  on behalf of shortForm .", value = "Fetching Abbriviation with given request!", nickname = "")
	@RequestMapping(value = "/v1/getabbsrequest", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponse abbGetAction(@Valid @RequestBody ApiRequest abbRequest) {
		String code = "500";
		String status = "FAILURE";
		String message;

		HeaderResponse header = new HeaderResponse();
		Payload payload = new Payload();
		ErrorInfo errorInfo = new ErrorInfo();
		ApiResponse response;

		logger.info("getAbbsRequest : Start");
		try {
			ThreadContext.push("getAbbsRequest : " + System.currentTimeMillis());
			ThreadContext.push(abbRequest.getHeader().getSoaCorrelationId());
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} catch (Exception e) {
			message = "Invalid Request Json";
			errorInfo.setCode(code);
			errorInfo.setMessage(message);
			errorInfo.setStatus(status);
			logger.error("Error While converting it to Json : " + e);
			response = new ApiResponse(header, errorInfo, payload);
		}
		try {
			response = new ApiResponse(header, errorInfo, payload);
			response = abbsJdbcService.getAbbService(abbRequest);
		} catch (Exception e) {
			message = "Something went wrong while processing response!";
			errorInfo.setCode(code);
			errorInfo.setMessage(message);
			errorInfo.setStatus(status);
			response = new ApiResponse(header, errorInfo, payload);
			logger.error("Invalid Request Json");
			logger.error("500");
			logger.error("Something went wrong while processing request!");
			logger.error("error occured during calling getAbbsRequest Service" + e);
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("getAbbsRequest : End");
		return response;
	}

	@ApiOperation(notes = "This service is fetched  for all Abbreviation  and cout total No of Abbreviation .", value = "Fetching All Abbriviation with given request!", nickname = "")
	@RequestMapping(value = "/v1/allabbsrequest", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponse abbAllAction(@Valid @RequestBody ApiRequest abbRequest) {
		logger.info("allAbbsRequest : Start");
		String code = "500";
		String status = "FAILURE";
		String message;

		HeaderResponse header = new HeaderResponse();
		Payload payload = new Payload();
		ErrorInfo errorInfo = new ErrorInfo();
		ApiResponse response;

		try {
			ThreadContext.push(abbRequest.getHeader().getSoaCorrelationId());
			response = new ApiResponse(header, errorInfo, payload);
			response = abbsJdbcService.allAbbService(abbRequest);
		} catch (Exception e) {
			message = "Something went wrong while processing response!";
			errorInfo.setCode(code);
			errorInfo.setMessage(message);
			errorInfo.setStatus(status);
			response = new ApiResponse(header, errorInfo, payload);
			logger.error("Invalid Request Json");
			logger.error("500");
			logger.error("Something went wrong while processing request!");
			logger.error("error occured during calling allAbbsRequest Service" + e);
		} finally {
			ThreadContext.pop();
		}
		logger.info("allAbbsRequest : End");
		return response;
	}

	@ApiOperation(notes = "This service is used to activate/deactivate NAV alert ", value = "A unique policy id is required to update the details!", nickname = "")
	@RequestMapping(value = "/setnavalert/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiUpdateResponseSetNav updateSetNavAlert(@Valid @RequestBody ApiUpdateRequestSetNav apiRequest) {
		ApiUpdateResponseSetNav apiResponse = new ApiUpdateResponseSetNav();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getPolicyNo() != null && !apiRequest.getRequest().getPayload().getPolicyNo().isEmpty()
					&& apiRequest.getRequest().getPayload().getTransactionType() != null && !apiRequest.getRequest().getPayload().getTransactionType().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navService.getUpdateNavAlert(apiRequest);
				apiResponse.getResponse().setHeader(header);
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiUpdateResponseSetNav(new UpdateResponseUpdateNav(header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiUpdateResponseSetNav(new UpdateResponseUpdateNav(header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get Nav details from policy id bases", value = "A policy id is required to get the details!", nickname = "")
	@RequestMapping(value = "/getnavstatusdetails/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseGetNavDetails getNavDetails(@Valid @RequestBody ApiGetNav apiRequest) {
		ApiResponseGetNavDetails apiResponse = new ApiResponseGetNavDetails();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.info("Error While mapping response header : " + ex);
		}
		try {
			String policyNumber = apiRequest.getRequest().getPayload().getPolicyNo();
			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getPolicyNo() != null && !apiRequest.getRequest().getPayload().getPolicyNo().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navService.getNavPolicyDetails(policyNumber);
				apiResponse.getResponse().setHeader(header);
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseGetNavDetails(new UpdateResponseSetNav(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseGetNavDetails(new UpdateResponseSetNav(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to check staus from policy id bases", value = "A policy id is required to get the details!", nickname = "")
	@RequestMapping(value = "/illustration", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseIllustration checkStatus(@Valid @RequestBody ApiIllustration apiRequest) {
		ApiResponseIllustration apiResponse = new ApiResponseIllustration();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("nav : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {
			String policyNumber = apiRequest.getRequest().getPayload().getPolicyNo();
			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getPolicyNo() != null && !apiRequest.getRequest().getPayload().getPolicyNo().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = navService.getIllustration(policyNumber);
				apiResponse.getResponse().setHeader(header);
				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseIllustration(new UpdateResponseIllustration(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseIllustration(new UpdateResponseIllustration(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

}
