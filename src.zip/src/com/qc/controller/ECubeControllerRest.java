package com.qc.controller;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.qc.api.request.eCube.ChatbotApiRequest;
import com.qc.api.response.eCube.ChatbotApiResponse;
import com.qc.common.dto.ApiResponseHeader;
import com.qc.common.dto.ERRORSTATUS;
import com.qc.common.dto.ErrorInfo;
import com.qc.common.dto.STATUSCODE;
import com.qc.service.ChatbotApiService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/services/api")
@Api(value="eCube", description="eCube service for Maxlifeisnurance.com",tags = {"eCube"})

public class ECubeControllerRest 
{
	private static Logger logger = LogManager.getLogger(ECubeControllerRest.class); 
	
	@Autowired
	ChatbotApiService chatbotApiService;
	@Autowired
	DozerBeanMapper dozerBeanMapper;
	
	
	@SuppressWarnings("null")
	@ApiOperation(notes = "This is Regarding eCubedata Service", value = "", nickname = "eCubeDataDetail")
	@RequestMapping(value = "/v1/eCubedata", method = RequestMethod.POST,
					consumes = {"application/json"}, produces = { "application/json" })
	public ChatbotApiResponse eCubeRequest(@Valid @RequestBody ChatbotApiRequest chatbotApiRequest ) 
	{
		logger.info("Method : ChatbotRequest :: STARTS :: API_REQUEST :: ");
		try 
		{
			ThreadContext.push("eCubeRequest : "+System.currentTimeMillis());
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			
			 
        } 
		catch (Exception e)
		{
			// Added by vinay
			logger.error("Error While converting it to Json : "+e);
		}
		ChatbotApiResponse response = null;
		ErrorInfo errorInfo = new ErrorInfo();
		try 
		{
			if(chatbotApiRequest != null)
			{
				response = chatbotApiService.getProceduresData(chatbotApiRequest.getPayload());
				response = new ChatbotApiResponse((dozerBeanMapper.map(chatbotApiRequest.getHeader(),
						ApiResponseHeader.class)),response.getErrorInfo(), response.getPayload());
			}
			else
			{
				logger.info("Invalid Request Json");
				errorInfo.setCode(STATUSCODE.INVALID_REQUEST.getValue());
				errorInfo.setStatus(ERRORSTATUS.FAILURE);
				errorInfo.setMessage("Invalid request parameter!");
				errorInfo.setDescription("Please verify your request parameter! : ");
				try{
				response = new ChatbotApiResponse((dozerBeanMapper.map(chatbotApiRequest.getHeader(),
						ApiResponseHeader.class)),errorInfo, null);
				}catch(Exception ex)
				{
					// Added by vinay
					logger.error(ex);
					logger.error("Invalid Response");
					errorInfo.setCode(STATUSCODE.INVALID_RESPONSE.getValue());
					errorInfo.setStatus(ERRORSTATUS.FAILURE);
					errorInfo.setMessage("Invalid Response!");
					errorInfo.setDescription("Invalid Response or Null response from API! : ");
				}
			}
		} 
		catch (Exception e)
		{
			// Added by vinay
			logger.error("Invalid Request Json");
			errorInfo.setCode(STATUSCODE.SERVER_ERROR.getValue());
			errorInfo.setStatus(ERRORSTATUS.FAILURE);
			errorInfo.setMessage("Something went wrong with your request!");
			errorInfo.setDescription("Please verify your request parameter! : ");
			logger.info("error occured during calling wipDetailRequest Service" + e);
		}
		try 
		{
			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
			logger.info("Method : ChatbotRequest :: ENDS :: API_RESPONSE :: : "+ow.writeValueAsString(response));
		} 
		catch (Exception e)
		{
			// Added by vinay
			logger.error("Error While converting it to Json : "+e);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		return response;
	}
}



	
