package com.qc.controller;

import javax.validation.Valid;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.qc.api.dto.ApiErrorInfo;
import com.qc.api.dto.ERRORSTATUS;
import com.qc.api.request.eKudos.OtpApiRequest;
import com.qc.api.request.eKudos.eKudosApiRequest;
import com.qc.api.response.eKudos.OtpApiResponse;
import com.qc.api.response.eKudos.eKudosApiResponse;
import com.qc.service.eKudosService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/drools/api")
@Api(value="eKUDOSService", description="eKUDOS service by qualtech consultants pvt. ltd.",tags = {"eKUDOSService"})
public class eKudosControllerRest 
{
	private static Logger logger = LogManager.getLogger(eKudosControllerRest.class);
	@Autowired
	eKudosService ekudosService;
	
	@ApiOperation(notes = "This service is created for ekudos earn and burnt.", value = "Earn ekudos using digital App!", nickname = "")
	@RequestMapping(value = "/v1/ekudos", method = RequestMethod.POST,consumes = { "application/json" }, produces = { "application/json" })
	public eKudosApiResponse burnearneKudos(@Valid @RequestBody eKudosApiRequest eKudosApiRequest) 
	{
		logger.info("eKudos : Start");
		eKudosApiResponse response = null;
		ApiErrorInfo apiErrorInfo = new ApiErrorInfo();
		try 
		{
			ThreadContext.push("earnburneKudos : "+System.currentTimeMillis());
//			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//			logger.info("String Json:-"+ow.writeValueAsString(eKudosApiRequest));
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		
		} 
		catch (Exception e)
		{
			logger.error("Error While converting it to Json : "+e);
		}
		try 
		{
			response = ekudosService.eKudosServicepoints(eKudosApiRequest);
		} 
		catch (Exception e)
		{
			logger.error("Invalid Request Json");
			apiErrorInfo.setCode("500");
			apiErrorInfo.setStatus(ERRORSTATUS.FAILURE);
			apiErrorInfo.setMessage("Something went wrong while processing request!");
			apiErrorInfo.setDescription("Please verify your request parameter!");
			logger.error("error occured during calling eKudos Service" + e);
		}
		try 
		{
//			ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
//			String json = ow.writeValueAsString(response);
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			
		} 
		catch (Exception e)
		{
			logger.error("Error While converting it to Json : "+e);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("BioVerification : End");
		return response;
	}
	
//	#############FOR CALLING ECUBE FOR SHOWING EKUDOS POINTS #############################
	
	@ApiOperation(notes = "This service is created for ekudos earn and burnt.", value = "Get ekudos using eCube App!", nickname = "")
	@RequestMapping(value = "/v1/getekudos", method = RequestMethod.POST,consumes = { "application/json" }, produces = { "application/json" })
	public eKudosApiResponse geteKudos(@Valid @RequestBody eKudosApiRequest eKudosApiRequest) 
	{
		logger.info("geteKudos : Start");
		eKudosApiResponse response = null;
		ApiErrorInfo apiErrorInfo = new ApiErrorInfo();
		try 
		{
			ThreadContext.push("earnburneKudos : "+System.currentTimeMillis());
			Gson gson = new GsonBuilder().setPrettyPrinting().create();

		} 
		catch (Exception e)
		{
			// added by vinay
			logger.error("Error While converting it to Json : "+e);
		}
		try 
		{
			response = ekudosService.geteKudospoints(eKudosApiRequest);
		} 
		catch (Exception e)
		{
			// added by vinay
			logger.error("Invalid Request Json");
			apiErrorInfo.setCode("500");
			apiErrorInfo.setStatus(ERRORSTATUS.FAILURE);
			apiErrorInfo.setMessage("Something went wrong while processing request!");
			apiErrorInfo.setDescription("Please verify your request parameter!");
			logger.error("error occured during calling eKudos Service" + e);
		}
		try 
		{
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
		} 
		catch (Exception e)
		{
			// added by vinay 
			logger.error("Error While converting it to Json : "+e);
		}
		finally
		{
			ThreadContext.pop();
			ThreadContext.pop();
		}
		logger.info("BioVerification : End");
		return response;
	}
	
	
}