package com.qc.controller;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qc.api.common.HeaderNew;
import com.qc.api.common.MsgInfo;
import com.qc.api.request.csg.NotificationDetail.ApiRequestNotificationDetails;
import com.qc.api.request.csg.createNotification.ApiRequestCreateNotification;
import com.qc.api.request.csg.listOfNotificationV2.ApiRequestListOfNotificationV2;
import com.qc.api.request.csg.notificationsearch.ApiRequestNotificationSearch;
import com.qc.api.request.csg.updateNotification.ApiRequestUpdateNotification;
import com.qc.api.request.csg.updateNotificationReadStatus.ApiRequestUpdateNotificationReadStatus;
import com.qc.api.response.StringConstants;
import com.qc.api.response.csg.NotificationDetail.ApiResponseNotificationDetails;
import com.qc.api.response.csg.NotificationDetail.ResponseNotificationDetails;
import com.qc.api.response.csg.createNotification.ApiResponseCreateNotification;
import com.qc.api.response.csg.createNotification.ResponseCreateNotification;
import com.qc.api.response.csg.listOfNotificationV2.ApiResponselistOfNotificationV2;
import com.qc.api.response.csg.listOfNotificationV2.ResponselistOfNotificationV2;
import com.qc.api.response.csg.notificationsearch.ApiResponseNotificationSearch;
import com.qc.api.response.csg.notificationsearch.ResponseNotificationSearch;
import com.qc.api.response.csg.updateNotification.ApiResponseUpdateNotification;
import com.qc.api.response.csg.updateNotification.ResponseUpdateNotification;
import com.qc.api.response.csg.updateNotificationReadStatus.ApiResponseUpdateNotificationReadStatus;
import com.qc.api.response.csg.updateNotificationReadStatus.ResponseUpdateNotificationReadStatus;
import com.qc.service.CsgServices;
import com.qc.utils.UniqueId;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(value = "/")
@Api(value = "CSG", description = "CSG service for maxlifeinsurance.com", tags = { "CSG Services" })
public class CsgController {

	private static Logger logger = LogManager.getLogger(CsgController.class);

	@Autowired
	CsgServices csgservices;

	@ApiOperation(notes = "This service is used to get the notification", value = "from date and to date are required", nickname = "")
	@RequestMapping(value = "notificationsearch/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNotificationSearch notificationSearch(@Valid @RequestBody ApiRequestNotificationSearch apiRequest) {
		ApiResponseNotificationSearch apiResponse = new ApiResponseNotificationSearch();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getStatus() != null && !apiRequest.getRequest().getPayload().getStatus().isEmpty()
					&& apiRequest.getRequest().getPayload().getFromDate() != null && !apiRequest.getRequest().getPayload().getFromDate().isEmpty() && apiRequest.getRequest().getPayload().getToDate() != null
					&& !apiRequest.getRequest().getPayload().getToDate().isEmpty() && apiRequest.getRequest().getPayload().getType() != null && !apiRequest.getRequest().getPayload().getType().isEmpty()) {
				logger.debug("Controller to service call notificationsearch : Start");
				apiResponse = csgservices.getNotificationSearch(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call notificationsearch : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseNotificationSearch(new ResponseNotificationSearch(null, header, msgInfo));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNotificationSearch(new ResponseNotificationSearch(null, header, msgInfo));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to create the notification", value = "", nickname = "")
	@RequestMapping(value = "createnotification/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseCreateNotification createNotification(@Valid @RequestBody ApiRequestCreateNotification apiRequest) {
		ApiResponseCreateNotification apiResponse = new ApiResponseCreateNotification();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getStatus() != null && !apiRequest.getRequest().getPayload().getStatus().isEmpty()
					&& apiRequest.getRequest().getPayload().getAppId() != null && !apiRequest.getRequest().getPayload().getAppId().isEmpty() && apiRequest.getRequest().getPayload().getType() != null
					&& !apiRequest.getRequest().getPayload().getType().isEmpty() && apiRequest.getRequest().getPayload().getNotification().size() > 0 && !apiRequest.getRequest().getPayload().getNotification().isEmpty()
					&& apiRequest.getRequest().getPayload().getNotification().get(0).getAgents().size() > 0 && !apiRequest.getRequest().getPayload().getNotification().get(0).getAgents().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = csgservices.createNotificationSearch(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseCreateNotification(new ResponseCreateNotification(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseCreateNotification(new ResponseCreateNotification(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to create the notification", value = "", nickname = "")
	@RequestMapping(value = "notificationdetail/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseNotificationDetails notificationDetails(@Valid @RequestBody ApiRequestNotificationDetails apiRequest) {
		ApiResponseNotificationDetails apiResponse = new ApiResponseNotificationDetails();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getId() != null && !apiRequest.getRequest().getPayload().getId().isEmpty()
					&& apiRequest.getRequest().getPayload().getAppId() != null && !apiRequest.getRequest().getPayload().getAppId().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = csgservices.notificationDetails(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseNotificationDetails(new ResponseNotificationDetails(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseNotificationDetails(new ResponseNotificationDetails(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get the notification", value = "from date and to date are required", nickname = "")
	@RequestMapping(value = "listofnotifications/v2", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponselistOfNotificationV2 listOfNotificationsV2(@Valid @RequestBody ApiRequestListOfNotificationV2 apiRequest) {
		ApiResponselistOfNotificationV2 apiResponse = new ApiResponselistOfNotificationV2();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getAgentId() != null && !apiRequest.getRequest().getPayload().getAgentId().isEmpty()
					&& apiRequest.getRequest().getPayload().getAppId() != null && !apiRequest.getRequest().getPayload().getAppId().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = csgservices.listOfNotificationsV2(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponselistOfNotificationV2(new ResponselistOfNotificationV2(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponselistOfNotificationV2(new ResponselistOfNotificationV2(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get the notification", value = "from date and to date are required", nickname = "")
	@RequestMapping(value = "updatenotificationreadstatus/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseUpdateNotificationReadStatus UpdateNotificationReadStatus(@Valid @RequestBody ApiRequestUpdateNotificationReadStatus apiRequest) {
		ApiResponseUpdateNotificationReadStatus apiResponse = new ApiResponseUpdateNotificationReadStatus();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getAgentId() != null && !apiRequest.getRequest().getPayload().getAgentId().isEmpty()
					&& apiRequest.getRequest().getPayload().getAppId() != null && !apiRequest.getRequest().getPayload().getAppId().isEmpty() && apiRequest.getRequest().getPayload().getId() != null
					&& !apiRequest.getRequest().getPayload().getId().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = csgservices.updateNotificationReadStatus(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseUpdateNotificationReadStatus(new ResponseUpdateNotificationReadStatus(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseUpdateNotificationReadStatus(new ResponseUpdateNotificationReadStatus(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}

	@ApiOperation(notes = "This service is used to get the notification", value = "from date and to date are required", nickname = "")
	@RequestMapping(value = "updatenotification/v1", method = RequestMethod.POST, consumes = { "application/json" }, produces = { "application/json" })
	public ApiResponseUpdateNotification UpdateNotification(@Valid @RequestBody ApiRequestUpdateNotification apiRequest) {
		ApiResponseUpdateNotification apiResponse = new ApiResponseUpdateNotification();
		HeaderNew header = null;
		MsgInfo msgInfo = new MsgInfo();
		try {
			ThreadContext.push("notification : " + UniqueId.getUniqueId());
			ThreadContext.push(apiRequest.getRequest().getHeader().getSoaCorrelationId());
			header = apiRequest.getRequest().getHeader();
		} catch (Exception ex) {
			logger.error("Error While mapping response header : " + ex);
		}
		try {

			if (apiRequest != null && apiRequest.getRequest().getPayload() != null && apiRequest.getRequest().getPayload().getPublishDate() != null && !apiRequest.getRequest().getPayload().getPublishDate().isEmpty()
					&& apiRequest.getRequest().getPayload().getType() != null && !apiRequest.getRequest().getPayload().getType().isEmpty() && apiRequest.getRequest().getPayload().getNotificationSummary() != null
					&& !apiRequest.getRequest().getPayload().getNotificationSummary().isEmpty() && apiRequest.getRequest().getPayload().getAppId() != null && !apiRequest.getRequest().getPayload().getAppId().isEmpty()) {
				logger.debug("Controller to service call : Start");
				apiResponse = csgservices.updateNotification(apiRequest);
				apiResponse.getResponse().setHeader(header);

				logger.debug("Controller to service call : End");
			} else {
				msgInfo.setMsgCode(StringConstants.C600);
				msgInfo.setMsg(StringConstants.FAILURE);
				msgInfo.setMsgDescription(StringConstants.C600DESC);
				logger.info(StringConstants.C600DESC);
				apiResponse = new ApiResponseUpdateNotification(new ResponseUpdateNotification(header, msgInfo, null));
			}
		} catch (Exception e) {
			msgInfo.setMsgCode(StringConstants.C500);
			msgInfo.setMsg(StringConstants.FAILURE);
			msgInfo.setMsgDescription(StringConstants.C500DESC);
			logger.error(StringConstants.C500DESC + " : " + e);
			apiResponse = new ApiResponseUpdateNotification(new ResponseUpdateNotification(header, msgInfo, null));
		} finally {
			ThreadContext.pop();
			ThreadContext.pop();
		}

		return apiResponse;
	}
}
