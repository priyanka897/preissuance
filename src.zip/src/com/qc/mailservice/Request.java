/**
 * Request.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qc.mailservice;

public class Request  implements java.io.Serializable {
    private java.lang.String mailIdTo;

    private java.lang.String mailIdCc;

    private java.lang.String mailIdBcc;

    private java.lang.String mailSubject;

    private java.lang.String fromName;

    private java.lang.String fromEmail;

    private java.lang.String mailBody;

    private boolean isFileAttached;

    private byte[][] attachments;

    private java.lang.String[] attachmentsName;

    private byte[][] embeddedAttachments;

    private boolean isConsolidate;

    private boolean isPdf;

    private boolean isZip;

    private java.lang.String[] reqParam1;

    private java.lang.String reqParam2;

    private java.lang.String reqParam3;

    private java.lang.String appId;

    private java.lang.String appName;

    private java.lang.String userType;

    private java.lang.String userName;

    private java.lang.String authenticationToken;

    private java.lang.String channel;

    private java.lang.String to;

    private java.lang.String requestTimestamp;

    public Request() {
    }

    public Request(
           java.lang.String mailIdTo,
           java.lang.String mailIdCc,
           java.lang.String mailIdBcc,
           java.lang.String mailSubject,
           java.lang.String fromName,
           java.lang.String fromEmail,
           java.lang.String mailBody,
           boolean isFileAttached,
           byte[][] attachments,
           java.lang.String[] attachmentsName,
           byte[][] embeddedAttachments,
           boolean isConsolidate,
           boolean isPdf,
           boolean isZip,
           java.lang.String[] reqParam1,
           java.lang.String reqParam2,
           java.lang.String reqParam3,
           java.lang.String appId,
           java.lang.String appName,
           java.lang.String userType,
           java.lang.String userName,
           java.lang.String authenticationToken,
           java.lang.String channel,
           java.lang.String to,
           java.lang.String requestTimestamp) {
           this.mailIdTo = mailIdTo;
           this.mailIdCc = mailIdCc;
           this.mailIdBcc = mailIdBcc;
           this.mailSubject = mailSubject;
           this.fromName = fromName;
           this.fromEmail = fromEmail;
           this.mailBody = mailBody;
           this.isFileAttached = isFileAttached;
           this.attachments = attachments;
           this.attachmentsName = attachmentsName;
           this.embeddedAttachments = embeddedAttachments;
           this.isConsolidate = isConsolidate;
           this.isPdf = isPdf;
           this.isZip = isZip;
           this.reqParam1 = reqParam1;
           this.reqParam2 = reqParam2;
           this.reqParam3 = reqParam3;
           this.appId = appId;
           this.appName = appName;
           this.userType = userType;
           this.userName = userName;
           this.authenticationToken = authenticationToken;
           this.channel = channel;
           this.to = to;
           this.requestTimestamp = requestTimestamp;
    }


    /**
     * Gets the mailIdTo value for this Request.
     * 
     * @return mailIdTo
     */
    public java.lang.String getMailIdTo() {
        return mailIdTo;
    }


    /**
     * Sets the mailIdTo value for this Request.
     * 
     * @param mailIdTo
     */
    public void setMailIdTo(java.lang.String mailIdTo) {
        this.mailIdTo = mailIdTo;
    }


    /**
     * Gets the mailIdCc value for this Request.
     * 
     * @return mailIdCc
     */
    public java.lang.String getMailIdCc() {
        return mailIdCc;
    }


    /**
     * Sets the mailIdCc value for this Request.
     * 
     * @param mailIdCc
     */
    public void setMailIdCc(java.lang.String mailIdCc) {
        this.mailIdCc = mailIdCc;
    }


    /**
     * Gets the mailIdBcc value for this Request.
     * 
     * @return mailIdBcc
     */
    public java.lang.String getMailIdBcc() {
        return mailIdBcc;
    }


    /**
     * Sets the mailIdBcc value for this Request.
     * 
     * @param mailIdBcc
     */
    public void setMailIdBcc(java.lang.String mailIdBcc) {
        this.mailIdBcc = mailIdBcc;
    }


    /**
     * Gets the mailSubject value for this Request.
     * 
     * @return mailSubject
     */
    public java.lang.String getMailSubject() {
        return mailSubject;
    }


    /**
     * Sets the mailSubject value for this Request.
     * 
     * @param mailSubject
     */
    public void setMailSubject(java.lang.String mailSubject) {
        this.mailSubject = mailSubject;
    }


    /**
     * Gets the fromName value for this Request.
     * 
     * @return fromName
     */
    public java.lang.String getFromName() {
        return fromName;
    }


    /**
     * Sets the fromName value for this Request.
     * 
     * @param fromName
     */
    public void setFromName(java.lang.String fromName) {
        this.fromName = fromName;
    }


    /**
     * Gets the fromEmail value for this Request.
     * 
     * @return fromEmail
     */
    public java.lang.String getFromEmail() {
        return fromEmail;
    }


    /**
     * Sets the fromEmail value for this Request.
     * 
     * @param fromEmail
     */
    public void setFromEmail(java.lang.String fromEmail) {
        this.fromEmail = fromEmail;
    }


    /**
     * Gets the mailBody value for this Request.
     * 
     * @return mailBody
     */
    public java.lang.String getMailBody() {
        return mailBody;
    }


    /**
     * Sets the mailBody value for this Request.
     * 
     * @param mailBody
     */
    public void setMailBody(java.lang.String mailBody) {
        this.mailBody = mailBody;
    }


    /**
     * Gets the isFileAttached value for this Request.
     * 
     * @return isFileAttached
     */
    public boolean isIsFileAttached() {
        return isFileAttached;
    }


    /**
     * Sets the isFileAttached value for this Request.
     * 
     * @param isFileAttached
     */
    public void setIsFileAttached(boolean isFileAttached) {
        this.isFileAttached = isFileAttached;
    }


    /**
     * Gets the attachments value for this Request.
     * 
     * @return attachments
     */
    public byte[][] getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this Request.
     * 
     * @param attachments
     */
    public void setAttachments(byte[][] attachments) {
        this.attachments = attachments;
    }

    public byte[] getAttachments(int i) {
        return this.attachments[i];
    }

    public void setAttachments(int i, byte[] _value) {
        this.attachments[i] = _value;
    }


    /**
     * Gets the attachmentsName value for this Request.
     * 
     * @return attachmentsName
     */
    public java.lang.String[] getAttachmentsName() {
        return attachmentsName;
    }


    /**
     * Sets the attachmentsName value for this Request.
     * 
     * @param attachmentsName
     */
    public void setAttachmentsName(java.lang.String[] attachmentsName) {
        this.attachmentsName = attachmentsName;
    }

    public java.lang.String getAttachmentsName(int i) {
        return this.attachmentsName[i];
    }

    public void setAttachmentsName(int i, java.lang.String _value) {
        this.attachmentsName[i] = _value;
    }


    /**
     * Gets the embeddedAttachments value for this Request.
     * 
     * @return embeddedAttachments
     */
    public byte[][] getEmbeddedAttachments() {
        return embeddedAttachments;
    }


    /**
     * Sets the embeddedAttachments value for this Request.
     * 
     * @param embeddedAttachments
     */
    public void setEmbeddedAttachments(byte[][] embeddedAttachments) {
        this.embeddedAttachments = embeddedAttachments;
    }

    public byte[] getEmbeddedAttachments(int i) {
        return this.embeddedAttachments[i];
    }

    public void setEmbeddedAttachments(int i, byte[] _value) {
        this.embeddedAttachments[i] = _value;
    }


    /**
     * Gets the isConsolidate value for this Request.
     * 
     * @return isConsolidate
     */
    public boolean isIsConsolidate() {
        return isConsolidate;
    }


    /**
     * Sets the isConsolidate value for this Request.
     * 
     * @param isConsolidate
     */
    public void setIsConsolidate(boolean isConsolidate) {
        this.isConsolidate = isConsolidate;
    }


    /**
     * Gets the isPdf value for this Request.
     * 
     * @return isPdf
     */
    public boolean isIsPdf() {
        return isPdf;
    }


    /**
     * Sets the isPdf value for this Request.
     * 
     * @param isPdf
     */
    public void setIsPdf(boolean isPdf) {
        this.isPdf = isPdf;
    }


    /**
     * Gets the isZip value for this Request.
     * 
     * @return isZip
     */
    public boolean isIsZip() {
        return isZip;
    }


    /**
     * Sets the isZip value for this Request.
     * 
     * @param isZip
     */
    public void setIsZip(boolean isZip) {
        this.isZip = isZip;
    }


    /**
     * Gets the reqParam1 value for this Request.
     * 
     * @return reqParam1
     */
    public java.lang.String[] getReqParam1() {
        return reqParam1;
    }


    /**
     * Sets the reqParam1 value for this Request.
     * 
     * @param reqParam1
     */
    public void setReqParam1(java.lang.String[] reqParam1) {
        this.reqParam1 = reqParam1;
    }

    public java.lang.String getReqParam1(int i) {
        return this.reqParam1[i];
    }

    public void setReqParam1(int i, java.lang.String _value) {
        this.reqParam1[i] = _value;
    }


    /**
     * Gets the reqParam2 value for this Request.
     * 
     * @return reqParam2
     */
    public java.lang.String getReqParam2() {
        return reqParam2;
    }


    /**
     * Sets the reqParam2 value for this Request.
     * 
     * @param reqParam2
     */
    public void setReqParam2(java.lang.String reqParam2) {
        this.reqParam2 = reqParam2;
    }


    /**
     * Gets the reqParam3 value for this Request.
     * 
     * @return reqParam3
     */
    public java.lang.String getReqParam3() {
        return reqParam3;
    }


    /**
     * Sets the reqParam3 value for this Request.
     * 
     * @param reqParam3
     */
    public void setReqParam3(java.lang.String reqParam3) {
        this.reqParam3 = reqParam3;
    }


    /**
     * Gets the appId value for this Request.
     * 
     * @return appId
     */
    public java.lang.String getAppId() {
        return appId;
    }


    /**
     * Sets the appId value for this Request.
     * 
     * @param appId
     */
    public void setAppId(java.lang.String appId) {
        this.appId = appId;
    }


    /**
     * Gets the appName value for this Request.
     * 
     * @return appName
     */
    public java.lang.String getAppName() {
        return appName;
    }


    /**
     * Sets the appName value for this Request.
     * 
     * @param appName
     */
    public void setAppName(java.lang.String appName) {
        this.appName = appName;
    }


    /**
     * Gets the userType value for this Request.
     * 
     * @return userType
     */
    public java.lang.String getUserType() {
        return userType;
    }


    /**
     * Sets the userType value for this Request.
     * 
     * @param userType
     */
    public void setUserType(java.lang.String userType) {
        this.userType = userType;
    }


    /**
     * Gets the userName value for this Request.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this Request.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }


    /**
     * Gets the authenticationToken value for this Request.
     * 
     * @return authenticationToken
     */
    public java.lang.String getAuthenticationToken() {
        return authenticationToken;
    }


    /**
     * Sets the authenticationToken value for this Request.
     * 
     * @param authenticationToken
     */
    public void setAuthenticationToken(java.lang.String authenticationToken) {
        this.authenticationToken = authenticationToken;
    }


    /**
     * Gets the channel value for this Request.
     * 
     * @return channel
     */
    public java.lang.String getChannel() {
        return channel;
    }


    /**
     * Sets the channel value for this Request.
     * 
     * @param channel
     */
    public void setChannel(java.lang.String channel) {
        this.channel = channel;
    }


    /**
     * Gets the to value for this Request.
     * 
     * @return to
     */
    public java.lang.String getTo() {
        return to;
    }


    /**
     * Sets the to value for this Request.
     * 
     * @param to
     */
    public void setTo(java.lang.String to) {
        this.to = to;
    }


    /**
     * Gets the requestTimestamp value for this Request.
     * 
     * @return requestTimestamp
     */
    public java.lang.String getRequestTimestamp() {
        return requestTimestamp;
    }


    /**
     * Sets the requestTimestamp value for this Request.
     * 
     * @param requestTimestamp
     */
    public void setRequestTimestamp(java.lang.String requestTimestamp) {
        this.requestTimestamp = requestTimestamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Request)) return false;
        Request other = (Request) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.mailIdTo==null && other.getMailIdTo()==null) || 
             (this.mailIdTo!=null &&
              this.mailIdTo.equals(other.getMailIdTo()))) &&
            ((this.mailIdCc==null && other.getMailIdCc()==null) || 
             (this.mailIdCc!=null &&
              this.mailIdCc.equals(other.getMailIdCc()))) &&
            ((this.mailIdBcc==null && other.getMailIdBcc()==null) || 
             (this.mailIdBcc!=null &&
              this.mailIdBcc.equals(other.getMailIdBcc()))) &&
            ((this.mailSubject==null && other.getMailSubject()==null) || 
             (this.mailSubject!=null &&
              this.mailSubject.equals(other.getMailSubject()))) &&
            ((this.fromName==null && other.getFromName()==null) || 
             (this.fromName!=null &&
              this.fromName.equals(other.getFromName()))) &&
            ((this.fromEmail==null && other.getFromEmail()==null) || 
             (this.fromEmail!=null &&
              this.fromEmail.equals(other.getFromEmail()))) &&
            ((this.mailBody==null && other.getMailBody()==null) || 
             (this.mailBody!=null &&
              this.mailBody.equals(other.getMailBody()))) &&
            this.isFileAttached == other.isIsFileAttached() &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              java.util.Arrays.equals(this.attachments, other.getAttachments()))) &&
            ((this.attachmentsName==null && other.getAttachmentsName()==null) || 
             (this.attachmentsName!=null &&
              java.util.Arrays.equals(this.attachmentsName, other.getAttachmentsName()))) &&
            ((this.embeddedAttachments==null && other.getEmbeddedAttachments()==null) || 
             (this.embeddedAttachments!=null &&
              java.util.Arrays.equals(this.embeddedAttachments, other.getEmbeddedAttachments()))) &&
            this.isConsolidate == other.isIsConsolidate() &&
            this.isPdf == other.isIsPdf() &&
            this.isZip == other.isIsZip() &&
            ((this.reqParam1==null && other.getReqParam1()==null) || 
             (this.reqParam1!=null &&
              java.util.Arrays.equals(this.reqParam1, other.getReqParam1()))) &&
            ((this.reqParam2==null && other.getReqParam2()==null) || 
             (this.reqParam2!=null &&
              this.reqParam2.equals(other.getReqParam2()))) &&
            ((this.reqParam3==null && other.getReqParam3()==null) || 
             (this.reqParam3!=null &&
              this.reqParam3.equals(other.getReqParam3()))) &&
            ((this.appId==null && other.getAppId()==null) || 
             (this.appId!=null &&
              this.appId.equals(other.getAppId()))) &&
            ((this.appName==null && other.getAppName()==null) || 
             (this.appName!=null &&
              this.appName.equals(other.getAppName()))) &&
            ((this.userType==null && other.getUserType()==null) || 
             (this.userType!=null &&
              this.userType.equals(other.getUserType()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName()))) &&
            ((this.authenticationToken==null && other.getAuthenticationToken()==null) || 
             (this.authenticationToken!=null &&
              this.authenticationToken.equals(other.getAuthenticationToken()))) &&
            ((this.channel==null && other.getChannel()==null) || 
             (this.channel!=null &&
              this.channel.equals(other.getChannel()))) &&
            ((this.to==null && other.getTo()==null) || 
             (this.to!=null &&
              this.to.equals(other.getTo()))) &&
            ((this.requestTimestamp==null && other.getRequestTimestamp()==null) || 
             (this.requestTimestamp!=null &&
              this.requestTimestamp.equals(other.getRequestTimestamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMailIdTo() != null) {
            _hashCode += getMailIdTo().hashCode();
        }
        if (getMailIdCc() != null) {
            _hashCode += getMailIdCc().hashCode();
        }
        if (getMailIdBcc() != null) {
            _hashCode += getMailIdBcc().hashCode();
        }
        if (getMailSubject() != null) {
            _hashCode += getMailSubject().hashCode();
        }
        if (getFromName() != null) {
            _hashCode += getFromName().hashCode();
        }
        if (getFromEmail() != null) {
            _hashCode += getFromEmail().hashCode();
        }
        if (getMailBody() != null) {
            _hashCode += getMailBody().hashCode();
        }
        _hashCode += (isIsFileAttached() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAttachmentsName() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAttachmentsName());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAttachmentsName(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEmbeddedAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEmbeddedAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEmbeddedAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += (isIsConsolidate() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsPdf() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIsZip() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getReqParam1() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getReqParam1());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getReqParam1(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getReqParam2() != null) {
            _hashCode += getReqParam2().hashCode();
        }
        if (getReqParam3() != null) {
            _hashCode += getReqParam3().hashCode();
        }
        if (getAppId() != null) {
            _hashCode += getAppId().hashCode();
        }
        if (getAppName() != null) {
            _hashCode += getAppName().hashCode();
        }
        if (getUserType() != null) {
            _hashCode += getUserType().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        if (getAuthenticationToken() != null) {
            _hashCode += getAuthenticationToken().hashCode();
        }
        if (getChannel() != null) {
            _hashCode += getChannel().hashCode();
        }
        if (getTo() != null) {
            _hashCode += getTo().hashCode();
        }
        if (getRequestTimestamp() != null) {
            _hashCode += getRequestTimestamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Request.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mailservice.qualtech.com/", "request"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailIdTo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mailIdTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailIdCc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mailIdCc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailIdBcc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mailIdBcc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailSubject");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mailSubject"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fromName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fromEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailBody");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mailBody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isFileAttached");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isFileAttached"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachmentsName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "attachmentsName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("embeddedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("", "embeddedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isConsolidate");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isConsolidate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isPdf");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isPdf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isZip");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isZip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reqParam1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reqParam1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reqParam2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reqParam2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reqParam3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reqParam3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "appId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "appName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authenticationToken");
        elemField.setXmlName(new javax.xml.namespace.QName("", "authenticationToken"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "channel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to");
        elemField.setXmlName(new javax.xml.namespace.QName("", "to"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestTimestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "requestTimestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
