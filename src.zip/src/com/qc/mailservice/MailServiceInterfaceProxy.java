package com.qc.mailservice;

public class MailServiceInterfaceProxy implements com.qc.mailservice.MailServiceInterface {
  private String _endpoint = null;
  private com.qc.mailservice.MailServiceInterface mailServiceInterface = null;
  
  public MailServiceInterfaceProxy() {
    _initMailServiceInterfaceProxy();
  }
  
  public MailServiceInterfaceProxy(String endpoint) {
    _endpoint = endpoint;
    _initMailServiceInterfaceProxy();
  }
  
  private void _initMailServiceInterfaceProxy() {
    try {
      mailServiceInterface = (new com.qc.mailserviceImpl.MailWebServiceLocator()).getMailService_Port();
      if (mailServiceInterface != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)mailServiceInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)mailServiceInterface)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (mailServiceInterface != null)
      ((javax.xml.rpc.Stub)mailServiceInterface)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.qc.mailservice.MailServiceInterface getMailServiceInterface() {
    if (mailServiceInterface == null)
      _initMailServiceInterfaceProxy();
    return mailServiceInterface;
  }
  
  public com.qc.mailservice.Common generateMail(com.qc.mailservice.Common arg0) throws java.rmi.RemoteException{
    if (mailServiceInterface == null)
      _initMailServiceInterfaceProxy();
    return mailServiceInterface.generateMail(arg0);
  }
  
  
}