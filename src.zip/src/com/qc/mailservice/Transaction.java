/**
 * Transaction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qc.mailservice;

public class Transaction  implements java.io.Serializable {
    private java.lang.String transactionType;

    private java.lang.String majorTransactionId;

    private java.lang.String minorTransactionId;

    private java.lang.String messageId;

    private java.lang.String correlationId;

    private java.lang.String priority;

    private java.lang.String isRetry;

    public Transaction() {
    }

    public Transaction(
           java.lang.String transactionType,
           java.lang.String majorTransactionId,
           java.lang.String minorTransactionId,
           java.lang.String messageId,
           java.lang.String correlationId,
           java.lang.String priority,
           java.lang.String isRetry) {
           this.transactionType = transactionType;
           this.majorTransactionId = majorTransactionId;
           this.minorTransactionId = minorTransactionId;
           this.messageId = messageId;
           this.correlationId = correlationId;
           this.priority = priority;
           this.isRetry = isRetry;
    }


    /**
     * Gets the transactionType value for this Transaction.
     * 
     * @return transactionType
     */
    public java.lang.String getTransactionType() {
        return transactionType;
    }


    /**
     * Sets the transactionType value for this Transaction.
     * 
     * @param transactionType
     */
    public void setTransactionType(java.lang.String transactionType) {
        this.transactionType = transactionType;
    }


    /**
     * Gets the majorTransactionId value for this Transaction.
     * 
     * @return majorTransactionId
     */
    public java.lang.String getMajorTransactionId() {
        return majorTransactionId;
    }


    /**
     * Sets the majorTransactionId value for this Transaction.
     * 
     * @param majorTransactionId
     */
    public void setMajorTransactionId(java.lang.String majorTransactionId) {
        this.majorTransactionId = majorTransactionId;
    }


    /**
     * Gets the minorTransactionId value for this Transaction.
     * 
     * @return minorTransactionId
     */
    public java.lang.String getMinorTransactionId() {
        return minorTransactionId;
    }


    /**
     * Sets the minorTransactionId value for this Transaction.
     * 
     * @param minorTransactionId
     */
    public void setMinorTransactionId(java.lang.String minorTransactionId) {
        this.minorTransactionId = minorTransactionId;
    }


    /**
     * Gets the messageId value for this Transaction.
     * 
     * @return messageId
     */
    public java.lang.String getMessageId() {
        return messageId;
    }


    /**
     * Sets the messageId value for this Transaction.
     * 
     * @param messageId
     */
    public void setMessageId(java.lang.String messageId) {
        this.messageId = messageId;
    }


    /**
     * Gets the correlationId value for this Transaction.
     * 
     * @return correlationId
     */
    public java.lang.String getCorrelationId() {
        return correlationId;
    }


    /**
     * Sets the correlationId value for this Transaction.
     * 
     * @param correlationId
     */
    public void setCorrelationId(java.lang.String correlationId) {
        this.correlationId = correlationId;
    }


    /**
     * Gets the priority value for this Transaction.
     * 
     * @return priority
     */
    public java.lang.String getPriority() {
        return priority;
    }


    /**
     * Sets the priority value for this Transaction.
     * 
     * @param priority
     */
    public void setPriority(java.lang.String priority) {
        this.priority = priority;
    }


    /**
     * Gets the isRetry value for this Transaction.
     * 
     * @return isRetry
     */
    public java.lang.String getIsRetry() {
        return isRetry;
    }


    /**
     * Sets the isRetry value for this Transaction.
     * 
     * @param isRetry
     */
    public void setIsRetry(java.lang.String isRetry) {
        this.isRetry = isRetry;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Transaction)) return false;
        Transaction other = (Transaction) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.transactionType==null && other.getTransactionType()==null) || 
             (this.transactionType!=null &&
              this.transactionType.equals(other.getTransactionType()))) &&
            ((this.majorTransactionId==null && other.getMajorTransactionId()==null) || 
             (this.majorTransactionId!=null &&
              this.majorTransactionId.equals(other.getMajorTransactionId()))) &&
            ((this.minorTransactionId==null && other.getMinorTransactionId()==null) || 
             (this.minorTransactionId!=null &&
              this.minorTransactionId.equals(other.getMinorTransactionId()))) &&
            ((this.messageId==null && other.getMessageId()==null) || 
             (this.messageId!=null &&
              this.messageId.equals(other.getMessageId()))) &&
            ((this.correlationId==null && other.getCorrelationId()==null) || 
             (this.correlationId!=null &&
              this.correlationId.equals(other.getCorrelationId()))) &&
            ((this.priority==null && other.getPriority()==null) || 
             (this.priority!=null &&
              this.priority.equals(other.getPriority()))) &&
            ((this.isRetry==null && other.getIsRetry()==null) || 
             (this.isRetry!=null &&
              this.isRetry.equals(other.getIsRetry())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransactionType() != null) {
            _hashCode += getTransactionType().hashCode();
        }
        if (getMajorTransactionId() != null) {
            _hashCode += getMajorTransactionId().hashCode();
        }
        if (getMinorTransactionId() != null) {
            _hashCode += getMinorTransactionId().hashCode();
        }
        if (getMessageId() != null) {
            _hashCode += getMessageId().hashCode();
        }
        if (getCorrelationId() != null) {
            _hashCode += getCorrelationId().hashCode();
        }
        if (getPriority() != null) {
            _hashCode += getPriority().hashCode();
        }
        if (getIsRetry() != null) {
            _hashCode += getIsRetry().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Transaction.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mailservice.qualtech.com/", "transaction"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionType");
        elemField.setXmlName(new javax.xml.namespace.QName("", "TransactionType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("majorTransactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MajorTransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minorTransactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MinorTransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("messageId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "MessageId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correlationId");
        elemField.setXmlName(new javax.xml.namespace.QName("", "CorrelationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("priority");
        elemField.setXmlName(new javax.xml.namespace.QName("", "Priority"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isRetry");
        elemField.setXmlName(new javax.xml.namespace.QName("", "IsRetry"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
