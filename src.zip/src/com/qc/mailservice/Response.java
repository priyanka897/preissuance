/**
 * Response.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qc.mailservice;

public class Response  implements java.io.Serializable {
    private java.lang.String responseTimestamp;

    private java.lang.String errorCode;

    private java.lang.String errorDescription;

    private java.lang.String statusCode;

    private java.lang.String statusDescription;

    private java.lang.String sender;

    private java.lang.String resultCodes;

    private java.lang.String optionalTokens;

    private java.lang.String resParam1;

    private java.lang.String resParam2;

    private java.lang.String resParam3;

    public Response() {
    }

    public Response(
           java.lang.String responseTimestamp,
           java.lang.String errorCode,
           java.lang.String errorDescription,
           java.lang.String statusCode,
           java.lang.String statusDescription,
           java.lang.String sender,
           java.lang.String resultCodes,
           java.lang.String optionalTokens,
           java.lang.String resParam1,
           java.lang.String resParam2,
           java.lang.String resParam3) {
           this.responseTimestamp = responseTimestamp;
           this.errorCode = errorCode;
           this.errorDescription = errorDescription;
           this.statusCode = statusCode;
           this.statusDescription = statusDescription;
           this.sender = sender;
           this.resultCodes = resultCodes;
           this.optionalTokens = optionalTokens;
           this.resParam1 = resParam1;
           this.resParam2 = resParam2;
           this.resParam3 = resParam3;
    }


    /**
     * Gets the responseTimestamp value for this Response.
     * 
     * @return responseTimestamp
     */
    public java.lang.String getResponseTimestamp() {
        return responseTimestamp;
    }


    /**
     * Sets the responseTimestamp value for this Response.
     * 
     * @param responseTimestamp
     */
    public void setResponseTimestamp(java.lang.String responseTimestamp) {
        this.responseTimestamp = responseTimestamp;
    }


    /**
     * Gets the errorCode value for this Response.
     * 
     * @return errorCode
     */
    public java.lang.String getErrorCode() {
        return errorCode;
    }


    /**
     * Sets the errorCode value for this Response.
     * 
     * @param errorCode
     */
    public void setErrorCode(java.lang.String errorCode) {
        this.errorCode = errorCode;
    }


    /**
     * Gets the errorDescription value for this Response.
     * 
     * @return errorDescription
     */
    public java.lang.String getErrorDescription() {
        return errorDescription;
    }


    /**
     * Sets the errorDescription value for this Response.
     * 
     * @param errorDescription
     */
    public void setErrorDescription(java.lang.String errorDescription) {
        this.errorDescription = errorDescription;
    }


    /**
     * Gets the statusCode value for this Response.
     * 
     * @return statusCode
     */
    public java.lang.String getStatusCode() {
        return statusCode;
    }


    /**
     * Sets the statusCode value for this Response.
     * 
     * @param statusCode
     */
    public void setStatusCode(java.lang.String statusCode) {
        this.statusCode = statusCode;
    }


    /**
     * Gets the statusDescription value for this Response.
     * 
     * @return statusDescription
     */
    public java.lang.String getStatusDescription() {
        return statusDescription;
    }


    /**
     * Sets the statusDescription value for this Response.
     * 
     * @param statusDescription
     */
    public void setStatusDescription(java.lang.String statusDescription) {
        this.statusDescription = statusDescription;
    }


    /**
     * Gets the sender value for this Response.
     * 
     * @return sender
     */
    public java.lang.String getSender() {
        return sender;
    }


    /**
     * Sets the sender value for this Response.
     * 
     * @param sender
     */
    public void setSender(java.lang.String sender) {
        this.sender = sender;
    }


    /**
     * Gets the resultCodes value for this Response.
     * 
     * @return resultCodes
     */
    public java.lang.String getResultCodes() {
        return resultCodes;
    }


    /**
     * Sets the resultCodes value for this Response.
     * 
     * @param resultCodes
     */
    public void setResultCodes(java.lang.String resultCodes) {
        this.resultCodes = resultCodes;
    }


    /**
     * Gets the optionalTokens value for this Response.
     * 
     * @return optionalTokens
     */
    public java.lang.String getOptionalTokens() {
        return optionalTokens;
    }


    /**
     * Sets the optionalTokens value for this Response.
     * 
     * @param optionalTokens
     */
    public void setOptionalTokens(java.lang.String optionalTokens) {
        this.optionalTokens = optionalTokens;
    }


    /**
     * Gets the resParam1 value for this Response.
     * 
     * @return resParam1
     */
    public java.lang.String getResParam1() {
        return resParam1;
    }


    /**
     * Sets the resParam1 value for this Response.
     * 
     * @param resParam1
     */
    public void setResParam1(java.lang.String resParam1) {
        this.resParam1 = resParam1;
    }


    /**
     * Gets the resParam2 value for this Response.
     * 
     * @return resParam2
     */
    public java.lang.String getResParam2() {
        return resParam2;
    }


    /**
     * Sets the resParam2 value for this Response.
     * 
     * @param resParam2
     */
    public void setResParam2(java.lang.String resParam2) {
        this.resParam2 = resParam2;
    }


    /**
     * Gets the resParam3 value for this Response.
     * 
     * @return resParam3
     */
    public java.lang.String getResParam3() {
        return resParam3;
    }


    /**
     * Sets the resParam3 value for this Response.
     * 
     * @param resParam3
     */
    public void setResParam3(java.lang.String resParam3) {
        this.resParam3 = resParam3;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Response)) return false;
        Response other = (Response) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.responseTimestamp==null && other.getResponseTimestamp()==null) || 
             (this.responseTimestamp!=null &&
              this.responseTimestamp.equals(other.getResponseTimestamp()))) &&
            ((this.errorCode==null && other.getErrorCode()==null) || 
             (this.errorCode!=null &&
              this.errorCode.equals(other.getErrorCode()))) &&
            ((this.errorDescription==null && other.getErrorDescription()==null) || 
             (this.errorDescription!=null &&
              this.errorDescription.equals(other.getErrorDescription()))) &&
            ((this.statusCode==null && other.getStatusCode()==null) || 
             (this.statusCode!=null &&
              this.statusCode.equals(other.getStatusCode()))) &&
            ((this.statusDescription==null && other.getStatusDescription()==null) || 
             (this.statusDescription!=null &&
              this.statusDescription.equals(other.getStatusDescription()))) &&
            ((this.sender==null && other.getSender()==null) || 
             (this.sender!=null &&
              this.sender.equals(other.getSender()))) &&
            ((this.resultCodes==null && other.getResultCodes()==null) || 
             (this.resultCodes!=null &&
              this.resultCodes.equals(other.getResultCodes()))) &&
            ((this.optionalTokens==null && other.getOptionalTokens()==null) || 
             (this.optionalTokens!=null &&
              this.optionalTokens.equals(other.getOptionalTokens()))) &&
            ((this.resParam1==null && other.getResParam1()==null) || 
             (this.resParam1!=null &&
              this.resParam1.equals(other.getResParam1()))) &&
            ((this.resParam2==null && other.getResParam2()==null) || 
             (this.resParam2!=null &&
              this.resParam2.equals(other.getResParam2()))) &&
            ((this.resParam3==null && other.getResParam3()==null) || 
             (this.resParam3!=null &&
              this.resParam3.equals(other.getResParam3())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getResponseTimestamp() != null) {
            _hashCode += getResponseTimestamp().hashCode();
        }
        if (getErrorCode() != null) {
            _hashCode += getErrorCode().hashCode();
        }
        if (getErrorDescription() != null) {
            _hashCode += getErrorDescription().hashCode();
        }
        if (getStatusCode() != null) {
            _hashCode += getStatusCode().hashCode();
        }
        if (getStatusDescription() != null) {
            _hashCode += getStatusDescription().hashCode();
        }
        if (getSender() != null) {
            _hashCode += getSender().hashCode();
        }
        if (getResultCodes() != null) {
            _hashCode += getResultCodes().hashCode();
        }
        if (getOptionalTokens() != null) {
            _hashCode += getOptionalTokens().hashCode();
        }
        if (getResParam1() != null) {
            _hashCode += getResParam1().hashCode();
        }
        if (getResParam2() != null) {
            _hashCode += getResParam2().hashCode();
        }
        if (getResParam3() != null) {
            _hashCode += getResParam3().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Response.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://mailservice.qualtech.com/", "response"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("responseTimestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "responseTimestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errorDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "errorDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusCode");
        elemField.setXmlName(new javax.xml.namespace.QName("", "statusCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("", "statusDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sender");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sender"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resultCodes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "resultCodes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("optionalTokens");
        elemField.setXmlName(new javax.xml.namespace.QName("", "optionalTokens"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resParam1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "resParam1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resParam2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "resParam2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("resParam3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "resParam3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
