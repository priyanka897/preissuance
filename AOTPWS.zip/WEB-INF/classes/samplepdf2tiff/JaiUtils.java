/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package samplepdf2tiff;

/**
 *
 * @author ashu
 */

import com.sun.media.jai.codec.*;
import com.sun.pdfview.PDFFile;
import com.sun.pdfview.PDFPage;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.image.RenderedImage;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.*;
import com.sun.media.jai.codec.TIFFField;
import org.apache.log4j.Logger;
import static com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet.TAG_X_RESOLUTION;
import static com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet.TAG_Y_RESOLUTION;
import static com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet.TAG_RESOLUTION_UNIT;
import static com.sun.media.jai.codec.TIFFField.TIFF_RATIONAL;
import static com.sun.media.jai.codec.TIFFField.TIFF_SHORT;

/**
 * Common class to hold methods for interfacing with the Java Advanced Imaging API.
 * @author Bruce Bilyeu
 */
public class JaiUtils {

    // Value which is used to enlarge or shrink the pixel width
    // and height(resolution) of the outputted image
    //final static double IMAGE_SCALER = 2.1389;
    final static double IMAGE_SCALER = 1.0;
    
    final static Logger logger = Logger.getLogger(JaiUtils.class);

    /**
	 * This procedure uses the PDFRenderer and the Java Advanced Imageing libraries
     * to convert the passed in pdf files into a tiff file which is output to the
     * passed in outputStream.
	 *
	 * @param out OutputStream that is used for writing the Tiff file out to.
	 * @param pdfFiles A list of pdf files which contains references to the pdfs we are going to convert.
	 * @return A boolean which will have the value true if it was successful and false otherwise.
	 */
    
    public static void main(String args[])throws Exception
    {
        
        
        
        if(ConvertPdfsToTiff(new FileOutputStream("D://00.tiff"),new File("D://0.pdf")))
        {
            System.out.println("1");
        }
        else
        {
            System.out.println("2");
        }
        
        
        
    }
    
    
    public static boolean ConvertPdfsToTiff(OutputStream out,File pdfFile) throws Exception{// List<File> pdfFiles) {
        ArrayList<Image> images = new ArrayList<Image>();

        try {
           // for(File pdfFile : pdfFiles) {
                    RandomAccessFile raf = new RandomAccessFile(pdfFile, "r");
                    FileChannel channel = raf.getChannel();
                    ByteBuffer buf = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
                    PDFFile pdf = new PDFFile(buf);
                    //Process each page of the pdf file
                    for (int i = 0; i < pdf.getNumPages(); ++i) {
                        PDFPage page = pdf.getPage(i);
                        if (page != null) {
                            //get the width and height for the doc at the default zoom
                            Rectangle rect = new Rectangle(0, 0, (int) page.getBBox().getWidth(), (int) page.getBBox().getHeight());
                            //generate the image
                            Image img = page.getImage((int) (rect.width*IMAGE_SCALER), (int) (rect.height*IMAGE_SCALER), rect, null, true, true);
                            images.add(img);
                        }
                    }
            //}

            TIFFEncodeParam param = new TIFFEncodeParam();
            //param.setExtraImages(images.listIterator(1));
            param.setCompression(TIFFEncodeParam.COMPRESSION_DEFLATE);
            //Set the dpi for the image it is being set as 200 dpi for both the X and Y resolutions
            TIFFField[] extras = new TIFFField[3];
            extras[0] = new TIFFField(TAG_X_RESOLUTION, TIFF_RATIONAL, 1, (Object)new long[][] {{(long)200, (long)1},{(long)0 ,(long)0}});
            extras[1] = new TIFFField(TAG_Y_RESOLUTION, TIFF_RATIONAL, 1, (Object)new long[][] {{(long)200, (long)1},{(long)0 ,(long)0}});
            extras[2] = new TIFFField(TAG_RESOLUTION_UNIT, TIFF_SHORT, 1, (Object) new char[] {2});
            param.setExtraFields(extras);

            //Packbits compression only works on tiffs that contain large areas of the same color
    //        param.setCompression(TIFFEncodeParam.COMPRESSION_PACKBITS);
           

            ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", out, param);
            encoder.encode((RenderedImage) images.get(0));
            return(true);
        } catch (IOException ioex) {
            logger.error("An IO exception was thrown by the encoder while building the TIFF. ", ioex);
            return(false);
        }
    }
}
