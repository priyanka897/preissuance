/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package samplepdf2tiff;

/**
 *
 * @author ashu
 */
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.renderable.ParameterBlock;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageTypeSpecifier;
import javax.imageio.ImageWriter;
import javax.imageio.metadata.IIOInvalidTreeException;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.FileImageOutputStream;
import javax.media.jai.InterpolationNearest;
import javax.media.jai.JAI;
import javax.media.jai.OpImage;
import javax.media.jai.RenderedOp;

import org.icepdf.core.exceptions.PDFException;
import org.icepdf.core.exceptions.PDFSecurityException;
import org.icepdf.core.pobjects.Document;
import org.icepdf.core.pobjects.Page;
import org.icepdf.core.util.GraphicsRenderingHints;

import com.sun.media.imageio.plugins.tiff.BaselineTIFFTagSet;
import com.sun.media.imageio.plugins.tiff.TIFFDirectory;
import com.sun.media.imageio.plugins.tiff.TIFFField;
import com.sun.media.imageio.plugins.tiff.TIFFTag;
import com.sun.media.jai.codec.SeekableStream;

public class TIFFHELPER {

    /**
     * 
     */
    private static final char[] INCH_RESOLUTION_UNIT = new char[]{2};
    private static final long[][] X_DPI_RESOLUTION = new long[][]{{200, 1}};
    private static final long[][] Y_DPI_RESOLUTION = new long[][]{{200, 1}};
    private static final char[] BITS_PER_SAMPLE = new char[]{1};
    private static final char[] COMPRESSION = new char[]{BaselineTIFFTagSet.COMPRESSION_DEFLATE};
    private static final int HEIGHT = 1650;

    /**
     * Convert a PDF document to a TIF file
     */
    protected static byte[] convert(byte[] pdf, String tif) throws IOException {

        ByteArrayInputStream ipStream = new ByteArrayInputStream(pdf);

        ByteArrayOutputStream opStream = new ByteArrayOutputStream();
        Document pdffile = new Document();
        try {

            pdffile.setInputStream(ipStream, null);

        } catch (PDFException ex) {
            System.out.println("Error parsing PDF document " + ex);
        } catch (PDFSecurityException ex) {
            System.out.println("Error encryption not supported " + ex);
        } catch (FileNotFoundException ex) {
            System.out.println("Error file not found " + ex);
        } catch (IOException ex) {
            System.out.println("Error handling PDF document " + ex);
        }catch (Exception ex) {
            System.out.println("Error handling PDF document " + ex);
        }

        int numPgs = pdffile.getNumberOfPages();
        float scale = 1.1f;
        float rotation = 0.008f;

        BufferedImage image[] = new BufferedImage[numPgs];

        for (int i = 0; i < numPgs; i++) {

            /*
             * Generate the image:
             */
            image[i] = (BufferedImage) pdffile.getPageImage(i,
                    GraphicsRenderingHints.SCREEN, Page.BOUNDARY_CROPBOX,
                    rotation, scale);
            Graphics2D g2 = image[i].createGraphics();
            g2.drawImage(image[i], null, null);
            
            //g2.drawImage(image[i],10,10,1600,2400, null);
            
            ImageIO.write(image[i], "tiff", opStream);

        }

//generate output image in localsyste for testing purpose
        System.out.print("befor save tiffBytes ");
        save(image, tif);
        System.out.print("after save tiffBytes ");
// convert tif to bytes
        byte tiffBytes[] = opStream.toByteArray();
        
        System.out.print(" tiffBytes "+tiffBytes.length);
        return tiffBytes;

    }

    /**
     * Save tiff
     */
    @SuppressWarnings("unchecked")
    private static void save(BufferedImage[] b, String tif) throws IOException {


        ByteArrayOutputStream baos = new ByteArrayOutputStream();
// Get a TIFF writer and set its output.
        Iterator writers = ImageIO.getImageWritersByFormatName("TIFF");

        if (writers == null || !writers.hasNext()) {
            throw new RuntimeException("No writers for available.");
        }

        ImageWriter writer = (ImageWriter) writers.next();
        writer.setOutput(new FileImageOutputStream(new File(tif)));

        writer.prepareWriteSequence(null);

        for (int i = 0; i < b.length; i++) {
            ImageTypeSpecifier imageType = ImageTypeSpecifier
                    .createFromRenderedImage(b[i]);

            IIOMetadata imageMetadata = writer.getDefaultImageMetadata(
                    imageType, null);
            imageMetadata = createImageMetadata(imageMetadata);
            writer.writeToSequence(new IIOImage(b[i], null, imageMetadata),
                    null);
        }

        writer.dispose();
        writer = null;

    }

    /**
     * Return the metadata for the new TIF image
     */
    private static IIOMetadata createImageMetadata(IIOMetadata imageMetadata)
            throws IIOInvalidTreeException {

// Get the IFD (Image File Directory) which is the root of all the tags
// for this image. From here we can get all the tags in the image.
        TIFFDirectory ifd = TIFFDirectory.createFromMetadata(imageMetadata);

// Create the necessary TIFF tags that we want to add to the image
// metadata
        BaselineTIFFTagSet base = BaselineTIFFTagSet.getInstance();

// Resolution tags...
        TIFFTag tagResUnit = base
                .getTag(BaselineTIFFTagSet.TAG_RESOLUTION_UNIT);
        TIFFTag tagXRes = base.getTag(BaselineTIFFTagSet.TAG_X_RESOLUTION);
        TIFFTag tagYRes = base.getTag(BaselineTIFFTagSet.TAG_Y_RESOLUTION);

// BitsPerSample tag
        TIFFTag tagBitSample = base
                .getTag(BaselineTIFFTagSet.TAG_BITS_PER_SAMPLE);

// Row and Strip tags...
        TIFFTag tagRowStrips = base
                .getTag(BaselineTIFFTagSet.TAG_ROWS_PER_STRIP);

// Compression tag
        TIFFTag tagCompression = base
                .getTag(BaselineTIFFTagSet.TAG_COMPRESSION);

// Set the tag values
        TIFFField fieldResUnit = new TIFFField(tagResUnit, TIFFTag.TIFF_SHORT,
                1, INCH_RESOLUTION_UNIT);
        TIFFField fieldXRes = new TIFFField(tagXRes, TIFFTag.TIFF_RATIONAL, 1,
                X_DPI_RESOLUTION);
        TIFFField fieldYRes = new TIFFField(tagYRes, TIFFTag.TIFF_RATIONAL, 1,
                Y_DPI_RESOLUTION);
        TIFFField fieldBitSample = new TIFFField(tagBitSample,
                TIFFTag.TIFF_SHORT, 1, BITS_PER_SAMPLE);
        TIFFField fieldRowStrips = new TIFFField(tagRowStrips,
                TIFFTag.TIFF_LONG, 1, new long[]{HEIGHT});
        TIFFField fieldCompression = new TIFFField(tagCompression,
                TIFFTag.TIFF_SHORT, 1, COMPRESSION);

// Cleanup the fields
// ifd.removeTIFFFields();

// Add the new tag/value sets to the image metadata
        ifd.addTIFFField(fieldResUnit);
        ifd.addTIFFField(fieldXRes);
        ifd.addTIFFField(fieldYRes);
        ifd.addTIFFField(fieldBitSample);
        ifd.addTIFFField(fieldRowStrips);
        ifd.addTIFFField(fieldCompression);

        return ifd.getAsMetadata();

    }

    /**
     * convert pdf file to bytes
     *     
* @param args
     */
    static byte[] convertPDF2Bytes(String fileName) throws Exception {
        File file = new File(fileName);
        System.out.println(file.exists() + "!!");

        FileInputStream fis = new FileInputStream(file);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[1024];
        try {
            for (int readNum; (readNum = fis.read(buf)) != -1;) {
                bos.write(buf, 0, readNum);
                System.out.println("read " + readNum + " bytes,");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        System.out.println("*** Convert All Files to bytes ***");
        byte[] bytes = bos.toByteArray();
        return bytes;

    }

    static byte[] convertByte2TIFF(byte[] bytes) throws Exception {

        ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        SeekableStream s = SeekableStream.wrapInputStream(bis, true);

        RenderedOp image = JAI.create("stream", s);

        ((OpImage) image.getRendering()).setTileCache(null);

        ParameterBlock pb = new ParameterBlock();
        pb.addSource(image); // The source image
        pb.add(1.0F); // The xScale
        pb.add(1.0F); // The yScale
        pb.add(0.0F); // The x translation
        pb.add(0.0F); // The y translation
        pb.add(new InterpolationNearest()); // The interpolation

        RenderedOp resizedImage = JAI.create("scale", pb, null);
// converting all files to tiff format
        RenderedOp op = JAI.create("encode", resizedImage, outputStream,
                "TIFF", null);

// generate output in local file system for testing purpose
        ParameterBlock pbSave = new ParameterBlock();
        pbSave.addSource(op);
        pbSave.add("D:\\image9.tif").add("TIFF");
        RenderedOp save = JAI.create("filestore", pbSave);

// converting tiff format to bytes
        byte[] imgBytes = outputStream.toByteArray();

        return imgBytes;
    }

    public static void main(String args[]) throws Exception {

//        byte[] byte1 = convertPDF2Bytes("D:\\999929989823_9560248542.pdf");
//
//        System.out.println("*****Converted in bytes****" + byte1.length);
//
//        ByteArrayInputStream bis = new ByteArrayInputStream(byte1);
//        BufferedImage iimg = ImageIO.read(bis);
//        if (iimg != null) {
//
//            System.out.println("*** Converting all images bytes to Tiff Bytes");
//
//            byte[] byte2 = convertByte2TIFF(byte1);
//
//            System.out.println("sucessfully converted tif format to bytes" + byte2.length);
//
//        } else {
//
//            System.out.println("** Converting pdf bytes to Tiff bytes");
//            byte[] byte2 = convert(byte1, null);
//
//            System.out.println("*****tiff format in bytes****" + byte2.length);
//
//
//        }
        
        
        tiffCreator("E:\\aa\\999929989823_9560248542.pdf","E:\\aa\\999929989823_9560248542.tif");

    }
    
    public static byte[] tiffCreator(String inputFile, String outFile) throws Exception {

        byte[] byte1 = convertPDF2Bytes(inputFile);

        System.out.println("*****Converted in bytes****" + byte1.length);
        byte[] byte2 = null;

        ByteArrayInputStream bis = new ByteArrayInputStream(byte1);
        BufferedImage iimg = ImageIO.read(bis);
        if (iimg != null) {

            System.out.println("*** Converting all images bytes to Tiff Bytes");

            byte2 = convertByte2TIFF(byte1);

            System.out.println("sucessfully converted tif format to bytes" + byte2.length);

        } else {

            System.out.println("** Converting pdf bytes to Tiff bytes");
            byte2 = convert(byte1, outFile);

            System.out.println("*****tiff format in bytes****" + byte2.length);


        }
        return byte2;
    }
    
    
    
}
