package com.qualtech.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Locale;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;

import org.apache.log4j.Logger;
import org.jpedal.PdfDecoder;

import com.sun.media.imageio.plugins.tiff.TIFFImageWriteParam;

public class PDF_To_Tiff {

	
	private static Logger _logger = Logger.getLogger(PDF_To_Tiff.class.getName());
	
	public static void main(String[] args) 
	{
		new PDF_To_Tiff().testTiff();
	}
	
	public void testTiff()
	{
		byte[] out = null; 
		try 
		{
			File file = new File("//Adhar//999929989823_9560248542.pdf");
			byte[] bai = getBytesFromFile(file);
			
			PdfDecoder decoder = new PdfDecoder();
		      decoder.openPdfArray(bai);
		       if (decoder.isFileViewable())
		      {
		         ByteArrayOutputStream baos = new ByteArrayOutputStream();
		         try
		         {
		            for (int i=0; i<decoder.getPageCount(); i++)		        	
		            {
		            	System.out.println("i "+i);
		               int pageNumber = i + 1;
		               TIFFImageWriteParam param = new TIFFImageWriteParam(new Locale("en"));		              
		               BufferedImage image = decoder.getPageAsImage(pageNumber);
		               
		               boolean foundWriter = false;
		               Iterator writerIter = ImageIO.getImageWritersByFormatName("tiff");
		              // while( writerIter.hasNext() && !foundWriter )
		               //{
		                  foundWriter = true;		                  
		                  ImageIO.write(image, "tiff", baos);		                  
		                  out = baos.toByteArray();
		               //}
		               if( !foundWriter )
		               {
		                  throw new RuntimeException( "Error: no writer found for image type 'Tiff'" );
		               }
		            }
		         }
		         finally
		         {
		            if( baos != null )
		            {
		               baos.flush();
		               baos.close();
		            }
		         }
		      }
		      decoder.closePdfFile();
		      FileOutputStream fout = new FileOutputStream("//Adhar//999929989823_9560248542.tiff");
				fout.write(out);
				fout.close();
		} 
		catch (Exception e) 
		{
		e.printStackTrace();
		}	
	}
	
	public static byte[] getBytesFromFile(File file)
	    throws IOException
	{
	    InputStream is = new FileInputStream(file);
	    long length = file.length();
	    if(length <= 0x7fffffffL);
	    byte bytes[] = new byte[(int)length];
	    int offset = 0;
	    for(int numRead = 0; offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0; offset += numRead);
	    if(offset < bytes.length)
	    {
	        throw new IOException("Could not completely read file " + file.getName());
	    } else
	    {
	        is.close();
	        return bytes;
	    }
	}
	

}
