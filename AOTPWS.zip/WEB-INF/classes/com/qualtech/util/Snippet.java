package com.qualtech.util;

public class Snippet {
	public static void main(String[] args) {
		 
	}
}

