package com.qualtech.util;

/**
 * 
 * @author Mohit Singhal
 *
 */
public interface IApplicationConstants{
	
	/**
	 * OTP Request Type Constants
	 */
	public static final String OTP_REQUEST = "O";
		/**
	 * AUTH Request Type Constants
	 */
	public static final String AUTH_REQUEST = "A";
	
	
	public static final String NOT_AUTH_MSG = "FingerPrint Authentication Failed";
	
	
	public static final String FAIL_STATUS="-1";
	public static final String SUCCESS_STATUS="S";
	
	
	public static final String S="S";
	
	public static final String OK="Y";
	public static final String NOTOK="N";
	
	public static final String ACTIVE="ACTIVE";
	public static final String INACTIVE="INACTIVE";
	
	public static final String OTP_REQ_TYPE1="00";
	public static final String OTP_REQ_TYPE2="01";
	public static final String OTP_REQ_TYPE3="02";
	
	
	public static final String AUTH_FAIL_MSG="Error in authenticating";
	public static final String KYC_FAIL_MSG="Error in getting details";
	
	public static final String OTP_SUCCESS_MSG="OTP generated and sent";
	public static final String KYC_SUCCESS_MSG="Matched and aadhaar details saved";
	public static final String AUTH_SUCCESS_MSG="FingerPrint Authenticated Successfully";
	
	public static final String KYC_SUC_MSG="Details Fetched and saved";
	public static final String KYC_DET_SAVE_ERR="Error in saving aadhaar details";
	
	
	
	public static final String OTP_FAIL_MSG="Error in generating OTP";
	public static final String OTP_SUCC_MSG="OTP generated and sent";
	
	public static final String ERR_DESC_NOTFOUND="NO_DESC";
	
	public static final String AADHAR_REQUIRED="Aadhar Number required";
	
	public static final String OTP_TYPE_REQUIRED="Otp request type required";
	public static final String OTP_TYPE_INVALID="Otp request type is invalid";
	
	public static final String OTP_REQUIRED="OTP required";
	
	public static final String INVALID_REQUEST="Invalid Request";
	
	public static final String INVALID_INPUT="Data Matching Parameters required";
	
	public static final String OTP_BLANK_RESPOSNE="No response fetched from NSDL";
	public static final String KYC_BLANK_RESPOSNE="No response fetched from NSDL";
	public static final String AUTH_BLANK_RESPOSNE="No response fetched from NSDL";
	
	public static final String KYC_ERROR_RESPOSNE="KYC Authentication Failed";
	public static final String AUTH_ERROR_RESPOSNE="AUA Authentication Failed";
	
	public static final String KYC_INVALID_RESPOSNE="Invalid KYC response";
	public static final String AUTH_INVALID_RESPOSNE="Invalid Auth response";
	
	public static final String KYC_NAME_NOT_MATCHED="Customer name Not Matched";
	public static final String KYC_DOB_NOT_MATCHED="Customer DOB Not Matched";
	public static final String KYC_GENDER_NOT_MATCHED="Customer gender Not Matched";
	
	public static final String KYC_MATCHED="Matched";
	
	
	
	public static final String NO_ERROR_DESC="Unknown Message";
	
	
	public static final String URL="URL";
	public static final String KEYSTOREPASSWORD="KEYSTOREPASSWORD";
	public static final String KEYSTOREALIAS="KEYSTOREALIAS";
	public static final String TERMINALID="TERMINALID";
	public static final String AUA="AUA";
	public static final String SA="SA";
	public static final String LICENSEKEY="LICENSEKEY";
	public static final String ASALICENSEKEY="ASALICENSEKEY";
	public static final String PUBLICKEYFILENAME="PUBLICKEYFILENAME";
	public static final String KEYSTOREFILEPATH="KEYSTOREFILEPATH";
	
	public static final String UDC="UDC";
	public static final String DC="DC";
	public static final String DPID="IDC";
	public static final String RDSVER="RDSVER";
	public static final String RDSID="RDSID";
	public static final String PIDVERSION="PIDVERSION";
	public static final String OTPVERSION="OTPVERSION";
	public static final String AUTHVERSION="AUTHVERSION";
	public static final String KYCVERSION="KYCVERSION";
	
	
	public static final String PROXYIP="PROXYIP";
	public static final String PROXYPORT="PROXYPORT";
	public static final String PROXYUSERID="PROXYUSERID";
	public static final String PROXYUSERPWD="PROXYUSERPWD";
	
	public static final String BOTH="00";
	public static final String FOLDER="01";
	public static final String DB="02";
	
	public static final String TIIF_SAVE_MODE="TIIF_SAVE_MODE";
	public static final String AADHAAR_TIFF_SAVE_FOLDER_PATH="AADHAAR_TIFF_SAVE_FOLDER_PATH";
	
	public static final String SMTPHOST="SMTPHOST";
	public static final String SMTPPORT="SMTPPORT";
	
	public static final String SENDER="SENDER";
	public static final String SENDERNAME="SENDERNAME";
	public static final String MAILSUBJECT="MAILSUBJECT";
	public static final String EXCEPTIONCONTENT="EXCEPTIONCONTENT";

	public static final String FINGERPRINT_REQUIRED="Finger print required";
	
	
}



