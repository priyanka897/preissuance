package com.qualtech.util;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.PdfPTable;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;


public class DataToPdfConvertor {
	
	private static Logger _logger = Logger.getLogger(DataToPdfConvertor.class.getName());
	
	public ByteArrayOutputStream dataToPdfConvertor(Map dataMap) {
		
		Map customerDtl = (Map) dataMap.get("customerDtl");
		Map imageMap = (Map) dataMap.get("imageMap");
		
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		
		try {
			   Document document=new Document(PageSize.A4);
		       //PdfWriter.getInstance(document,new FileOutputStream("D:\\aa\\1.pdf"));
			   PdfWriter writer  = PdfWriter.getInstance(document,bos);
		       document.open();
		       PdfContentByte cb = writer.getDirectContent();
		       
		       
		       PdfPTable table = new PdfPTable(2);
		       Iterator it = customerDtl.entrySet().iterator();
				 while (it.hasNext()) 
				 {
				        Map.Entry pairs = (Map.Entry)it.next();
				        if(pairs.getKey() != null && pairs.getValue() != null && !pairs.getKey().equals("pht"))
				        {
				        	_logger.debug(pairs.getKey() + " = " + pairs.getValue());
				           table.addCell(pairs.getKey().toString());
					       table.addCell(pairs.getValue().toString());
				        }
				        it.remove(); // avoids a ConcurrentModificationException
				  }
		       document.add(table);
		       //document.newPage();
		       byte[] imgByte = (byte[]) imageMap.get("Pht");
		       Image image = Image.getInstance(imgByte);
		       
		       if (image.scaledWidth() > 600 || image.scaledHeight() > 750) {
		    	   image.scaleToFit(100, 150);
				}
		       document.setPageSize(PageSize.A4);
		       //image.scaleAbsolute(150f, 150f);
		       image.setAbsolutePosition(200, 100);
		       cb.addImage(image);
		       
		       _logger.debug("data to pdf created");
		       
		       document.close();	
		       bos.flush();
		       
		} catch (Exception e) {
			e.printStackTrace();
			 _logger.error("exception in convertingg data 2 PDF "+e,new Throwable());
		}
				
		 return bos;
	}
}
