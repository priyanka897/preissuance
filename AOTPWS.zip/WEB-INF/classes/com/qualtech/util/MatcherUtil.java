package com.qualtech.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.qualtech.webservice.exception.AppBaseException;


public class MatcherUtil {
	
	private static Logger _logger = Logger.getLogger(MatcherUtil.class
			.getName());
	
	
	public boolean checkName(String givenCustName , String kycCustName)
	{
		boolean nameStatus = false;
		
		String givenName=givenCustName;
		givenName  = givenName.trim();
		givenName= givenName.replaceAll(" ", "");
		givenName = givenName.toUpperCase();
		
		
		String kycName=kycCustName;
		kycName  = kycName.trim();
		kycName= kycName.replaceAll(" ", "");
		kycName = kycName.toUpperCase();
		
		if(givenName.equals(kycName))
		{
			nameStatus = true;
			_logger.debug("name matched....");
		}
		return nameStatus;
		
	}
	
	public boolean checkGender(String givenCustGender , String kycCustGender)
	{
		boolean genderStatus = false;
		
		String givenGender=givenCustGender;
		givenGender  = givenGender.trim();
		givenGender = givenGender.toUpperCase();
		
		String kycGender=kycCustGender;
		kycGender  = kycGender.trim();
		kycGender = kycGender.toUpperCase();
		
		if(givenGender.equals(kycGender))
		{
			genderStatus = true;
			_logger.debug("gender matched....");
		}
		return genderStatus;
		
	}
	
	public boolean checkDOB(String givenCustDOB , String kycCustDOB) 
	{
		boolean dobStatus = false;
		
		String givenDOB=givenCustDOB;
		givenDOB  = givenDOB.trim();

		
		String kycDOB=kycCustDOB;
		kycDOB  = kycDOB.trim();

		
		SimpleDateFormat newformat = new SimpleDateFormat("dd-MM-yyyy");
		
		try {
		Date givD = newformat.parse(givenDOB);
		
		
		DateFormat userDateFormat = new SimpleDateFormat("dd-MM-yyyy");  
        DateFormat dateFormatNeeded = new SimpleDateFormat("dd-MM-yyyy");  
        Date date = userDateFormat.parse(kycDOB);  
        String convertedDate = dateFormatNeeded.format(date); 
        
		Date kycD = newformat.parse(convertedDate);
				
		if(givD.compareTo(kycD)==0)
		{
			dobStatus = true;
			_logger.debug("DOB matched....");
		}
		} 
		catch (Exception e) {
			_logger.debug("parser exception in comparing dates " +e,new Throwable());
			//throw new AppBaseException("parser exception in comparing dates " +e);
			
		}
		
		return dobStatus;
		
	}
	
	
	

}
