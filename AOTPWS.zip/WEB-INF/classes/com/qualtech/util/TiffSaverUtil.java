package com.qualtech.util;

import java.io.FileOutputStream;
import java.util.List;
import java.util.PropertyResourceBundle;

import org.apache.log4j.Logger;

import samplepdf2tiff.TIFFHELPER;

import com.qualtech.in.gov.uidai.auth.aua.qc.NSDLPropertyUtil;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;


public class TiffSaverUtil {
	
	private static Logger _logger = Logger.getLogger(TiffSaverUtil.class.getName());
	
	
	public boolean saveTiff(InputRequestDVO req  , ResponseDVO res)
	{
		_logger.debug("going to save tiff");
		PropertyResourceBundle bund = null;
		String tiffSaveMode ="";
		byte[] tiffBytes = null;
		boolean folderStatus= false;
		boolean dbStatus= false;
		boolean tifSaveStatus= false;
		try
		{
			bund = NSDLPropertyUtil.getInstance().getNDSLProp();
			tiffSaveMode  =bund.getString(IApplicationConstants.TIIF_SAVE_MODE);
			
			tiffBytes = res.getTiffByte();
			
			if(tiffBytes!=null)
			{
				if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.BOTH))
				{
					_logger.debug("going to save tiff in both DB and folder");
					folderStatus = saveTiffInFolder(tiffBytes  ,req );
					
				//	dbStatus = saveTiffInDB(req ,res );
					
					if(folderStatus && dbStatus)
					{
						tifSaveStatus =true;
						_logger.debug("Tiff saved in both DB and folder successfully");
					}
					
					
				}
				else if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.FOLDER))
				{
					_logger.debug("going to save tiff in folder only");
					folderStatus = saveTiffInFolder(tiffBytes  ,req );
					
					if(folderStatus)
					{
						tifSaveStatus =true;
						_logger.debug("Tiff saved in folder successfully");
					}
					
				}
				else if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.DB))
				{
					_logger.debug("going to save tiff in DB only ");
					
				//	dbStatus = saveTiffInDB(req ,res );
					
					if(dbStatus)
					{
						tifSaveStatus =true;
						_logger.debug("Tiff saved in Database successfully");
					}
				}
				else
				{
					_logger.debug("invalid tiff save mode ");
				}
			
			}
			else
			{
				_logger.debug("invalid tiff bytes.... ");
			}
			
			
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
			tifSaveStatus = false;
			_logger.error("Exception in saving tiff file "+ee,new Throwable());
		}
		
		return tifSaveStatus;
	}
	
	
	public boolean savePDF(InputRequestDVO req  , ResponseDVO res)
	{
		_logger.debug("going to save pdf");
		PropertyResourceBundle bund = null;
		String tiffSaveMode ="";
		byte[] tiffBytes = null;
		boolean folderStatus= false;
		boolean dbStatus= false;
		boolean tifSaveStatus= false;
		try
		{
			bund = NSDLPropertyUtil.getInstance().getNDSLProp();
			tiffSaveMode  =bund.getString(IApplicationConstants.TIIF_SAVE_MODE);
			
			tiffBytes = res.getTiffByte();
			
			if(tiffBytes!=null)
			{
				if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.BOTH))
				{
					_logger.debug("going to save pdf in both DB and folder");
					System.out.println("going to save pdf in both DB and folder");
					folderStatus = savePdfInFolder(tiffBytes  ,req );
					
				//	dbStatus = savePdfInDB(req ,res );
					
					if(folderStatus && dbStatus)
					{
						tifSaveStatus =true;
						System.out.println("pdf saved in both DB and folder successfully");
						_logger.debug("pdf saved in both DB and folder successfully");
					}
					
					
				}
				else if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.FOLDER))
				{
					System.out.println("going to save pdf in folder only");
					_logger.debug("going to save pdf in folder only");
					folderStatus = savePdfInFolder(tiffBytes  ,req );
					
					if(folderStatus)
					{
						tifSaveStatus =true;
						System.out.println("pdf saved in folder successfully");
						_logger.debug("pdf saved in folder successfully");
					}
					
				}
				else if(tiffSaveMode.equalsIgnoreCase(IApplicationConstants.DB))
				{
					System.out.println("going to save pdf in DB only ");
					_logger.debug("going to save pdf in DB only ");
				//	dbStatus = savePdfInDB(req ,res );
					
					if(dbStatus)
					{
						tifSaveStatus =true;
						System.out.println("pdf saved in Database successfully");
						_logger.debug("pdf saved in folder successfully");
					}
				}
				else
				{
					System.out.println("invalid pdf save mode ");
					_logger.debug("pdf saved in folder successfully");
				}
			
			}
			else
			{
				System.out.println("invalid pdf bytes.... ");
				_logger.debug("pdf saved in folder successfully");
			}
			
			
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
			tifSaveStatus = false;
			_logger.error("Exception in saving tiff file "+ee,new Throwable());
			System.out.println("Exception in saving tiff file "+ee.getMessage());
		}
		
		return tifSaveStatus;
	}
	
	/*boolean saveTiffInDB(InputRequestDVO req  , ResponseDVO res)
	{
		 boolean saveStatus =false;
		//AadharDAO aDao = new AadharDAO();
		try
		{
			if(aDao.saveTiffInDB(req, res))
			{
				if(req.getPropNumList().size()>1)
				{
					if(aDao.savePdfReplicaFor2ndProposal(req  , res))
					 saveStatus =true;
				}
				else
				{
					saveStatus =true;
				}
				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
			saveStatus = false;
			_logger.error("Exception in saving tiff file in DB "+ee,new Throwable());
		}
		
		return saveStatus;
		
	}*/
	
	
/*	boolean savePdfInDB(InputRequestDVO req  , ResponseDVO res)
	{
		 boolean saveStatus =false;
	//	AadharDAO aDao = new AadharDAO();
		try
		{
			if(aDao.savePdfInDB(req, res))
			{
				if(req.getPropNumList().size()>1)
				{
					if(aDao.savePdfReplicaFor2ndProposal(req  , res))
					 saveStatus =true;
				}
				else
				{
					saveStatus =true;
				}
				
			}
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
			saveStatus = false;
			_logger.error("Exception in saving tiff file in DB "+ee,new Throwable());
		}
		
		return saveStatus;
		
	}*/
	
	
	boolean saveTiffInFolder(byte[] tiffBytes  ,InputRequestDVO req)
	{
		 List propList =  req.getPropNumList();
		 String imgStorePath="";
		 boolean saveStatus =false;
		 try
		 {
			PropertyResourceBundle pBundle = NSDLPropertyUtil.getInstance().getNDSLProp();
		 
			 imgStorePath = pBundle.getString(IApplicationConstants.AADHAAR_TIFF_SAVE_FOLDER_PATH);
			 for(int i=1;i<propList.size();i++)
			 {
				 for(int j=0;j<propList.get(i).toString().split("~").length;j++)
				 {
					 _logger.debug("Tiff  saved in image folder successfully"+imgStorePath+req.getAadharNo()+"_"+propList.get(i).toString().split("~")[j]+".tif");
					 FileOutputStream imgFos = new FileOutputStream(imgStorePath+req.getAadharNo()+"_"+propList.get(i).toString().split("~")[j]+".tif");
					 _logger.debug("Tiff  saved in image folder successfully");
					 System.out.println("Tiff  saved in image folder successfully");
					 imgFos.write(tiffBytes);
					 imgFos.close();
					 System.out.println("Tiff  saved in image folder successfully");
					 _logger.debug("Tiff  saved in image folder successfully");
				 }
			 }
			 saveStatus = true;
			 _logger.debug("Tiff saved in image folder successfully");
		 }
		 catch(Exception ee)
		 {
			 ee.printStackTrace();
			 saveStatus =false;
			 _logger.error("Exception in saving tiff file in image folder "+ee,new Throwable());
		 }
		
		 return saveStatus;
	}
	
	boolean savePdfInFolder(byte[] tiffBytes  ,InputRequestDVO req)
	{
		 List propList =  req.getPropNumList();
		 String imgStorePath="";
		 boolean saveStatus =false;
		 try
		 {
			PropertyResourceBundle pBundle = NSDLPropertyUtil.getInstance().getNDSLProp();
		 
			 imgStorePath = pBundle.getString(IApplicationConstants.AADHAAR_TIFF_SAVE_FOLDER_PATH);
			 for(int i=1;i<propList.size();i++)
			 {
				 for(int j=0;j<propList.get(i).toString().split("~").length;j++)
				 {
					 _logger.debug("pdf saved in image folder successfully"+imgStorePath+req.getAadharNo()+"_"+propList.get(i).toString().split("~")[j]+".pdf");
					 System.out.println("pdf saved in image folder successfully"+imgStorePath+req.getAadharNo()+"_"+propList.get(i).toString().split("~")[j]+".pdf");
					 FileOutputStream imgFos = new FileOutputStream(imgStorePath+req.getAadharNo()+"_"+propList.get(i).toString().split("~")[j]+".pdf");
					 _logger.debug("pdf saved in image folder successfully");
					 System.out.println("pdf saved in image folder successfully");
					 imgFos.write(tiffBytes);
					 imgFos.close();
					 System.out.println("pdf saved in image folder successfully");
					 _logger.debug("pdf saved in image folder successfully");
				 }
			 }
			 saveStatus = true;
			 System.out.println("pdf saved in image folder successfully");
			 _logger.debug("pdf saved in image folder successfully");
		 }
		 catch(Exception ee)
		 {
			 ee.printStackTrace();
			 saveStatus =false;
			 System.out.println("Exception in saving pdf file in image folder "+ee);
			 _logger.error("Exception in saving pdf file in image folder "+ee,new Throwable());
		 }
		
		 return saveStatus;
	}

}
