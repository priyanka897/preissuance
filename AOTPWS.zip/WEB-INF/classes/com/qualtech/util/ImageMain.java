package com.qualtech.util;

import com.qualtech.webservice.helper.KYCResponseParser;
import com.sun.media.imageioimpl.plugins.tiff.TIFFImageReaderSpi;
//import com.sun.pdfview.PDFFile;
//import com.sun.pdfview.PDFPage;

import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Transparency;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import javax.imageio.ImageIO;
import javax.imageio.spi.IIORegistry;
import javax.swing.*;


import org.apache.log4j.Logger;

import java.awt.image.*;

public class ImageMain {
	private static Logger _ologger = Logger.getLogger(ImageMain.class
			.getName());
//	 public static byte[] setupCalling(String inFile,String outFile) throws Exception {
//		 
//		 System.out.println("outFile "+outFile +" inFile"+inFile);
//	        // load a pdf from a byte buffer
//	        File file = new File(inFile);
//	        byte[]  outByte = null;
//	        RandomAccessFile raf = new RandomAccessFile(file, "r");
//	        System.out.println("outFile "+outFile +" inFile  1");
//	        FileChannel channel = raf.getChannel();
//	        ByteBuffer buf = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
//	        PDFFile pdffile = new PDFFile(buf);
//	        int numPgs = pdffile.getNumPages();
//	        
//	        IIORegistry reg = IIORegistry.getDefaultInstance();
//	        reg.registerServiceProvider(new TIFFImageReaderSpi());
//	        
//	        System.out.println("outFile numPgs "+numPgs +" numPgs  1");
//	        for (int i = 0; i < numPgs; i++) {
//	            // draw the first page to an image
//	            PDFPage page = pdffile.getPage(i);
//	            // get the width and height for the doc at the default zoom
//	            Rectangle rect = new Rectangle(0, 0, (int) page.getBBox().getWidth(), (int) page.getBBox().getHeight());
//	            // generate the image
//	            Image img = page.getImage(rect.width, rect.height, // width & height
//	                    rect, // clip rect
//	                    null, // null for the ImageObserver
//	                    true, // fill background with white
//	                    true // block until drawing is done
//	                    );
//	            // save it as a file
//	            BufferedImage bImg = toBufferedImage(img);
//	            File yourImageFile = new File(outFile);
//	            System.out.println("outFile numPgs "+numPgs +" numPgs  2");
//	            ImageIO.write(bImg, "bmp", yourImageFile);
//	            System.out.println("outFile numPgs "+numPgs +" numPgs  3");
//	            FileInputStream fin = null;
//	            try{
//	            	//RandomAccessFile f = new RandomAccessFile(outFile, "r");
//	            	System.out.println("outFile numPgs "+numPgs +" numPgs  4");
//	            	File fileoutFile = new File(inFile);
//	            	fin = new FileInputStream(fileoutFile);
//	            	System.out.println("outFile numPgs "+numPgs +" numPgs  5");
//	            	outByte = new byte[(int)fileoutFile.length()];
//	            	System.out.println("outFile numPgs "+numPgs +" numPgs  6");
//	            	if(fileoutFile != null)
//	            	{
//	            		fileoutFile.deleteOnExit();
//	            	}
//	            	
//	            }
//	            catch(Exception ex)
//	            {
//	            	outByte = null;
//	            	ex.printStackTrace();
//	            }
//	            finally
//	            {
//	            	try{
//	            	if(fin != null)
//	            		fin.close();
//	            	}
//	            	catch(Exception ex)
//	            	{
//	            		ex.printStackTrace();
//	            	}
//	            }
//	            
//	            
//	        }
//	        System.out.println("outFile numPgs "+numPgs +" numPgs  6"+outByte);
//	        return outByte;
//	        
//	    }
//	
//	
//    public static void setup() throws IOException {
//        // load a pdf from a byte buffer
//        File file = new File("E://aa//999929989823_9560248542.pdf");
//        RandomAccessFile raf = new RandomAccessFile(file, "r");
//        FileChannel channel = raf.getChannel();
//        ByteBuffer buf = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size());
//        PDFFile pdffile = new PDFFile(buf);
//        int numPgs = pdffile.getNumPages();
//        for (int i = 0; i < numPgs; i++) {
//            // draw the first page to an image
//            PDFPage page = pdffile.getPage(i);
//            // get the width and height for the doc at the default zoom
//            Rectangle rect = new Rectangle(0, 0, (int) page.getBBox().getWidth(), (int) page.getBBox().getHeight());
//            // generate the image
//            Image img = page.getImage(rect.width, rect.height, // width & height
//                    rect, // clip rect
//                    null, // null for the ImageObserver
//                    true, // fill background with white
//                    true // block until drawing is done
//                    );
//            // save it as a file
//            BufferedImage bImg = toBufferedImage(img);
//            File yourImageFile = new File("E://aa/page_" + i + ".tiff");
//            ImageIO.write(bImg, "tiff", yourImageFile);
//        }
//    }
//
//    // This method returns a buffered image with the contents of an image
//    public static BufferedImage toBufferedImage(Image image) {
//        if (image instanceof BufferedImage) {
//            return (BufferedImage) image;
//        }
//        // This code ensures that all the pixels in the image are loaded
//        image = new ImageIcon(image).getImage();
//        // Determine if the image has transparent pixels; for this method's
//        // implementation, see e661 Determining If an Image Has Transparent
//        // Pixels
//        boolean hasAlpha = hasAlpha(image);
//        // Create a buffered image with a format that's compatible with the
//        // screen
//        BufferedImage bimage = null;
//        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
//        try {
//            // Determine the type of transparency of the new buffered image
//            int transparency = Transparency.OPAQUE;
//            if (hasAlpha) {
//                transparency = Transparency.BITMASK;
//            }
//            // Create the buffered image
//            GraphicsDevice gs = ge.getDefaultScreenDevice();
//            GraphicsConfiguration gc = gs.getDefaultConfiguration();
//            bimage = gc.createCompatibleImage(image.getWidth(null), image.getHeight(null), transparency);
//        } catch (HeadlessException e) {
//            // The system does not have a screen
//        }
//        if (bimage == null) {
//            // Create a buffered image using the default color model
//            int type = BufferedImage.TYPE_INT_RGB;
//            if (hasAlpha) {
//                type = BufferedImage.TYPE_INT_ARGB;
//            }
//            bimage = new BufferedImage(image.getWidth(null), image.getHeight(null), type);
//        }
//        // Copy image to buffered image
//        Graphics g = bimage.createGraphics();
//        // Paint the image onto the buffered image
//        g.drawImage(image, 0, 0, null);
//        g.dispose();
//        return bimage;
//    }
//
//    public static boolean hasAlpha(Image image) {
//        // If buffered image, the color model is readily available
//        if (image instanceof BufferedImage) {
//            BufferedImage bimage = (BufferedImage) image;
//            return bimage.getColorModel().hasAlpha();
//        }
//        // Use a pixel grabber to retrieve the image's color model;
//        // grabbing a single pixel is usually sufficient
//        PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
//        try {
//            pg.grabPixels();
//        } catch (InterruptedException e) {
//        }
//        // Get the image's color model
//        ColorModel cm = pg.getColorModel();
//        return cm.hasAlpha();
//    }
//
//    public static void main(final String[] args) {
//        SwingUtilities.invokeLater(new Runnable() {
//            public void run() {
//                try {
//                    ImageMain.setup();
//                } catch (IOException ex) {
//                    ex.printStackTrace();
//                }
//            }
//        });
//    }
}