package com.qualtech.util;

/*
 * Main.java
 *
 * Created on March 19, 2007, 1:33 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */


import org.jpedal.*;

import com.sun.media.imageio.plugins.tiff.TIFFField;
import com.sun.media.jai.codec.TIFFEncodeParam;
import com.sun.media.jai.codecimpl.TIFFImageEncoder;
 
import java.io.*;
 
import javax.imageio.*;
import javax.imageio.stream.*;
import javax.media.jai.PlanarImage;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.DataBuffer;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
 
import java.util.*;
/**
 *
 * @author 43255810
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    public static byte[] PDFToImage(byte[] bai, String imageType) 
    {
	byte[] out = null;
	try 
	{
		PdfDecoder decoder = new PdfDecoder();
		decoder.openPdfArray(bai);
		if (decoder.isFileViewable()) 
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageOutputStream ios = ImageIO.createImageOutputStream(baos);
			boolean foundWriter = false;
			Iterator writerIter = ImageIO.getImageWritersByFormatName(imageType);
			while (writerIter.hasNext() && !foundWriter) 
			{
				foundWriter = true;
				ImageWriter writer = (ImageWriter)writerIter.next();
				writer.setOutput(ios);
				ImageWriteParam param = writer.getDefaultWriteParam();
				writer.prepareWriteSequence(null);
				for (int i = 0; i < decoder.getPageCount(); i++) 
				{
					int pageNumber = i + 1;
					BufferedImage image = decoder.getPageAsImage(pageNumber);
					IIOImage iioImage = new IIOImage(image, null, null);													
					writer.writeToSequence(iioImage, param);
				}
				writer.endWriteSequence();
				ios.flush();
				writer.dispose();
				ios.close();
				out = baos.toByteArray();
			}
			if (!foundWriter) 
			{
				throw new RuntimeException("Error: no writer found for image type '"
								+ imageType
								+ "'");
			}
		}
		decoder.closePdfFile();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	return out;
    }

    public static byte[] PDFToTiff(String FileName, String imageType) 
    {
	byte[] out = null;
	try 
	{
		PdfDecoder decoder = new PdfDecoder();
		decoder.openPdfFile(FileName);
		if (decoder.isFileViewable()) 
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageOutputStream ios = ImageIO.createImageOutputStream(baos);
			boolean foundWriter = false;
			Iterator writerIter = ImageIO.getImageWritersByFormatName(imageType);
			while (writerIter.hasNext() && !foundWriter) 
			{
				foundWriter = true;
				ImageWriter writer = (ImageWriter)writerIter.next();
				writer.setOutput(ios);
				ImageWriteParam param = writer.getDefaultWriteParam();
				writer.prepareWriteSequence(null);
				for (int i = 0; i < decoder.getPageCount(); i++) 
				{
					int pageNumber = i + 1;
					BufferedImage image = decoder.getPageAsImage(pageNumber);
					IIOImage iioImage = new IIOImage(image, null, null);													
					writer.writeToSequence(iioImage, param);
				}
				writer.endWriteSequence();
				ios.flush();
				writer.dispose();
				ios.close();
				out = baos.toByteArray();
			}
			if (!foundWriter) 
			{
				throw new RuntimeException("Error: no writer found for image type '"
								+ imageType
								+ "'");
			}
		}
		decoder.closePdfFile();
	} 
	catch (Exception e) 
	{
		e.printStackTrace();
	}
	return out;
    }
    
    /**
     * @param args the command line arguments
     */
//    public static void main(String[] args) {
//        // TODO code application logic here        
//        try 
//        {
//        	
//        	//open document
//        	com.aspose.pdf.Document pdfDocument = new com.aspose.pdf.Document("input.pdf");
//        	// create stream object to save the output image
//        	java.io.OutputStream imageStream = new java.io.FileOutputStream("Converted_Image.tiff");
//
//        	//create Resolution object
//        	com.aspose.pdf.Resolution resolution = new  Resolution(300);
//        	//create TiffDevice object with particular resolution
//        	com.aspose.pdf.TiffDevice   tiffDevice = new com.aspose.pdf.TiffDevice(resolution);
//        	//convert a particular page (Page 1) and save the image to stream
//        	tiffDevice.process(pdfDocument,1,1, imageStream);
//
//        	//close the stream
//        	imageStream.close();
//        	
//        	
//        	
////            String inputFile = args[0];
////            String outputFile = args[1];
////            FileOutputStream fos = new FileOutputStream(outputFile);
////
////            byte[] out = PDFToTiff(inputFile,"TIF");
////            fos.write(out);
////            fos.flush();
////            fos.close();
//        }
//        catch(Exception e)
//        {
//            System.out.println("Error: " + e.getMessage());
//        }
//    }
    
    
    public static void main(String[] args)
    {
        Main me = new Main();
        try
        {
            me.runMe(args);

        } catch (Exception e)
        {
            e.printStackTrace();
        }
    }

//  -----------------------------------------------------------------------------------------------------    
    private void runMe(String[] args) throws Exception
    {
    
        File myFile = new File("E:\\AnnotatedTif.tif");  
        if (myFile.exists())
            myFile.delete();
        
        FileOutputStream fout = new FileOutputStream(myFile); 
        String annotateStrings[] = new String[] {"This is the first annotation","Some more annotation","and a third line","and a third line","and a third line","and a third line","and a third line","and a third line"};  
        createAnnotatedTif( annotateStrings, fout);
        fout.close();
        System.out.println("Completed.");
    }

    //  -----------------------------------------------------------------------------------------------------    
        public void createAnnotatedTif(String[] args, OutputStream out) throws Exception
        {
             
        byte[] byteArray = new byte[] { -1, 0 };
        ColorModel colorModel = new IndexColorModel(1, 2, byteArray, byteArray, byteArray);
        
        WritableRaster writeableRaster = Raster.createPackedRaster(DataBuffer.TYPE_BYTE, 1700, 2200, 1, 1, null);
        BufferedImage bufImg = new BufferedImage(colorModel, writeableRaster, false, null);
        
        // -------------------------------------------------------------------        
        Graphics2D g2d = bufImg.createGraphics() ; 
        g2d.setColor ( Color.black ) ;
        
        Font font = new Font("Arial Bold", Font.PLAIN, 36);
        g2d.setFont(font); 
        int vertPos = 200; 
        for (int i=0; i<args.length; i++)
        {
            g2d.drawString ( args[i], 75, vertPos ) ;
            vertPos += 48; 
        }
         
        PlanarImage planarImage = PlanarImage.wrapRenderedImage ( bufImg ) ; 
                      
        TIFFEncodeParam encodeParam = new TIFFEncodeParam ();
        encodeParam.setCompression(TIFFEncodeParam.COMPRESSION_GROUP4);
        encodeParam.setWriteTiled(false);  // false means use strips.
        encodeParam.setTileSize(0, 0);  // tiling will make the file size much larger. 
        encodeParam.setLittleEndian(true);  // create an Intel (II) format image
        
        String SoftwareVersion[] = new String[] {"TIFF by Joe, " + this.getClass().getName()};
        String docName[] = new String[] {"JoesTifAnnotator"}; 
        
        // Create a new TIFF fields including a new TIFF ASCII TIFF tag.
        TIFFField tiffFields[] = new TIFFField[5]; 
//        
//        tiffFields[0] = new TIFFField(269, TIFFField.TIFF_ASCII, docName.length, docName);
//        tiffFields[1] = new TIFFField(282, TIFFField.TIFF_RATIONAL, 1, new long[][] {{ 200, 1 } });
//        tiffFields[2] = new TIFFField(283, TIFFField.TIFF_RATIONAL, 1, new long[][] { { 200, 1 } });
//        // resolution unit 
//        tiffFields[3] = new TIFFField(296, TIFFField.TIFF_SHORT, 1, new char[] { 2 });
//        tiffFields[4] = new TIFFField(305, TIFFField.TIFF_ASCII, SoftwareVersion.length, SoftwareVersion);  
//        
       // encodeParam.setExtraFields( tiffFields );
               
        TIFFImageEncoder encoder = new TIFFImageEncoder (out, encodeParam);
        encoder.encode(planarImage);         
    }
    

}

