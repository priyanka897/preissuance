package com.qualtech.util;

import org.icepdf.core.pobjects.Document;
import org.icepdf.core.pobjects.Page;
import org.icepdf.core.pobjects.PDimension;
import org.icepdf.core.exceptions.PDFException;
import org.icepdf.core.exceptions.PDFSecurityException;
import org.icepdf.core.util.GraphicsRenderingHints;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriter;
import javax.imageio.IIOImage;
import javax.imageio.ImageWriteParam;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.awt.image.IndexColorModel;
import java.awt.image.DataBuffer;
import java.awt.*;
import java.io.*;

public class MultiPageCapture {
public static final double PRINTER_RESOLUTION = 300.0;
public static final String COMPRESSION_TYPE = "CCITT T.6";

public static void main(String[] args) {
String filePath = "E:\\aa\\2.pdf";
Document document = new Document();
try {
document.setFile(filePath);
} catch (PDFException ex) {
System.out.println("Error parsing PDF document " + ex);
} catch (PDFSecurityException ex) {
System.out.println("Error encryption not supported " + ex);
} catch (FileNotFoundException ex) {
System.out.println("Error file not found " + ex);
} catch (IOException ex) {
System.out.println("Error handling PDF document " + ex);
}
try {
File file = new File("E:\\aa\\2.tif");
System.out.println("Output file location " + file);
ImageOutputStream ios = ImageIO.createImageOutputStream(file);
ImageWriter writer = ImageIO.getImageWritersByFormatName("tiff").next();
writer.setOutput(ios);
for (int i = 0; i < document.getNumberOfPages(); i++)
{
final double targetDPI = PRINTER_RESOLUTION;
float scale = 1.0f;
float rotation = 0f;
PDimension size = document.getPageDimension(i, rotation, scale);
double dpi = Math.sqrt((size.getWidth()*size.getWidth()) + (size.getHeight()*size.getHeight()) ) /Math.sqrt((8.5*8.5)+(11*11));
if (dpi < (targetDPI-0.1))
{
scale = (float) (targetDPI / dpi);
size = document.getPageDimension(i, rotation, scale);
}
int pageWidth = (int) size.getWidth();
int pageHeight = (int) size.getHeight();
int[] cmap = new int[] { 0xFF000000, 0xFFFFFFFF };
IndexColorModel cm = new IndexColorModel(1, cmap.length, cmap, 0, false, Transparency.OPAQUE,DataBuffer.TYPE_BYTE);
BufferedImage image = new BufferedImage(pageWidth, pageHeight, BufferedImage.TYPE_BYTE_BINARY, cm);
Graphics g = image.createGraphics();
document.paintPage(i, g, GraphicsRenderingHints.PRINT, Page.BOUNDARY_CROPBOX,rotation, scale);
g.dispose();
IIOImage img = new IIOImage(image, null, null);
ImageWriteParam param = writer.getDefaultWriteParam();
param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
param.setCompressionType(COMPRESSION_TYPE);
if (i == 0)
{
writer.write(null, img, param);
}
else
{
writer.writeInsert(-1, img, param);
}
image.flush();
}
ios.flush();
ios.close();
writer.dispose();
System.out.println("PDF converted to Tiff successfully with compression type " + COMPRESSION_TYPE);
}
catch(IOException e) {
System.out.println("Error saving file " + e);
e.printStackTrace();
}
document.dispose();
} 
}