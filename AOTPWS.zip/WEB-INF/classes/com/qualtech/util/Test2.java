package com.qualtech.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Iterator;


import javax.imageio.IIOImage;

import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;

import org.apache.log4j.Logger;
import org.jpedal.PdfDecoder;

public class Test2 {
	
	private static Logger _logger = Logger.getLogger(Test2.class.getName());
	
	public byte[] PDFToImage(byte[] bai, String imageType) 
	{
		
		
	     byte[] out = null;
	     try 
	     {
	          PdfDecoder decoder = new PdfDecoder();
	          decoder.openPdfArray(bai);
	  //        System.out.println("decoder.isFileViewable() "+decoder.isFileViewable());
	          _logger.info("decoder.isFileViewable() "+decoder.isFileViewable());
	          if (decoder.isFileViewable()) 
	          {
	 //       	  System.out.println("decoder.isFileViewable() "+decoder.isFileViewable());
	        	  
	               ByteArrayOutputStream baos = new ByteArrayOutputStream();
	               ImageOutputStream ios = ImageIO.createImageOutputStream(baos);
	               boolean foundWriter = false;
	               
	               Iterator<ImageWriter> writerIter = ImageIO.getImageWritersByFormatName(imageType);
	     //          System.out.println("decoder.isFileViewable() writerIter "+writerIter);
	     //          System.out.println("decoder.isFileViewable() writerIter.toString()"+writerIter.toString());
	    //           System.out.println("decoder.isFileViewable() "+writerIter);
	 	          _logger.info("decoder.isFileViewable() "+writerIter.hasNext());
	 	          
	  //             System.out.println("writerIter "+writerIter.hasNext());
	               
	               //while (writerIter.hasNext() && !foundWriter)
	               for(int ii=0;ii<2;ii++)
	               {
	  //          	   System.out.println("decoder.isFileViewable() "+writerIter.hasNext());
	 	 	          _logger.info("decoder.isFileViewable() "+writerIter.hasNext());
	 	 	          
	            	   
	                    foundWriter = true;
	                    ImageWriter writer = (ImageWriter)writerIter.next();
	  //                  System.out.println("decoder.isFileViewable() writer  writerIter.next() ");
	                    
	 //                   System.out.println("decoder.isFileViewable() writer "+writer);
	                    
	 //                   System.out.println("decoder.isFileViewable() ImageWriter "+writerIter.hasNext());
		 	 	          _logger.info("decoder.isFileViewable() ImageWriter "+writerIter.hasNext());
	                    writer.setOutput(ios);
	//                    System.out.println("decoder.isFileViewable() writer ios "+ios);
	                    ImageWriteParam param = writer.getDefaultWriteParam();
	                    writer.prepareWriteSequence(null);
	//                    System.out.println("decoder.isFileViewable() writer prepareWriteSequence ");
	//                    System.out.println("decoder.isFileViewable() ImageWriter param "+writerIter.hasNext());
		 	 	          _logger.info("decoder.isFileViewable() ImageWriter "+writerIter.hasNext());
	                    
	                    for (int i = 0; i < decoder.getPageCount(); i++) 
	                    {
	                         int pageNumber = i + 1;
	                         BufferedImage image = decoder.getPageAsImage(pageNumber);
	                         IIOImage iioImage = new IIOImage(image, null, null);                                                                 
	                         writer.writeToSequence(iioImage, param);
	                    }
	                    writer.endWriteSequence();
	                    ios.flush();
	                    writer.dispose();
	                    ios.close();
	                    out = baos.toByteArray();
	                    
	//                    System.out.println("kkkkkkkk");
	               }
	               if (!foundWriter) 
	               {
	                    throw new RuntimeException("Error: no writer found for image type '"
	                                        + imageType
	                                        + "'");
	               }
	          }
	          decoder.closePdfFile();
	     } 
	     catch (Exception e) 
	     {
	          e.printStackTrace();
	     }
	     return out;
	}

}
