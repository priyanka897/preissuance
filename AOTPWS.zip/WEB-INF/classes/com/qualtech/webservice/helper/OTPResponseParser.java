package com.qualtech.webservice.helper;

import com.qualtech.in.gov.uidai.auth.aua.httpclient.NamespaceFilter;
import com.qualtech.in.gov.uidai.authentication.otp._1.OtpRes;
import com.qualtech.in.gov.uidai.authentication.otp._1.OtpResult;
import com.qualtech.in.gov.uidai.authentication.uid_auth_response._1.AuthRes;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.exception.AppBaseException;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.ResponseDVO;

public class OTPResponseParser {

	private static Logger _ologger = Logger.getLogger(OTPProcessor.class
			.getName());

	public ResponseDVO parseOTPResponse(ResponseDVO respDVO)
		 {
		String errorMsg="";
		OtpRes otpRes =null;
		try 
		{
			if(	respDVO.getResponseXML()!=null && !respDVO.getResponseXML().equals(""))
			{
				otpRes = parseOTPResponseXML(respDVO.getResponseXML());
				
				if(otpRes!=null)
				{
					OtpResult otpres = otpRes.getRet();
					
					if(otpres.equals(OtpResult.Y))
					{
						errorMsg = IApplicationConstants.OTP_SUCC_MSG;
						respDVO.setStatus(IApplicationConstants.SUCCESS_STATUS);
						respDVO.setStatusMsg(IApplicationConstants.OTP_SUCC_MSG);
						
						respDVO.setErrCode("");
						respDVO.setErrDesc(IApplicationConstants.OTP_SUCC_MSG);
					}
					else if(otpres.equals(OtpResult.N))
					{
						errorMsg = getErrorMsg(otpRes.getErr(),"O");
						
						respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
						respDVO.setStatusMsg(errorMsg);
					}
					respDVO.setErrCode(otpRes.getErr());
					respDVO.setErrDesc(errorMsg);
				}
			}
			else
			{
				respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				respDVO.setStatusMsg(IApplicationConstants.OTP_BLANK_RESPOSNE);
				
				respDVO.setErrCode(IApplicationConstants.FAIL_STATUS);
				respDVO.setErrDesc(IApplicationConstants.OTP_BLANK_RESPOSNE);
			}
			
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			_ologger.error("exception in parsing otp responsexml "+e,new Throwable());
			//throw new AppBaseException("exception in parsing otp  responsexml "+e);
		}
		
		
		return respDVO;

	}
	
	private String getErrorMsg(String errCode,String type)
	{
		//AadharDAO adao = new AadharDAO();
		String errorMsg="";
		
		//errorMsg = adao.getErrorDescMsg(errCode, type);
		
		
		
		return errorMsg;
	}

	private OtpRes parseOTPResponseXML(String xmlToParse)
			throws JAXBException {

		// Create an XMLReader to use with our filter
		try {
			// Prepare JAXB objects
			JAXBContext jc = JAXBContext.newInstance(OtpRes.class);
			Unmarshaller u = jc.createUnmarshaller();

			XMLReader reader;
			reader = XMLReaderFactory.createXMLReader();

			// Create the filter (to add namespace) and set the xmlReader as its
			// parent.
			NamespaceFilter inFilter = new NamespaceFilter(
					"http://www.uidai.gov.in/authentication/otp/1.0",
					true);
			inFilter.setParent(reader);

			// Prepare the input, in this case a java.io.File (output)
			InputSource is = new InputSource(new StringReader(xmlToParse));

			// Create a SAXSource specifying the filter
			SAXSource source = new SAXSource(inFilter, is);

			// Do unmarshalling
			OtpRes res = u.unmarshal(source, OtpRes.class).getValue();
			return res;
		} catch (Exception e) {
			_ologger.error("exception in parseOTPResponseXML "+e,new Throwable());
			e.printStackTrace();
		}

		return null;
	}

}
