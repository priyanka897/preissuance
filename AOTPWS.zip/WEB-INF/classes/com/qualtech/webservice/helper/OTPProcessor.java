package com.qualtech.webservice.helper;

import com.qualtech.in.gov.uidai.auth.aua.qc.OtpRequestCaller;

import org.apache.log4j.Logger;

//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;
import com.qualtech.webservice.nsdl.NSDLCaller;

public class OTPProcessor 
{
	private static Logger _ologger = Logger.getLogger(OTPProcessor.class.getName());

	public ResponseDVO processOTP(InputRequestDVO reqDVO) throws Exception
	{
		_ologger.debug("going to process OTP Request");
		ResponseDVO resDVO = new ResponseDVO();
		//AadharDAO aadDao = new AadharDAO();
		
		reqDVO = getOTPRequestXML(reqDVO);
		_ologger.debug("OTP request xml fetched.....");
		
		reqDVO= auditUIDRequest(reqDVO);
		_ologger.debug("uid request inserted in DB for audit");
				
		resDVO = getOTPResponseXML(reqDVO,resDVO);
		_ologger.debug("got otp response , going to parse it");
		_ologger.debug("response XML::::"+resDVO.getResponseXML());		
		resDVO  = parseResponse(resDVO);
				
	//	aadDao.updateUIDStatus(reqDVO, resDVO);
		_ologger.debug("uid status updated in DB....");
		
		return resDVO;
	}
	
	
	ResponseDVO parseResponse(ResponseDVO resDVO)
	{
		OTPResponseParser resParser = new OTPResponseParser();
		
		resDVO = resParser.parseOTPResponse(resDVO);
		
		return resDVO;
	}
	
	
	ResponseDVO getOTPResponseXML(InputRequestDVO reqDVO , ResponseDVO respDVO)
	{
		ResponseDVO resDVO = respDVO;
		String responseXML="";
		try
		{
			
			NSDLCaller caller = new NSDLCaller();
			responseXML = caller.getResponseFromHttps(reqDVO.getRequestXML());
			
			if(responseXML==null )responseXML="";
			
			resDVO.setResponseXML(responseXML);
			resDVO.setException("");
		}
		
		catch(Exception ee)
		{
			ee.printStackTrace();
			resDVO.setResponseXML("");
			resDVO.setException("exception in getting response from NSDL");
			_ologger.error("exception in getting response from NSDL"+ee,new Throwable());
		}
		
		return resDVO;
	}
	
	
	
	InputRequestDVO auditUIDRequest(InputRequestDVO reqDVO) 
	{
		//AadharDAO aDao = new AadharDAO(); 
	//	reqDVO = aDao.inputUIDAudit(reqDVO);
		
		return reqDVO;
	}
	
	
	InputRequestDVO getOTPRequestXML(InputRequestDVO reqDVO) throws Exception
	{
		String requestXML="";
		
		OtpRequestCaller reqCaller  = new OtpRequestCaller();
		requestXML = reqCaller.getOTPReqXML(reqDVO);
		
		reqDVO.setRequestXML(requestXML);
		
		_ologger.debug("requestXML "+requestXML);
		
		return reqDVO;
	}	
}