package com.qualtech.webservice.helper;

import com.qualtech.in.gov.uidai.auth.aua.httpclient.NamespaceFilter;
import com.qualtech.in.gov.uidai.authentication.otp._1.OtpRes;
import com.qualtech.in.gov.uidai.kyc.client.DataDecryptor;
import com.qualtech.in.gov.uidai.kyc.client.utils.XMLUtilities;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_response._1.Resp;

import java.io.StringReader;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.exception.AppBaseException;
import com.qualtech.webservice.service.KYCValidator;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;

public class KYCResponseParser {

	private static Logger _ologger = Logger.getLogger(KYCResponseParser.class
			.getName());

	private DataDecryptor dataDecryptor;
	
	public ResponseDVO parseKYCResponse(InputRequestDVO reqDVO , ResponseDVO respDVO)
			throws Exception {
		String errorMsg="";
		String xml = "";
		KYCValidator kycValid= new KYCValidator(); 
		
		ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
		String strkeyStoreFile =bundle.getString(IApplicationConstants.KEYSTOREFILEPATH);
		String strPublicKeyFile =bundle.getString(IApplicationConstants.PUBLICKEYFILENAME);		
		String strKeyStorePwd =bundle.getString(IApplicationConstants.KEYSTOREPASSWORD);
		char[] 	keyStorePassword = strKeyStorePwd.toCharArray();
		String strKeyAlias =bundle.getString("KEYSTOREALIASPRIVATE");
		try 
		{			
			//respDVO.setResponseXML("<?xml version=\"1.0\" encoding=\"UTF-8\"?><Resp status=\"0\" ko=\"KUA\" ret=\"Y\" code=\"0cb0db9ec74a42a99678598c0d99f3c0\" txn=\"UKC:STGALIC001:20140901051430343\" ts=\"2014-09-01T17:14:37.319+05:30\"><kycRes>VkVSU0lPTl8xLjAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDZhAFE/0ARFU+UP7yHTWDVL6s/nnJwAWPlZ3wbN3uAfNkgLRdpJcJa6atFsf12jr7B+AnGjaMl9ce8L5mo6JEvsl3dfRN8JYzrvuWmrsq6Js6xeFp7i3/MyBQ1p3EXmzw5l8LgxMBA/w/JCSLRGHVE4yk2zhkWIwqVjo8R10DSUIdHoE940ZLSj+YNXoiyggMT1Us1vx2HcI0RcM8gH9LU2MZGmdPq2lXGrfCUo6ftKJIzJAXvfYCCNMkG/Gp9YkJbLt2pXLPy03y9+DTXRv33NSBw25htRZrq5D4ZZvk7k8X56CXnRsTgY963FYxJ/FDz5zsr7PGINpqEfIuo+hVFAgMBAAH5r6Ooh8cz33h8Mm8EIzA6hgezqdWBTRcv9CLjSXkqS5UC//s3xzVFcv/X10/jiuoKBnk88OEsc/Dm3g+2AIpLuDpCf44oKKfwQP/KobDQKZ+VbycNSLnQ5T4LqoKdLC1Q+ZlgCQ5aRk6vzzjpoGK849pcH/DlCowW2C2Z5V7MI9UfkBChGzCPMvrZplCSmkUNjvApS63QynWFaN6CIUe6Nq6W5nQkBX8igb0Q3n3huHZfKIdeEHYQQEjoOSpq31vfV+SLfAwYbM0j7EQ8gR7L3qV2aCrFxlxuO7Hd1Z3MBHfQDQE1ArWyXIX5f/4lIAcq+EZmeN6eOH8wrVbnWG6twXqQmuC6jwW8xIPu7gIHDpzY2H6d3DrIOJs5GYiMALl8pmA/MEfIKH+DDlneors6pR3Wl7tCKPvfz4sR6zgAyu9VhfSpLA2nYU3xhGBT1y2H+/iUYGBQJzk6HhC9e/ADLoBlce+ga3bp7evIN2Bw0tGe8TtZfluLBRSHbLyOAvEWZyf0G0DQmDbwPyr5gt5Ta2ZaIRdCSRiHhJzfocm8G09D2O/sMaUUVxFqkGOpHfKxftVYfblht85uFQSBqUjlb+XM0Yvf6K9ioFiOSeM3/iSeLbmodo63vSVvPDVUo8Z/CKEKwRBZ5JAWGNd1Utanw/jbHMC0P2KwmzlXR2/xUZ6bkvl7bJULbm2z53e9MAgnIjvxHgr5HZ/07oxFXo7xR95WBpb9u19mvPCmodxwlmBmW0ErlOpRhvbvvTt6pVZft7HC2Mf+fNHAC12t5gAZkXYSCzZA9gLMJgO0Yx4R2PAkhiC6d7ax+HIkSJsDRfNX7F4hZuBYLQE5WV2VoI4aFcKsifqmuqmlROgPdTL0qdtHQXUsH7k6Ogqdi1ytsJK+9iiXqa+MeGT3wCnKL4swFkKHaihLDzeTvA+CBIKzQzxm+1g0E/cpWPqHXlpGWhnVVK8G5Vyb9HoHjXyUbaQa2o+L2tbjgR+QyWClDQw457NhT8E2xcU+HH/DROwHJ6jMNoypskwH0xqvd878SVI4vm3Uyp+ff6jKYVD9xXJwtiRqpJgLTl9B/QHCFixj6XeMTu1ly/7SlGu2zWpKg3WVQAxvd0VrKWWmbePVvH6ocX5XQeeXw+agkg1/yf0VJjOuKP8ZcDzUFlNtPlicdrDOGc/NZO3TLy44WNDdhzUodUYRBZYsg6GCKwkOMtEaZXDPiNhOo6K/V5pA1ENhBqgLgzQkRRqUnq95f2XOCydbhIW0ziv/pu2giMT33CrovphLZmktM1ssvHtN5pOCTN/bdTfQVwUV2Ape07zXBzdQlExsHbiFrfFUsHKMjmIZX6A/klSeaPQly1p2v5/P/Mm3ABz7tfJmKRvvFE4JJr8ZItlVkAECpxIaaaFIvox4j37Hfta7e+OwF5gp3WUOVqnHTF7W3NgooiIRFk/hTRe/MXC3NJiby3XPZICKsh8cBDmhZOCrKfit6TvV8GPLzP9nIJPJhYMT7b7lTW03VgVBRwqTXyzf8AOazbGLwhJcrgBbaaMfGwxQm2jJJG/TK2g14pqm7qfKzWx+ZisVGIzEhCduKQJNtMf+80glXnUKo4tqrOB/5POQ3jLRaG+yUupULUQOn6jSTmR5ceIM/ggBd9dJKY3ygJ7S5t434aDnfKli0/ybLdVOs5/2Wwv9oZpNpfPQTwJ6du9L0fU8s6dtopsWs4NVhLlI4LtL6bC2TCJTX8URl79YuED+NwCXqVi2qJSN+RPIN9iGoPNLjCMV5BUB9kOUI27pkOouF3SgqhHzAZKTTEOnvyUQaJLYx6u3n8RsdPe1cftGVRgM3PnX9qSvPe8unvHkeMcpBf8/xj/ZSUL5h8ZYPp3gp+hTRYMDlgQH5cXL6sNHxnLEGVGUaAX5sQh7w+chEVrn8LeO+GvWJ8zMUxJcr0z9kJgWLXktGr0Uaz7K9VUrJqrj+U8sacdTtYSCEfFJWRZVbh24/l+TpzODgyyWYHD/gu2Sm812jXiXZB6htKSPUwvbYlDVLCrxcmlyGkKsU6ei/yX9LabCsdb/UXgv2mD1+KA5xf+1xiLYAutS+YRH26NpLYSEbBOK7XwSduAUAYADpw3GCcqkRrkaxALj1qWAj3nCdUZzoUwucQUOoWDLUiH2eLHVBTqTgCehsj/quMOesV+4PrA9iU0Sim2D3Yf3YWbRikyEJXa2sGzGUnd/qgZ74XwtMxUPnN0m1+GbQe4/z2jah0oVWb7reg6Tyr7U1NcNt+DsucYO7YEbvs18tBNrV8LG3Skh6vYo+/uz403eZCWIflvtu0LXCKnS0jYTWmH9ADn/g3Erwvq7rtTSGK6M1bqh61jkseRD0MjaWk/I7Y/wIAarknStt/AoaHjPf/rvoVwCJj/R65BrXCX2hAi9RDFID8zgv2mKmUJa70E9gB0VMIpLergBK9epQY5L7/mSeH/KMCrxr4b+x54Xv3DnsWs045+9EQ723MvIpd54ywQpUxcjupqzulIqa/MMTmwz5FPTZHI3h9zzbuZjrjiJQ+eYgLYD3Fj7RyIBH3ZWKKDwhDtNRqsEzwNEp2cT4CIxYdUwR1fNvR8muuSuw0bmdjsqxvg4kZp9pDE8BGlOs0oZp7aXvuxjf+Qd1+cBhtP8BlmldunEQZLREITsL7T4ve/mLruWWW9YvIWdG87cmcrYGSUpaWu2wWQEeWjWnK747IXubfZTf2igmjGsHSRU00m3cTIuMhvvaGKF6ociKog13kPyrYT6r6eYl6wBkB4kajO70XHaAObF0SOhHwkZaOyqlw96SkUVhU5gvnI0cIJhm5Y8p+UEZGKFdzguCBpP5P7KTpqp3Nldh99DH0drYR7kVogubmRYTVx9TeLteMgccWhCIPhF+tPVJec9S9VZIqSR5QD7Hx5Dfs/Ij/qd8U9lJEItHyd89rCp3sn3tkxE0HjYUEViyEu1abC5HAXPfJOFJirMfEYJlF8CBBo/TN2fB71eY1uUMl3WrtMxg49qm3fZfGWKaNhAkjWp1seLhjTtHGMJ0thXkm6FdiG6p+BMXfgNc4l8pfuM2oHBaEEAVVE0PfDdCfcC8CZI52FR4//QoGE00u5JDQuwIn1DNN0+JiFreNWEEokNl8+2T/Cll/U+Qhiw6+neYPHYiFBuFGcWLasqWy7DPrTlJWb+vipdWEGpArg/oZzVgK5JmZDkd8miOlSR9X8uUciWxGMBXUBd7aVik4JUQXZ95lM4TEe+QHeyvCgVHzElfUtX5jlebKo7Wmaibqdr6CiEe4IvDmHz9tK+cS2JZdB0GP75ta/fOIYGnKCPBidMg+453RIi/FXb/OumW98Eba/eY3jDhrM/CV5KYo1Ts65RNORO+EanpixaXGuW9dnH+foKOpajnbCutN03hYLj/tvAIEqtaValVQfR5Sm0xA56jh9KJZPe5jYaBQDiIAmBdRq4qT3NRgk/Q1T7s3V6dEMvvvKJ6+uko0DqZrm4gHs/5LM+oVrSHEvXiXmQMZ5SNb8eOK0erkQlU1/nOO+4YN8pgWif3Mt+ROl5KL++jKjnKtlR6akeIu4MM461I+1DeEkNrSVe9btNWGlDh/z/NyTBdcifnevXyQkJyX6v3hgZ2tztvyFSoKdh4Jpqm5q1L9RClv7Gymd662JVEMGRqKdDI9FZx43U16IYpqqH7xKpQuXpdV4OmD99jLoTm6JivkYebUnKUWc4AMISEC65byK/qwVvadAyZvrA9itH3S41B+zdLaeygFc4v7LcPm+CQjhyLoIPK7GxJTid9exMKZfbw2/C6EZbTfxHzNiY8hG/whGYYVAJZvczzaJMbDJS6pPY1owSj87DhNeTMafsit7LYft9PrWD6YAVPkrpiyoz4j8ebgK+52OjOvABN1W6DNNLia9U+SbZsDekBvcgJQHNg6VcEGwyg2TK9yp3EoPfHqlkvTM8rrxsXNmDgftbEkQUY9r88LdnEBv7Egc6rRt9MIrnkhjpHtoFEZCfFpfxUx+NX0GKXxqlqSlLkXcjhYshN32fLWIqoLdukux0bgZnwz/AL6ah6Y58bKSNa872C6d52sNDlrW/gjPwEMqKlXNWmWx/eLpmzevPSm0FHIUg5Ye/8zLtF1BGjGiBqwIDp07tZNzGvi6eRwlyyOqmx7kV9QU2FOMxudaZ5NTJ+U3btOZv9QixcDdVcZQrAHaVKMEyEQTi0/KvVhsTEMU+GRhp7vD2sZOKucium8g6f5hi12L9+O2ZsZUmcbikyycoAsl5pDliVCbBnYZmN7dHqA2kS7Da+9KRgWwwjFCCqnSZFKprKxNl9XrZYMiohjCE2Q1ZK/4QP5fR2GvZV1Sl21KkOGOEgjHc4tSZeARIWyTD4k+Otu/2Wn/AoGYHxx2LzsNPeYjeckAc902LXzFQtHkX44t7Yexk7dcCINVPslPx4cgS/Y7tDAzl20nIpfwtg03iOYOiwhX2+xgQ71ZpoOoR+rY7WJhGO/u5xN8b5CfzqZyYVUewYlVYTojW9ue4m7X1dSGMwv7S+BkTJ9xIu5RPp5rQ87vZzzggDAHxT04EloxTdAjA3uDsnhIBpDeVoi8Rq0KdUgBmssF7NykXAGd79LYo96ATOQDjcW+NByp2mkkPNZEF7P9pY3Ute+pKCYsO8RKXcFrxd+KG0fJXEPq15/yOxShrCCz43bszElE9qZpFHQ41yygiPcXhwFCZHb/8MULrKSsMTtJ1PhP3izbnk0jrFc21kOPYRdPm2uBa9jxGzfsOxTS5UDBabG392FcHvf3XgOS9wXXYAWadTQFkRq1scno6gg96Tm4pGAV2R42je13Ox5rNEsQop/MpU3ZsifcXOXtLpOvirrEwfZ1rNl6rCVHnP/7zgbzWxN6nGub8bP+NM6GbkJ1SrkK+90MYGtvmlsKcROuqdTf1z51kou8fMjFb8pvmJsuF5N51SYUgk3lDre6tfZjwToPE+NmAtRy6nInT9tgOaYrq1EZkdbwc/Ng2eiuGjZzmAXwH8hz0lKoEgxOGo8QY4wbA6mUVBE2yePWYvdbjcEoJan3+g9aaCrM1ObqRYTuc6n1CCvQMXFIyQLBBKaEN4eMcWGSPDYPTmLfnbpwCn3fOpxx8aKE+0IDXmXDsIy6MVuMxmnHN5V2at6oCiC74K2WBX51StijKFhiy5OZWBv2rI0lGIeX8VEr69ZUez9TI6+JKxnYXUN2sT+eGP+Ldy3aXYgxMEV62OwaPcwxoxFdNkpsVIYXPw37+cte3wD3KubBpQ/3+o/tI7jbZx5a4uvmS9jXauwfQc5Q90q+xo601pI7Nv8Fwx5o3AD4AuEvRouCOwNXpQI2VIjKjnBMcBuPD2dRQupz41Mu3tRPuCx4jysx6/OOU8eHYeOKAbDiW82lSgoRwAIv19Oby/oASB4DxN+ekrXMEGREC06usfaTWBJphz9Q1Vb4XPri5+8nA945kkJgM8I1dLde2lZ94V4YAZNAb6pPQeeEeATp6A5guPJn9xGkVUWbYuK0pA4A2J+uUcm5zCLuSnmdthIEh1NoUF1lDvrXJ2LvS9FhLJQhuVgcfgARsJpEu8uT0xCgjxCW9grK2h0yVDLZV702H961eAjTvbe5AQZIvT9q7SmD9A4tIOfZaQt6TcqX4YQcVYcC4NNDwNBBezYSuML72okzBtDS84EAzY/ewtI3TMdtKX55Etb487Jetbuw2x50p5BdLw0+CVSt01rnriXMbsW5mE7NwUV+3LOx9N+FWdhRvKcJv6rOiX26mALJJTHw8eQACQ7I4XfoPxTCZh9Pm+KpkWxGmEpMd3VBlAx79f4j0Ja6mrv46qNZuWabvGOH5ZyfZaV5blMZrwcWmXsXZXOl3c/lIzZsht7iYKPKJF2RE720jKGYSCw8KCXjH5LUUu3J0pfRbPGYt8suiptM4307ZTUGfZVm5gJYXeo1lGi+8VoWcXDaygfWt6XRiSSMfODMbsBmfhGxiTf281PbjfrtJJagwFEzwSD0bll+Zq3uxvw6NvZR38BVM9p+Ag7hwm0CbnbhU8ZHhsRrlPuFVcH7J7yZZwp9rGDK2rht3qH7vyFF+gBBimChsaIiP49HDKCumPKcz4g0ArA3HyliGWOHGsatMKMiAdaw2o5ZS+iKN1H3VrB09+DLzEpU1AA842TEDYF0kiQPv+097OWetDDw2W2ecHflYds551hCACBZa+rK6Ji+nvFjnL6rjvXEm1u4QALcdkRrTocV+Lz7avhoT+yi4TSIaVi8WgzSRncfRHGebj5Mp5aiC34zuUR957rKF71IGWPSfVZLGrVTr2XVy1MFkQMUe0oFNuSSJq9eddmVcZro9M0GNg9gB7k85WwgEfM2X1X3ssqlTXGmoh9jzE0jT3DLJeL2LPQH1pSJ29uRZKNkmm+O42nCaewckQkxHMNHGqK+dYFkJfC8apNdRIAFYZt5spDZKHFSv7f8IKpz4LzJG+vjoH+rbSpt0z9iCAtHMJvpzVZSxwvyzP/Wl7LDbIZVE1sLucxJ76hZNYbCfDt0qHNR9IlyLaQE1tx1TRJSFhBdoA4lvbljov7I2rRSlBzj7f1Ww5Gl/wV5rR69baG0IjmhCe/p3uweJKbube4TCVM8+YAgqPSnX/2uevfMaWYGmXhIAQwAsjQl4q87E/pGs451LrwDYFAsS6LDc61Lv5spaUseB+yasCchpEBLo1sYVbwKuemOVjZw5CIJkk8kIUACxai1ts/1bl4kj1IDoQLgud7ral27v8myhOCvGb1t4ufzkNOuwl82nIa6r8TuFWIfSYh7rfYDDFrgc1ymHUR+927xmGPsrOWiBFMCHnu8AjOemGyTcY42D4TNfXPEPhRf9ToCPpsCRcpgipNZ9U8VH1Ekiy5jW9GmDKroEN9MIBCiOHUnJ9HHixNQbEKMCXv81uMZDVA6L0la+D5O8mELiqa2Oi/VacuUMFP5Jta5tQE9wXUo2BtHq1ccZ4w8Jw7aYLFDbj4BwEuMELq10IEGLsmTkBtyfXagaXNTcZY9qH02XCxIlfWm9fvbXWGpRePjcwC48biSoIivpWodGQxkWMZLoqs5hJqPJ2HeaQUxxDCy3ZmhMkJO5DY4d6YOfJ3FX/2aQ/7CdAHG+R7Szt6rf6AzrjEqAuotECN5sAP16ZxEiO8Um+bG1X37QuP3bm7BKwGT+phuLRU1VmF67I+CWX5hXli2vzVUjo7NM+QtRKO0FKE8n9FPRW+4uq3RDbWnHY2mxDM1ctKPfkIob3dDJcodYLuKQoI69SdzYM84oeBTX4N11+tz+63uK03L0MbkciiEtRyShQl4c1R5iGxCCQb5QoWB6GH0tw1PNs9Y9gxd7HZFG6t28wNxkJnxVkBh5ozzTQCTc8loXNmMVFsgtbdXGdOCyfTh0hg406WyOseELG5GIcAKcvZWo0evxBhohHjXlO2zadqCjBh+pAKuteKQJ6eXuXGdHml+O4dUhNFvol2IaftxT97h53tfaA/geMBBzGmSQmYTFPJJKnnb7co6OvRxidNxhQ3ov5ezTwkDue/2dM5YmFN2khrODU4YITI+/M7cN5RD6GA2sT8z2cvYwdJhBfryGDio3KTzrY6gfAzyDsCW3PCTfc4rjDwYqM9WTGFw42aURygkAsj9lCDlsroZvbfrbPxCNb1lQ6gLAsR99ZBCg/E7TV94dRI8UbPvTyST5IhYcoACEzTH+DxL0VMnGuSW1Xd/c8SahqfnGSTatKACht25kZ6Oi7g7vuS+gsxEcyEqipVvl7vNAVUvd3QH2swEne3Ko5i09TS4ITcNwCWv8WZY7svtqZORgMkcYFmp/8hq8rdVjU3eBSJQwCPtVmZ5Q0HJySJPOE0RAb2qIyQb3S0WWLkvvT1lzqsXchFUOdta5FWvrJdj8mRr/SQuQohvwQmsbYK/dTYJaE4W2KG4DILUy/qufiYx8gTWTWYXDS52MOplnciUhfT4ETJybkAXt30htlvJS6nRg0CbJKPcJaVF/9UrD1pyt0o5uz/hU+BicZLBVsapO5eUNiFK56kscGR3zBA6xhR862orFA1T2AYmfhiuuCpTktSGmqpRoVczEoR8HW48rZoDRaZLr0JYZB8ZWOlePj/ADTvlYTTJNlVmLv3tY5eKN0KRt/g1smYtL4GvQk7h7Sc+9tV1zTrU+jm+rLnBSwuzkKhLcZRD5rFOvINrruvvAuywz34YtqTqN2c0BhOMhN5XwEQBId8IpqkcvjvjqjBNnCTtYqeU+jcw0URxibIcR36RbSh7UhC93RxTDfaBZ7Reib/1TlzIeq2TuoYqq3uCLYZG97KWAdrZgJeKWmVzyrEyAAJ3PL67D5KKGpk58hCt58VXK5d6IIzcFYdFoCvi63pFCO58olURkv20uKnEh8WVRLr2wL++rRfdqmSFoPX4mgs6KAUsiPQwjhB6v/YMgD+/8zqLjN24RMtwnH0I8uZ9MW+MhH5OAeXArOd4i1QDNzBh2zA4+Ki9sQ0+ayjYXZzN4xXNhzwkWRz8ocZdYw49rpbSXdwjckKT3xFNvmOB9H2iVM8VPXlxqaxvfPGfDdtzAGYZ2dEl0tHRVHurOV11VLxnHuVuTc0mnTP3VauWpTyij5v+enLzeg2Fdo//tKhUmfWfRbAGOKfY7OsRHPo1VOODOOOOrAn/ysvrADPuCsyh6ZF0yjqn/Eo/MTz8EyIst2/tJAFOp5YunzV9yUL9ODscrQDONV9D3DIKt5PXNAbbnnO+tKi3WGpmVshuoQU3FS1XK14RpeRGUUwZhfVVIfYoLbeKCLDZZeqSNHkj+OefFP+dj1uP21hCa2hqRC53b4dUzcr6bCwt/oBYt/WuA+pMuj99QghiD/7jpjBK4OTTUfvb3fQMjNzKDLBXc8DtIk2aSs3NR/BT/uR9dnDKUw/jLQe6h4nrEccQ/1wnrLCJ7z4Yjpul465KroET16zOslvIoTYFDFyNrVHPYHUcaNS2Da+kUy/z61j91DY88uYYhFJ48L984OZxfd/BV8ohKTn82NFbCY0DuQLhpw7iFEj2gZWdwY9M6ibMDExaUUmD9U+xdOOO9t07BTrKP71kebmpk79oREsaxFspU2bmr+ztWgF0nzpWzd8+10HT67UamqfIIGlzlqLQ34JooO/4V/dLJTkLpNUG9ozj/w/qbfs4HQNxON2GloUQQ8i9Ar/OMcHRAPjSzyD1OEWD60Uz78LkQMy0z0ynP3YGQZsoyQCgUXvfvWWw7TS/Q/P1EC9RbEac1vzMB6foiCe18aCX7EV9HZPChPtcpsKYUBvhD0K4dBtpTyGFiefSkYzqal1EFS/VLeRmdXESTaA1soCkD+Efqfo/YfzfR0ehpMOJdSa+x9LPC/uqZc1QsVDrb6jRzywZj3LSdyRBdfvYHdPazIwmjL1JQiIrq0YziUwq+zGG3CuCRRCbp5AHc6lZW+fXVUDTlXRY9dluCfKJzCkMo3grxZxYmIj9NadZkFG+TNjfyMq2quNw8zdu07bWPcs2yA7jCctVMlGyEIY/2u5iPMfMNdbLm/SThz2y6mSwebl84lxpEPG2Qrv7BH3Gcs/dce4EijFkAMCpMCpKAYktJyfcOmVbCC2ejaEO8kEUnGQoxKytDFTf3tLPAnS9d5ppi70ZCWvLZbORFjdRMW1cqEttJLTMPNcrLbWcbh088mc6fVSGFvS9iNAnwVv9wNeqwkjF5oHxYxXMjagwf70wpmfCFbjJQSZwzN5yDBcgXVWvdBavu//+EFR4yzPcd2c9mniZt6wtHKdow/PhIdS7DFHwmh6A+knIGPVWHtefCmeSPFitnV1/G11ldbE89F5HC6F839idTlTWXZHl2bzfqnRTLwZ6uspGQfH95Y2c9hRcqkqhxIfiXRGbRDL22oiGduVmwEOtjdZGFd/zwfcufNidGaeErc7vRRMpf4F5+Drt2pnUGpvXjutvg8GMKrvFz33LEXNhy4ZfMCzOjM+0O5ZUKwSpmFjARlglHYoXihJ3e33XDcpW9jyXSzJAsoahXbTpUehGz9R0rA2UapfMoNaVqYaomBNfd7zCyjMabu5lWUyhkAhDshr6gn+fhyRCGzYzzJk+lmGhC2nvdX0ZfnCt6WxSUR8crkEOnS0hjJHGcQe/4SaCf8zX9ttQ/VbXLGMEAXyq86MstEwUkaqsMwlR710sMUT9tqvLRwZGqMvJlG8etcqb20Pfwwa57iGvklNjsd1HEq7iuS4+qfRt3F5py5K6kINMbezcpiBnrNxWcGyN5jwVxWNMkGdwsNqjnh6Hb7foV7hNqXkXPcVoaeSAtw2qZfuycg4yTh+69e15pY8ahMxNLcZppyN1spCsQxBcFWXTPP1MWevtTDpgh+2pawDipecuxE3fph1AzKrQIPBpmg66HTomIpNvaWoJhmdkxHO0WIOjkKXLg2wT2kKsOdC5q7TUOneQlMifokDZxsXHAqtYL7WdbjdN+JQRnb6MZpE4vV/DhiKlEfBAzciTA4MdFvoIO6U7zDEMrXyflVilBjO671LY0uuSedXZV4OxwyOCFSjuLPy/p6E0vzfPYbgSG0QErJ9Gstkzr0JTW1W5EYJypNO89AUsViqd+Dpp0tR/4k+h/MUSGolC7LyKZOKFOJKjRRkGOiFa/kalzZn0kKvEGLSyJhZJxdumxPgXN5vlDebgrTIARpFIme8aTBgdJ2+9IOsE4/bIBbk+EAClw61iLtjKVDqY8Frj0a6Z9qQ4IAyKIL1Nb6adla8JjeO1npjs9YVpPaOBlo2S9IyN2G0IHxSwJlVC0sGic0h4LTacYfJMp+7x3fDWHvUVsvLpk01GLoo7Z/9kriPNhWNeGQBbzQZWbAeGVXYwmJ3KA41Ksa3XReVvxvRZqh+wJyVoaW+mMuH6/NE3IwjLG9cqwGRphJm1d6sQXu6+RREwBJSCMqmFgKGouBUhJqCCZgrjA9trWjAiNgKpag/QHgMvSByD6+aZKITe3tMZ1Q6GUlGL4hLWcxB5ecw0PXqm4ZoMD6UiBZJ1d7nMnO4DFxRZ2/eWhu8/6n8rN+Fo/9TRgoHf0vIOdmSRWjIjyYO9KP/xn1lmKRNRE8a9iWv4ql5jNxlcYqQbHIZKcZsI0mEoegz1xamX45eocbo7jPTOAHv+KoF/YUPMODGlTap/nOr0v77HTgatu3BvLWp4vVYW/nG8dfblNf5zL5NGjofQBrAX8Jh+MuB7eODchmZlXCywdca+1Lr7+w/heez6c882tIoU0HA4VkLqYULSeKOdrah2Yl8UttfLMhpWbCMchPIXgwQdaHFro79UIRlUdH9XZBcJqu459pP7vF4fdb+zKhuK+ax4juDTav9UHuf+GXnOqExq16VoqhW/PCeuLWhcWwSTD3dFP4U9QgyFsODRskISN+eq6hFu/AUlS4nbBHyChYjapqO6LwliWOVtJkHoaGGp8b1kBVHbNCjzLJ2vlWUPlbAhdYLIU03HxGyu+9EY8DhevhRXPoub1PDKNuTPWv5zw3tV7oCWZLsyisDJIrLcoDPkK+g6g8eRvGfpu7mSskD9hk8i7PRFVt8ZIDD1rEB73V5zTF4S9bsW1/jnd8VW/KbHo5bBIGIDboyfK6HGCQY7GwiqEl3XftlfXfnn0yDjalJvjgbI6LLQFjN1Genevi7cfQLTfoR8lsaOUhIXNrFbDVfHZmpHEw5zEA5/KiwDjQtnmtqvV2O+OJYJMCmmmvatJgxEAPk9H17bmJ2Cvax2j21MNFgk9jlPKOoi3IDkYxlYlw6S6QkgiqBPqnQSMVWJaHf4tJbHBSEsw2bOwaAgsUPp63c/5ckXn2DCrPgkXYkMaAsP81Iu9jBaStFpwksBKIgZKC8FDPPRhwEZBc8eU2R56s9kVhZm3P/9bHTMCxlFor0Et0Eh4URssu9NdxSV0hcG4Gsn8b4M9GWAVnNZrXBzq5YWCBo1LZ3iQ/FsJfh58s9MIrKz+QpIl02MM0MKroDtYWDDSkZyTzOkyDQnl1v4rwxYKzqDXKSKRbg9lqwAtHdpcWKbYQgaR8x7z8nOKR2I1T0i8S4uXDRW3z53G4fUcgSChsDeX3Btu7QQqmq868KETrMvBGgCMNHXvNIq9V8FswQka3mXIRX7/VISJYMjde54fAr1Yipjs/IVZlXT2isy0hhJHGBCYJOfirOcJDCx1/pOALB0DqP1FdCXSKtgP5Qam2YGz7qLIjx43L6lqJGzSa2LZrKNP4PPsf2/uQ5p1bAKY6DpxMhcH9+XE3XeJoyU5ianbTxLGxl0dCLVhDgf/zD9Ri/rfP6DIhCcUAmVtzeB+cu/lgr9RESL399s0zQeKY/RZtDb64Ej1BN6PGwOCGUoSOwIvVlZXAPmrII3pYip06VJU3wuWa6sn5u6vc8IcONfqa95H38ab9FSZ3AHWkctZ+lfWW+eJmqX2CNeh6nwAzfODTimT6xvmHTmQTCsRXIoV3T6X68GOiRBRIdcpZe8ta9fIOH1F7pQLzPJerZXpp75b5RLEOlaCP2jze1CQYXNfxZhqS59VMDMLa09p59hbiPU3EvexkEx7hhQ4PdBTmsl5jrJuU9uit248Cx9apHS0LFAty06nP3RaXM4e4dZBGUJfe+pcWAwooB2A5yLCxXIC/AOVP/Rxzs+IiBq3JsBYVK9jV1SUi+1b0RxCPZB+D2B+nbiVx93LB9EDJu65szJy0DMPwcqsf3jGuetOzcScFvybV7/+blUUdKPt9c4BbF/Ys+NwmMYDNOBLED1fkyaeI983Ygs0t1nNCoNNmle8YPoWY+I3C8NhC9yv4waVhwj9GG+O38iRKxWpgXRexWPhi8JioH0C/Jq9dF+HmfFfia310WXdz+vVhf6im703T5Oui3IybIShrf7WIo90olqBVbOHA3eBLp84vZOWTKL307K+IdGwmFPhBApZ1wQ+smBGKrVQcDAAhtJ7wmtVfLeggf02pZmA+2mAlkVoeciIASRpk1W0UJHe6pTk3PkRqDzJV8lAxiSCNaRLO+AI0g13uJZC2lShO/Fdx59J0HaoSZxHSZeCuKCEe/qpCGh74qQma7mREE33tQ9q4TXOMHFgfRSi+TgPoEiag3xR2Idx11MZMlUX3AYeXx3yn7qFs65a+sGM82waWjIZl27+CcekAiEMa7bBLj+ruzvWp+tX6X09Qm35xiW9trQ5tqWmFvdUMMg08hOhlsEBy8tkyuL1ACRq5TRL6TqiFGLIukOxB8GOTWstXgvgyoyOIRypPCOnUhURJHvAHZXedo+nHUvpv/drLuJ3/DEGp90j+Opa2nbr20TvJXyiEj8uQxOROm1hv4XnKt1ZsHql96EwoE80OQNmewIwxk2ZS9tNlbo8ZFY7ee5bHGjvSLOp4iLNxz1e8vCR6AtuyYDJonvAkZ3D9DaKlNYhQARJgoCBuHaK+Rl9GvwMoigwZtTh+DvHScuVM3ei1bJnRXMQYpmWa8eTLz5bZpTgFTvORp+OutIUlDAqCGLWECBdept59tVWBDX9oAjv9fgeAKZ13V9KJALzRMUVhrKFcYiQH9r6oyCO5uBcgUC7nTy4pctb3aUM2vY1/xC5+rETO6OWZDlKIajBojm+6efAUawby24poXNc1y+XWtnoHthb+IXqQUROsZxj4REl19KJXSe8OZyexsTLiTktmoILlBTj5F1jtGUp91cQNxj6diWVyi1cyVIidCejH2u4NLBUVVGP2HZQmJMc3DeOx3W+pyzd1JBs/ik0XU8PSGrtjCppSCuSGQDS60eqKAsq3sQQrlv0dCggBVXvslAgXG5pa5tKOFOdkmUULb4b6SPF72r68omBioF+Rj+xyQkk2Vx986iYaC3KSyJoT4/nEFub1O9pSwJ7Ihxe0dxX23bbQVxrMBMkVWcFJRubNDVNoNK8Dai8GhJQDdkX1fbYyFSLpx4Syt93T8AdMY98lSd5OF4otWFDgofQ6dCEEv3YSDZ2SEgll/fi2WmOuDqsk462glNDzObQ/S8BBvXmMsgkPk1hZIHUyPQa6ufKP6iCUC3cORkvpECg+e+p5Of4GuhT00diLObIyNUVISOp8tdpvURnaBpK8Yjm8cZc28CZeqE4g6a7deXTx4UznzRksVpHJd6kVVGz0214GdeLhgKZxQVUkcKHhRtgqVWckUCj6MKr1bGoOxdA5Iid5UIZ+m7NiUsSrUgIB/Hx0dBGbD5rhaLlAgczLcCLncQEwwOMf2ZpWGRp9clqFlrHOJ+O0ThsTiw12FiwaWFPf2eNy5dNUgLyXEx7ojuTrFXbzc7EuTTSOY6f+aY9CachoV120Sxa4H+Wrk1SrzuUrFd9Wfqf+7kbus1M8kPliwNCbit/WDI7X1B8qClR8B4s7pSD6JmACzFC4bXVpb7ANkKEvMXB1HSZFI3szhTlbj97IYkxgwMCIOT4tp1oEFWNR4ROPfRnSlurIDQvfBmTTAgNik2uKF5dzlOYtAMew/82u6FXKDQeQusnrAOcxEET/NgGbXt6V2EY96Tp+i1Hw65qjlakxPzhzxAIrNSXPQu/EjXHPNsTsFwmezSwcm9FyomF8LpC6dCKQiifPGh7URXsrgqVzBUAvp1fNqLiNVFMzpamUHf8W8fu08t7XW+VtU1y/5mXTcUcEn/EGAzMIkAavHk94gMJI4p5AjVcORsjLAiX1T+ut26y/SSsBmxF/3y1Y04auGb0nDY/mD5wRrlvV/IE2+Iwjduihp+W5CYlSCXDOX04iwCJFavNAky8VwmYozXihOGBubA1251ylHdCuPZmWHJUyYDN9hwqPWoPMN8urlROPPhtXzsPsIzHw3444d0/+fVh9S76PVoMv2145gkKShhRPNR/FOE18y80Vbdmm/TL4ovxLDoWzu8c7eBFJxH2855Q9KXmT3opv+Hvml7Mw6S/FRgOYyBtFVuRSuDmYVW5gJyTGLWVJGjBMBDgGO1T0bzHlY6mHJTYI0At90do1+TvfBuJGP4tS3hsQ52BMNlQFvlAzzL+dsy4OQ4/5GYq+3M0rC0J/ohBViVMbbnbE70lbwCUf16P5j+MsNO+weqWppvl41Sfxs4KsQrC0tC4hwelpGbSaETQRoVNjRCryXi9s+8dIXAXehEfzDw62x/zQb4qd/6j8Df1J5XqXdGxoPy02nwF2ISjNnkI1o6thnWb9ocYUNqnyWH0vqVSMa77eaIOguPTcOgPfNDn2zuN9U+MTg0UFYruv4V2+EZs/f10Zwf7fo4Mlq/WrAw4VKLXyYwxbcAa/S1sZjmyi5Jcxz38RxfhAcfHbgPWxBiF/higQTL5FQu4sG9dml2IkPLoUVZ6s1v4oALzs3jds9SwKc8TWvZv1vdYEiIbRqDnV7e/Ls2DqWjKztNMOetHoQsTYZG8ssev6n+n9dfAKxVcshus2TewwVk1xK5L1M5W9JOmTXNI+5TIN5S6Q37Vudsmf5Ai6sFwtB7MV30+jNdSAzWEpzV2pS+1JO+SvxI7tvVSzLTl4L7uFkiUFTxKk0zDayWF3+wgLtslvMI66h8yY4W9mudAvCCKN++QaFpqY1kKxqXZgGIHbFF9SXjeXiWpTJPGV6RD7kpMI3epnZZf/WKfb8FhNeJvv7iYqKRpWCsBGGi0HskjzlE8e1dw9iLF09eK/YaGYCF2P9y8Lmv32WNTgdLYJLie/XN6U661PO9XJ28r4+fSfYR35AbbLOBQaIgWqgc985u5ibh9qz2mmSLhSqx7jfWl0U6snHRF9CZvJ3DzRgYEZmznqk8ksyEfLXQQLe3QqE9Ody6jVZiP/fyVUx+4hVTvVUc3gwPHLi/+I1PC57w/PcPNaKL7GYGck2e5UirbjRIg8/Lg3U1a9UD+Yv00xFd69ndXPUmy9DpMbOlZc5XLk2kyoy61+vghgQbu0XPKoPaTdO91t3EoZoX4iWb0DWDqiUiBLqc30sbdnYYz6ycOUZ0Y9RHz4VJhVoLtBi1RKGeYwE+rFQyS7jxCNRkZ6gakIydHP6sgrBlCprRl8FHOUw2WDUdNa3bXhXmWv2aQmoOOgd9B9IXgrEQKllPgE83RU8HefLRTuzPQ3WFa8O/BedG+BDMrPicQ6DZGxeHYEVi71OeO2mys7afza4Ftl4pPuaQKNIeTNNtJ9k+tKyD3GZxrZRPliQqmbifedDl+0LuAD9GrL8ST5vcgVEJGOD7mNdgU1jFET0BV4m24a7txN89D0rs0oGhRNBy9S8vewqh767AqKLHuLwF7BLEp8jiBD1tVTp8+2BLjZBLOLXTPLEcA6KXZCvph3Gjp9wh945EAf9qYdP4B97Fqrjn4ENXA31VROPSFeZ7unwQ3CsRTElPBNUzRWn1hJVE43rhJmYa7Oq9pidCx1EolNjPWPKWyfZFpiETw4+O8gJ7U8bZ7kTk6XiksfnPLT/qhA/xbkdWtyKNTsL55xMUABVHMxaJYxwLwmm9naFR85+5gKOX1lYKumcTY9MostIxOzxwKx6fgPIkRdonxHxyflQ7cgJVI5LvrkeR3s6ytXpNaC6sx3FO5kkxpyza5Q/1zKv8W+tODgunziZtm0MEWRqJS+hYy6KTw59KT6TykjTziiu0ZKx5zn9tlft0v8/ygPWl1ODquuif2oecOQUSxt07o60V7LN0Pb7RjycKGnQDVGBhOe2d2NC+bFuvbjKz9dGliJ2DDNBJ0r6nBvaJ4ab1ciFgRg/1+ZhCD5xIjzmd7+/HOgml9ZjTGImEy/dJv5Ou8OJd1R8NbxH0OqEBKmtjhLGlj+mxFAHhVqUPOjmOipsV5CBPjswaGlGPS56G7YftVivF0rEU1ciRNY4S3UAJUidaRsHAwtzD9vE1ugnCnBXcwZ7plJ/YzbBufiVGQPD2JEaf0rjmbYZbPP1HJrgNWfBd7HkRBI0owb1nSbxzOlxk8n0wYxidKv0PWvPDeq2VjyJ392ECYqvutvu5z08jekSfzZaIe1GKl27KSKB27lkhAs61hBwnIAjKbilmytu8b0ubonnX/z4vZmfMeB1jZAFLYaTwahNe+tMLIpOWSo2yCqk1izz70XFSnLECbRHM3B9SviUnlUsxiQAesekvU63R0BsMKnbrWVDpPOrYjQGpLKInyGDuzWm46jIayFGBjRvfqzQi0BYejhd2p3fC88OXSd6qeuwPx6Mc7t2yAccuAF354TbzxsnLNnGxEppnuafqhuhIEkKI1cBxWf5XeWsXMFda+HQ2Q61UIh6i2chbEK6tsK759vi0s7CXEtL2KyUNiFNspw22cPu+BlI8nS8nBCWSIM4tZIs4AeFM+KDz3Vxy2Vy9m5RjWHHzwIrf+cwtnuqii1bKuTNGEfLONN4FVeq6Io4g5I6elpg5Xd0daXze1iVXIG1PAFk4jSAT29Mh7Dk4fl2a6xX7PCShIkgVKYQGK9hdn7qn7LwsPEjHIoCeMXlHvZRERmUaYGzysxKthQvf45nE+64dceXw=</kycRes></Resp>");
			dataDecryptor = new DataDecryptor(strkeyStoreFile, keyStorePassword, strPublicKeyFile,strKeyAlias);//,bundle.getString(IApplicationConstants.KEYSTOREALIAS));
				
			if(	respDVO.getResponseXML()!=null && !respDVO.getResponseXML().equals(""))
			{
				_ologger.debug("parsing kyc response xml ....");
				if(respDVO.getResponseXML().equalsIgnoreCase(IApplicationConstants.FAIL_STATUS))
				{
					_ologger.debug("kyc authentication failed ....");
					respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
					respDVO.setStatusMsg(IApplicationConstants.KYC_ERROR_RESPOSNE);
					
					respDVO.setErrCode(IApplicationConstants.FAIL_STATUS);
					respDVO.setErrDesc(IApplicationConstants.KYC_ERROR_RESPOSNE);	
				}
				
				else
				{
					
					Resp resp1 = (Resp) XMLUtilities.parseXML(Resp.class, respDVO.getResponseXML());
				
					
					if (resp1.getStatus().equalsIgnoreCase("-1")) 
					{
						_ologger.debug("kyc returned -1 hence no data found ....");
						errorMsg = getErrorMsg(resp1.getErr(),"K");
						
						respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
						respDVO.setStatusMsg(errorMsg);
						
						respDVO.setErrCode(resp1.getErr());
						respDVO.setErrDesc(errorMsg);
						
					}
					else
					{
						_ologger.info("kyc responds success.............");
						
						byte[] kycRes = resp1.getKycRes();
					
						
						if (resp1.getStatus().equalsIgnoreCase("0"))
						{
							_ologger.info("kyc responds is 0");
							int x1=respDVO.getResponseXML().indexOf("<kycRes>");	
					        x1+=8;
					        int y1=respDVO.getResponseXML().indexOf("</kycRes>");
					        String  kycResStr = respDVO.getResponseXML().substring(x1, y1);			
					        _ologger.info("kycResStr >>>> "+kycResStr);
					        _ologger.info("<<<<  Now decrypting base64 String  >>>> ");
					        kycRes = com.qualtech.in.gov.uidai.base64.CustomBase64.decodeBase64(kycResStr);
					        _ologger.debug("<<<<  After Base64 decryption now decrypting through keys  >>>> ");
							xml = new String(dataDecryptor.decrypt(kycRes));
							_ologger.info("<<<<  Decrypted xml  >>>> " + xml);
						}
						else 
						{
							xml = new String(kycRes);
						}
						_ologger.info("decrpted response xml::"+xml);
						if(StringUtils.isBlank(System.getenv("SKIP_RESP_SIG_VERIFY")))
						{
							//if (dataDecryptor.verify(xml))
							{
								_ologger.debug("decrpted response xml verified ");
								respDVO = kycValid.validateKYCResponse(reqDVO, respDVO , xml);
							}
							//else
							{
							//	throw new Exception("KYC response xml signature verification failed.");
							}
						}
						else
						{
							_ologger.debug("SKIP_RESP_SIG_VERIFY is not blank ");	
						}
					}					
					//respDVO = kycValid.validateKYCResponse(reqDVO, respDVO , xml);								
				}						
			}
			else
			{
				respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				respDVO.setStatusMsg(IApplicationConstants.KYC_BLANK_RESPOSNE);
				
				respDVO.setErrCode(IApplicationConstants.FAIL_STATUS);
				respDVO.setErrDesc(IApplicationConstants.KYC_BLANK_RESPOSNE);
			}
			
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			_ologger.error("exception in parsing kyc response xml --> "+e.getMessage(),new Throwable());
			//throw new AppBaseException("exception in parsing kyc  response xml ");
		}
		return respDVO;
	}
	
	private String getErrorMsg(String errCode,String type) throws AppBaseException
	{
	//	AadharDAO adao = new AadharDAO();
		String errorMsg="";
		
	//	errorMsg = adao.getErrorDescMsg(errCode, type);
		//
		
		
		return errorMsg;
	}

	private OtpRes parseKYCResponseXML(String xmlToParse)
			 {

		// Create an XMLReader to use with our filter
		try {
			// Prepare JAXB objects
			JAXBContext jc = JAXBContext.newInstance(OtpRes.class);
			Unmarshaller u = jc.createUnmarshaller();

			XMLReader reader;
			reader = XMLReaderFactory.createXMLReader();

			// Create the filter (to add namespace) and set the xmlReader as its
			// parent.
			NamespaceFilter inFilter = new NamespaceFilter(
					"http://www.uidai.gov.in/authentication/otp/1.0",
					true);
			inFilter.setParent(reader);

			// Prepare the input, in this case a java.io.File (output)
			InputSource is = new InputSource(new StringReader(xmlToParse));

			// Create a SAXSource specifying the filter
			SAXSource source = new SAXSource(inFilter, is);

			// Do unmarshalling
			OtpRes res = u.unmarshal(source, OtpRes.class).getValue();
			return res;
		} catch (Exception e) {
			_ologger.error("exception in parsing kyc response xml --> "+e.getMessage(),new Throwable());
			//e.printStackTrace();
		}

		return null;
	}

}
