package com.qualtech.webservice.helper;

import com.qualtech.in.gov.uidai.auth.aua.qc.KYCRequestCaller;

import org.apache.log4j.Logger;

import com.qualtech.util.IApplicationConstants;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;
import com.qualtech.webservice.nsdl.NSDLCaller;

public class KYCProcessor {
	
	
	private static Logger _ologger = Logger.getLogger(KYCProcessor.class.getName());

	
	
	public ResponseDVO processKYC(InputRequestDVO reqDVO) 
	{
		_ologger.debug("going to process KYC Request");
		ResponseDVO resDVO = new ResponseDVO();
	//	AadharDAO aadDao = new AadharDAO();
		
		reqDVO = getKYCRequestXML(reqDVO);
		_ologger.debug("KYC request xml fetched.....");

		
		reqDVO= auditUIDRequest(reqDVO);
		_ologger.debug("uid request inserted in DB for audit");
		
		
		resDVO = getKYCResponseXML(reqDVO,resDVO);
		_ologger.debug("got KYC response , going to parse it");
		_ologger.debug("KYC response XML ::::"+resDVO.getResponseXML());
		
		resDVO  = parseResponse(reqDVO , resDVO);
		
		
		//aadDao.updateUIDStatus(reqDVO, resDVO);
		_ologger.debug("uid status updated in DB....");
		
		return resDVO;
	}
	
	
	ResponseDVO parseResponse(InputRequestDVO reqDVO , ResponseDVO resDVO) 
	{
		KYCResponseParser kycResParser = new KYCResponseParser();
		
		try
		{
			resDVO = kycResParser.parseKYCResponse(reqDVO , resDVO);
		}
		catch(Exception ee)
		{
			_ologger.error("AppBaseException in parsing response xml-->"+ee.getMessage(),new Throwable());
			ee.printStackTrace();
			resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
			resDVO.setStatusMsg(IApplicationConstants.KYC_FAIL_MSG);
			
			resDVO.setErrDesc(IApplicationConstants.KYC_FAIL_MSG);
			resDVO.setException("Exception in parsing response xml ");
		}
		
		
		return resDVO;
	}
	
	
	ResponseDVO getKYCResponseXML(InputRequestDVO reqDVO , ResponseDVO respDVO)
	{
		ResponseDVO resDVO = respDVO;
		int counter=1;
		String responseXML="";
		try
		{
			
			NSDLCaller caller = new NSDLCaller();
			responseXML = caller.getResponseFromHttps(reqDVO.getRequestXML());
			
			while(responseXML==null ||responseXML=="" || responseXML.equals(""))
			{
				_ologger.debug("KYC response XML found null hitting again the same request  counter value- ::::"+counter);
				_ologger.debug("KYC response XML  value- ::::"+responseXML);
				if(counter<=3)
				{
				responseXML = caller.getResponseFromHttps(reqDVO.getRequestXML());
				counter++;
				}
				else 
					break;
				
			}
			
			resDVO.setResponseXML(responseXML);
			resDVO.setException("");
		}
		
		catch(Exception ee)
		{
			ee.printStackTrace();
			resDVO.setResponseXML("");
			resDVO.setException("exception in getting response from NSDL");
			_ologger.error("exception in getting response from NSDL"+ee,new Throwable());
		}
		
		return resDVO;
	}
	
	
	
	InputRequestDVO auditUIDRequest(InputRequestDVO reqDVO) 
	{
		//AadharDAO aDao = new AadharDAO(); 
		//reqDVO = aDao.inputUIDAudit(reqDVO);
		
		return reqDVO;
	}
	
	
	InputRequestDVO getKYCRequestXML(InputRequestDVO reqDVO) 
	{
		String requestXML="";
		
		KYCRequestCaller reqKYCCaller  = new KYCRequestCaller();
		try {
			requestXML = reqKYCCaller.generateKyc(reqDVO);
			_ologger.debug("Auth-xml-fetched-saurav::::"+requestXML);
		
		reqDVO.setRequestXML(requestXML);
		
		_ologger.debug("KYC requestXML "+requestXML);
	}
		catch (Exception e) {
			e.printStackTrace();
			_ologger.error("exception in getting request xml "+e,new Throwable());
		}
		return reqDVO;
	}
	
	
	
}
