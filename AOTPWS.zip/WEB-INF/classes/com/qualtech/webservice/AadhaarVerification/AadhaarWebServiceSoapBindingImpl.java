/**
 * AadhaarWebServiceSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.qualtech.webservice.AadhaarVerification;

import com.qualtech.webservice.main.UIDAIService;

public class AadhaarWebServiceSoapBindingImpl implements com.qualtech.webservice.AadhaarVerification.AadhaarVerificationWebService{
    public com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse saveAadhaarVerificationInformation(com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest aadhaarVerificationServiceRequest) throws java.rmi.RemoteException {
    	AadhaarVerificationServiceResponse aadhaarVerificationServiceResponse=new AadhaarVerificationServiceResponse();
    	
        try{
        	//new TIFFHELPER().tiffCreator("D://aviva//999929989823_9560248542.pdf","D://aviva//999929989823_9560248542.pdf");
        	//new TIFFHELPER().tiffCreator("/Adhar/999929989823_9560248542.pdf","/Adhar/999929989823_9560248542.pdf");
        }
        catch(Exception ex)
        {
        	ex.printStackTrace();
        }
        	
        	
        	UIDAIService uidService = new UIDAIService();
        	aadhaarVerificationServiceResponse = uidService.getAadharDetails(aadhaarVerificationServiceRequest);
        	
        	
        	/*
        	if(aadhaarVerificationServiceRequest.getRequestType().equalsIgnoreCase("OTP"))
        	{
        		aadhaarVerificationServiceResponse.setOutputStatus("S");
        		aadhaarVerificationServiceResponse.setOutputMessage("Successfully send to Customer");
        	}
        	else if(aadhaarVerificationServiceRequest.getRequestType().equalsIgnoreCase("Verify"))
        	{
        		aadhaarVerificationServiceResponse.setOutputStatus("S");
        		aadhaarVerificationServiceResponse.setOutputMessage("Successfully Verify");
        	}*/
        	
        	
        	return aadhaarVerificationServiceResponse;
    }

}
