package com.qualtech.webservice.service;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.qualtech.in.gov.uidai.auth.aua.httpclient.NamespaceFilter;
import com.qualtech.in.gov.uidai.authentication.uid_auth_response._1.AuthRes;
import com.qualtech.in.gov.uidai.authentication.uid_auth_response._1.AuthResult;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_response._1.Resp;
import com.qualtech.util.IApplicationConstants;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;
import com.qualtech.webservice.exception.AppBaseException;

public class AuthResponseParser {
	
	private static Logger _ologger = Logger.getLogger(AuthResponseParser.class
			.getName());

	
	public ResponseDVO parseAuthResponse(InputRequestDVO reqDVO , ResponseDVO respDVO)
	throws Exception {
		
		String errorMsg="";
		Resp authRes = null;
		if(	respDVO.getResponseXML()!=null && !respDVO.getResponseXML().equals(""))
		{
			_ologger.debug("parsing auth response xml ....");
			
			if(respDVO.getResponseXML().equalsIgnoreCase(IApplicationConstants.FAIL_STATUS))
			{
				_ologger.debug("AUA authentication failed ....");
				respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				respDVO.setStatusMsg(IApplicationConstants.AUTH_ERROR_RESPOSNE);
				
				respDVO.setErrCode(IApplicationConstants.FAIL_STATUS);
				respDVO.setErrDesc(IApplicationConstants.AUTH_ERROR_RESPOSNE);	
			}
			
			else
			{
				authRes = parseAuthResponseXML(respDVO.getResponseXML());
				
				if(authRes!=null)
				{
					String ar = authRes.getRet(); 
					if(ar.equals(AuthResult.Y))
					{
						errorMsg = IApplicationConstants.AUTH_SUCCESS_MSG;
						respDVO.setStatus(IApplicationConstants.SUCCESS_STATUS);
						respDVO.setStatusMsg(IApplicationConstants.AUTH_SUCCESS_MSG);
						
						respDVO.setErrCode("");
						respDVO.setErrDesc(IApplicationConstants.AUTH_SUCCESS_MSG);
					}
					else if(ar.equals(AuthResult.N))
					{
						errorMsg = getErrorMsg(authRes.getErr(),"A");
						
						//errorMsg = "User Auth Failed";
						
						respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
						respDVO.setStatusMsg(errorMsg);
						
						respDVO.setErrCode(authRes.getErr());
						respDVO.setErrDesc(errorMsg);
					}
				}
				
					
					
			}
				
		}
		else
		{
			respDVO.setStatus(IApplicationConstants.FAIL_STATUS);
			respDVO.setStatusMsg(IApplicationConstants.AUTH_BLANK_RESPOSNE);
			
			respDVO.setErrCode(IApplicationConstants.FAIL_STATUS);
			respDVO.setErrDesc(IApplicationConstants.AUTH_BLANK_RESPOSNE);
		}
		
		return respDVO;
	}
	
	
				
		private Resp parseAuthResponseXML(String xmlToParse)
				throws JAXBException {
			
			// Create an XMLReader to use with our filter
			try {
				// Prepare JAXB objects
				JAXBContext jc = JAXBContext.newInstance(Resp.class);
				Unmarshaller u = jc.createUnmarshaller();
			
				XMLReader reader;
				reader = XMLReaderFactory.createXMLReader();
			
				// Create the filter (to add namespace) and set the xmlReader as its
				// parent.
				NamespaceFilter inFilter = new NamespaceFilter(
						"http://www.uidai.gov.in/authentication/uid-auth-response/1.0",
						true);
				inFilter.setParent(reader);
			
				// Prepare the input, in this case a java.io.File (output)
				InputSource is = new InputSource(new StringReader(xmlToParse));
			
				// Create a SAXSource specifying the filter
				SAXSource source = new SAXSource(inFilter, is);
			
				// Do unmarshalling
				Resp res = u.unmarshal(source, Resp.class).getValue();
				return res;
			} catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
			}
	
	private String getErrorMsg(String errCode,String type) throws AppBaseException
	{
	//	AadharDAO adao = new AadharDAO();
		String errorMsg="";
		
	//	errorMsg = adao.getErrorDescMsg(errCode, type);
		
		
		
		return errorMsg;
	}
	
	
	
}
