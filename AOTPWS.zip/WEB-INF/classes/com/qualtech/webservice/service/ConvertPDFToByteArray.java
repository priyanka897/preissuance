package com.qualtech.webservice.service;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ResourceBundle;

import org.apache.axis.encoding.Base64;
import org.apache.log4j.Logger;


public class ConvertPDFToByteArray {
	
	Logger logger = Logger.getLogger(ConvertPDFToByteArray.class.getName());
	ResourceBundle resProp = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
	 public  String pdfByteCaller(String aadhaarno,String policyno) throws IOException
	 {
		   logger.info("Came Inside pdfByteCaller with Aadhar& policy no- "+aadhaarno);
	        byte data[] = convertPDFToByteArray(aadhaarno, policyno);
	        String filedata=Base64.encode(data);
		 //   System.out.println(filedata);
/*//		    -----------For decode------------------
	        Base64 b = new Base64();
	        byte[] bytes = b.decode(filedata); 
	        FileOutputStream fos = new FileOutputStream("D:\\AadharWebService\\AadhaarKycFiles\\New\\999929989823.pdf");
	        fos.write(bytes);
	        fos.close();
	   */
		    return filedata;
		    }
	 private  byte[] convertPDFToByteArray(String aadhaarno,String policyno)
	 {
		 logger.info("Came Inside convertPDFToByteArray with Aadhar& policy no- "+aadhaarno+" "+policyno);
		    InputStream inputStream = null;
		    ByteArrayOutputStream baos = new ByteArrayOutputStream();
		    try {
		    	String pdfpath=resProp.getString("pdfpath");
//		    	File pdffile= new File(pdfpath+aadhaarno+"_"+policyno+".pdf");
		    	File pdffile= new File(pdfpath+aadhaarno+".pdf");
		    	if(pdffile.exists())
		    	{
		    	logger.info("Pdf found at Location"+pdfpath);		
//		        inputStream = new FileInputStream(pdfpath+aadhaarno+"_"+policyno+".pdf");
		    	inputStream = new FileInputStream(pdfpath+aadhaarno+".pdf");
		    	byte[] buffer = new byte[1024];
		        baos = new ByteArrayOutputStream();

		        int bytesRead;
		        while ((bytesRead = inputStream.read(buffer)) != -1) {
		            baos.write(buffer, 0, bytesRead);
		        }
		    	}
		    	else
		    	{
		    		logger.info("Pdf not saved at Location"+pdfpath);
		    		
		    	}

		    } catch (FileNotFoundException e)
		    {
		    	logger.info("File not found--"+e);
		        e.printStackTrace();
		    } catch (IOException e) {
		    	logger.info("IO exception --"+e);
		        e.printStackTrace();
		    } finally {
		        if (inputStream != null) {
		            try {
		                inputStream.close();
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
		        }
		    }
		    logger.info("Pdf byte array--"+ baos.toByteArray());
		    return baos.toByteArray();
		    }

		}




