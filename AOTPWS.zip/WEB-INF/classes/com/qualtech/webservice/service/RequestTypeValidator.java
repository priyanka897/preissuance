package com.qualtech.webservice.service;

import java.util.HashMap;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.qualtech.in.gov.uidai.auth.aua.helper.AuthRequestCreator;
import com.qualtech.in.gov.uidai.auth.aua.helper.AuthResponseValidator;
import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.aua.helper.SignatureVerifier;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.AuthClient;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.BfdClient;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.KYCClient;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.OtpClient;
import com.qualtech.in.gov.uidai.auth.device.helper.AuthAUADataCreator;
import com.qualtech.in.gov.uidai.auth.device.helper.BfdAUADataCreator;
import com.qualtech.in.gov.uidai.auth.device.helper.Encrypter;
import com.qualtech.in.gov.uidai.auth.device.helper.PidCreator;
import com.qualtech.in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.auth.device.model.DeviceCollectedAuthData;
import com.qualtech.in.gov.uidai.authentication.common.types._1.Meta;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.DataType;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Uses;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.UsesFlag;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.MatchingStrategy;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;
import com.qualtech.in.gov.uidai.kyc.client.DataDecryptor;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.KYCDetailsDVO;
import com.qualtech.webservice.dvo.ResponseDVO;
import com.qualtech.webservice.helper.KYCProcessor;
import com.qualtech.webservice.helper.KYCResponseParser;
import com.qualtech.webservice.helper.OTPProcessor;
import com.qualtech.webservice.main.UIDAIService;
import com.qualtech.webservice.nsdl.NSDLCaller;






public class RequestTypeValidator 
{	
	private static Logger _ologger = Logger.getLogger(RequestTypeValidator.class.getName());
	ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
	
	//BfdClient bfdClient;
	//OtpClient otpClient;
	AuthResponseValidator authResponseValidator;
	AuthAUADataCreator auaDataCreator = null;
	BfdAUADataCreator auaDataCreatorForBfd = null;
	String response = "";
	boolean residentConsent =true;
	private String customKYCXML="";
	public static HashMap<String,String> Authtxno= new HashMap<String,String>();
	public AadhaarVerificationServiceResponse validateRequest(InputRequestDVO reqDVO)
	{
		AadhaarVerificationServiceResponse resp  = new AadhaarVerificationServiceResponse();
		ResponseDVO resDVO = new ResponseDVO();
	//	AadharDAO aDao = new AadharDAO();
		boolean authStatus = false;
		String failMsg ="";
		
		try 
		{
			//reqDVO = aDao.auditInputRequest(reqDVO);
			_ologger.debug("input audit inserted ....");
			
			authStatus = true;
					//checkUserAuthentication(reqDVO);
			
			if(authStatus)
			{
				_ologger.debug("User authenticated ");
				resDVO  = checkRequestType(reqDVO);
			}
			else
			{
				failMsg = IApplicationConstants.NOT_AUTH_MSG;
				//aDao.updateFailStatus(reqDVO, failMsg);
				
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.NOT_AUTH_MSG);
				
				_ologger.debug("User not authenticated ");
			}
			System.out.println("Insertting Response >>>>>>>>>>>");
			KYCDetailsDVO customerDetail=resDVO.getCustomerDetail();
			if(customerDetail!=null){
				resp.setCustomerName(customerDetail.getCustName());
				resp.setCustomerDOB(customerDetail.getCustDOB());
				resp.setCustomerGender(customerDetail.getCustgender());
				resp.setOutputParam1(customerDetail.getCustPhone());
				resp.setOutputParam2(customerDetail.getCustEmail());
				 
				JSONObject addressobj=new JSONObject();
				 addressobj.put("CAREOF",customerDetail.getCareOf());
				 addressobj.put("HOUSE",customerDetail.getHouse());
				 addressobj.put("STREET",customerDetail.getStreet());
				 addressobj.put("LANDMARK",customerDetail.getLandmark());
				 addressobj.put("LOCATION",customerDetail.getLocality());
				 addressobj.put("PIN",customerDetail.getPinCode());
				 addressobj.put("POSTOFFICE",customerDetail.getPostOffice());
				 addressobj.put("VILL/CITY", customerDetail.getVillName());
				 addressobj.put("SUB-DIST",customerDetail.getSubdistName());
				 addressobj.put("DIST", customerDetail.getDistName());
				 addressobj.put("STATE", customerDetail.getState());
				 String aadhaarno=UIDAIService.aadharNo;
				 ConvertPDFToByteArray pdftobyte= new ConvertPDFToByteArray();
				 String pdfbyte=pdftobyte.pdfByteCaller(aadhaarno, "12345");
				 addressobj.put("PDFBYTE", pdfbyte);
				 
				 resp.setCustomerAddress(addressobj.toString());
				resp.setOutputParam3(customerDetail.getPhtString());
				
				
			}
			resp.setOutputStatus(resDVO.getStatus());
			resp.setOutputMessage(resDVO.getStatusMsg());
			System.out.println("out");
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			resp.setOutputStatus(IApplicationConstants.FAIL_STATUS);
			resp.setOutputMessage("");
			_ologger.error("Exception "+e,new Throwable());
		}
		
		
		return resp;
	}
	
	ResponseDVO checkRequestType(InputRequestDVO reqDVO) 
	{
		String failureReason ="";
	//	AadharDAO aDao = new AadharDAO();
		ResponseDVO resDVO = new ResponseDVO(); 
		OTPProcessor otpPro = new OTPProcessor();
		KYCProcessor kycPro = new KYCProcessor();
		 ResponseDVO resDVO1 = new ResponseDVO();
		
		if(reqDVO.getReqType().equalsIgnoreCase(IApplicationConstants.OTP_REQUEST))
		{
			try
			{
			if(reqDVO.getAadharNo()==null || reqDVO.getAadharNo().equals(""))
			{
				_ologger.debug("aadahar no is required");
				failureReason = IApplicationConstants.AADHAR_REQUIRED;
			//	aDao.updateFailStatus(reqDVO, failureReason);
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.AADHAR_REQUIRED);
			}			
		/*	else if(reqDVO.getFingerPrint()==null || reqDVO.getFingerPrint().equals(""))
			{
				_ologger.debug("finger print is required");
				failureReason = IApplicationConstants.FINGERPRINT_REQUIRED;
				aDao.updateFailStatus(reqDVO, failureReason);
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.FINGERPRINT_REQUIRED);	
			}*/
			else
			{
				if(reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE1) ||
						reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE2) ||
						reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE3) )
				{
					_ologger.debug("process otp....");
				
					resDVO  = otpPro.processOTP(reqDVO);
					//_ologger.debug("initialize Auth Client start");
					//initializeAuthClient();
					_ologger.debug("initialize Auth Client end.calling authenticateRequest()");
					    // authenticateRequest(constructAuthRequest( reqDVO), reqDVO);
						    
					   
					
					
					
					
					
		//			aDao.updateStatus(reqDVO, resDVO);
					
					_ologger.debug("webservice status updated");
					
					
				}
				/*else
				{
					_ologger.debug("otp recieved type is invalid");
					failureReason = IApplicationConstants.OTP_TYPE_INVALID;
					aDao.updateFailStatus(reqDVO, failureReason);
					
					resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
					resDVO.setStatusMsg(IApplicationConstants.OTP_TYPE_INVALID);	
				}*/
			 }
			}
			catch(Exception ee)
			{
				ee.printStackTrace();
				_ologger.error("AppBaseException in getting OTP ::->"+ee,new Throwable());
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.OTP_FAIL_MSG);
			}
		}
		else if(reqDVO.getReqType().equalsIgnoreCase(IApplicationConstants.AUTH_REQUEST))
		{
			try
			{
			if(reqDVO.getAadharNo()==null || reqDVO.getAadharNo().equals(""))
			{
				_ologger.debug("aadahar no is required");
				failureReason = IApplicationConstants.AADHAR_REQUIRED;
			//	aDao.updateFailStatus(reqDVO, failureReason);
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.AADHAR_REQUIRED);
			}			
			/*else if(reqDVO.getFingerPrint()==null || reqDVO.getFingerPrint().equals(""))
			{
				_ologger.debug("finger print is required");
				failureReason = IApplicationConstants.FINGERPRINT_REQUIRED;
				aDao.updateFailStatus(reqDVO, failureReason);
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.FINGERPRINT_REQUIRED);	
			}*/
			else
			{
				/*if(reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE1) ||
						reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE2) ||
						reqDVO.getOtpRecieveType().equalsIgnoreCase(IApplicationConstants.OTP_REQ_TYPE3) )*/
				{
					//_ologger.debug("process otp....");
				
					//resDVO  = otpPro.processOTP(reqDVO);
					/*_ologger.debug("initialize Auth Client start");
					initializeAuthClient();
					_ologger.debug("initialize Auth Client ends.");
					_ologger.debug("initialize KYC Client start");
					initializeKycClient();
					_ologger.debug("initialize KYC Client end.calling authenticateRequest()");*/
					//resDVO= authenticateRequest(constructAuthRequest( reqDVO), reqDVO);
						    
					   
					resDVO = kycPro.processKYC(reqDVO);
					
					    
					
					
					 //    aDao.updateStatus(reqDVO, resDVO);//-----------------
					    // resDVO1.setStatus(resDVO.getStatus());
					    // resDVO1.setErrDesc(resDVO.getErrDesc());
					    // resDVO1.setErrCode(resDVO.getErrCode());
					    // resDVO1.setStatusMsg(resDVO.getStatusMsg());
					
					_ologger.debug("webservice status updated");
					
					
				}
				/*else
				{
					_ologger.debug("otp recieved type is invalid");
					failureReason = IApplicationConstants.OTP_TYPE_INVALID;
					aDao.updateFailStatus(reqDVO, failureReason);
					
					resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
					resDVO.setStatusMsg(IApplicationConstants.OTP_TYPE_INVALID);	
				}*/
			 }
			}
			catch(Exception ee)
			{
				ee.printStackTrace();
				_ologger.error("AppBaseException in getting OTP ::->"+ee,new Throwable());
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.OTP_FAIL_MSG);
			}
			
		}
		else
		{
			try
			{
			
			failureReason = IApplicationConstants.INVALID_REQUEST;
		//	aDao.updateFailStatus(reqDVO, failureReason);
			
			resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
			resDVO.setStatusMsg(IApplicationConstants.INVALID_REQUEST);
			_ologger.debug("Invalid request type");
			}
			catch(Exception ee)
			{
				ee.printStackTrace();
				_ologger.error("Exception in invalid request ::->"+ee,new Throwable());
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				resDVO.setStatusMsg(IApplicationConstants.INVALID_REQUEST);
			}
		}
		
		
		return resDVO;
	}
	
	
	boolean checkUserAuthentication(InputRequestDVO reqDVO) 
	{
		boolean authStatus=false;
		
		//AadharDAO aDao = new AadharDAO();
		//authStatus = aDao.authenticateUser(reqDVO);
		
		return authStatus;
	}
	
	/////////////////////////////////  For otp 
	private DeviceCollectedAuthData constructAuthRequest(InputRequestDVO reqDVO )
	  {
		  
		   _ologger.info("constructing request for AadhaarID: " + reqDVO.getAadharNo());
		    DeviceCollectedAuthData request = new DeviceCollectedAuthData();
		 
		
		    
		    if(reqDVO.getFingerPrint()==null || reqDVO.getFingerPrint().equalsIgnoreCase(""))
		    {
					    if(reqDVO.getAadharNo()!=null && reqDVO.getAadharNo().length()!=0 )
					    	request.setUid(reqDVO.getAadharNo());
				
					    if(reqDVO.getCustomerName()!=null &&reqDVO.getCustomerName().length()!=0)
					    {
					    	request.setName(reqDVO.getCustomerName());
					    	request.setNameMatchValue(100);
					    	request.setNameMatchStrategy(MatchingStrategy.E);
					    }
					    
					    if(reqDVO.getCustomerGender()!=null && reqDVO.getCustomerGender().length()!=0)
					    	request.setGender(reqDVO.getCustomerGender());
				
					    //request.setNameMatchValue(100);
				
					    //request.setNameMatchStrategy(MatchingStrategy.E);
				
					    request.setFullAddress("");
					    request.setLocalFullAddress("");
					    String dynamicPin=null;
					    if(reqDVO.getOtp()!=null&&reqDVO.getOtp().length()!=0)
					    {
					    	dynamicPin=reqDVO.getOtp();
					    }
					    
						if ((dynamicPin != null) && (dynamicPin.length() > 0)) {
							request.setDynamicPin(dynamicPin);
						}
						
					    Meta m = createMeta();
					    request.setDeviceMetaData(m);
					    // Log.kua.info("end  constructAuthRequest");
					    return request;
		    }
		    
		    /*if(reqDVO.getFingerPrint()!=null && reqDVO.getFingerPrint().length()>0)
		    {
			  DeviceCollectedAuthData.BiometricData b = new DeviceCollectedAuthData.BiometricData(BiometricPosition.valueOf(reqDVO.getFingerPosition()), BioMetricType.FMR, CustomBase64.decodeBase64(reqDVO.getFingerPrint()));
		    	
		    	List<DeviceCollectedAuthData.BiometricData> li= new ArrayList<DeviceCollectedAuthData.BiometricData>();
		    	li.add(b);
		    	request.setBiometrics(li);
		    } */
			  
			  if(reqDVO.getAadharNo()!=null)
			    	request.setUid(reqDVO.getAadharNo());
			    	
			    
			    
			    Meta m = createMeta();
			    request.setDeviceMetaData(m);
			    _ologger.info("request constructed");
			  
			  
		 
	    return request;
	  }
	 
	   private Meta createMeta()
	  {
		   
		   Meta meta = new Meta();
			meta.setUdc(bundle.getString("UDC"));
			meta.setDc(bundle.getString("DC"));
			meta.setDpId(bundle.getString("DPID"));
			meta.setRdsId(bundle.getString("RDSID"));
			meta.setRdsVer(bundle.getString("RDSVER"));
			meta.setMc("");
			meta.setMi("");
		//	meta.setLot(LocationType.P);
			
	   
	    return meta;
	  } 	
	   
	   private void initializeAuthClient()
		  {
			
			  DigitalSigner ds =null;
			  DataDecryptor dd = null;
			  Properties properties = new Properties();
			  
		    try
		    {
		    	_ologger.info("start initializeAuthClient usetoken ");
		    	AuthClient authClient = new AuthClient();
		    	BfdClient bfdClient = new BfdClient();
		    	_ologger.info("INSIDE Auth 2");
		    	OtpClient otpClient = new OtpClient();
				_ologger.info("INSIDE Auth 3");
				KYCClient kycClient = new KYCClient();
		      //authClient = new AuthClient(new URL(UIDProperties.getAuthServerUrl().toString()).toURI());
		     // bfdClient = new BfdClient(new URL(UIDProperties.getBfdServerUrl().toString()).toURI());
		     // otpClient = new OtpClient(new URL(UIDProperties.getOtpServerUrl().toString()).toURI());
		     // DigitalSigner ds = new DigitalSigner(UIDProperties.getSignKeyStore().toString(), UIDProperties.getSignaturePassword().toCharArray(), UIDProperties.getSignatureAlias().toString());
		      /*
		      if (UIDProperties.isUseToken())
		      {
		    	  
		    	  _ologger.info("UIDProperties.isUseToken() "+UIDProperties.isUseToken());
			        properties.load(new FileInputStream(new File(UIDProperties.getTokenConfig())));
			        eTokenLibrary = properties.getProperty("library");
			        	    	  
		    	    if(eTokenLibrary !=null && eTokenLibrary.length() > 0 ) {
			        	 ds = new DigitalSigner(UIDProperties.getTokenConfig(),UIDProperties.getTokenPassword().toCharArray());
			        	 authClient.setDigitalSignator(ds);
			        	 _ologger.info("After setting DigitalSignators in initializeAuthClient");
			        	 authResponseValidator = new AuthResponseValidator(new SignatureVerifier(UIDProperties.getPublicKeyFileDSIG().toString()));
			        	 auaDataCreator = new AuthAUADataCreator(new Encrypter(UIDProperties.getPublicKeyFile().toString()), "YES".equalsIgnoreCase(UIDProperties.getUseSSK().toString()));
			        	 _ologger.info("AuthClient initialized Successfully");
			        }
			         else{
			        	 _ologger.info("Check the DLL / SO file is present or not ");
			        	 response = "E";
			         }
		      }
		      else*/
		      
		      {
		    	  
		    	  //File Based Signature Verification
		    	  if(bundle.getString("KEYSTOREFILEPATH")!=null && bundle.getString("KEYSTOREFILEPATH").length() > 0)
		    	  {
		    		  ds = new DigitalSigner(bundle.getString("KEYSTOREFILEPATH").toString(), bundle.getString("KEYSTOREPASSWORD").toCharArray(), bundle.getString("KEYSTOREALIAS"));
		    		  dd = new DataDecryptor(bundle.getString("KEYSTOREFILEPATH").toString(), bundle.getString("KEYSTOREPASSWORD").toCharArray(),bundle.getString("PUBLICKEYFILENAME"));
		    		    authClient.setDigitalSignator(ds);		    		  
			  			bfdClient.setDigitalSignator(ds);
			  			otpClient.setDigitalSignator(ds);
			  			kycClient.setDigitalSignator(ds);
			  			kycClient.setDataDecryptor(dd);
		    		  _ologger.info("After setting DigitalSignators in initializeAuthClient");
		    		  authResponseValidator = new AuthResponseValidator(new SignatureVerifier(bundle.getString("PUBLICKEYFILENAME")));
		    	      auaDataCreator = new AuthAUADataCreator(new Encrypter(bundle.getString("PUBLICKEYFILENAME")), "YES".equalsIgnoreCase("No"));
		    	      _ologger.info("AuthClient initialized Successfully");
		    	  }
		    	  else{
		    		  _ologger.info("SignKeyStore cannot be null");
		    	  }
		      }
		    }
		    catch (Exception e1) 
		    {
		        response = "E";
		        _ologger.error("Exception in initializeAuthClient " + e1.getMessage(), e1);
		    }
		  }
	   
	   private void initializeKycClient() {
	        try {
	        	 _ologger.info("Inside try for kyc");
	            String useSSK = bundle.getString("useSSK").toString();
	            boolean useSSKFlag = "yes".equalsIgnoreCase(useSSK) ? true : false;
	            _ologger.info(":"+bundle.getString("PUBLICKEYFILENAME")+" "+useSSKFlag+":");
	            AuthAUADataCreator authAUADataCreator = new AuthAUADataCreator(new Encrypter(bundle.getString("PUBLICKEYFILENAME")), useSSKFlag);
	            _ologger.info("try1");
	            KYCClient kYCClient = new KYCClient();
	            _ologger.info("try2");	            
	            OtpClient otpClient = new OtpClient();
	            _ologger.info("try3");
	            
	            DigitalSigner ds = null;
	            DataDecryptor dd = null;
	        //    _ologger.info("keystore:"+EKYCProperties.getSignKeyStore()+":");
	         //   _ologger.info("pwd:"+EKYCProperties.getSignaturePassword()+":");
	         //   _ologger.info("alias:"+EKYCProperties.getSignatureAlias()+":");
	            //ds = new DigitalSigner(EKYCProperties.getSignKeyStore(),EKYCProperties.getSignaturePassword().toCharArray(),EKYCProperties.getSignatureAlias());
	            //ds = new DigitalSigner(bundle.getString("KEYSTOREFILEPATH").toString(),bundle.getString("KEYSTOREPASSWORD").toCharArray());
	            ds = new DigitalSigner(bundle.getString("KEYSTOREFILEPATH").toString(), bundle.getString("KEYSTOREPASSWORD").toCharArray(), bundle.getString("KEYSTOREALIAS"));

	            //dd = new DataDecryptor(EKYCProperties.getSignKeyStore(), EKYCProperties.getSignaturePassword().toCharArray(),EKYCProperties.getPublicKeyFileDSIG(),EKYCProperties.getSignatureAlias());
	            //dd = new DataDecryptor(EKYCProperties.geteTokenConfig(), EKYCProperties.geteTokenPassword().toCharArray(),EKYCProperties.getPublicKeyFileDSIG());
	            dd = new DataDecryptor(bundle.getString("KEYSTOREFILEPATH").toString(), bundle.getString("KEYSTOREPASSWORD").toCharArray(),bundle.getString("PUBLICKEYFILENAME"));
	            
	            kYCClient.setDigitalSignator(ds);
	            otpClient.setDigitalSignator(ds);
	            //otpClient.setAsaLicenseKey(EKYCProperties.getAsaLicenseKey());
	            kYCClient.setDataDecryptor(dd);
	            //kYCClient.setAsaLicenseKey(EKYCProperties.getAsaLicenseKey());
	        } catch (Exception ex) {
	            ex.printStackTrace();
	       
	        }
		}
	   
	   
	   
	   private ResponseDVO authenticateRequest(DeviceCollectedAuthData authData,InputRequestDVO reqDVO )
		  {
		   ResponseDVO resDVO = new ResponseDVO();
		    try
		    {
		    	_ologger.info("Setting proxy Settings in authenticateRequest");
		     // System.setProperty(UIDProperties.getProxyHost(), UIDProperties.getProxyIP());
		     // System.setProperty(UIDProperties.getProxyPort(), UIDProperties.getProxyPortNum());
		      try
		      {
		    	  _ologger.info("connecting to server");
		      //  new URL(UIDProperties.getAuthServerUrl().toString()).openConnection().connect();
		      }
		      catch (Exception e)
		      {
		        response = "E";
		        _ologger.error("Exception in connecting to URL ", e);
		        return null;
		      }

		      //if (!new File(UIDProperties.getPublicKeyFile()).exists()) 
		     // {
		    //	  _ologger.error("Public key file not found.\nVerify the file path in in properties file");
		     //   return;
		      //}

		     /* if (!new File(UIDProperties.getSignKeyStore().toString()).exists()) {
		        Log.biom_Log.error("Signature file not found.\nVerify the file path in properties file");
		        return;
		      }*/

		      Uses usesElement = createUsesElement();

		      AuthDataFromDeviceToAUA auaData = null;
		      _ologger.info("CREATING XML");
		      _ologger.info("UID :"+authData.getUid());
		      _ologger.info("Terminal ID :"+bundle.getString("TERMINALID"));
		      //Log.biom_Log.info("Metadata :"+authData.getDeviceMetaData());
		      //Log.biom_Log.info("PID :"+PidCreator.createXmlPid(authData));
		      _ologger.info("Data type :"+DataType.X);
		      
		      Pid pid=PidCreator.createXmlPid(authData);
		      
		       auaData = auaDataCreator.prepareAUAData(authData.getUid(),bundle.getString("TERMINALID"), authData.getDeviceMetaData(), 
		    		   pid, DataType.X);
		       
		      
		      
		      com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Tkn token = null;

		      AuthRequestCreator reqCreator = new AuthRequestCreator();
		      _ologger.info("creating request");
		      Auth auth = reqCreator.createAuthRequest(bundle.getString("AUA"), bundle.getString("SA"),bundle.getString("LICENSEKEY"), usesElement, token, auaData, authData.getDeviceMetaData(),bundle.getString("AUTHVERSION"));
		      
		      
		      
		    boolean mec = true;
		  	boolean lr = true;
		  	boolean de = false;
		  	if(reqDVO.getRc()!=null && reqDVO.getRc().equalsIgnoreCase("Y"))
		  	{
		  		residentConsent = true;
		  	}
		  	if(reqDVO.getMec()!=null && reqDVO.getMec().equalsIgnoreCase("Y"))
		  	{
		  		mec = true;
		  	}
		  	if(reqDVO.getLr()!=null && reqDVO.getLr().equalsIgnoreCase("Y"))
		  	{
		  		lr = true;
		  	}
		      
		      System.out.println("############"+mec+" @@@@@@@@@@@@@"+lr);
		      _ologger.info("authenticating request");
		      KYCClient kycClient=new KYCClient();
		      
		      String strKeyStorePwd =bundle.getString(IApplicationConstants.KEYSTOREPASSWORD);
		      char[] 	keyStorePassword = strKeyStorePwd.toCharArray();
		      kycClient.setDigitalSignator(new DigitalSigner(bundle.getString(IApplicationConstants.KEYSTOREFILEPATH),keyStorePassword,bundle.getString(IApplicationConstants.KEYSTOREALIAS)));				
		      kycClient.setAsaLicenseKey(bundle.getString(IApplicationConstants.ASALICENSEKEY));		      
		      
		      //String reqXMl = kycClient.authenticate(auth);
		      String reqXMl = kycClient.kycTrans(auth,bundle.getString("AUA"),residentConsent,
						"",usesElement,customKYCXML,mec,lr,de,reqDVO.getFingerPrint(),bundle.getString(IApplicationConstants.URL),pid);
		      
		     
		      
		      _ologger.info("Auth request XML ::::"+reqXMl);
		      reqDVO.setRequestXML(reqXMl);
		     
		      
		      //////
		      //   reqDVO= auditUIDRequest(reqDVO);
				_ologger.debug("uid request inserted in DB for audit");
				
				
				resDVO = getAuthResponseXML(reqDVO,resDVO);
				_ologger.debug("got Auth response , going to parse it");
				_ologger.info("Auth response XML ::::"+resDVO.getResponseXML());
				
				resDVO  = parseResponse(reqDVO , resDVO);
				
		//		System.out.println(resDVO.getTiffByte());
		//		System.out.println(resDVO.getResponseXML());
		//		System.out.println(resDVO.getStatus());
				
				
				//AadharDAO aadDao = new AadharDAO();
			//	aadDao.updateUIDStatus(reqDVO, resDVO);
				_ologger.debug("uid status updated in DB....");
		      
		      
		      
		      
		      ////////////////////
		      
		      
		    }
		    catch (Exception e)
		    {
		      response = "E";
		      _ologger.error("error in authentication", e);
		      e.printStackTrace();
		    }
		    return resDVO;
		  }
	   
	   private Uses createUsesElement() {
		   _ologger.info("in  createUsesElement"); 
			Uses uses = new Uses();
			uses.setPi(UsesFlag.valueOf(bundle.getString("usesPi").equals("true")? "Y" : "N"));
			uses.setPa(UsesFlag.valueOf(bundle.getString("usesPa").equals("true") ? "Y" : "N"));
			uses.setPin(UsesFlag.valueOf(bundle.getString("usesPin").equals("true") ? "Y" : "N"));
			uses.setOtp(UsesFlag.valueOf(bundle.getString("usesOtp").equals("true") ? "Y" : "N"));
			uses.setBio(UsesFlag.valueOf(bundle.getString("usesBio").equals("true") ? "Y" : "N"));
			uses.setPfa(UsesFlag.valueOf(bundle.getString("usesPfa").equals("true") ? "Y" : "N"));
			
			String biometricTypes = bundle.getString("usesBioFMR").equals("true")?"FMR" : "";
			if(biometricTypes.length()!=0)
				biometricTypes +=  bundle.getString("usesBioFIR").equals("true")?",FIR" : "";
			else
				biometricTypes +=   bundle.getString("usesBioFIR").equals("true")?"FIR" : "";
			
			if(biometricTypes.length()!=0)
				biometricTypes +=   bundle.getString("usesBioFIR").equals("true")?",IIR" : "";
			else
				biometricTypes +=   bundle.getString("usesBioIIR").equals("true")?"IIR" : "";
			/*
		 	if (jCheckBoxFMR.isSelected()) {
			
				biometricTypes += "FMR";
			}
			
			if (jCheckBoxFIR.isSelected()) {
				if (StringUtils.isNotBlank(biometricTypes)) {
					biometricTypes += ",";
				}
				biometricTypes += "FIR";
			}
			
			if (jCheckBoxIIR.isSelected()) {
				if (StringUtils.isNotBlank(biometricTypes)) {
					biometricTypes += ",";
				}
				biometricTypes += "IIR";
			}
			*/
			uses.setBt(biometricTypes);
		//	System.out.println(" TYPES >>>> "+biometricTypes);
			 _ologger.info("end  createUsesElement"); 
			return uses;
		}
		
		ResponseDVO getAuthResponseXML(InputRequestDVO reqDVO , ResponseDVO respDVO)
		{
			ResponseDVO resDVO = respDVO;
			String responseXML="";
			try
			{
				
				NSDLCaller caller = new NSDLCaller();
				responseXML = caller.getResponseFromHttps(reqDVO.getRequestXML());
			//	System.out.println("responseXML  >>> "+responseXML);
				if(responseXML==null )responseXML="";
				
				
				resDVO.setResponseXML(responseXML);
				resDVO.setException("");
			}
			
			catch(Exception ee)
			{
				ee.printStackTrace();
				resDVO.setResponseXML("");
				resDVO.setException("exception in getting response from NSDL");
				_ologger.error("exception in getting response from NSDL"+ee,new Throwable());
			}
			
			return resDVO;
		}
		InputRequestDVO auditUIDRequest(InputRequestDVO reqDVO) 
		{
		//	AadharDAO aDao = new AadharDAO(); 
		//	reqDVO = aDao.inputUIDAudit(reqDVO);
			
			return reqDVO;
		}
		
		ResponseDVO parseResponse(InputRequestDVO reqDVO , ResponseDVO resDVO) 
		{
			//AuthResponseParser authResParser = new AuthResponseParser();
			KYCResponseParser kycResParser = new KYCResponseParser();
			try
			{
				_ologger.error("Going to parse response "); 
				resDVO = kycResParser.parseKYCResponse(reqDVO , resDVO);
				_ologger.error("Response parsed... "); 
			}
			catch(Exception ee)
			{
				_ologger.error("AppBaseException in parsing auth response xml-->"+ee.getMessage(),new Throwable());
				ee.printStackTrace();
				resDVO.setStatus(IApplicationConstants.FAIL_STATUS);
				//resDVO.setStatusMsg(IApplicationConstants.AUTH_FAIL_MSG);
				
				resDVO.setErrDesc(IApplicationConstants.AUTH_FAIL_MSG);
				resDVO.setException("Exception in parsing auth response xml ");
			}
			
			
			return resDVO;
		}
}
