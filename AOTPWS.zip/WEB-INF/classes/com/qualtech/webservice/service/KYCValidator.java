package com.qualtech.webservice.service;

import java.io.StringReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.NamespaceFilter;
import com.qualtech.in.gov.uidai.kyc.common.types._1.GenderType;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_response._1.KycRes;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.util.MatcherUtil;
import com.qualtech.util.Pdf2Tiff;
//import com.qualtech.webservice.db.AadharDAO;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.KYCDetailsDVO;
import com.qualtech.webservice.dvo.ResponseDVO;

public class KYCValidator {

	private static Logger _logger = Logger.getLogger(KYCValidator.class.getName());

	public ResponseDVO validateKYCResponse(InputRequestDVO req, ResponseDVO res,
			String kycResXML) throws Exception
	{
		_logger.debug("validating kyc response");
		
		 KycRes kycRes = parseKYCResponseXML(kycResXML); 
		 //KycRes kycRes = new KycRes();
		 
				
		 KYCDetailsDVO kycDet  = fetchAadhaarDetails(kycRes);
		
		 /*KYCDetailsDVO kycDet = new KYCDetailsDVO();
		 kycDet.setCustName("Rakesh Pawa");
		 kycDet.setCustgender("M");
		 kycDet.setCustDOB("01-01-1985");
		 */
		 
		 if(kycRes.getErr()==null || kycRes.getErr().equals(""))
			{
			 
		MatcherUtil matUtil =new MatcherUtil();
		
		Pdf2Tiff tiffObj = new Pdf2Tiff();
		String kycCustName =kycDet.getCustName();
		String kycCustGender =kycDet.getCustgender();
		String kycCustDOB = kycDet.getCustDOB();
		
		boolean nameMatched=false;
		boolean genderMatched=false;
		boolean dobMatched=false;
		
		if(kycRes != null)
		{
				// get all the attributes of kyc resposne xml ....(like dob , name , addess etc....
			
			
			if(req.getDataMatchRequired().equalsIgnoreCase(IApplicationConstants.OK))
			{
				
				//nameMatched = matUtil.checkName(req.getCustomerName() ,kycCustName );
				nameMatched=true;
				if(nameMatched)
				{
					_logger.debug("customer name matched , checking for gender....");
					genderMatched = matUtil.checkGender(req.getCustomerGender(), kycCustGender);
					if(genderMatched)
					{
						_logger.info("customer gender matched , checking for DOB....");
						
						dobMatched = matUtil.checkDOB(req.getCustomerDOB(), kycCustDOB);
						
						if(dobMatched)
						{
							_logger.info("Customer Details Matched , going to make TIFF File");
							
							// make tiff file code goes here.....
							res = tiffObj.processTiffCreation(kycDet , res , req);
							
							
						}
						else
						{
							res.setStatus(IApplicationConstants.FAIL_STATUS);
							res.setStatusMsg(IApplicationConstants.KYC_DOB_NOT_MATCHED);
							_logger.info("kyc customer DOB not matched....");
						}
					}
					else
					{
						res.setStatus(IApplicationConstants.FAIL_STATUS);
						res.setStatusMsg(IApplicationConstants.KYC_GENDER_NOT_MATCHED);
						_logger.info("kyc customer gender not matched....");
					}
				}
				else
				{
					res.setStatus(IApplicationConstants.FAIL_STATUS);
					res.setStatusMsg(IApplicationConstants.KYC_NAME_NOT_MATCHED);
					_logger.debug("kyc customer name not matched....");
				}
				
				
			}
			else
			{
				
				res = tiffObj.processTiffCreation(kycDet , res , req);
			}
			
			
		}
		else
		{
			res.setStatus(IApplicationConstants.FAIL_STATUS);
			res.setStatusMsg(IApplicationConstants.KYC_INVALID_RESPOSNE);
			_logger.debug("kyc resposne is invalid....");
		}
		
		}
		 else
		 {
			 String errorMsg= "";
			 _logger.debug("kyc decrpted xml returned error code hence invalid data found ....");
				errorMsg = getErrorMsg(kycRes.getErr(),"K");
				
				res.setStatus(IApplicationConstants.FAIL_STATUS);
				res.setStatusMsg(errorMsg);
				
				res.setErrCode(kycRes.getErr());
				res.setErrDesc(errorMsg);
		 }
		
		return res;
		
	}
	
	private String getErrorMsg(String errCode,String type)
	{
	//	AadharDAO adao = new AadharDAO();
		String errorMsg="";
		
	//	errorMsg = adao.getErrorDescMsg(errCode, type);
		
		return errorMsg;
	}
	
	private KYCDetailsDVO fetchAadhaarDetails(KycRes kycRes)
	{
		 KYCDetailsDVO kycDet = new KYCDetailsDVO();
		 try
		 {
		 if(kycRes!=null)
		 {
			 GenderType gtype = kycRes.getUidData().getPoi().getGender();
			 
			 kycDet.setCustName(kycRes.getUidData().getPoi().getName());
			 kycDet.setCustDOB(kycRes.getUidData().getPoi().getDob());
			 kycDet.setCustPhone(kycRes.getUidData().getPoi().getPhone());
			 kycDet.setCustEmail(kycRes.getUidData().getPoi().getEmail());
			 kycDet.setCustgender(gtype.value());
			 
			 kycDet.setCareOf(kycRes.getUidData().getPoa().getCo());
			 kycDet.setDistName(kycRes.getUidData().getPoa().getDist());
			 kycDet.setHouse(kycRes.getUidData().getPoa().getHouse());
			 kycDet.setLandmark(kycRes.getUidData().getPoa().getLm());
			 kycDet.setLocality(kycRes.getUidData().getPoa().getLoc());
			 kycDet.setPinCode(kycRes.getUidData().getPoa().getPc());
			 kycDet.setPostOffice(kycRes.getUidData().getPoa().getPo());
			 kycDet.setState(kycRes.getUidData().getPoa().getState());
			 kycDet.setStreet(kycRes.getUidData().getPoa().getStreet());
			 kycDet.setSubdistName(kycRes.getUidData().getPoa().getSubdist());
			 kycDet.setVillName(kycRes.getUidData().getPoa().getVtc());
			 
			byte[] imgbyte = kycRes.getUidData().getPht().getBytes();
			kycDet.setCustPhoto(Base64.decodeBase64(imgbyte));
			//kycDet.setCustPhoto(imgbyte);
			kycDet.setPhtString(kycRes.getUidData().getPht());
			/*System.out.println("///////////////////////////////");
			System.out.println("photo  : " +kycRes.getUidData().getPht());
			System.out.println("photo byte : " + kycRes.getUidData().getPht().getBytes());
			System.out.println("after decode : " + Base64.decodeBase64(imgbyte).toString());
			System.out.println("///////////////////////////////"); 
			 */
		 }
		 }
		 catch(Exception ee)
		 {
			 ee.printStackTrace();
			 _logger.debug("Exception in fetching user details from decrypted xml.."+ee,new Throwable());
		 }
		 
		 return kycDet;
		
	}
	
	

	private KycRes parseKYCResponseXML(String xmlToParse)  {

		KycRes res  = null;
		// Create an XMLReader to use with our filter
		try {
			// Prepare JAXB objects
			JAXBContext jc = JAXBContext.newInstance(KycRes.class);
			Unmarshaller u = jc.createUnmarshaller();

			XMLReader reader;
			reader = XMLReaderFactory.createXMLReader();

			// Create the filter (to add namespace) and set the xmlReader as its
			// parent.
			NamespaceFilter inFilter = new NamespaceFilter(
					"http://www.uidai.gov.in/kyc/uid-kyc-response/1.0", true);
			inFilter.setParent(reader);

			// Prepare the input, in this case a java.io.File (output)
			InputSource is = new InputSource(new StringReader(xmlToParse));

			// Create a SAXSource specifying the filter
			SAXSource source = new SAXSource(inFilter, is);

			// Do unmarshalling
			res = u.unmarshal(source, KycRes.class).getValue();
			
		} catch (SAXException e) {
			_logger.error("SAXException in parsing kyc response xml "+e,new Throwable());
			e.printStackTrace();	//throw new AppBaseException("SAXException in parsing kyc response xml "+e);
			
		}
		catch (JAXBException e) {
			_logger.error("JAXBException in parsing kyc response xml "+e,new Throwable());
			e.printStackTrace();//throw new AppBaseException("JAXBException in parsing kyc response xml "+e);
			
		}
		catch (Exception e) {
			_logger.error("Exception in parsing kyc response xml "+e,new Throwable());
			e.printStackTrace();//throw new AppBaseException("Exception in parsing kyc response xml "+e);
		}
		return res;
	}

}
