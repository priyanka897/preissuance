package com.qualtech.webservice.service;


import java.util.Date;
import java.util.Properties;
import java.util.PropertyResourceBundle;
import java.util.StringTokenizer;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import org.apache.log4j.Logger;
import com.qualtech.in.gov.uidai.auth.aua.qc.NSDLPropertyUtil;
import com.qualtech.util.IApplicationConstants;



public class EmailSenderAction 
{        
	static Logger  logger = Logger.getLogger(EmailSenderAction.class.getName());
	
	EmailValidator emailValidator=new EmailValidator();
   
    public void sendEmail()
    {   
		try
		{
			PropertyResourceBundle res = NSDLPropertyUtil.getInstance().getNDSLProp();
			
	        logger.info("In send mail method....." );
	        Multipart mp = null;
	        Properties mailProps = new Properties();
		    Session mailSession =null;
		    MimeMessage msg = null;
  	        boolean debug = false;
			int totalEmail=0;
        	String subject="";
    		String userType="";
    		String message="";
			//MailerDTO.setStatus("S");	
			
			mailProps.put("mail.smtp.host",res.getString(IApplicationConstants.SMTPHOST));
			mailProps.put("mail.smtp.port",res.getString(IApplicationConstants.SMTPPORT));
		    mailSession=Session.getDefaultInstance(mailProps, null);
			mailSession.setDebug(debug);	        	 
	        
			try
        	{
				
    		 	msg=new MimeMessage(mailSession);  
		        	mp = new MimeMultipart();	        		        		
		        	
		        	
		        	subject=res.getString(IApplicationConstants.MAILSUBJECT);
					userType="email.exception.";
		    		message=res.getString(IApplicationConstants.EXCEPTIONCONTENT);
		    		totalEmail=Integer.parseInt(res.containsKey(userType+"totalCount")?res.getString(userType+"totalCount"):"0");
		    		
		    		msg.setFrom(new InternetAddress(res.getString(IApplicationConstants.SENDER),res.getString(IApplicationConstants.SENDERNAME)));
		    		
		        	
		        	emailAddress(subject,userType,totalEmail,msg , res);
		        	setContentEmail(mp,message);	        	      
			       
				        msg.setContent(mp);
				        msg.setHeader("X-Mailer", "JavaMailer");
				        msg.setSentDate(new Date());         
				        
				        //Transport transport = mailSession.getTransport("smtp"); 
				        
				        Transport.send(msg);
				        
						logger.info("Mail Successfully sent.");
						System.out.println("Mail Successfully sent.");		        
			        	   
	        	}
	        	catch(Exception e)
	        	{
	        		logger.error("Error While sending mail:-"+e,new Throwable());
	        		System.out.println("Error While sending mail:-"+e);
	        		//e.printStackTrace();
	        	}
	            
		}
	    catch (Exception e) 
	    {	    
	    	logger.error("Exception Caught::"+e,new Throwable()); 	    
	    }
	    logger.info("out from send mail method....." );
	}
    
    public void emailAddress(String subject,String userType,int totalEmailCount,MimeMessage msg,PropertyResourceBundle res)
    {
    	logger.debug("Getting in EmailAddress:-");
    	int count=1;
    	String emailFormat=null;
    	String[] detailArray=null;
    	String toEmails="";
    	String ccEmails="";
    	String bccEmails="";
    	try
    	{	         	        
  	         for(count=1;count<=totalEmailCount;count++)
  	    	 {	  	    	  
  	        	  emailFormat=res.getString(userType+count);
  	        	  detailArray=emailFormat.split("~");
	  	    	  if(detailArray[3].trim().equalsIgnoreCase("Y"))
	  	    	  {	  
	  	    		  if(detailArray[0].equalsIgnoreCase("TO"))
	  	    			toEmails=toEmails+","+detailArray[2];
	  	    		  if(detailArray[0].equalsIgnoreCase("CC"))
	  	    			ccEmails=ccEmails+","+detailArray[2];	  
	  	    		  if(detailArray[0].equalsIgnoreCase("BCC"))
	  	    			bccEmails=bccEmails+","+detailArray[2];    	     
	  	    	  } 	  	    	  
  	    	}	     
  	        logger.info("TO Emails --> "+ toEmails +"\n CC Emails--> "+ccEmails+"\nBCC Emails--> "+bccEmails);
 	        System.out.println("TO Emails --> "+ toEmails +"\nCC Emails--> "+ccEmails+"\nBCC Emails--> "+bccEmails);
        	processAddress(msg,toEmails, ",", "TO");
        	processAddress(msg,ccEmails, ",", "CC");
        	processAddress(msg,bccEmails, ",", "BCC");
        	
        	msg.setSubject(subject);
    	}
    	catch(Exception e)
    	{	
    		logger.error("Error while getting Mail ids:-"+e,new Throwable());
    		e.printStackTrace();
    	}
    	logger.debug("Getting out from EmailAddress:-");
    }
    
    public void setContentEmail(Multipart mp,String message)
    {
    	logger.debug("Getting in SetContentEmail:");
        MimeBodyPart mbp = new MimeBodyPart();
        try
        {        	
        	      	
        	mbp.setContent(message,"text/html");
	    	mp.addBodyPart(mbp);    	
	    		    	
        }
		catch (Exception e) 
	    {
	    	logger.error("Exception Caught while Mail content design error:::"+e,new Throwable());
	    	 
	    }
		logger.debug("Getting out SetContentEmail:");
    }
		
	private MimeMessage processAddress(MimeMessage msg, String address, String delim, String recipientType)
    {
        StringTokenizer st = new StringTokenizer(address, delim);
        if(st != null)
        {
            do
            {
                if(!st.hasMoreTokens())
                    break;
                String eMail = st.nextToken();		
    	        if(eMail!=null || emailValidator.validate(eMail))
    	        {            	    	        	
                    logger.info("Adding recipientType:-"+recipientType +" and mailid is:-"+eMail);
                    try
                    {
                        if(recipientType.equalsIgnoreCase("TO"))
                            msg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(eMail));
                        else if(recipientType.equalsIgnoreCase("CC"))
                            msg.addRecipient(javax.mail.Message.RecipientType.CC, new InternetAddress(eMail));
                        else if(recipientType.equalsIgnoreCase("BCC"))
                            msg.addRecipient(javax.mail.Message.RecipientType.BCC, new InternetAddress(eMail));
                    }
                    catch(AddressException e)
                    {
                        logger.error("ERROR: " + e);
                        e.printStackTrace();
                    }
                    catch(MessagingException e)
                    {
                        logger.error("ERROR: " + e);
                        e.printStackTrace();
                    }
                    catch(Exception e)
                    {
                        logger.error("ERROR: " + e);
                        e.printStackTrace();
                    }
                }
            } while(true);
        }
        return msg;
    }
	
//	public class SMTPAuthenticator extends javax.mail.Authenticator
//	{
//		String userName = "amit";
//		String password = "jain";
//		
//		SMTPAuthenticator(String userName,String password)
//		{
//			this.userName=userName;
//			this.password=password;
//		}
//		public  PasswordAuthentication getPasswordAuthentication()
//		{
//			return new PasswordAuthentication(userName, password);
//		}
//	}
}

