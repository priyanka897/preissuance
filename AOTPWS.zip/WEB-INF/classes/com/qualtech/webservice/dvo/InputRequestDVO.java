package com.qualtech.webservice.dvo;

import java.util.List;

public class InputRequestDVO {

	
	
	private String systemID;
	private String password;
	private String reqType;
	private String aadharNo;
	private String otp;
	private String reqParam1;
	private String reqParam2;
	private String reqParam3;
	private String reqParam4;
	private String reqParam5;
	private String otpRecieveType;
	private String customerName;
	private String customerDOB;
	private String customerGender;
	private String proposalNumber1;
	private String proposalNumber2;
	private String dataMatchRequired;
	private Long seqNo;
	private Long uidSeqNo;
	
	private List propNumList;
	private String fingerPrint;
	private String fingerPosition;
	private String Rc;
	private String Mec;
	private String Lr;
	
	public String getRc() {
		return Rc;
	}
	public void setRc(String rc) {
		Rc = rc;
	}
	public String getMec() {
		return Mec;
	}
	public void setMec(String mec) {
		Mec = mec;
	}
	public String getLr() {
		return Lr;
	}
	public void setLr(String lr) {
		Lr = lr;
	}

	public String getFingerPrint() {
		return fingerPrint;
	}
	public void setFingerPrint(String fingerPrint) {
		this.fingerPrint = fingerPrint;
	}
	public String getFingerPosition() {
		return fingerPosition;
	}
	public void setFingerPosition(String fingerPosition) {
		this.fingerPosition = fingerPosition;
	}
	public List getPropNumList() {
		return propNumList;
	}
	public void setPropNumList(List propNumList) {
		this.propNumList = propNumList;
	}
	public Long getUidSeqNo() {
		return uidSeqNo;
	}
	public void setUidSeqNo(Long uidSeqNo) {
		this.uidSeqNo = uidSeqNo;
	}
	private String requestXML;
	
	
	public String getRequestXML() {
		return requestXML;
	}
	public void setRequestXML(String requestXML) {
		this.requestXML = requestXML;
	}
	public String getSystemID() {
		return systemID;
	}
	public void setSystemID(String systemID) {
		this.systemID = systemID;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	public String getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(String aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getReqParam1() {
		return reqParam1;
	}
	public void setReqParam1(String reqParam1) {
		this.reqParam1 = reqParam1;
	}
	public String getReqParam2() {
		return reqParam2;
	}
	public void setReqParam2(String reqParam2) {
		this.reqParam2 = reqParam2;
	}
	public String getReqParam3() {
		return reqParam3;
	}
	public void setReqParam3(String reqParam3) {
		this.reqParam3 = reqParam3;
	}
	public String getReqParam4() {
		return reqParam4;
	}
	public void setReqParam4(String reqParam4) {
		this.reqParam4 = reqParam4;
	}
	public String getReqParam5() {
		return reqParam5;
	}
	public void setReqParam5(String reqParam5) {
		this.reqParam5 = reqParam5;
	}
	public java.lang.String getOtpRecieveType() {
		return otpRecieveType;
	}
	public void setOtpRecieveType(java.lang.String otpRecieveType) {
		this.otpRecieveType = otpRecieveType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerDOB() {
		return customerDOB;
	}
	public void setCustomerDOB(String customerDOB) {
		this.customerDOB = customerDOB;
	}
	public String getCustomerGender() {
		return customerGender;
	}
	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}
	public String getProposalNumber1() {
		return proposalNumber1;
	}
	public void setProposalNumber1(String proposalNumber1) {
		this.proposalNumber1 = proposalNumber1;
	}
	public String getProposalNumber2() {
		return proposalNumber2;
	}
	public void setProposalNumber2(String proposalNumber2) {
		this.proposalNumber2 = proposalNumber2;
	}
	public String getDataMatchRequired() {
		return dataMatchRequired;
	}
	public void setDataMatchRequired(String dataMatchRequired) {
		this.dataMatchRequired = dataMatchRequired;
	}
	public Long getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(Long seqNo) {
		this.seqNo = seqNo;
	}
	
}
