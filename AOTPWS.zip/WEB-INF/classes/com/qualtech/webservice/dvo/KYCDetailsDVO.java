package com.qualtech.webservice.dvo;

public class KYCDetailsDVO {
	
	
	private String custName;
	private String custDOB; 
	private String custgender;
	private String custPhone;
	private String custEmail;
	private String careOf;
	private String house;
	private String street;
	private String landmark;
	private String locality;
	private String villName;
	private String subdistName;
	private String distName;
	private String state;
	private String pinCode;
	private String postOffice;
	private byte[] custPhoto;
	private String phtString;
	
	
	
	public String getPhtString() {
		return phtString;
	}
	public void setPhtString(String phtString) {
		this.phtString = phtString;
	}
	public String getCustName() {
		return custName==null?" ":custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustDOB() {
		return custDOB==null?" ":custDOB;
	}
	public void setCustDOB(String custDOB) {
		this.custDOB = custDOB;
	}
	public String getCustgender() {
		return custgender==null?" ":custgender;
	}
	public void setCustgender(String custgender) {
		this.custgender = custgender;
	}
	public String getCustPhone() {
		return custPhone==null?" ":custPhone;
	}
	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}
	public String getCustEmail() {
		return custEmail==null?" ":custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public String getCareOf() {
		return careOf==null?" ":careOf;
	}
	public void setCareOf(String careOf) {
		this.careOf = careOf;
	}
	public String getHouse() {
		return house==null?" ":house;
	}
	public void setHouse(String house) {
		this.house = house;
	}
	public String getStreet() {
		return street==null?" ":street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getLandmark() {
		return landmark==null?" ":landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public String getLocality() {
		return locality==null?" ":locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	public String getVillName() {
		return villName==null?" ":villName;
	}
	public void setVillName(String villName) {
		this.villName = villName;
	}
	public String getSubdistName() {
		return subdistName==null?" ":subdistName;
	}
	public void setSubdistName(String subdistName) {
		this.subdistName = subdistName;
	}
	public String getDistName() {
		return distName==null?" ":distName;
	}
	public void setDistName(String distName) {
		this.distName = distName;
	}
	public String getState() {
		return state==null?" ":state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPinCode() {
		return pinCode==null?" ":pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getPostOffice() {
		return postOffice==null?" ":postOffice;
	}
	public void setPostOffice(String postOffice) {
		this.postOffice = postOffice;
	}
	public byte[] getCustPhoto() {
		return (byte[]) (custPhoto==null?" ":custPhoto);
	}
	public void setCustPhoto(byte[] custPhoto) {
		this.custPhoto = custPhoto;
	}

}
