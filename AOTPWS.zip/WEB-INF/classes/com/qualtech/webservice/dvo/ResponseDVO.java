package com.qualtech.webservice.dvo;


import java.util.Map;

public class ResponseDVO {
	
	
	
	private String status;
	private String statusMsg;
	private String responseXML;
	private String exception;
	
	private String errCode;
	private String errDesc;
	private byte[] tiffByte;
	private KYCDetailsDVO customerDetail;
	
	
	
	public KYCDetailsDVO getCustomerDetail() {
		return customerDetail;
	}
	public void setCustomerDetail(KYCDetailsDVO customerDetail) {
		this.customerDetail = customerDetail;
	}
	public byte[] getTiffByte() {
		return tiffByte;
	}
	public void setTiffByte(byte[] tiffByte) {
		this.tiffByte = tiffByte;
	}
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getErrDesc() {
		return errDesc;
	}
	public void setErrDesc(String errDesc) {
		this.errDesc = errDesc;
	}
	public String getException() {
		return exception;
	}
	public void setException(String exception) {
		this.exception = exception;
	}
	public String getResponseXML() {
		return responseXML;
	}
	public void setResponseXML(String responseXML) {
		this.responseXML = responseXML;
	}
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatusMsg() {
		return statusMsg;
	}
	public void setStatusMsg(String statusMsg) {
		this.statusMsg = statusMsg;
	}
	

}
