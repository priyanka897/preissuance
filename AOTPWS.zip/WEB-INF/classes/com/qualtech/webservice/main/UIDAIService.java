package com.qualtech.webservice.main;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;

import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceRequest;
import com.qualtech.webservice.AadhaarVerification.AadhaarVerificationServiceResponse;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.service.RequestTypeValidator;


public class UIDAIService {
	
	private static Logger _ologger = Logger.getLogger(UIDAIService.class.getName());
	public static String aadharNo;
	@SuppressWarnings("unchecked")
	public AadhaarVerificationServiceResponse getAadharDetails(AadhaarVerificationServiceRequest aSerReq)
	{
		_ologger.debug("<<<<<<<   START   >>>>>>>>>");
		
		AadhaarVerificationServiceResponse aVerServResp=new AadhaarVerificationServiceResponse();
		RequestTypeValidator reqVal = new RequestTypeValidator();
		
		InputRequestDVO reqDVO =new InputRequestDVO();
	try{
		NDC.push("getAadharDetails : "+System.currentTimeMillis());
		reqDVO.setAadharNo(aSerReq.getAadhaarNumber());
		aadharNo=aSerReq.getAadhaarNumber();
		reqDVO.setCustomerDOB(aSerReq.getCustomerDOB());
		reqDVO.setCustomerGender(aSerReq.getCustomerGender());
		reqDVO.setCustomerName(aSerReq.getCustomerName());
		reqDVO.setDataMatchRequired(aSerReq.getDataMatchRequired());
		reqDVO.setOtp(aSerReq.getOtp());
		reqDVO.setOtpRecieveType(aSerReq.getOtpRecieveType());
		reqDVO.setPassword(aSerReq.getPassword());
		reqDVO.setSystemID(aSerReq.getSystemID());
		reqDVO.setProposalNumber1(aSerReq.getProposalNumber1());
		reqDVO.setProposalNumber2(aSerReq.getProposalNumber2());
		reqDVO.setReqType(aSerReq.getRequestType());
		//reqDVO.setFingerPrint(aSerReq.getParam1());     //////  FingerPrint()
		//reqDVO.setFingerPosition(aSerReq.getParam2());   //    FingerPosition()
		reqDVO.setLr("Y");
		reqDVO.setMec("Y");
		reqDVO.setRc("Y");
		
		List propNumList =new ArrayList();
		if(aSerReq.getProposalNumber1()!=null && !aSerReq.getProposalNumber1().equals(""))
				propNumList.add(aSerReq.getProposalNumber1());

		if(aSerReq.getProposalNumber2()!=null && !aSerReq.getProposalNumber2().equals(""))
			propNumList.add(aSerReq.getProposalNumber2());
		
		reqDVO.setPropNumList(propNumList);
		
		
		reqDVO.setReqParam1(aSerReq.getCustomerName()+"~"+aSerReq.getCustomerDOB()+"~"+aSerReq.getCustomerGender()
				+"~"+aSerReq.getProposalNumber1()+"~"+aSerReq.getProposalNumber2()+"~"+aSerReq.getDataMatchRequired());
		
		
		aVerServResp  = reqVal.validateRequest(reqDVO);
		
		_ologger.debug("<<<<<<<   END   >>>>>>>>>");
	}catch(Exception ex)
	{
		_ologger.debug(ex);
	}finally{
		NDC.pop();
	}
		
		return aVerServResp;
	}
}