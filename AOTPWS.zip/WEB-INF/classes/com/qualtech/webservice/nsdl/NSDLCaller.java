package com.qualtech.webservice.nsdl;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Authenticator;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.security.cert.X509Certificate;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.service.EmailSenderAction;

public class NSDLCaller {
	
	private static Logger _ologger = Logger.getLogger(NSDLCaller.class.getName());
/*
	public static void main(String[] args) throws IOException, AppBaseException {
		
		String asaUrl="https://59.163.223.221/TIN/KSA";
		String inputXml="";
		String  responseXML ="";
		
		//FileReader fr= new FileReader("D:\\aa\\kycreq.txt");
		FileReader fr= new FileReader("D:\\aa\\otpreq.txt");
		BufferedReader br = new BufferedReader(fr); 
		String s; 
		while((s = br.readLine()) != null) { 
			inputXml =inputXml + s;
		} 
		fr.close(); 
		
		try {
			responseXML = new NSDLCaller().getResponseFromHttps(inputXml);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("responseXML "+responseXML);
	}*/
	
	
	public String getResponseFromHttps(String xml) throws Exception
	{
		
		//NSDLPropertyUtil propUtil = new NSDLPropertyUtil();
		//PropertyResourceBundle bundle= NSDLPropertyUtil.getInstance().getNDSLProp();	
		
		ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
		EmailSenderAction mailAction  =new EmailSenderAction();
		
		_ologger.debug("in getResponseFromHttps ");
		
		String strCallUrl = bundle.getString(IApplicationConstants.URL);
		String strProxy = bundle.getString(IApplicationConstants.PROXYIP);
		String strPort = bundle.getString(IApplicationConstants.PROXYPORT);
		String strPUname =  bundle.getString(IApplicationConstants.PROXYUSERID);
		String strPPwd =   bundle.getString(IApplicationConstants.PROXYUSERPWD);
		
		SSLContext sslcontext = null;
		String  responseXML ="";
		String proxy="";
		String port="";
		String username="";
		String password="";
		
		String urlParameters="eXml=";
		try
		{
			urlParameters =urlParameters + URLEncoder.encode(xml, "UTF-8");
		}
		catch(Exception e)
		{
			System.out.println("exception in url encoding response "+e);
			throw new Exception("exception in url encoding response "+e,new Throwable());
			
		}
		try{
			//SSLSocketFactory factory = sslcontext.getSocketFactory();
			
			URL url;
			HttpsURLConnection connection;
			InputStream is = null;

			
			proxy = strProxy;
			port = strPort;
			username = strPUname;
			password = strPPwd;
			
			Authenticator.setDefault(new SimpleAuthenticator(username,
			password));
			

			String ip=strCallUrl;
			url = new URL(ip);
			_ologger.debug("Calling URL "+ip);
			
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						return null;
					}
					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}
			};

			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};

			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			
			Properties systemProperties = System.getProperties();
	//		systemProperties.setProperty("https.proxyHost", proxy);
	//		systemProperties.setProperty("https.proxyPort", port);
			
			//Proxy proxy1 = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			
			
			connection = (HttpsURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");
			connection.setUseCaches (false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			//connection.setSSLSocketFactory(factory);
			
			
			
//				HostnameVerifier hv = new HostnameVerifier() {
//				public boolean verify(String urlHostName, SSLSession session) {
//					_ologger.debug("Warning: URL Host: "+urlHostName+" vs. "+session.getPeerHost());
//				return true;
//				}
//				};
//			
//			//connection.setHostnameVerifier(new DummyHostnameVerifier());
//				connection.setHostnameVerifier(hv);
			
			
			OutputStream os = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			osw.write(urlParameters);
			osw.flush();
			osw.close();
			is =connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			
			String strTemp;
		    while ((strTemp = in.readLine()) != null) 
		    {
		    	responseXML = responseXML + strTemp;
		    	
		    }
		    
			is.close();
			in.close();
		}
		catch(ConnectException e){
		//	e.printStackTrace();
		//	mailAction.sendEmail();
			
			_ologger.error("Connection exception in getting response "+e,new Throwable());
			//throw new Exception("Connection exception in  getting response");
		}
		catch(Exception e)
		{
		//	e.printStackTrace();
		//	mailAction.sendEmail();
			
			_ologger.error("Exception in making request"+e,new Throwable());
			//throw new AppBaseException("Exception in getting response",e);
		}
		
		_ologger.debug("In getResponseFromHttps method of ConnectHttps :::"+responseXML);
		return responseXML;
	}
	
	
}


