package com.qualtech.webservice.exception;

import org.apache.log4j.Logger;


/**
 * @author Dhananjay Singh 
 * @version :
 * 
 * AppBaseException is Application level base exception.
 */
public class AppBaseException extends Exception {

	private static Logger _olooger = Logger.getLogger(AppBaseException.class.getName());
	/* Serial Version Unique ID	 */
	private static final long serialVersionUID = -3818495307874681244L;

	private int errorCode;

	private String initialMsg;

	private String additionalMsg;

	private Exception initialException;

	/**
	 * BasicException constructor
	 */
	public AppBaseException() {
		super();
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_intErrorCode
	 */
	public AppBaseException(int a_intErrorCode) {
		errorCode = a_intErrorCode;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_oInitialException
	 */
	public AppBaseException(Exception a_oInitialException) {
		initialException = a_oInitialException;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_intErrorCode
	 * @param a_oInitialException
	 */
	public AppBaseException(int a_intErrorCode, Exception a_oInitialException) {
		errorCode = a_intErrorCode;
		initialException = a_oInitialException;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_intErrorCode
	 * @param a_oInitialException
	 * @param a_strInitialMsg
	 */
	public AppBaseException(int a_intErrorCode,
			Exception a_oInitialException, String a_strInitialMsg) {
		errorCode = a_intErrorCode;
		initialException = a_oInitialException;
		initialMsg = a_strInitialMsg;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_strAdditionalMsg
	 * @param a_oInitialException
	 */
	public AppBaseException(String a_strAdditionalMsg,
			Exception a_oInitialException) {
		additionalMsg = a_strAdditionalMsg;
		initialException = a_oInitialException;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_strInitialMsg
	 */
	public AppBaseException(String a_strInitialMsg) {
		initialMsg = a_strInitialMsg;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_strAdditionalMsg
	 * @param a_strInitialMsg
	 */
	public AppBaseException(String a_strAdditionalMsg, String a_strInitialMsg) {
		this.additionalMsg = a_strAdditionalMsg;
		this.initialMsg = a_strInitialMsg;
	}

	/**
	 * PortalBusinessException constructor
	 * 
	 * @param a_intErrorCode
	 * @param a_strInitialMsg
	 */
	public AppBaseException(int a_intErrorCode, String a_strInitialMsg) {
		errorCode = a_intErrorCode;
		initialMsg = a_strInitialMsg;
	}

	/**
	 * 
	 * @return additionalMsg
	 */
	public String getAdditionalMsg() {
		return additionalMsg;
	}

	/**
	 * 
	 * @return errorCode
	 */
	public int getErrorCode() {
		return errorCode;
	}

	/**
	 * 
	 * @return initialException
	 */
	public Exception getInitialException() {
		return initialException;
	}

	/**
	 * 
	 * @return initialMsg
	 */
	public String getInitialMsg() {
		return initialMsg;
	}

	/**
	 * Retrieves (recursively) the root cause exception.
	 * 
	 * @return the root cause exception.
	 */
	public Exception getRootCause() {
		if (initialException instanceof AppBaseException) {
			return ((AppBaseException) initialException).getRootCause();
		}
		return initialException == null ? this : initialException;
	}

	/**
	 * 
	 * @return exception.toString()
	 */
	public String toString() {
		if (initialException instanceof AppBaseException) {
			return ((AppBaseException) initialException).toString();
		}
		return initialException == null ? super.toString() : initialException
				.toString();
	}

}
