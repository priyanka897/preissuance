package com.qualtech.webservice.db;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.sql.BLOB;
import oracle.sql.CLOB;

import org.apache.log4j.Logger;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.dvo.ResponseDVO;

public class AadharDAO_BKP 
{	
	private static Logger _ologger = Logger.getLogger(AadharDAO_BKP.class.getName());
	
	@SuppressWarnings("unchecked")
	public InputRequestDVO auditInputRequest(InputRequestDVO _objInputDTO) 
	{		
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String inputQuery="";
		String seqQuery="";
		int insertStatus=0;
		Long seqNo=0L;		
		try 
		{
			_objConn=DBHelper.getInstance().getSourceConnection();
			if(_objConn!=null)
			{
				//_objConn.setAutoCommit(false);
				try
				{
					seqQuery = SQLRepository.SEQ_WS_QUERY;
					System.out.println("seqQuery "+seqQuery);				
					_pstmt=_objConn.prepareStatement(seqQuery);
					_rset = _pstmt.executeQuery();				
					while(_rset.next())
					{
						seqNo = _rset.getLong(1);
					}
					_objInputDTO.setSeqNo(seqNo);
					_objConn.commit();
					if(_pstmt!=null)
					{
						_pstmt.close();
					}
				}
				catch(Exception e)
				{
					_ologger.error("Error while getting sequence values:-"+e,new Throwable());
				}
			}
			_objConn=DBHelper.getInstance().getSourceConnection();
			if(_objConn!=null)
			{
				_objConn.setAutoCommit(false);
				try
				{
					inputQuery = SQLRepository.INPUT_INSERT_QUERY;
					System.out.println("inputQuery "+inputQuery);
					_pstmt=_objConn.prepareStatement(inputQuery);
					_pstmt.setLong(1, _objInputDTO.getSeqNo());
					_pstmt.setString(2, _objInputDTO.getSystemID());
					_pstmt.setString(3, _objInputDTO.getPassword());
					_pstmt.setString(4, _objInputDTO.getReqType());
					_pstmt.setString(5, _objInputDTO.getAadharNo());
					_pstmt.setString(6, _objInputDTO.getOtp());
					_pstmt.setClob(7,oracle.sql.CLOB.empty_lob());
					insertStatus = _pstmt.executeUpdate();							
					if(insertStatus>0)
					_ologger.info("input request record inserted successfully");
					else
						_ologger.info("input request record not inserted");
					_objConn.commit();
					if(_pstmt!=null)
					_pstmt.close();			
					_ologger.info("going to update clobs");		
				}
				catch(Exception e)
				{
					_ologger.error("Error while UPDATING VALUES values:-"+e,new Throwable());
				}
			}
			_objConn=DBHelper.getInstance().getSourceConnection();
			if(_objConn!=null)
			{
				_objConn.setAutoCommit(false);			
				try
				{
					String selClobQuery=SQLRepository.SELECT_CLOB_QUERY;
					//_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
					_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					_pstmt.setLong(1, seqNo);
					_rset = _pstmt.executeQuery();	
					
					ArrayList list = new ArrayList();
					list.add(0,"REQ_PARAM_1");
					ArrayList dlist = new ArrayList();
					dlist.add(0,_objInputDTO.getReqParam1());
					//if(_rset!=null)
					if(_rset.next())
					{
						for(int i=0;i<list.size();i++)
						{
							int count=0;
			    		    /*Clob []clob=new java.sql.Clob[_rset.getMetaData().getColumnCount()];
			    		    if(_rset.next())
			    		    {
				    		    while(count<clob.length && _rset!=null)
				    		    { 
				    				clob[count] = _rset.getClob((String) list.get(i));	    				
				    				clob[count].setString(1,dlist.get(i).toString());
				    				_pstmt.setObject(count+1,clob[count]);
				    				count++;
				    		    }
				    		    _rset.updateRow();
			    		    }*/
							
							oracle.sql.CLOB  clobnew =  (CLOB) _rset.getClob((String) list.get(i));
			
						    byte[] bytes = dlist.get(i).toString().getBytes();
						    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
						    InputStreamReader isr = new InputStreamReader(bais);
						    PrintWriter pw = new PrintWriter(clobnew.getCharacterOutputStream() );
			
						    BufferedReader br = new BufferedReader(isr);
						    String  lineIn = null;
						    while( ( lineIn = br.readLine() ) != null )
						      pw.println( lineIn );
						      pw.close();
						      br.close();
						}
					}
					_objConn.setAutoCommit(true);
					_objConn.commit();				
					_rset.close();
					_pstmt.close();		
				}
				catch(Exception e)
				{
					_ologger.error("Error while clob values:-"+e,new Throwable());
				}
			}
			_rset.close();
			_pstmt.close(); 
			_ologger.info("clobs updated successfully");				
		} 
		catch (Exception ioe)
		{
			ioe.printStackTrace();
			_ologger.error("IOException in inserting input request "+ioe,new Throwable());
		}		
		finally
		{
			try
			{
				System.out.println("Trying to close Resources DBConnection in autit  inp request Method:- ");     
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				System.out.println("Successfully closed Resources DBConnection in autit inp request  Method:- ");
			}
			catch(Exception e)
			{				
				_ologger.error("Exception while closing resources DBConnection in autit  inp request  Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
		return _objInputDTO;
	}
	
	public boolean authenticateUser(InputRequestDVO _objInputDTO) 
	{
		
		PreparedStatement _pstmt=null;
		ResultSet _rsltSet=null;
		Connection _objConn=null;
		String authUserQuery="";
		int authCount=0;
		boolean authStatus=false;		
		try 
		{
			_objConn=DBHelper.getInstance().getSourceConnection();			
			if(_objConn!=null)
			{	
				authUserQuery = SQLRepository.AUTHENTICATE_USER_QUERY;
				_pstmt=_objConn.prepareStatement(authUserQuery);
				_pstmt.setString(1, _objInputDTO.getSystemID());
				_pstmt.setString(2, _objInputDTO.getPassword());
				
				_rsltSet=_pstmt.executeQuery();
				
				while(_rsltSet.next())
				{
					authCount =_rsltSet.getInt(1);
				}
				
				if(authCount>0)
				{
					_ologger.info("User "+_objInputDTO.getSystemID()+" Authenticted");
					authStatus = true;
				}
				else
				{
					_ologger.info("User "+_objInputDTO.getSystemID()+" Not Authenticted");
				}
			}
		} 
		catch (Exception e)
		{
			_ologger.error("Exception while authencating user"+ e,new Throwable());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				_ologger.debug("Trying to close Resources DBConnection in user authentication:- ");     
				if(_rsltSet!=null)
				{
					_rsltSet.close();
					_rsltSet=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.debug("Successfully closed Resources DBConnection in user authentication Method:- ");
			}
			catch(Exception e)
			{		
				e.printStackTrace();	
				_ologger.error("Exception while closing resources DBConnection in user authentication: Method: "+e,new Throwable());
			}
        }
		return authStatus;
	}
	
	public void updateFailStatus(InputRequestDVO _inpDTO,String failMsg)
	{
		PreparedStatement _pstmt=null;
		Connection _objConn=null;
		String updateQuery="";
		int updateCount=0;
		try 
		{
			_objConn=DBHelper.getInstance().getSourceConnection();
			if(_objConn!=null)
			{	
				updateQuery = SQLRepository.UPDATE_FAIL_QUERY;
				_pstmt=_objConn.prepareStatement(updateQuery);
				_pstmt.setString(1, failMsg);
				_pstmt.setLong(2, _inpDTO.getSeqNo());				
				updateCount=_pstmt.executeUpdate();
				if(updateCount>0)
				{
					_ologger.info("ststus updated in DB for authentication fail");
				}	
			}	
		} 
		catch (Exception e)
		{
			_ologger.error("Exception in status updated in DB for update fail status "+e,new Throwable());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				System.out.println("Trying to close Resources DBConnection in DB for update fail status - ");
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				System.out.println("Successfully closed Resources DBConnection in DB for update fail status Method:- ");
			}
			catch(Exception e)
			{			e.printStackTrace();	
				_ologger.error("Exception while closing resources DBConnection in update fail status Method: "+e,new Throwable());
			}
        }		
	}	
	
	@SuppressWarnings("unchecked")
	public InputRequestDVO inputUIDAudit(InputRequestDVO _objInputDTO) 
	{		
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String inputQuery="";
		String seqQuery="";
		int insertStatus=0;
		Long seqNo=0L;		
		try 
		{
			_objConn=DBHelper.getInstance().getSourceConnection();
			if(_objConn!=null)
			{	
				_objConn.setAutoCommit(false);
				seqQuery = SQLRepository.SEQ_UID_QUERY;
				System.out.println("uid seqQuery::: "+seqQuery);
				_pstmt=_objConn.prepareStatement(seqQuery);
				_rset = _pstmt.executeQuery();
				while(_rset.next())
				{
					seqNo = _rset.getLong(1);
				}
				_objInputDTO.setUidSeqNo(seqNo);
				_objConn.commit();
				if(_pstmt!=null)
					_pstmt.close();				
				inputQuery = SQLRepository.NSDL_INSERT_QUERY;
				System.out.println("xml request query ::::"+inputQuery);
				_pstmt=_objConn.prepareStatement(inputQuery);
				_pstmt.setLong(1, _objInputDTO.getUidSeqNo());
				_pstmt.setString(2, _objInputDTO.getSystemID());
				_pstmt.setString(3, _objInputDTO.getPassword());
				_pstmt.setString(4, _objInputDTO.getReqType());
				_pstmt.setString(5, _objInputDTO.getAadharNo());
				_pstmt.setString(6, _objInputDTO.getOtp());
				_pstmt.setClob(7, oracle.sql.CLOB.empty_lob());	
				_pstmt.setClob(8, oracle.sql.CLOB.empty_lob());	
				_pstmt.setLong(9, _objInputDTO.getSeqNo());
				insertStatus = _pstmt.executeUpdate();
			}
			if(insertStatus>0)
			_ologger.info("uid request record inserted");
			else
				_ologger.info("uid request record not inserted");
			
			if(_pstmt!=null)
				_pstmt.close();
				if(_rset!=null)
					_rset.close();
				_ologger.info("going to update xml request clobs");
				_objConn.setAutoCommit(false);
				String selClobQuery=SQLRepository.SELECT_UID_CLOB_QUERY;
				_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				_pstmt.setLong(1, seqNo);
				_rset = _pstmt.executeQuery();
				ArrayList list = new ArrayList();
				list.add(0,"REQ_DATA");
				list.add(0,"EXCEPTION");
				ArrayList dlist = new ArrayList();
				dlist.add(0,_objInputDTO.getRequestXML());
				dlist.add(0,"");
				if(_rset.next())
				{
					for(int i=0;i<list.size();i++)
					{
					oracle.sql.CLOB  clobnew =  (CLOB) _rset.getClob((String) list.get(i));

				    byte[] bytes = dlist.get(i).toString().getBytes();
				    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
				    InputStreamReader isr = new InputStreamReader(bais);
				    PrintWriter pw = new PrintWriter(clobnew.getCharacterOutputStream() );

				    BufferedReader br = new BufferedReader(isr);
				    String  lineIn = null;
				    while( ( lineIn = br.readLine() ) != null )
				      pw.println( lineIn );
				      pw.close();
				      br.close();
					}
				}				
				_objConn.setAutoCommit(true);
				_objConn.commit();				
				_rset.close();
				_pstmt.close();				
				_ologger.info("xml request clobs updated successfully");			
		} 
		catch (IOException e)
		{
			e.printStackTrace();
			_ologger.error("IOException in inserting/updaing xml request "+e,new Throwable());
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			_ologger.error("SQLException in inserting/updaing xml request "+e,new Throwable());
		}
		catch (Exception e)
		{
			e.printStackTrace();
			_ologger.error("Exception in inserting/updaing xml request "+e,new Throwable());
		}		
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in DB for inserting xml request - ");    				
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in DB for inserting xml request- ");
			}
			catch(Exception e)
			{		
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in inserting xml request "+e,new Throwable());
			}
        }		
		return _objInputDTO;
	}	
	
	public String getErrorDescMsg(String errorCode , String reqType)
	{		
		PreparedStatement _pstmt=null;
		ResultSet _rsltSet=null;
		Connection _objConn=null;
		String errorMsgQuery="";
		String statusMsg="";
		_ologger.info("errorCode "+errorCode);
		_ologger.info("reqType "+reqType);		
		try 
		{
			_objConn=DBHelper.getInstance().getSourceConnection();			
			if(_objConn!=null)
			{	
				errorMsgQuery = SQLRepository.ERROR_CODE_QUERY;
				_pstmt=_objConn.prepareStatement(errorMsgQuery);
				_pstmt.setString(1, errorCode);
				_pstmt.setString(2, reqType);				
				_rsltSet=_pstmt.executeQuery();				
				while(_rsltSet.next())
				{
					statusMsg =_rsltSet.getString(1);
				}				
				_ologger.info("statusMsg "+statusMsg);				
				if(statusMsg==null || statusMsg.equals(""))
				{
					statusMsg = IApplicationConstants.NO_ERROR_DESC;
				}
			}					
		} 
		catch (Exception e)
		{
			e.printStackTrace();
			_ologger.error("Exception while getting error code msg"+ e,new Throwable());
		}
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in getting error code msg ");     
				if(_rsltSet!=null)
				{
					_rsltSet.close();
					_rsltSet=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in getting error code msg ");
			}
			catch(Exception e)
			{		
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in getting error code msg "+e,new Throwable());
			}
        }
		return statusMsg;
	}	
	
	@SuppressWarnings("unchecked")
	public boolean saveTiffInDB(InputRequestDVO _inpDTO , ResponseDVO _resDTO)
	{
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String insertTifQuery="";
		String tiffName="";
		int updateCount=0;
		boolean stat =false;
		
		_ologger.info("inserting tiff in DB");
		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{	
				String firstPropNum ="";
				 List propList =  _inpDTO.getPropNumList();
				if(propList.size()>0)
				{
					firstPropNum = (String)propList.get(0);
				}
				
				tiffName = _inpDTO.getAadharNo()+"_"+firstPropNum+".tif";
				
				insertTifQuery = SQLRepository.INSERT_TIFF_QUERY;
				_pstmt=_objConn.prepareStatement(insertTifQuery);
				
				_pstmt.setBlob(1, oracle.sql.BLOB.empty_lob());
				_pstmt.setString(2, tiffName);
				_pstmt.setString(3, firstPropNum);
				_pstmt.setLong(4, _inpDTO.getUidSeqNo());
				_pstmt.setLong(5, _inpDTO.getSeqNo());
				
				
				updateCount =_pstmt.executeUpdate();
				
				if(updateCount>0)
				{
					_ologger.info("blank tiff inserted in DB");
				}
				
				if(_pstmt!=null)
					_pstmt.close();
					if(_rset!=null)
						_rset.close();
					
					_ologger.info("going to update tiff clob");
					
					_objConn.setAutoCommit(false);
					
					String selClobQuery=SQLRepository.SELECT_TIFF_CLOB_QUERY;
					_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					_pstmt.setLong(1, _inpDTO.getUidSeqNo());
					_rset = _pstmt.executeQuery();
					
					
					ArrayList list = new ArrayList();
					//list.add(0,"TIFF_DATA");
					list.add(0,"PDF_DATA");
					
					ArrayList dlist = new ArrayList();
					dlist.add(0,_resDTO.getTiffByte());
					
					if(_rset.next())
					{
						for(int i=0;i<list.size();i++)
						{
						oracle.sql.BLOB  clobnew =  (BLOB) _rset.getBlob((String) list.get(i));

					    byte[] bytes = (byte[]) dlist.get(i);
					    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
					    InputStreamReader isr = new InputStreamReader(bais);
					    PrintWriter pw = new PrintWriter(clobnew.getBinaryOutputStream() );

					    BufferedReader br = new BufferedReader(isr);
					    String  lineIn = null;
					    while( ( lineIn = br.readLine() ) != null )
					      pw.println( lineIn );
					      pw.close();
					      br.close();
						}
					}
					stat = true;
					_objConn.setAutoCommit(true);
					_objConn.commit();
					
					_rset.close();
					_pstmt.close(); 
						_ologger.info("tiff clob updated successfully");
				
			}	
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			_ologger.error("SQLException tiff response clobs updation  "+e,new Throwable());
		}
		 catch (IOException e) {
			 e.printStackTrace();
			 _ologger.error("IOException tiff response clobs updation "+e,new Throwable());
		}
		 catch (Exception e) {
			 e.printStackTrace();
			 _ologger.error("Exception tiff response clobs updation "+e,new Throwable());
		}		
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in tiff update ");     
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in tiff update  ");
			}
			catch(Exception e)
			{				
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in tiff update  "+e,new Throwable());
			}
        }
		return stat;
	}
	@SuppressWarnings("unchecked")
	public boolean savePdfInDB(InputRequestDVO _inpDTO , ResponseDVO _resDTO)
	{
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String insertTifQuery="";
		String tiffName="";
		int updateCount=0;
		boolean stat =false;
		
		_ologger.info("inserting pdf in DB");
		System.out.println("inserting pdf in DB");
		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{	
				String firstPropNum ="";
				 List propList =  _inpDTO.getPropNumList();
				if(propList.size()>0)
				{
					firstPropNum = (String)propList.get(0);
				}
				
				tiffName = _inpDTO.getAadharNo()+"_"+firstPropNum+".pdf";
				
				insertTifQuery = SQLRepository.INSERT_TIFF_QUERY;
				_pstmt=_objConn.prepareStatement(insertTifQuery);
				
				_pstmt.setBlob(1, oracle.sql.BLOB.empty_lob());
				_pstmt.setString(2, tiffName);
				_pstmt.setString(3, firstPropNum);
				_pstmt.setLong(4, _inpDTO.getUidSeqNo());
				_pstmt.setLong(5, _inpDTO.getSeqNo());
				
				
				updateCount =_pstmt.executeUpdate();
				
				if(updateCount>0)
				{
					_ologger.info("blank pdf inserted in DB");
					System.out.println("blank pdf inserted in DB");
				}
				
				if(_pstmt!=null)
					_pstmt.close();
					if(_rset!=null)
						_rset.close();
					
					_ologger.info("going to update pdf blob");
					System.out.println("going to update pdf blob");
					
					_objConn.setAutoCommit(false);
					
					String selClobQuery=SQLRepository.SELECT_TIFF_CLOB_QUERY;
					_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					_pstmt.setLong(1, _inpDTO.getUidSeqNo());
					_rset = _pstmt.executeQuery();
					
					
					ArrayList list = new ArrayList();
					list.add(0,"PDF_DATA");
					
					ArrayList dlist = new ArrayList();
					dlist.add(0,_resDTO.getTiffByte());
					
					if(_rset.next())
					{
						for(int i=0;i<list.size();i++)
						{
						oracle.sql.BLOB  clobnew =  (BLOB) _rset.getBlob((String) list.get(i));

					    byte[] bytes = (byte[]) dlist.get(i);
					    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
					    InputStreamReader isr = new InputStreamReader(bais);
					    PrintWriter pw = new PrintWriter(clobnew.getBinaryOutputStream());

					    BufferedReader br = new BufferedReader(isr);
					    String  lineIn = null;
					    while( ( lineIn = br.readLine() ) != null )
					      pw.println( lineIn );
					      pw.close();
					      br.close();
						}
					}
					stat = true;
					_objConn.setAutoCommit(true);
					_objConn.commit();
					
					_rset.close();
					_pstmt.close(); 
						_ologger.info("pdf clob updated successfully");
						System.out.println("pdf clob updated successfully");
				
			}	
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			_ologger.error("SQLException tiff response clobs updation  "+e,new Throwable());
			System.out.println("pdf clob updated successfully"+e.getMessage());
		}
		 catch (IOException e) {
			 e.printStackTrace();
			 System.out.println("IOException tiff response blobs updation "+e.getMessage());
			 _ologger.error("IOException tiff response blobs updation "+e.getMessage(),new Throwable());
		}
		 catch (Exception e) {
			 e.printStackTrace();
			 System.out.println("Exception pdf response blobs updation "+e.getMessage());
			 _ologger.error("Exception pdf response blobs updation "+e,new Throwable());
		}
		
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in pdf update ");  
				System.out.println("Successfully closed Resources DBConnection in pdf update   ");
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in pdf update  ");
				System.out.println("Successfully closed Resources DBConnection in pdf update  ");
			}
			catch(Exception e)
			{				
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in pdf update  "+e,new Throwable());
				System.out.println("Exception while closing resources DBConnection in pdf update "+e.getMessage());
			}
        }
		return stat;
	}
	
	@SuppressWarnings("unchecked")
	public boolean saveTiffReplicaFor2ndProposal(InputRequestDVO _inpDTO , ResponseDVO _resDTO)
	{
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String seqQuery="";
		String insertTiffQuery="";
		int updateCount=0;
		boolean stat =false;
		String tiffName="";
		Long seqNo=0L;
		
		_ologger.info("inserting 2nd tiff in DB");
		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{					
				List propList = _inpDTO.getPropNumList();
				String propNum2[] =((String)propList.get(1)).split("~");
				int i=0;
				while(i<propNum2.length)
				{
					tiffName = _inpDTO.getAadharNo()+"_"+propNum2[i]+".tif";
					
					seqQuery = SQLRepository.SEQ_UID_QUERY;
					_ologger.info("uid seqQuery::: "+seqQuery);
					
					_pstmt=_objConn.prepareStatement(seqQuery);
					_rset = _pstmt.executeQuery();
					
					while(_rset.next())
					{
						seqNo = _rset.getLong(1);
					}
					if(_pstmt!=null)_pstmt.close();
					
					
					insertTiffQuery ="Insert Into Av_Ad_Uid_Mst Select '"+seqNo+"' , T.* From ( "+
						" Select Ref_Id ,Req_Type,Aadhar_No,System_Id,Password,Req_Time,Otp,Req_Param_1,Req_Param_2,Req_Param_3, "+
						" Status,Status_Msg,Req_Data,Res_Param_1,Res_Param_2,Res_Param_3,Res_Data,Tiff_Data,Error_Code,Error_Desc, "+
						" Res_Time,Exception,'"+tiffName+"',REQ_DATE ,'"+propNum2[i]+"' From Av_Ad_Uid_Mst Where Ref_Id='"+_inpDTO.getSeqNo()+"' "+
						" )t ";
					
					_pstmt = _objConn.prepareStatement(insertTiffQuery);
					updateCount = _pstmt.executeUpdate();
					if(updateCount>0)stat =true;
					_ologger.info("2nd tiff inserted in db");
				}
			}	
		} 
		
		catch (Exception e) {
			e.printStackTrace();
			 _ologger.error("Exception tiff response clobs updation "+e,new Throwable());
		
		}
		
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in 2nd tiff update ");     
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in 2nd tiff update  ");
			}
			catch(Exception e)
			{				
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in 2nd tiff update  "+e,new Throwable());
			}
        }
		return stat;
	}
	
	
	@SuppressWarnings("unchecked")
	public boolean savePdfReplicaFor2ndProposal(InputRequestDVO _inpDTO , ResponseDVO _resDTO)
	{
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String seqQuery="";
		String insertTiffQuery="";
		int updateCount=0;
		boolean stat =false;
		String tiffName="";
		Long seqNo=0L;
		
		_ologger.info("inserting 2nd pdf in DB");
		System.out.println("inserting 2nd pdf in DB");
		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{					
				List propList = _inpDTO.getPropNumList();
				String propNum2[] =((String)propList.get(1)).split("~");
				int i=0;
				while(i<propNum2.length)
				{
					tiffName = _inpDTO.getAadharNo()+"_"+propNum2[i]+".pdf";
				
					seqQuery = SQLRepository.SEQ_UID_QUERY;
					_ologger.info("uid seqQuery::: "+seqQuery);
					System.out.println("uid seqQuery::: "+seqQuery);
					
					_pstmt=_objConn.prepareStatement(seqQuery);
					_rset = _pstmt.executeQuery();
					
					while(_rset.next())
					{
						seqNo = _rset.getLong(1);
					}
					if(_pstmt!=null)_pstmt.close();
					
					
					insertTiffQuery ="Insert Into Av_Ad_Uid_Mst Select '"+seqNo+"' , T.* From ( "+
						" Select Ref_Id ,Req_Type,Aadhar_No,System_Id,Password,Req_Time,Otp,Req_Param_1,Req_Param_2,Req_Param_3, "+
						" Status,Status_Msg,Req_Data,Res_Param_1,Res_Param_2,Res_Param_3,Res_Data,tiff_Data,Error_Code,Error_Desc, "+
						" Res_Time,Exception,'"+tiffName+"',REQ_DATE ,'"+propNum2[i]+"',pdf_Data From Av_Ad_Uid_Mst Where Ref_Id='"+_inpDTO.getSeqNo()+"' "+
						" and rownum=1)t ";
					
					_pstmt = _objConn.prepareStatement(insertTiffQuery);
					updateCount = _pstmt.executeUpdate();
					if(updateCount>0)stat =true;
					_ologger.info("2nd pdf inserted in db");
					System.out.println("2nd pdf inserted in db");
					i++;
				}
			}
			
		} 
		
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Exception pdf response clobs updation "+e.getMessage());
			 _ologger.error("Exception pdf response clobs updation "+e,new Throwable());
		
		}
		
		finally
		{
			try
			{
				System.out.println("Trying to close Resources DBConnection in 2nd pdf update ");     
				_ologger.info("Trying to close Resources DBConnection in 2nd pdf update ");     
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				System.out.println("Successfully closed Resources DBConnection in 2nd pdf update  ");
				_ologger.info("Successfully closed Resources DBConnection in 2nd pdf update  ");
			}
			catch(Exception e)
			{				
				e.printStackTrace();
				
				_ologger.error("Exception while closing resources DBConnection in 2nd tiff update  "+e,new Throwable());
			}
        }
		return stat;
	}
	
	public void updateStatus(InputRequestDVO _inpDTO,ResponseDVO resDTO) 
	{
		PreparedStatement _pstmt=null;
		ResultSet _rsltSet=null;
		Connection _objConn=null;
		String updateQuery="";
		int updateCount=0;
		
		
		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{	
				updateQuery = SQLRepository.UPDATE_WS_QUERY;
				_pstmt=_objConn.prepareStatement(updateQuery);
				
				
				_pstmt.setString(1, resDTO.getStatus());
				_pstmt.setString(2, resDTO.getStatusMsg());
				_pstmt.setString(3, resDTO.getErrCode());
				_pstmt.setString(4, resDTO.getErrDesc());
				_pstmt.setLong(5, _inpDTO.getSeqNo());
				
				updateCount=_pstmt.executeUpdate();
				
				if(updateCount>0)
				{
					_ologger.info("web service master response updated in DB");
				}	
			}	
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			_ologger.error("SQLException in updating web service master rsponse in DB "+e,new Throwable());
		}
		finally
		{
			try
			{
				_ologger.info("Trying to close Resources DBConnection in update ws status ");     
				if(_rsltSet!=null)
				{
					_rsltSet.close();
					_rsltSet=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.info("Successfully closed Resources DBConnection in update ws status ");
			}
			catch(Exception e)
			{			
				e.printStackTrace();
				_ologger.error("Exception while closing resources DBConnection in update ws status "+e,new Throwable());
			}
		
	}
	
	}

	@SuppressWarnings("unchecked")
	public void updateUIDStatus(InputRequestDVO _inpDTO , ResponseDVO _resDTO) 
	{
		PreparedStatement _pstmt=null;
		ResultSet _rset=null;
		Connection _objConn=null;
		String updateQuery="";
		int updateCount=0;

		
		try {
			_objConn=DBHelper.getInstance().getSourceConnection();
			
			if(_objConn!=null)
			{	
				updateQuery = SQLRepository.UPDATE_UID_QUERY;
				_pstmt=_objConn.prepareStatement(updateQuery);
				
				
				_pstmt.setString(1, _resDTO.getStatus());
				_pstmt.setString(2, _resDTO.getStatusMsg());
				_pstmt.setClob(3, oracle.sql.CLOB.empty_lob());
				_pstmt.setString(4, _resDTO.getErrCode());
				_pstmt.setString(5, _resDTO.getErrDesc());
				_pstmt.setClob(6, oracle.sql.CLOB.empty_lob());
				//_pstmt.setLong(7, _inpDTO.getUidSeqNo());
				_pstmt.setLong(7, _inpDTO.getSeqNo());
				
				updateCount =_pstmt.executeUpdate();
				
				if(updateCount>0)
				{
					_ologger.info("NSDL response updated in DB");
				}
				
				if(_pstmt!=null)
					_pstmt.close();
					if(_rset!=null)
						_rset.close();
					
					_ologger.info("going to update response clobs");
					
					_objConn.setAutoCommit(false);
					
					String selClobQuery=SQLRepository.SELECT_UID_RES_CLOB_QUERY;
					_pstmt=_objConn.prepareStatement(selClobQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
					_pstmt.setLong(1, _inpDTO.getSeqNo());
					//_pstmt.setLong(1, _inpDTO.getUidSeqNo());
					_rset = _pstmt.executeQuery();
					
					
					ArrayList list = new ArrayList();
					list.add(0,"RES_DATA");
					list.add(1,"EXCEPTION");
					
					System.out.println("res "+_resDTO.getResponseXML());
					System.out.println("res "+_resDTO.getException());
					
					ArrayList dlist = new ArrayList();
					dlist.add(0,_resDTO.getResponseXML());
					dlist.add(1,_resDTO.getException());
					
					while(_rset.next())
					{
						for(int i=0;i<list.size();i++)
						{
						oracle.sql.CLOB  clobnew =  (CLOB) _rset.getClob((String) list.get(i));

					    byte[] bytes = dlist.get(i).toString().getBytes();
					    ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
					    InputStreamReader isr = new InputStreamReader(bais);
					    PrintWriter pw = new PrintWriter(clobnew.getCharacterOutputStream() );

					    BufferedReader br = new BufferedReader(isr);
					    String  lineIn = null;
					    while( ( lineIn = br.readLine() ) != null )
					      pw.println( lineIn );
					      pw.close();
					      br.close();
						}
					}
					_objConn.setAutoCommit(true);
					_objConn.commit();
					
					_rset.close();
					_pstmt.close(); 
						_ologger.info("nsdl response clobs updated successfully");
				
			}	
		} 
        catch (Exception e) {
			 _ologger.error("Exception nsdl response clobs updation "+e,new Throwable());
			 e.printStackTrace();	
		}		 
		finally
		{
			try
			{
				_ologger.debug("Trying to close Resources DBConnection in update uid status ");     
				if(_rset!=null)
				{
					_rset.close();
					_rset=null;
				}
				if(_pstmt!=null)
				{
					_pstmt.close();
					_pstmt=null;
				}
				if(_objConn!=null)
				{
					_objConn.close();
					_objConn=null;
				}
				_ologger.debug("Successfully closed Resources DBConnection in update uid status ");
			}
			catch(Exception e)
			{				
				_ologger.error("Exception while closing resources DBConnection in update uid status "+e,new Throwable());
				e.printStackTrace();
			}
        }
	}
}	