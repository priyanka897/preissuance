package com.qualtech.webservice.db;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;

import oracle.jdbc.driver.OracleResultSet;

import org.apache.log4j.Logger;

import com.qualtech.webservice.db.DBHelper;

public class DBConnection
{	
	static Logger logger = Logger.getLogger(DBConnection.class);
	static ResourceBundle res=ResourceBundle.getBundle("com.max.recruitmentDB.resources.ApplicationResources");
	
	public String getSeqNextValue(String seqName) throws SQLException
    {
    	logger.debug("Comes to DBConnection in getSeqNextValue Method: ");        
    	ResultSet rs=null;
    	Connection con=null;
        Statement stmt =null;
        String result=null;
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{
        		String query="SELECT "+seqName+".NEXTVAL FROM DUAL";
				logger.info("SQL query to be executed : "+query);
		        stmt = con.createStatement();	
		        stmt.setQueryTimeout(0);
		        rs=stmt.executeQuery(query);
		        if(rs.next())
		        {
		        	result=rs.getString(1);
		        }			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching next Sequence Value : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in getSeqNextValue Method:- ");     
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				logger.debug("Successfully closed Resources DBConnection in getSeqNextValue Method:- ");
			}
			catch(Exception e)
			{				
				logger.error("Exception while closing resources DBConnection in getSeqNextValue Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
        logger.debug("Getting out from DBConnection in getSeqNextValue Method : ");
        return result;
    }
	 
	public List<List<String>> getMetaData(String query)
	{        
        logger.debug("Comes to DBConnection in getMetaData Method: ");        
    	ResultSet rs=null;
    	Connection con=null;
        PreparedStatement stmt =null;
        List<List<String>> result=new ArrayList<List<String>>();    
        String message="";
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{
        		try
        		{
			        stmt = con.prepareStatement(query);		  
			        stmt.setQueryTimeout(0);
			        logger.info("SQL query to be executed : "+query);
			        rs=stmt.executeQuery();
        		}
        		catch(Exception e)
        		{
        			message=res.getString("com.max.recruitmentDB.TableNotExist");
        		}
		        if(rs!=null)
		        {
		        	ResultSetMetaData resultSetMetaData = rs.getMetaData();
			        int noOfColumns = resultSetMetaData.getColumnCount();
			        List<String> colName=new ArrayList<String>();
			        for (int i = 1; i <= noOfColumns; i++)
			        {
			        	colName=new ArrayList<String>();
			        	colName.add(resultSetMetaData.getColumnName(i));
			        	colName.add(""+resultSetMetaData.getColumnTypeName(i));
			        	colName.add(""+resultSetMetaData.getScale(i));
			        	colName.add(""+resultSetMetaData.getPrecision(i));
			        	colName.add(""+resultSetMetaData.isNullable(i));
			        	result.add(colName);
			        }			        
			        logger.info("total No of Columns fetch are:-"+noOfColumns);			       
		        }			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
				message=res.getString("com.max.recruitmentDB.DBNotConnect");
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
			message=res.getString("com.max.recruitmentDB.GetRecords");
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in getMetaData Method:- ");  
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	logger.debug("Successfully closed Resources DBConnection in getMetaData Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in getMetaData Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
		if(result!=null && result.size()==0 && !message.equalsIgnoreCase(""))
		{
	        List<String> colName=new ArrayList<String>();
	        colName.add(message);
			result.add(colName);
		}
        logger.debug("Getting out from DBConnection in getMetaData Method : ");
        return result;
    }
	
    public String executeUpdate(String query,String[] param) throws SQLException
    {
        logger.debug("Comes to DBConnection in ExecuteUpdate Method : ");
        Connection con=null;
        PreparedStatement stmt =null;
        String message="";
        int i=0;
        int count=-999;
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{
        		try
        		{
        			con.setAutoCommit(true);
        			stmt = con.prepareStatement(query);		  
        			if(param.length>0)
            		{
            			logger.info("SQL query to be executed : "+query +" with Parameters :-"+Arrays.toString(param));
        		        while(i<param.length)
        		        {
        		        	stmt.setString(i+1,param[i]);
        		        	i++;
        		        }
            		}
            		else
            		{
            			logger.info("SQL query to be executed : "+query);
            		}
            		count=stmt.executeUpdate();
            		logger.debug("After Executing query total change count is:-"+count);
        		}
        		catch(Exception e)
        		{
        			logger.error("Error while executing query:"+e,new Throwable());
        			e.printStackTrace();
        			message=e+" "+res.getString("com.max.recruitmentDB.RecordOperation");
        		}       		        		  	
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");		
				message=res.getString("com.max.recruitmentDB.DBNotConnect");
			}
		}
    	catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
			message=res.getString("com.max.recruitmentDB.GetRecords");
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in ExecuteUpdate Method:- ");   
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	logger.debug("Successfully closed Resources DBConnection in ExecuteUpdate Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteUpdate Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
		if(count!=-999)
		{
	        message=String.valueOf(count);
		}
        logger.debug("Getting out from DBConnection in ExecuteUpdate Method : ");      
        return message;
    }

    public boolean executeUpdate(String selectQuery,String optype,String param[],List<?> param1)
    {
        logger.debug("Comes to DBConnection in ExecuteUpdate Method : ");
        Connection con=null;
        PreparedStatement stmt =null;
        ResultSet rs=null;
        Clob clob[]=null;
		Blob blob[]=null;
        int count=0;
        boolean flag=false;
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{      		
        		stmt=con.prepareStatement(selectQuery,ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
        		if(param.length>0)
        		{
        			logger.info("SQL query to be executed : "+selectQuery +" with Parameters :-"+param);
    		        while(count<param.length)
    		        {
    		        	stmt.setString(count+1,param[count]);
    		        	count++;
    		        }
        		}
	    		else
	    		{
	    			logger.info("SQL query to be executed : "+selectQuery);
	    		}
	    		rs=stmt.executeQuery();	  
	        	if(optype!=null && optype.equalsIgnoreCase("clob"))
	        	{
	        		count=0;
	    		    clob=new java.sql.Clob[rs.getMetaData().getColumnCount()];
	    		    if(rs.next())
	    		    {
		    		    while(count<param1.size()&& rs!=null)
		    		    { 
		    				clob[count] = rs.getClob(count+1);	    				
		    				clob[count].setString(1,param1.get(count).toString());
		    				stmt.setObject(count+1,clob[count]);
		    				count++;
		    		    }
		    		    rs.updateRow();
	    		    }
	    	    }
	        	if(optype!=null && optype.equalsIgnoreCase("blob"))
	        	{
	        		count=0;
	        		blob=new Blob[rs.getMetaData().getColumnCount()];
	        		if(rs.next())
	    		    {
		    		    while(count<param1.size()&& rs!=null)
		    		    { 
		    				blob[count] = rs.getBlob(count+1);	
		    				blob[count].setBytes((long)count+1,(byte[])param1.get(count));		    				
		    				count++;
		    		    }
		    		    rs.updateRow();
	    		    }
	    		
	    		}
	        	//count=1;
    			con.commit();
	    		if(count>0)
	    		{
	    			flag=true;
	    		}
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in ExecuteUpdate Method:- ");
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
				clob=null;
				blob=null;
		    	logger.debug("Successfully closed Resources DBConnection in ExecuteUpdate Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteUpdate Method: "+e,new Throwable());
				e.printStackTrace();
			}
	    }
	    logger.debug("Getting out from DBConnection in ExecuteUpdate Method : ");			     
        return flag;
    }
	
	public List<List<String>> executeQuery(String query,String[] param) throws SQLException
	{        
        logger.debug("Comes to DBConnection in ExecuteQuery Method: ");        
    	ResultSet rs=null;
    	Connection con=null;
        PreparedStatement stmt =null;
        int count=0;
        List<List<String>> result=null;
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{
		        stmt = con.prepareStatement(query);		  
		        stmt.setQueryTimeout(0);
		        if(param.length>0)
        		{
        			logger.info("SQL query to be executed : "+query +" with Parameters :-"+Arrays.toString(param));
    		        while(count<param.length)
    		        {
    		        	stmt.setString(count+1,param[count]);
    		        	count++;
    		        }
        		}
        		else
        		{
        			logger.info("SQL query to be executed : "+query);
        		}
		        rs=stmt.executeQuery();
		        if(rs!=null)
		        {
		        	result=new ArrayList<List<String>>();
		        	ResultSetMetaData resultSetMetaData = rs.getMetaData();
			        int noOfColumns = resultSetMetaData.getColumnCount();
			        List<String> colName=new ArrayList<String>();
			        for (int i = 1; i <= noOfColumns; i++)
			        {
			        	colName.add(resultSetMetaData.getColumnName(i));
			        }
			        result.add(colName);
			        count=0;
			        logger.info("total No of Columns fetch are:-"+noOfColumns);
			        while(rs.next())
			        {
			        	List<String> data=new ArrayList<String>();
			        	count++;
			        	for(int i=1;i<=noOfColumns;i++)
			        	{	
			        		data.add(rs.getObject(i)!=null?rs.getObject(i).toString():"");
			        	}
			        	result.add(data);
			        }
			        logger.info("total No of Records fetch are:-"+count);
		        }			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in ExecuteQuery Method:- ");  
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	logger.debug("Successfully closed Resources DBConnection in ExecuteQuery Method:- ");  
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in ExecuteQuery Method: "+e,new Throwable());
				e.printStackTrace();
			}
        }
        logger.debug("Getting out from DBConnection in ExecuteQuery Method : ");
        return result;
    }
	
	public List<List<?>> executeDataLobQuery(String query,String[] param) throws SQLException
	{        
        logger.debug("Comes to DBConnection in ExecuteDataLobQuery Method: ");        
    	ResultSet rs=null;
    	Connection con=null;
        PreparedStatement stmt =null;
        BufferedInputStream bis=null;
		ByteArrayOutputStream baos=null;
		ResultSetMetaData resultSetMetaData=null;
    	Blob blob=null;
    	Clob clob=null;
    	int noOfColumns=0;
    	int count=0;
    	int i=0;
		int length = 0; 
    	byte[] buffer=null;
    	List<Object> data=new ArrayList<Object>();
        List<List<?>> result=new ArrayList<List<?>>();
        try
        {
        	con=DBHelper.getInstance().getSourceConnection();		
        	if(con!=null)
        	{
		        stmt = con.prepareStatement(query);
		        stmt.setQueryTimeout(0);
		        if(param.length>0)
        		{
        			logger.info("SQL query to be executed : "+query +" with Parameters :-"+Arrays.toString(param));
    		        while(count<param.length)
    		        {
    		        	stmt.setString(count+1,param[count]);
    		        	count++;
    		        }
        		}
        		else
        		{
        			logger.info("SQL query to be executed : "+query);
        		}
		        rs=stmt.executeQuery();
		        if(rs!=null)
		        {
		        	resultSetMetaData=rs.getMetaData();
			        noOfColumns = resultSetMetaData.getColumnCount();
			        List<String> colName=new ArrayList<String>();
			        for (i = 1; i <= noOfColumns; i++)
			        {
			        	colName.add(resultSetMetaData.getColumnName(i));			        	
			        }
			        result.add(colName);
			        count=0;
			        logger.info("total No of Columns fetch are:-"+noOfColumns);
			        while(rs.next())
			        {
			        	count++;
			        	for(i=1;i<=noOfColumns;i++)
			        	{	
				        	try
				        	{
				        		if(resultSetMetaData.getColumnTypeName(i)!=null && resultSetMetaData.getColumnTypeName(i).equalsIgnoreCase("BLOB"))
				        		{
				        			try
				        			{
						        		blob=((OracleResultSet) rs).getBlob(i); 
						        		if (blob != null) 
						        		{ 			        			
						        			buffer = new byte[4096];
						        			bis=new BufferedInputStream(blob.getBinaryStream());
						        			baos=new ByteArrayOutputStream(); 
						        			while ((length = bis.read(buffer)) != -1) 
						        			{ 
						        				baos.write(buffer, 0, length);
						        			}
						        			data.add(baos.toByteArray());
						        			try
						        			{
						        				baos.close(); 
						        				bis.close();
						        			}
						        			catch(Exception e)
						        			{
						        				logger.error("Error in Closing of resource:-"+e,new Throwable());
						        				e.printStackTrace();
						        			}			        			 
						        		}
				        			}
				        			catch(Exception e)
				        			{
				        				logger.error("Error in reteriving BLOB Value:-"+e,new Throwable());
				        				e.printStackTrace();
				        			}
				        		}
				        		if(resultSetMetaData.getColumnTypeName(i)!=null && resultSetMetaData.getColumnTypeName(i).equalsIgnoreCase("CLOB"))
				        		{
				        			try
				        			{
				        				clob=rs.getClob(i);	            	
					            		data.add((Object)clob.getSubString(1L, (int)clob.length()));
				        			}
				        			catch(Exception e)
				        			{
				        				logger.error("Error in reteriving CLOB Value:-"+e,new Throwable());
				        				e.printStackTrace();
				        			}
					            }
				        		else
				        		{
				        			data.add(rs.getObject(i)!=null?rs.getObject(i).toString():"");
				        		}
				        	}
				        	catch(Exception e)
				        	{
				        		logger.error("Error in Getting Data from coloum"+e,new Throwable());
				        	}
			        	}
			        	result.add(data);
			        }
			        logger.info("total No of Records fetch are:-"+count);
		        }			
			}
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while fetching records : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
				if(rs!=null)
				{
					rs.close();
					rs=null;
				}
				if(stmt!=null)
				{
					stmt.close();
					stmt=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		        bis=null;
				baos=null;
				resultSetMetaData=null;
				blob=null;
				clob=null;
				buffer=null;
		    	data=null;
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources : "+e,new Throwable());
				e.printStackTrace();
			}
        }
        logger.debug("Getting out from DBConnection in ExecuteDataLobQuery Method : ");
        return result;
    }
	
    public void procCall(String procName,String[] param) throws SQLException
    {
	    logger.debug("Getting in DBConnection in procCall Method : ");   
		Connection con = null;
		CallableStatement proc = null;
		int i=0;
		try
	    {
	       con=DBHelper.getInstance().getSourceConnection();		
	       if(con!=null)
	       {
	    	    proc = con.prepareCall("{ call "+procName+" }");
	    	    proc.setQueryTimeout(0);
	       		if(param.length>0)
	    		{
	    			logger.info("procCall Method with procName : "+procName +" with Parameters :-"+Arrays.toString(param));
	    			while(i<param.length)
			        {
			        	proc.setString(i+1,param[i]);
			        	i++;
			        }
	    		}
	    		else
	    		{
	    			logger.info("procCall Method with procName : "+procName);
	    		}		        
		        proc.execute();
	        }
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while Executing Proc : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in procCall Method:- ");   
				if(proc!=null)
				{
					proc.close();
					proc=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	logger.debug("Successfully closed Resources DBConnection in procCall Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in procCall Method: "+e,new Throwable());
				e.printStackTrace();
			}
	    }
	    logger.debug("Getting out from DBConnection in procCall Method : ");       	      
   }
    
   public String[] procWithReturnValues(String procName,String[] param,int count) throws SQLException
   {
	    logger.debug("Getting in DBConnection in procWithReturnValues Method : ");   
		Connection con = null;
		CallableStatement proc = null;
		String[] output=new String[count];
		int i=0;
		int j=0;
		try
	    {
	       con=DBHelper.getInstance().getSourceConnection();		
	       if(con!=null)
	       {
	    	    proc = con.prepareCall("{ call "+procName+" }");
	    	    proc.setQueryTimeout(0);
	       		if(param.length>0)
	    		{
	    			logger.info("procCall Method with procName : "+procName +" with Parameters :-"+Arrays.toString(param));
	    			while(i<param.length)
			        {
			        	proc.setString(i+1,param[i]);
			        	i++;
			        }
	    		}
	    		else
	    		{
	    			logger.info("procCall Method with procName : "+procName);
	    		}
	       		while(j<count)
	       		{
	       			proc.registerOutParameter(++i,Types.VARCHAR);
	       			j++;
	       		}
		        proc.execute();
		        if(j>0)
		        {
		        	i=i-count;
		        	j=0;
		        	while(j<count)
		        	{
		        		output[j++]=proc.getString(++i);
		        	}
		        }
	        }
			else
			{
				logger.error("Connection is Not Available Service unavailable.");				
			}
		}
		catch(Exception e)
		{			
			logger.error("Some exception occured while Executing procWithReturnValues : "+e,new Throwable());
			e.printStackTrace();
		}		
		finally
		{
			try
			{
		    	logger.debug("Trying to close Resources DBConnection in procWithReturnValues Method:- ");   
				if(proc!=null)
				{
					proc.close();
					proc=null;
				}
				if(con!=null)
				{
					con.close();
					con=null;
				}
		    	logger.debug("Successfully closed Resources DBConnection in procWithReturnValues Method:- ");   
			}
			catch(Exception e)
			{				
				logger.error("SQL exception while closing resources DBConnection in procWithReturnValues Method: "+e,new Throwable());
				e.printStackTrace();
			}
	    }
	    logger.debug("Getting out from DBConnection in procWithReturnValues Method : ");
	    return output;
    }    
}