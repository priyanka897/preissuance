package com.qualtech.webservice.db;

public class SQLConstants 
{	
	public static final String SaveRequestSeq="RECRUITMENT_REQ_RES_SEQ";
	
	public static final String SaveRequest="INSERT INTO RECRUITMENT_REQ_RES (REQID,SERVERNAME,REQUESTTYPE) VALUES (?,?,?)";
	
	public static final String SaveInputRequest="SELECT INPUTJSON FROM RECRUITMENT_REQ_RES WHERE REQID=? FOR UPDATE";
	
	public static final String SaveResponse="UPDATE RECRUITMENT_REQ_RES SET RESTIME=CURRENT_TIMESTAMP WHERE REQID=?";
	
	public static final String SaveOutputResponse="SELECT OUTPUTMESSAGE FROM RECRUITMENT_REQ_RES WHERE REQID=? FOR UPDATE";
	
	public static final String MetaDataQuery="SELECT * FROM <TABLENAME> WHERE 1=2";
}