package com.qualtech.webservice.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class DBHelper 
{
	private static DBHelper instance=null;
	private DataSource ds=null;
	static Logger logger = Logger.getLogger(DBHelper.class.getName());
		
	public void init() 
	{
		try
		{
			InitialContext cxt = new InitialContext();
			if ( cxt == null ) 
			{
				logger.error("Error no Context found:-");
			}
			try
			{
				logger.info("Looking for Data Source:- java:/comp/env/AADHAAR_DS");
				ds = (DataSource) cxt.lookup( "java:/comp/env/AADHAAR_DS" );
				logger.info("Data Source Found "+ds);
			}
			catch(Exception e)
			{
				try
				{
					if(ds == null)
					{
						logger.info("Looking for Data Source:-java:/  AADHAAR_DS");
						ds = (DataSource) cxt.lookup("java:/AADHAAR_DS");
						logger.info("Data Source Found java:/ "+ds);
					}
				}
				catch(Exception e1)
				{			
					logger.error("Error while getting data source "+e1,new Throwable());
					e1.printStackTrace();
				}							
			}	
			try
			{
				Connection con = ds.getConnection();
				if(con!=null)
				{				
					logger.info("Connection created..........");							
				}
				else
				{				
					logger.error("Connection isn't created..........");
				}
			}
			catch(Exception e)
			{			
				logger.error("Error while getting Connection from DataSource:- "+e,new Throwable());
				e.printStackTrace();	
			}
			if ( ds == null ) 
			{
			   logger.error("Data source not found!!!");
			   throw new Exception("Data source not found!!!");
			}
		}
		catch(Exception e)
		{
			logger.error("Error while initializing DB Helper "+e,new Throwable());
			e.printStackTrace();			
		}		
	}
	
	public Connection getSourceConnection() throws SQLException
	{
		Connection con = null;		
		try
		{
			con = ds.getConnection();
			//Class.forName("oracle.jdbc.driver.OracleDriver");			
			//con = java.sql.DriverManager.getConnection("jdbc:oracle:thin:@10.72.1.6:1521:alitst", "rform", "rform");
			con.getMetaData();
		}
		catch(Exception e)
		{ 
			logger.error("Error while getting connection from data source "+e,new Throwable());
			e.printStackTrace();
		}		
		return con;
	}
	
	public static synchronized DBHelper getInstance()
	{
		if(instance == null)
		{
			try
			{
				logger.info("Creating DBHelper Instance.");
				instance = new DBHelper();
				logger.info("Initializing Instance.");
				instance.init();
			}
			catch(Exception e)
			{
				logger.error("Error in database Instance Initialization:-"+e,new Throwable());
				e.printStackTrace();
			}
		}
		return instance;
	}
}