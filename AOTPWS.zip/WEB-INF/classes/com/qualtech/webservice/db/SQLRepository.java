package com.qualtech.webservice.db;

public class SQLRepository 
{
	public static final String SEQ_WS_QUERY="select isnull(MAX(ID),0)+1 as SequenceNo from AV_AD_WS_MST";
	
	public static final String INPUT_INSERT_QUERY="insert into AV_AD_WS_MST (ID,SYSTEM_ID,PASSWORD,REQ_TYPE,AADHAR_NO," +
			"OTP,REQ_TIME,REQ_PARAM_1) values (?,?,?,?,?,?,getdate(),?)";
	
	
	public static final String SELECT_CLOB_QUERY="select REQ_PARAM_1 from AV_AD_WS_MST where ID =?";
	
	public static final String SELECT_UID_CLOB_QUERY="select REQ_DATA,EXCEPTION from av_ad_uid_mst where ID =? ";
	
	public static final String  UPDATE_CLOB_QUERY ="update AV_AD_WS_MST set REQ_PARAM_1=?,REQ_PARAM_2=? , REQ_PARAM_3 =? where id=?";
	
	public static final String UPDATE_WS_QUERY="update AV_AD_WS_MST SET STATUS = ? , STATUS_MSG = ? , " +
	" ERROR_CODE =? , ERROR_DESC=? , RES_TIME=getdate() " +
	" where ID=?";

	
	public static final String AUTHENTICATE_USER_QUERY="select count(1) from AV_AD_USER_AUTH_MST where system_id=? and password=? and status='Y' and valid_till>=getdate()";
	
	public static final String UPDATE_FAIL_QUERY="update AV_AD_WS_MST SET STATUS = 'E' , STATUS_MSG = ? ,RES_TIME=getdate()  where ID=?";
	
	public static final String ERROR_CODE_QUERY="select error_desc from AV_AD_ERR_CODE_MST where error_code = ? and error_type=?";
	
	
	
	public static final String SEQ_UID_QUERY="select isnull(MAX(ID),0)+1 as SequenceNo from AV_AD_UID_MST";
	
	public static final String NSDL_INSERT_QUERY="insert into AV_AD_UID_MST (ID,SYSTEM_ID,PASSWORD,REQ_TYPE,AADHAR_NO," +
	"OTP,REQ_TIME,EXCEPTION,REF_ID,REQ_DATE,PROP_NO) values (?,?,?,?,?,?,getdate(),?,?,getdate(),?)";
	
	
	public static final String UPDATE_UID_QUERY="update AV_AD_UID_MST SET STATUS = ? , STATUS_MSG = ? ,  " +
	"  ERROR_CODE =? , ERROR_DESC=? , RES_TIME=getdate() " +
	", EXCEPTION=? where REF_ID=?";
	//", EXCEPTION=? where ID=? AND REF_ID=?";

	
	public static final String INSERT_TIFF_QUERY="update AV_AD_UID_MST SET TIFF_DATA = ?,PROP_TIFF_NAME=?,PROP_NO=? where ID=? AND REF_ID=?";
	
	public static final String SELECT_TIFF_CLOB_QUERY="select TIFF_DATA from av_ad_uid_mst where ID =? ";
	
	public static final String SELECT_UID_RES_CLOB_QUERY="select RES_DATA, EXCEPTION from av_ad_uid_mst where REF_ID =? ";
	//public static final String SELECT_UID_RES_CLOB_QUERY="select RES_DATA, EXCEPTION from av_ad_uid_mst where ID =? FOR UPDATE";
	
	
	public static final String UPDATE_UID_FAIL_QUERY="update AV_AD_UID_MST SET STATUS = ? , STATUS_MSG = ? where ID=?";
	
	
	
	
}