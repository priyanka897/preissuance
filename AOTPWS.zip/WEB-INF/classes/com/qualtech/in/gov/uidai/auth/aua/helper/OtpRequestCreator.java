/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.aua.helper;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;

import com.qualtech.in.gov.uidai.auth.device.model.OtpDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.authentication.otp._1.Opts;
import com.qualtech.in.gov.uidai.authentication.otp._1.Otp;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.webservice.service.RequestTypeValidator;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;

/**
 * This class provides a method to generate the Otp request object
 * using information that has been received from Otp client and using the information that
 * is available with AUA.
 *  
 * @author UIDAI
 *
 */
public class OtpRequestCreator {

	/**
	 * Constructor
	 * @param aua AUA code
	 * @param saSub AUA code
	 * @param licenseKey License key
	 * @param token Token element, typically used for authentication requests received over mobile networks.
	 * @param auaData Data received from otp client.
	 * @return Instance of {@link Auth}
	 */
	String uidNo="";
	public Otp createOtpRequest(String aua, String sa, String licenseKey, OtpDataFromDeviceToAUA auaData  ,String otpVersion) {

		try {

			Otp otpReq = new Otp();
			otpReq.setUid(auaData.getUid());
			uidNo=auaData.getUid();
			otpReq.setVer(otpVersion);
			otpReq.setAc(aua);
			otpReq.setSa(sa);
			Calendar calendar = GregorianCalendar.getInstance();
			otpReq.setTs((XMLGregorianCalendarImpl.createDateTime(
					calendar.get(Calendar.YEAR),
					calendar.get(Calendar.MONTH) + 1,
					calendar.get(Calendar.DAY_OF_MONTH),
					calendar.get(Calendar.HOUR_OF_DAY),
					calendar.get(Calendar.MINUTE),
					calendar.get(Calendar.SECOND))));
			

			String txn = createTxn(aua);
			otpReq.setTxn(txn);
           System.out.println("~~~~~~~~~~~~~~``~~~~~~~~~~~~~~~~~~~````~~~~~~~~~~~~~~~~~~~~~~~~~"+txn);  
			otpReq.setLk(licenseKey);
			otpReq.setTid(auaData.getTerminalId());
			
			
			if (StringUtils.isNotBlank(auaData.getChannel())) {
				Opts c = new Opts();
				c.setCh(auaData.getChannel());
				otpReq.setOpts(c);
			}
			
			return otpReq;
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
	}

	/**
	 * Method to construct transaction code based on AUA code and current time.
	 * @param aua AUA code
	 * @return String representing transaction code.
	 */
	private String createTxn(String aua) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmmssSSS");
		String txn = "AuthDemoClient" + ":" + aua + ":" + dateFormat.format(new Date());
		RequestTypeValidator.Authtxno.put(uidNo, txn);
		return txn;
	}

}
