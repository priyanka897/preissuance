package com.qualtech.in.gov.uidai.auth.aua.helper;
 
 
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.ResourceBundle;
 
import javax.xml.crypto.dsig.CanonicalizationMethod;
import javax.xml.crypto.dsig.DigestMethod;
import javax.xml.crypto.dsig.Reference;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.SignedInfo;
import javax.xml.crypto.dsig.Transform;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMSignContext;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.KeyInfoFactory;
import javax.xml.crypto.dsig.keyinfo.X509Data;
import javax.xml.crypto.dsig.spec.C14NMethodParameterSpec;
import javax.xml.crypto.dsig.spec.TransformParameterSpec;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.log4j.Logger; 
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.qualtech.in.gov.uidai.auth.aua.qc.KYCRequestCaller;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.service.EmailSenderAction;
 
/**
* <code>DigitalSigner</code> class provides a utility method to digitally sign
* XML document. This implementation uses .p12 file as a source of signer's
* digital certificate. In production environments, a hardware security module
* (HSM) should be used for digitally signing.
*
* @author UIDAI
*
*/
public class DigitalSigner {
	
	private static Logger _ologger = Logger.getLogger(DigitalSigner.class.getName());
                private static final String MEC_TYPE = "DOM";
                private static final String WHOLE_DOC_URI = "";
                private static final String KEY_STORE_TYPE = "PKCS12";
 
                private  KeyStore.PrivateKeyEntry keyEntry;
                private static KeyStore ks = null;
 
                // used for dongle
                private static  Provider provider;
                private static final String KEY_STORE_TYPE_DONGLE = "PKCS11";
 
                /**
                 * Constructor
                 *
                 * @param keyStoreFile
                 *            - Location of .p12 file
                 * @param keyStorePassword
                 *            - Password of .p12 file
                 * @param alias
                 *            - Alias of the certificate in .p12 file
                 */
                /*public DigitalSigner(String keyStoreFile, char[] keyStorePassword,
                                                String alias) {
                                this.keyEntry = getKeyFromKeyStore(keyStoreFile, keyStorePassword,
                                                                alias);
 
                                if (keyEntry == null) {
                                                throw new RuntimeException(
                                                                                "Key could not be read for digital signature. Please check value of signature "
                                                                                                                + "alias and signature password, and restart the Auth Client");
                                }
                }*/
 
                /**
                 * Constructor
                 *
                 * read key from dongle file
                 *
                 *
                 * @param safesignfile
                 * @param providerName
                 * @param pin
                 */
                public DigitalSigner(String safesignfile, char[] pin , String alias) {
                              //  System.out.println("Enter into DigitalSigner");
                                this.provider = new sun.security.pkcs11.SunPKCS11(safesignfile);
                                Security.addProvider(this.provider);
                                this.keyEntry = getPrivateKeyFromDongle(pin , alias);
                                //getPrivateKeyFromDongle(pin);
                                if (keyEntry == null) {
                                                throw new RuntimeException(
                                                                                "Key could not be read for digital signature. Please check value of signature "
                                                                                                                + "alias and signature password, and restart the Auth Client");
                                }
                             //   System.out.println("Exit from DigitalSigner");
                }
 
                private static KeyStore.PrivateKeyEntry getPrivateKeyFromDongle(
                                                //private static void getPrivateKeyFromDongle(
                                                char[] keyStorePassword , String keyAlias) {
                                //KeyStore ks;
                               // System.out.println("Enter into getPrivateKeyFromDongle 1");
                                try {
                                                //ks = KeyStore.getInstance(KEY_STORE_TYPE_DONGLE, provider);
                                                ks = KeyStore.getInstance(KEY_STORE_TYPE_DONGLE);
                                                //System.out.println("Enter into getPrivateKeyFromDongle 2");
                                                //keyStorePassword = "password123".toString().toCharArray();
                                                //System.out.println("Enter into getPrivateKeyFromDongle 3");
                                                ks.load(null, keyStorePassword);
                                                //System.out.println("Enter into getPrivateKeyFromDongle 4");
                                                Enumeration<String> alias = ks.aliases();
                                                //System.out.println("Enter into getPrivateKeyFromDongle 5");
                                                String signAlias = "";
 
                                                //while (alias.hasMoreElements()) {
                                                                String aliasName = keyAlias;
                                                                //String aliasName = "9f28cf52-e4ef-493d-8000-0e4279ff793e";//alias.nextElement();
                                                                X509Certificate cert = (X509Certificate) ks
                                                                                                .getCertificate(aliasName);
                                                               // System.out.println("Enter into getPrivateKeyFromDongle 6");
                                                                boolean[] keyUsage = cert.getKeyUsage();
                                                                for (int i = 0; i < keyUsage.length; i++) {
                                                                                if ((i == 0 || i == 1) && keyUsage[i] == true) {
                                                                                                signAlias = aliasName;
                                                                                                break;
                                                                                }
                                                                }
                                                //}
                                                                //System.out.println("Enter into getPrivateKeyFromDongle 7");
                                                                //System.out.println(new KeyStore.PasswordProtection(keyStorePassword));
                                                                //System.out.println(keyStorePassword);
                                                                KeyStore.PrivateKeyEntry keyEntry = (KeyStore.PrivateKeyEntry) ks.getEntry(signAlias,
                                                                                                new KeyStore.PasswordProtection(keyStorePassword));
//
                                               // System.out.println("Exit from getPrivateKeyFromDongle");
                                                return keyEntry;
 
                                } catch (KeyStoreException e) {
                                                e.printStackTrace();
                                } catch (NoSuchAlgorithmException e) {
                                                e.printStackTrace();
//                            } catch (UnrecoverableEntryException e) {
//                                            e.printStackTrace();
                                } catch (CertificateException e) {
                                                e.printStackTrace();
                                } catch (IOException e) {
                                                e.printStackTrace();
                                }catch (Exception e) {
                                    //            System.out.println("EException in getPrivateKeyFromDongle");
                                                e.printStackTrace();
                                }
                                return null;
                }
 
                /**
                 * Method to digitally sign an XML document.
                 *
                 * @param xmlDocument
                 *            - Input XML Document.
                 * @return Signed XML document
                 */
                public String signXML(String xmlDocument, boolean includeKeyInfo) {
                	  _ologger.info("namespace removed ===========>:" + xmlDocument);
                                if (this.provider == null) {
                                                this.provider = new BouncyCastleProvider();
                                }
                                Security.addProvider(this.provider);
                              //  System.out.println("Enter into signXML");
                                try {
                                                // Parse the input XML
                                                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                                                dbf.setNamespaceAware(true);
                                                Document inputDocument = dbf.newDocumentBuilder().parse(
                                                                                new InputSource(new StringReader(xmlDocument)));
 
                                                // Sign the input XML's DOM document
                                                Document signedDocument = sign(inputDocument, includeKeyInfo);
 
                                                // Convert the signedDocument to XML String
                                                StringWriter stringWriter = new StringWriter();
                                                TransformerFactory tf = TransformerFactory.newInstance();
                                                Transformer trans = tf.newTransformer();
                                                trans.transform(new DOMSource(signedDocument), new StreamResult(
                                                                                stringWriter));
                                                //System.out.println("Exit from signXML");
                                                return stringWriter.getBuffer().toString();
                                } catch (Exception e) {
                                                e.printStackTrace();
                                                throw new RuntimeException(
                                                                                "Error while digitally signing the XML document", e);
                                }
                }
 
                private Document sign(Document xmlDoc, boolean includeKeyInfo)
                                                throws Exception {
 
                                ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
                                //bundle.getString(IApplicationConstants.KEYSTOREALIAS);
 
 
                                EmailSenderAction mailAction  =new EmailSenderAction();
 
                                if (System.getenv("SKIP_DIGITAL_SIGNATURE") != null) {
                                                return xmlDoc;
                                }
                               // System.out.println("Enter into sign");
                               // Creating the XMLSignature factory.
                                XMLSignatureFactory fac = XMLSignatureFactory.getInstance(MEC_TYPE);
                                // Creating the reference object, reading the whole document for
                                // signing.
                                //System.out.println("Enter into sign 1");
                                Reference ref = fac.newReference(WHOLE_DOC_URI, fac.newDigestMethod(
                                                                DigestMethod.SHA1, null), Collections.singletonList(fac
                                                                .newTransform(Transform.ENVELOPED,
                                                                                                (TransformParameterSpec) null)), null, null);
                               // System.out.println("Enter into sign 2");
                                // Create the SignedInfo.
                                SignedInfo sInfo = fac.newSignedInfo(fac.newCanonicalizationMethod(
                                                                                                CanonicalizationMethod.INCLUSIVE,
                                                                                                (C14NMethodParameterSpec) null), fac
                                                                                                .newSignatureMethod(SignatureMethod.RSA_SHA1, null),
                                                                                                Collections.singletonList(ref));
                               // System.out.println("Enter into sign 4");
                                if (ks == null) {
                                                System.out.println("Enter into sign 5");
                                                throw new RuntimeException(
                                                                                "Key could not be read for digital signature. Please check value of signature alias and signature password, and restart the Auth Client");
                                }
                          //      System.out.println("Enter into sign 6");
                                String alias = bundle.getString(IApplicationConstants.KEYSTOREALIAS);
                                //String alias = "9f28cf52-e4ef-493d-8000-0e4279ff793e";
                                //System.out.println("Enter into sign 7");
 
                                //PrivateKey privateKey=(PrivateKey) ks.getKey(alias,"password123".toString().toCharArray());
 
                                //PrivateKey privateKey = new Etoken_Sig().getPrivateKeySignature();
 
                         //       System.out.println("Enter into sign 8");
                                X509Certificate x509Cert=(X509Certificate) ks.getCertificate(alias);
                         //       System.out.println("Enter into sign 9");
                                //X509Certificate x509Cert = (X509Certificate) keyEntry.getCertificate();
                        //        System.out.println("Enter into sign 10");
                                KeyInfo kInfo = getKeyInfo(x509Cert, fac);
                                DOMSignContext dsc = new DOMSignContext(this.keyEntry.getPrivateKey(),
                                                                xmlDoc.getDocumentElement());
                                XMLSignature signature = fac.newXMLSignature(sInfo,
                                                                includeKeyInfo ? kInfo : null);
                                signature.sign(dsc);
 
                                Node node = dsc.getParent();
                                System.out.println("Exit from sign");
                                return node.getOwnerDocument();
 
                }
 
                @SuppressWarnings("unchecked")
                private KeyInfo getKeyInfo(X509Certificate cert, XMLSignatureFactory fac) {
                                // Create the KeyInfo containing the X509Data.
                    //            System.out.println("Enter into getKeyInfo");
                                KeyInfoFactory kif = fac.getKeyInfoFactory();
                                List x509Content = new ArrayList();
                                x509Content.add(cert.getSubjectX500Principal().getName());
                                x509Content.add(cert);
                                X509Data xd = kif.newX509Data(x509Content);
                //                System.out.println("Exit from getKeyInfo");
                                return kif.newKeyInfo(Collections.singletonList(xd));
                }
 
                private KeyStore.PrivateKeyEntry getKeyFromKeyStore(String keyStoreFile,
                                                char[] keyStorePassword, String alias) {
                                // Load the KeyStore and get the signing key and certificate.
                                FileInputStream keyFileStream = null;
                                try {
                                                KeyStore ks = KeyStore.getInstance(KEY_STORE_TYPE);
                                                keyFileStream = new FileInputStream(keyStoreFile);
                                                ks.load(keyFileStream, keyStorePassword);
 
                                                KeyStore.PrivateKeyEntry entry = (KeyStore.PrivateKeyEntry) ks
                                                                                .getEntry(alias, new KeyStore.PasswordProtection(
                                                                                                                keyStorePassword));
                                                return entry;
 
                                } catch (Exception e) {
                                                e.printStackTrace();
                                                return null;
                                } finally {
                                                if (keyFileStream != null) {
                                                                try {
                                                                                keyFileStream.close();
                                                                } catch (IOException e) {
                                                                                e.printStackTrace();
                                                                }
                                                }
                                }
 
                }
 
 
 
}
 
