/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.device.helper;

import com.qualtech.in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.auth.device.model.SessionKeyDetails;
import com.qualtech.in.gov.uidai.auth.generic.helper.HashGenerator;
import com.qualtech.in.gov.uidai.authentication.common.types._1.Meta;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.DataType;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;

import java.io.StringWriter;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

/**
 * This class provides a method to collate all the data that needs to sent from Auth Client to AUA server.
 * 
 * @author UIDAI
 * 
 */
public class AuthAUADataCreator {

	private static final int AES_256_KEY_SIZE = 32;
	private Encrypter encrypter;
	private HashGenerator hashGenerator;
	private static Logger _ologger = Logger.getLogger(AuthAUADataCreator.class.getName());
	private static final String RANDOM_ALGORITH_NAME = "SHA1PRNG";

	private Map<DataType, SynchronizedKey> skeyMap = new HashMap<DataType, SynchronizedKey>();
	
	private long expiryTime = 10 * 60 * 1000; //10 minutes for testing purpose.
	
	private SecureRandom secureSeedGenerator;
	private boolean useSSK = false;

	/**
	 * Constructor
	 * @param encrypter For encryption of Pid
	 * @param useSynchronizedSesionKey Flag indicating whether synchronized sesssion key should be used.
	 */
	public AuthAUADataCreator(Encrypter encrypter, boolean useSynchronizedSesionKey) {
		this.hashGenerator = new HashGenerator();
		this.encrypter = encrypter;
		this.useSSK = useSynchronizedSesionKey;

		try {
			this.secureSeedGenerator = SecureRandom.getInstance(RANDOM_ALGORITH_NAME);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * Creates an instance of {@link AuthDataFromDeviceToAUA} that represents all the data that an Auth client
	 * will send to AUA server.
	 * 
	 * @param uid
	 * @param terminalId
	 * @param meta
	 * @param pid
	 * @param dataType
	 * @return
	 */
	public AuthDataFromDeviceToAUA prepareAUAData(String uid, String terminalId, Meta meta, Object pid, DataType dataType) {
		/*System.out.println(" AuthDataFromDeviceToAUA prepareAUAData");
		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData uid"+uid);
		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData terminalId"+terminalId);
		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData meta"+meta);
		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData pid"+pid);
		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData dataType"+dataType);*/
		
		try {
			byte[] rawPid=null;

			if (DataType.X == dataType)
			{
			//	System.out.println(" AuthDataFromDeviceToAUA prepareAUAData rawPid"+dataType);
//---saurav Auth2.0 change rawPid = ((com.qualtech.in.gov.uidai.authserver.protobuf.Auth.Pid) pid).toByteArray();
				
				rawPid = createPidXML((com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid) pid).getBytes();
		//		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData rawPid"+rawPid);
		//		System.out.println("Proto Pid in Hex: " + Hex.encodeHexString(rawPid));
		//		System.out.println("Proto Pid in Hex: " + Hex.encodeHexString(rawPid));
			}
			//else {//---------------------saurav
				
			//	rawPid = createPidXML((com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid) pid).getBytes();
		//		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData rawPid else "+rawPid);
		//	}  //-----------------------saurav

			byte[] pidXmlBytes = rawPid;
			
			byte[] sessionKey = null;
			
			byte[] newRandom = new byte[20];
			
			SynchronizedKey synchronizedKey = null;
			byte[] encryptedSessionKey = null;
			
			SessionKeyDetails sessionKeyDetails;
	//		System.out.println(" AuthDataFromDeviceToAUA prepareAUAData sessionKeyDetails ");
			if (this.useSSK) {
				synchronizedKey = this.skeyMap.get(dataType);
				
				if (synchronizedKey == null || synchronizedKey.getSeedCreationDate().getTime()  - System.currentTimeMillis() > expiryTime) {
		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData synchronizedKey 1 "+synchronizedKey);
					
					synchronizedKey = new SynchronizedKey(this.encrypter.generateSessionKey(), UUID.randomUUID().toString(), new Date());
		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData synchronizedKey 2 "+synchronizedKey);
					this.skeyMap.put(dataType, synchronizedKey);
					
					sessionKey = synchronizedKey.getSeedSkey();
					
		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData sessionKey 1 "+sessionKey);
					
					encryptedSessionKey = this.encrypter.encryptUsingPublicKey(sessionKey);
					
					sessionKeyDetails = SessionKeyDetails.createSkeyToInitializeSynchronizedKey(synchronizedKey.getKeyIdentifier(), encryptedSessionKey);
					
		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData sessionKeyDetails 1 "+sessionKeyDetails);
					
				} else {
					
		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails 1 ");
					byte[] seed = secureSeedGenerator.generateSeed(20);

		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails 1 seed"+seed.toString());
					
					SecureRandom random = SecureRandom.getInstance(RANDOM_ALGORITH_NAME);
					random.setSeed(seed);
					random.nextBytes(newRandom);

		//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails 1 random"+random);
					
					sessionKey = Arrays.copyOf(this.encrypter.encryptUsingSessionKey(synchronizedKey.getSeedSkey(), newRandom), AES_256_KEY_SIZE);
					
	//				System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails 1 sessionKey"+sessionKey);
					encryptedSessionKey = newRandom;
	//				System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else encryptedSessionKey "+encryptedSessionKey);
					sessionKeyDetails = SessionKeyDetails.createSkeyToUsePreviouslyGeneratedSynchronizedKey(synchronizedKey.getKeyIdentifier(), encryptedSessionKey);
	//				System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails "+sessionKeyDetails);
				}
			} else {
				this.skeyMap.clear();
	//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails else ");
				sessionKey = this.encrypter.generateSessionKey();
	//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails else"+sessionKey);
				encryptedSessionKey = this.encrypter.encryptUsingPublicKey(sessionKey);
	//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails else encryptedSessionKey"+encryptedSessionKey);
				sessionKeyDetails = SessionKeyDetails.createNormalSkey(encryptedSessionKey);
	//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData else sessionKeyDetails else sessionKeyDetails"+sessionKeyDetails);
			}

//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData ");
			byte[] encXMLPIDData =  this.encrypter.pidEncryptUsingSessionKey(sessionKey,pidXmlBytes,((Pid)pid).getTs().toString());
					//---------------this.encrypter.encryptUsingSessionKey(sessionKey, pidXmlBytes);
//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData encXMLPIDData"+encXMLPIDData);
			byte[] hmac = this.hashGenerator.generateSha256Hash(pidXmlBytes);
//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData hmac"+hmac);
			byte[] encryptedHmacBytes = this.encrypter.hmacEncryptUsingSessionKey(sessionKey,hmac,((Pid)pid).getTs().toString());
					//----------------------this.encrypter.encryptUsingSessionKey(sessionKey, hmac);
//			System.out.println(" AuthDataFromDeviceToAUA prepareAUAData encryptedHmacBytes"+encryptedHmacBytes);

			String certificateIdentifier = this.encrypter.getCertificateIdentifier();
			
			/*System.out.println("sessionKey -->"+sessionKey);
			System.out.println("encXMLPIDData -->"+encXMLPIDData);
			System.out.println("hmac -->"+hmac);
			System.out.println("encryptedHmacBytes -->"+encryptedHmacBytes);
			System.out.println("certificateIdentifier -->"+certificateIdentifier);
			
			System.out.println("sessionKey -->"+sessionKey);
			System.out.println("encXMLPIDData -->"+encXMLPIDData);
			System.out.println("hmac -->"+hmac);
			System.out.println("encryptedHmacBytes -->"+encryptedHmacBytes);
			System.out.println("certificateIdentifier -->"+certificateIdentifier);*/
			
			
			byte[] demoBytes=null;
			if (DataType.X == dataType) {
			//	System.out.println("certificateIdentifier DataType-->"+dataType);
			//---------------------saurav	demoBytes = ((com.qualtech.in.gov.uidai.authserver.protobuf.Auth.Pid) pid).getDemo().toByteArray();
		//		System.out.println("certificateIdentifier --> dataType"+demoBytes);
			//------------------------------} else {
		//		System.out.println("certificateIdentifier DataType-->"+dataType);
				demoBytes = getDemoXML((com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid) pid).getBytes();
		//		System.out.println("certificateIdentifier --> dataType"+demoBytes);
			}

			byte[] hashedDemoBytes = StringUtils.leftPad("0", 64, '0').getBytes();
			if (demoBytes != null && demoBytes.length > 0) {
		//		System.out.println("certificateIdentifier --> demoBytes"+demoBytes);
				hashedDemoBytes = hashGenerator.generateSha256Hash(demoBytes);
		//		System.out.println("certificateIdentifier --> hashedDemoBytes"+hashedDemoBytes);
			}
	//		System.out.println("certificateIdentifier --> AuthDataFromDeviceToAUA");
			AuthDataFromDeviceToAUA auaData = new AuthDataFromDeviceToAUA(uid, terminalId, sessionKeyDetails, encXMLPIDData, encryptedHmacBytes, hashedDemoBytes,
					certificateIdentifier, dataType, meta);
	//		System.out.println("certificateIdentifier --> AuthDataFromDeviceToAUA"+auaData);
			return auaData;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
			//throw new RuntimeException(e);
		}
	}

	/**
	 * This method returns Demo XML string for a given Pid. This method can be
	 * used for verifying Demo XML hash received in auth responses.
	 * 
	 * @param pid
	 *            Pid instance
	 * @return String containing XML representation of Demo element
	 */
	private String getDemoXML(Pid pid) {
		StringWriter sw = new StringWriter();

		try {
			JAXBContext.newInstance(Pid.class).createMarshaller().marshal(pid, sw);
		} catch (JAXBException e) {
			e.printStackTrace();
		}

		String pidXML = sw.toString();
		String demoXML ="";
		try {
			
			String demoStartStr = "<Demo";
			int startOfDemoElement = pidXML.lastIndexOf(demoStartStr);

			String demoEndStr = "</Demo";
			int beginningOfEndOfDemoElement = pidXML.indexOf(demoEndStr, startOfDemoElement + demoStartStr.length());

			int realEnd = pidXML.indexOf(">", beginningOfEndOfDemoElement + demoEndStr.length());
// saurav changes for Auth2.0
			if(pidXML.length() < realEnd+1){
				demoXML = pidXML.substring(startOfDemoElement, realEnd + 1);
			}
		} catch (Exception e) {
			// In case of exception return blank string
			e.printStackTrace();
		}
		
		System.out.println("DEMOXML --> "+demoXML);
		
		return demoXML;
	}

	private String createPidXML(Pid pid) {
		StringWriter pidXML = new StringWriter();

		try {
			JAXBContext.newInstance(Pid.class).createMarshaller().marshal(pid, pidXML);
		} catch (JAXBException e) {
			e.printStackTrace();
		}

		//System.out.println("PID XML :::"+pidXML.toString());
		_ologger.info("PID XML---->>>>>>>>>>> :"+pidXML.toString());     
		return pidXML.toString();
	}

	public void restSkeyMap() {
		this.skeyMap.clear();
	}
	
	public static class SynchronizedKey {
		byte[] seedSkey;
		String keyIdentifier;
		Date seedCreationDate;
		
		public SynchronizedKey(byte[] seedSkey, String keyIdentifier, Date seedCreationDate) {
			super();
			this.seedSkey = seedSkey;
			this.keyIdentifier = keyIdentifier;
			this.seedCreationDate = seedCreationDate;
		}

		public String getKeyIdentifier() {
			return keyIdentifier;
		}
		
		public Date getSeedCreationDate() {
			return seedCreationDate;
		}
		
		public byte[] getSeedSkey() {
			return seedSkey;
		}
	}
}
