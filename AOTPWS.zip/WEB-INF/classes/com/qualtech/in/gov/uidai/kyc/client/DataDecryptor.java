/**
 * DISCLAIMER: The sample code or utility or tool described herein
 * is provided on an "as is" basis, without warranty of any kind.
 * UIDAI does not warrant or guarantee the individual success
 * developers may have in implementing the sample code on their
 * environment. 
 * 
 * UIDAI does not warrant, guarantee or make any representations
 * of any kind with respect to the sample code and does not make
 * any representations or warranties regarding the use, results
 * of use, accuracy, timeliness or completeness of any data or
 * information relating to the sample code. UIDAI disclaims all
 * warranties, express or implied, and in particular, disclaims
 * all warranties of merchantability, fitness for a particular
 * purpose, and warranties related to the code, or any service
 * or software related thereto. 
 * 
 * UIDAI is not responsible for and shall not be liable directly
 * or indirectly for any direct, indirect damages or costs of any
 * type arising out of use or any action taken by you or others
 * related to the sample code.
 * 
 * THIS IS NOT A SUPPORTED SOFTWARE.
 * 
 */

package com.qualtech.in.gov.uidai.kyc.client;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringReader;
import java.math.BigInteger;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.interfaces.RSAKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.MGF1ParameterSpec;
import java.util.Enumeration;
import java.util.ResourceBundle;

import javax.crypto.Cipher;
import javax.crypto.spec.OAEPParameterSpec;
import javax.crypto.spec.PSource;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBException;
import javax.xml.crypto.MarshalException;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureException;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.crypto.AsymmetricBlockCipher;
import org.bouncycastle.crypto.BufferedBlockCipher;
import org.bouncycastle.crypto.InvalidCipherTextException;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.encodings.OAEPEncoding;
import org.bouncycastle.crypto.engines.AESEngine;
import org.bouncycastle.crypto.engines.RSAEngine;
import org.bouncycastle.crypto.modes.CFBBlockCipher;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.crypto.params.RSAKeyParameters;
import org.bouncycastle.crypto.util.PublicKeyFactory;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.itextpdf.text.log.SysoLogger;
import com.qualtech.in.gov.uidai.kyc.client.utils.XMLUtilities;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_response._1.Resp;

import sun.security.rsa.RSAPadding;

class UnicodeFormatter 
{     
	static public String byteToHex(byte b) 
	{       // Returns hex String representation of byte b      
		char hexDigit[] = {         
				'0', '1', '2', '3', '4', '5', '6', '7',     
		
				'8', '9', 'a', 'b', 'c', 'd', 'e', 'f'     
				};   
		char[] array = { hexDigit[(b >> 4) & 0x0f], hexDigit[b & 0x0f] };    
		return new String(array);   
		}     
	static public String charToHex(char c) {    
		// Returns hex String representation of char c  
		byte hi = (byte) (c >>> 8);     
		byte lo = (byte) (c & 0xff);  
		return byteToHex(hi) + byteToHex(lo);   
		}   
} // class 
	
		
	




public class DataDecryptor {

	private static final int PUBLIC_KEY_SIZE = 294;
	private static final int EID_SIZE = 32;
	private static final int SECRET_KEY_SIZE = 256;
	//private static final String TRANSFORMATION = "OAEPWITHSHA256ANDMGF1PADDING";
	//private static final String TRANSFORMATION = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";
	private static final String TRANSFORMATION = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";
	 
	private static final String SECURITY_PROVIDER = "BC";
	private static final String DIGEST_ALGORITHM = "SHA-256";
	private static final String MASKING_FUNCTION = "MGF1";
	private static final int VECTOR_SIZE = 16;
	private static final int HMAC_SIZE = 32;
	private static final int BLOCK_SIZE = 128;
	private static final byte[] HEADER_DATA = "VERSION_1.0".getBytes();
	private static final String SIGNATURE_TAG = "Signature";
	private static final String MEC_TYPE = "DOM";
	private static final String KEY_STORE_TYPE_DONGLE = "PKCS11";
	private Provider userProvider;
	private KeyStore.PrivateKeyEntry privateKey;
	private String publicKeyFile;
	static{
	Security.addProvider(new BouncyCastleProvider());
	}
	
	/**
	 * Constructor
	 * @param keyStoreFile - Location of .p12 file
	 * @param keyStorePassword - Password of .p12 file
	 * @param alias - Alias of the certificate in .p12 file
	 */
	public DataDecryptor(String keyStoreFile, char[] keyStorePassword, String publicKeyFile,String alias) {
		this.privateKey = getKeyFromFile(keyStoreFile, keyStorePassword,alias);
		this.publicKeyFile = publicKeyFile;
		
		if (privateKey == null) {
			throw new RuntimeException("Key could not be read for digital signature. Please check value of signature "
					+ "alias and signature password, and restart the Auth Client");
		}
		//System.setProperty("file.encoding", "UTF-8");
	}
	public DataDecryptor(String providerConfigFile, char[] keyStorePassword, String publicKeyFile) {
	//	System.out.println("inside DataDecryptor constructor for eToken");
		userProvider = new sun.security.pkcs11.SunPKCS11(providerConfigFile);
	//	System.out.println("inside DataDecryptor constructor for eToken - 1");
		Security.addProvider(userProvider);
	//	System.out.println("inside DataDecryptor constructor for eToken - 2");
		this.privateKey = getKeyFromFile(userProvider, keyStorePassword);
	//	System.out.println("inside DataDecryptor constructor for eToken - 3");
		this.publicKeyFile = publicKeyFile;
		if(!(privateKey.getPrivateKey() instanceof RSAPrivateKey))
		{
			System.out.println("Private key is not a instance of RSA key");
		}
		
		if (privateKey == null) {
			throw new RuntimeException("Key could not be read for digital signature. Please check value of signature "
					+ "alias and signature password, and restart the Auth Client");
		}
		//System.setProperty("file.encoding", "UTF-8");
	}
	
	private KeyStore.PrivateKeyEntry getKeyFromFile(Provider userProvider, char[] keyStorePassword) 
	{
		// Load the KeyStore and get the signing key and certificate.
		
		try 
		{
			ResourceBundle res=ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
		//	System.out.println("inside try in getkeyfromkeystore for dongle");
			KeyStore ks = KeyStore.getInstance(KEY_STORE_TYPE_DONGLE/*,userProvider*/);
			//KeyStore ks = KeyStore.getInstance(KEY_STORE_TYPE_DONGLE);
			//keyFileStream = new FileInputStream(keyStoreFile);
			System.out.println("1");
			ks.load(null, keyStorePassword);
			System.out.println("2");
			Enumeration<String>  e= ks.aliases();
			String alias=null;
			while (e.hasMoreElements()) 
			{
				alias = e.nextElement();
			//	System.out.println("Alias :"+alias);
				if(res.getString("KEYSTOREALIASPRIVATE").equalsIgnoreCase(alias))
				{
					break;
				}
			}
	//		System.out.println("alias loaded : "+alias);
			/*X509Certificate UserCert = (X509Certificate) ks.getCertificate(alias);
			System.out.println("X509Certificate : \n"+UserCert);*/
	//		System.out.println("inside try in getkeyfromkeystore before load");
			
			KeyStore.PrivateKeyEntry entry = (KeyStore.PrivateKeyEntry) ks.getEntry(alias,
					new KeyStore.PasswordProtection(keyStorePassword));
			
	//		System.out.println(entry.getPrivateKey().toString());
	//		System.out.println("inside try in getkeyfromkeystore before return");

			return entry;

		} catch (Exception e) {
			e.printStackTrace();
	//		System.out.println("in getKeyFromKeyStore method and the exception is"+e );
			return null;
		} 
		

	}
	public  void printBytes(byte[] array, String name) {
	    for (int k = 0; k < array.length; k++) {
	   // 	System.out.println(name + "[" + k + "] = " + "0x" +
	     //       UnicodeFormatter.byteToHex(array[k]));
	    }
	}

	public byte[] decrypt(byte[] data) throws Exception {
		if(data == null || data.length == 0)
			throw new Exception("byte array data can not be null or blank array.");
		
		
		ByteArraySpliter arrSpliter = new ByteArraySpliter(data);
		
		RSAKeyParameters rsaKeyParam = (RSAKeyParameters) PublicKeyFactory.createKey(arrSpliter.getPublicKeyData());
		
		byte[] secretKey = decryptSecretKeyData(arrSpliter.getEncryptedSecretKey(), arrSpliter.getIv(), privateKey.getPrivateKey(),rsaKeyParam);
		
		byte[] plainData = decryptData(arrSpliter.getEncryptedData(), arrSpliter.getIv(), secretKey);
		
		boolean result = validateHash(plainData);
//		System.out.println("Hash result :"+result);
		//result=true;
		if(!result) 
			throw new Exception( "Integrity Validation Failed : " +
					"The original data at client side and the decrypted data at server side is not identical");
		
		return trimHMAC(plainData);
	}
	
	/**
	 * To convert xml string with digital signature
	 * @param document: Document
	 * @return xmlString: String
	 * @throws PlatformException
	 */
	private static String covertDocumentToString(Document document) throws Exception{
		java.io.StringWriter sw = new java.io.StringWriter();
		try {
		DOMSource domSource = new DOMSource(document);
	    TransformerFactory tf = TransformerFactory.newInstance();
	    Transformer transformer = tf.newTransformer();

	    transformer.setOutputProperty(OutputKeys.METHOD, "xml");
	    //transformer.setOutputProperty(OutputKeys.ENCODING,"ISO-8859-1");
	    //transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
	    //transformer.setOutputProperty(OutputKeys.INDENT, "yes");

	    StreamResult sr = new StreamResult(sw);
	    transformer.transform(domSource, sr);
		}catch (TransformerException e) {
			e.printStackTrace();
		}

	  return  sw.toString();
	 }

	private static void printUsage() {
	//	System.out.println("Please provide command-line arguments.");
	//	System.out.println("Syntax: java DecryptDataAndVerifySignature <ENC_FILE_PATH> <KEY_STORE_FILE_PATH> <KEY_STORE_PWD> <CERTIFICATE_FILE>");
	//	System.out.println("For Eg: java DecryptDataAndVerifySignature enc.xml keyStore.p12 test@123 certificate.cer");
	}
	
	public static byte[] getDataFromFile(String fileName) throws Exception {
		
		FileInputStream inputStream = new FileInputStream(fileName);
		byte[] encBytes = new byte[inputStream.available()];
		inputStream.read(encBytes, 0, encBytes.length);
		inputStream.close();
		return encBytes;
	}
	
	public static void writeToFile(byte[] plainData, String fileName) throws Exception {

		FileOutputStream os = new FileOutputStream(fileName);
		os.write(plainData, 0, plainData.length);
		os.flush();
		os.close();
	}
	
	private Document getDomObject(String string) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance(); 
		dbf.setNamespaceAware(true);
		DocumentBuilder builder = dbf.newDocumentBuilder();
		return builder.parse(new InputSource(new StringReader(string)));
	}
	
	private String getOutputFilename(String encryptedFile) {
		
		return encryptedFile + ".xml";
	}
	
	private PublicKey getPublicKey(String certFile) throws Exception {
		CertificateFactory factory = CertificateFactory.getInstance("X.509");
		FileInputStream fis = new FileInputStream(certFile);
		Certificate cert = factory.generateCertificate(fis);
		//fis.close();
		return cert.getPublicKey();
	}
	
	private KeyStore.PrivateKeyEntry getKeyFromFile(String keyStoreFile, char[] keyStorePassword,String alias) {
		FileInputStream keyFileStream = null;
		try {
			// Load the KeyStore and get the signing key and certificate.
			KeyStore ks = KeyStore.getInstance("PKCS11");
			keyFileStream = new FileInputStream(keyStoreFile);
			ks.load(keyFileStream, keyStorePassword);
			//String alias = ks.aliases().nextElement();
		//	System.out.println("in getKeyFromFile in data decryptor "+keyStoreFile+":"+keyStorePassword+":"+alias+":");
			KeyStore.PrivateKeyEntry  entry = (KeyStore.PrivateKeyEntry) ks.getEntry
			        (alias, new KeyStore.PasswordProtection(keyStorePassword));
			
			if(entry == null)
				throw new Exception("Key not found for the given alias.");
			return entry;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if (keyFileStream != null) {
				try {
					keyFileStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}
	
	private byte[] decryptSecretKeyData(byte[] encryptedSecretKey, byte[] iv, PrivateKey privateKey, RSAKeyParameters rsaKeyParam ) throws Exception {
		
		try {
						
				Cipher rsaCipher = Cipher.getInstance("RSA/ECB/NoPadding");		
				rsaCipher.init(Cipher.DECRYPT_MODE, privateKey);
				/*
				rsaCipher.init(Cipher.DECRYPT_MODE, privateKey,
						new OAEPParameterSpec(DIGEST_ALGORITHM, MASKING_FUNCTION,
								MGF1ParameterSpec.SHA256, pSrc));*/
				byte[] paddedPlainText  = rsaCipher.doFinal(encryptedSecretKey);
				
			    BigInteger exp = new BigInteger("1", 16);
			    RSAKeyParameters p_Temp = new RSAKeyParameters(false,rsaKeyParam.getModulus(),exp);
			    AsymmetricBlockCipher cipher = new OAEPEncoding(new RSAEngine(),  new SHA256Digest(),iv);
			    cipher.init(false,p_Temp);
			    return cipher.processBlock(paddedPlainText, 0, paddedPlainText.length);
			    
		} catch (GeneralSecurityException e) {
			e.printStackTrace();
			throw new Exception("Failed to decrypt AES secret key using RSA.", e);
		}
	}
	
	private byte[] decryptData(byte[] encryptedData, byte[] eid, byte[] secretKey) throws Exception {
		try {
			byte[][] iv = split(eid, VECTOR_SIZE);
			
			BufferedBlockCipher cipher = new BufferedBlockCipher(new CFBBlockCipher(new AESEngine(), BLOCK_SIZE));
			KeyParameter key = new KeyParameter(secretKey);
			
			cipher.init(false, new ParametersWithIV(key, iv[0]));
	//		System.out.println("result length :"+encryptedData.length);
			int outputSize = cipher.getOutputSize(encryptedData.length);
	//		System.out.println("result length :"+outputSize);
			byte[] result = new byte[outputSize];
			int processLen = cipher.processBytes( encryptedData, 0, encryptedData.length, result, 0);
			cipher.doFinal(result, processLen);
			//System.out.println(new String(result,"UTF-8"));
			return result;
		}
		catch(InvalidCipherTextException txtExp) {
			throw new Exception("Decrypting data using AES failed", txtExp);
		}
	}
	
	private boolean validateHash(byte[] decryptedText) throws Exception {
		byte[][] hs = split(decryptedText, HMAC_SIZE);
		try {
			
		
			//printBytes(decryptedText, "decryptedText");
			//System.out.println("has data :"+new String(hs[1],"UTF-8"));
			//System.out.println("Before generate hash :\n"+new String(hs[1],"UTF-8"));
			byte[] actualHash = generateHash(hs[1]);
			//printBytes(actualHash, "actualHash");
			//System.out.println();
			//printBytes(hs[0], "uidai");
			//System.out.println("Actual :"+new String(actualHash, "UTF-8")+ "\n from uidai :"+new String(hs[0], "UTF-8"));
			if (new String(hs[0], "UTF-8").equals(new String(actualHash, "UTF-8"))) {
				return true;
			} else {
				return false;
			}
		} 
		catch(Exception he) {
			throw new Exception("Not able to compute hash.", he);
		}
	}
	
	private byte[] trimHMAC(byte[] decryptedText) {
		byte[] actualText;
		if (decryptedText == null || decryptedText.length <= HMAC_SIZE) {
			actualText = new byte[0];
		} else {
			actualText = new byte[decryptedText.length - HMAC_SIZE];
			System.arraycopy(decryptedText, HMAC_SIZE, actualText, 0,
					actualText.length);
		}
		return actualText;
	}
	
	private static class ByteArraySpliter {
		
		private final byte[] headerVersion;
		private final byte[] iv; 
		private final byte[] encryptedSecretKey;
		private final byte[] encryptedData;
		private final byte[] publicKeyData;

		public ByteArraySpliter(byte[] data) throws Exception {
			int offset = 0;
			headerVersion = new byte[HEADER_DATA.length];
			copyByteArray(data, 0, headerVersion.length, headerVersion);
			offset = offset + HEADER_DATA.length;
			publicKeyData = new byte[PUBLIC_KEY_SIZE];
			copyByteArray(data, offset, publicKeyData.length, publicKeyData);
			offset = offset + PUBLIC_KEY_SIZE;
			iv = new byte[EID_SIZE];
			copyByteArray(data, offset, iv.length, iv);
			offset = offset + EID_SIZE;
			encryptedSecretKey = new byte[SECRET_KEY_SIZE];
			copyByteArray(data, offset, encryptedSecretKey.length, encryptedSecretKey);
			offset = offset + SECRET_KEY_SIZE;
			encryptedData = new byte[data.length - offset];
			copyByteArray(data, offset, encryptedData.length, encryptedData);
		}
		
		public byte[] getIv() {
			return iv;
		}

		public byte[] getEncryptedSecretKey() {
			return encryptedSecretKey;
		}

		public byte[] getEncryptedData() {
			return encryptedData;
		}
		
		public byte[] getPublicKeyData() {
			return publicKeyData;
		} 

		private void copyByteArray(byte[] src, int offset, int length, byte[] dest) throws Exception {
			try {
				System.arraycopy(src, offset, dest, 0,length);
			}
			catch(Exception e) {
				
				throw new Exception("Decryption failed, Corrupted packet ", e);
			}
		}
	}
	
	private byte[][] split(byte[] src, int n) {
		byte[] l, r;
		if (src == null || src.length <= n) {
			l = src;
			r = new byte[0];
		} else {
			l = new byte[n];
			r = new byte[src.length - n];
			System.arraycopy(src, 0, l, 0, n);
			System.arraycopy(src, n, r, 0, r.length);
		}
		return new byte[][] { l, r };
	}
	
	public byte[] generateHash(byte[] message) throws Exception {
		byte[] hash = null;
		try {
			// Registering the Bouncy Castle as the RSA provider.
			//MessageDigest digest = MessageDigest.getInstance(DIGEST_ALGORITHM, SECURITY_PROVIDER);
			MessageDigest digest = MessageDigest.getInstance(DIGEST_ALGORITHM);
			digest.reset();
			hash = digest.digest(message);
		} catch (GeneralSecurityException e) {
			throw new Exception("SHA-256 Hashing algorithm not available");
		}
		return hash;
	}
	
	public boolean verify(String xml) throws Exception {
		try {
			Document xmlDoc = getDomObject(xml);
			PublicKey publicKey = getPublicKey(publicKeyFile);
			NodeList nl = xmlDoc.getElementsByTagNameNS(XMLSignature.XMLNS, SIGNATURE_TAG);
			if (nl.getLength() == 0) 
			    throw new IllegalArgumentException("Cannot find Signature element");
			
			XMLSignatureFactory fac = XMLSignatureFactory.getInstance(MEC_TYPE, new 
					org.jcp.xml.dsig.internal.dom.XMLDSigRI());
			
			DOMValidateContext valContext = new DOMValidateContext(publicKey, nl.item(0));
			XMLSignature signature = fac.unmarshalXMLSignature(valContext);
			
			return signature.validate(valContext);
		}
		catch(MarshalException mExp) {
			throw new Exception(mExp);
		} catch (XMLSignatureException xmlExp) {
			throw new Exception(xmlExp);
		}
	}
	
	private static Node getSignatureNode(Document inputDocument) {
		if (inputDocument != null) {
			Element rootElement = inputDocument.getDocumentElement();
			if (rootElement != null) {
				NodeList nl = rootElement.getChildNodes();
				if (nl != null) {
					for (int i = 0; i < nl.getLength(); i++) {
						Node n = nl.item(i);
						if (n != null) {
							if (n.getNodeName() != null && "signature".equalsIgnoreCase(n.getLocalName())) {
								return n;
							}
						}
					}
				}
			}
		}
		
		return null;
	}

	public static Document removeSignature(Document inputDocument) {
		
		if (inputDocument != null) {
			Element rootElement = inputDocument.getDocumentElement();
			Node n = getSignatureNode(inputDocument);
			if (n != null) {
				rootElement.removeChild(n);
			}
		}
		
		return inputDocument;
	}
	
	public static void main(String[] a) throws Exception
	{
		//String str = "C:\\Program Files\\Apache Software Foundation\\apache-tomcat-6.0.35\\webapps\\KUAWEB\\WEB-INF\\classes\\kua.properties";
		//String responseXML ="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Resp status=\"0\" ko=\"KUA\" ret=\"Y\" code=\"0cb0db9ec74a42a99678598c0d99f3c0\" txn=\"UKC:STGALIC001:20140901051430343\" ts=\"2014-09-01T17:14:37.319+05:30\"><kycRes>VkVSU0lPTl8xLjAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDZhAFE/0ARFU+UP7yHTWDVL6s/nnJwAWPlZ3wbN3uAfNkgLRdpJcJa6atFsf12jr7B+AnGjaMl9ce8L5mo6JEvsl3dfRN8JYzrvuWmrsq6Js6xeFp7i3/MyBQ1p3EXmzw5l8LgxMBA/w/JCSLRGHVE4yk2zhkWIwqVjo8R10DSUIdHoE940ZLSj+YNXoiyggMT1Us1vx2HcI0RcM8gH9LU2MZGmdPq2lXGrfCUo6ftKJIzJAXvfYCCNMkG/Gp9YkJbLt2pXLPy03y9+DTXRv33NSBw25htRZrq5D4ZZvk7k8X56CXnRsTgY963FYxJ/FDz5zsr7PGINpqEfIuo+hVFAgMBAAH5r6Ooh8cz33h8Mm8EIzA6hgezqdWBTRcv9CLjSXkqS5UC//s3xzVFcv/X10/jiuoKBnk88OEsc/Dm3g+2AIpLuDpCf44oKKfwQP/KobDQKZ+VbycNSLnQ5T4LqoKdLC1Q+ZlgCQ5aRk6vzzjpoGK849pcH/DlCowW2C2Z5V7MI9UfkBChGzCPMvrZplCSmkUNjvApS63QynWFaN6CIUe6Nq6W5nQkBX8igb0Q3n3huHZfKIdeEHYQQEjoOSpq31vfV+SLfAwYbM0j7EQ8gR7L3qV2aCrFxlxuO7Hd1Z3MBHfQDQE1ArWyXIX5f/4lIAcq+EZmeN6eOH8wrVbnWG6twXqQmuC6jwW8xIPu7gIHDpzY2H6d3DrIOJs5GYiMALl8pmA/MEfIKH+DDlneors6pR3Wl7tCKPvfz4sR6zgAyu9VhfSpLA2nYU3xhGBT1y2H+/iUYGBQJzk6HhC9e/ADLoBlce+ga3bp7evIN2Bw0tGe8TtZfluLBRSHbLyOAvEWZyf0G0DQmDbwPyr5gt5Ta2ZaIRdCSRiHhJzfocm8G09D2O/sMaUUVxFqkGOpHfKxftVYfblht85uFQSBqUjlb+XM0Yvf6K9ioFiOSeM3/iSeLbmodo63vSVvPDVUo8Z/CKEKwRBZ5JAWGNd1Utanw/jbHMC0P2KwmzlXR2/xUZ6bkvl7bJULbm2z53e9MAgnIjvxHgr5HZ/07oxFXo7xR95WBpb9u19mvPCmodxwlmBmW0ErlOpRhvbvvTt6pVZft7HC2Mf+fNHAC12t5gAZkXYSCzZA9gLMJgO0Yx4R2PAkhiC6d7ax+HIkSJsDRfNX7F4hZuBYLQE5WV2VoI4aFcKsifqmuqmlROgPdTL0qdtHQXUsH7k6Ogqdi1ytsJK+9iiXqa+MeGT3wCnKL4swFkKHaihLDzeTvA+CBIKzQzxm+1g0E/cpWPqHXlpGWhnVVK8G5Vyb9HoHjXyUbaQa2o+L2tbjgR+QyWClDQw457NhT8E2xcU+HH/DROwHJ6jMNoypskwH0xqvd878SVI4vm3Uyp+ff6jKYVD9xXJwtiRqpJgLTl9B/QHCFixj6XeMTu1ly/7SlGu2zWpKg3WVQAxvd0VrKWWmbePVvH6ocX5XQeeXw+agkg1/yf0VJjOuKP8ZcDzUFlNtPlicdrDOGc/NZO3TLy44WNDdhzUodUYRBZYsg6GCKwkOMtEaZXDPiNhOo6K/V5pA1ENhBqgLgzQkRRqUnq95f2XOCydbhIW0ziv/pu2giMT33CrovphLZmktM1ssvHtN5pOCTN/bdTfQVwUV2Ape07zXBzdQlExsHbiFrfFUsHKMjmIZX6A/klSeaPQly1p2v5/P/Mm3ABz7tfJmKRvvFE4JJr8ZItlVkAECpxIaaaFIvox4j37Hfta7e+OwF5gp3WUOVqnHTF7W3NgooiIRFk/hTRe/MXC3NJiby3XPZICKsh8cBDmhZOCrKfit6TvV8GPLzP9nIJPJhYMT7b7lTW03VgVBRwqTXyzf8AOazbGLwhJcrgBbaaMfGwxQm2jJJG/TK2g14pqm7qfKzWx+ZisVGIzEhCduKQJNtMf+80glXnUKo4tqrOB/5POQ3jLRaG+yUupULUQOn6jSTmR5ceIM/ggBd9dJKY3ygJ7S5t434aDnfKli0/ybLdVOs5/2Wwv9oZpNpfPQTwJ6du9L0fU8s6dtopsWs4NVhLlI4LtL6bC2TCJTX8URl79YuED+NwCXqVi2qJSN+RPIN9iGoPNLjCMV5BUB9kOUI27pkOouF3SgqhHzAZKTTEOnvyUQaJLYx6u3n8RsdPe1cftGVRgM3PnX9qSvPe8unvHkeMcpBf8/xj/ZSUL5h8ZYPp3gp+hTRYMDlgQH5cXL6sNHxnLEGVGUaAX5sQh7w+chEVrn8LeO+GvWJ8zMUxJcr0z9kJgWLXktGr0Uaz7K9VUrJqrj+U8sacdTtYSCEfFJWRZVbh24/l+TpzODgyyWYHD/gu2Sm812jXiXZB6htKSPUwvbYlDVLCrxcmlyGkKsU6ei/yX9LabCsdb/UXgv2mD1+KA5xf+1xiLYAutS+YRH26NpLYSEbBOK7XwSduAUAYADpw3GCcqkRrkaxALj1qWAj3nCdUZzoUwucQUOoWDLUiH2eLHVBTqTgCehsj/quMOesV+4PrA9iU0Sim2D3Yf3YWbRikyEJXa2sGzGUnd/qgZ74XwtMxUPnN0m1+GbQe4/z2jah0oVWb7reg6Tyr7U1NcNt+DsucYO7YEbvs18tBNrV8LG3Skh6vYo+/uz403eZCWIflvtu0LXCKnS0jYTWmH9ADn/g3Erwvq7rtTSGK6M1bqh61jkseRD0MjaWk/I7Y/wIAarknStt/AoaHjPf/rvoVwCJj/R65BrXCX2hAi9RDFID8zgv2mKmUJa70E9gB0VMIpLergBK9epQY5L7/mSeH/KMCrxr4b+x54Xv3DnsWs045+9EQ723MvIpd54ywQpUxcjupqzulIqa/MMTmwz5FPTZHI3h9zzbuZjrjiJQ+eYgLYD3Fj7RyIBH3ZWKKDwhDtNRqsEzwNEp2cT4CIxYdUwR1fNvR8muuSuw0bmdjsqxvg4kZp9pDE8BGlOs0oZp7aXvuxjf+Qd1+cBhtP8BlmldunEQZLREITsL7T4ve/mLruWWW9YvIWdG87cmcrYGSUpaWu2wWQEeWjWnK747IXubfZTf2igmjGsHSRU00m3cTIuMhvvaGKF6ociKog13kPyrYT6r6eYl6wBkB4kajO70XHaAObF0SOhHwkZaOyqlw96SkUVhU5gvnI0cIJhm5Y8p+UEZGKFdzguCBpP5P7KTpqp3Nldh99DH0drYR7kVogubmRYTVx9TeLteMgccWhCIPhF+tPVJec9S9VZIqSR5QD7Hx5Dfs/Ij/qd8U9lJEItHyd89rCp3sn3tkxE0HjYUEViyEu1abC5HAXPfJOFJirMfEYJlF8CBBo/TN2fB71eY1uUMl3WrtMxg49qm3fZfGWKaNhAkjWp1seLhjTtHGMJ0thXkm6FdiG6p+BMXfgNc4l8pfuM2oHBaEEAVVE0PfDdCfcC8CZI52FR4//QoGE00u5JDQuwIn1DNN0+JiFreNWEEokNl8+2T/Cll/U+Qhiw6+neYPHYiFBuFGcWLasqWy7DPrTlJWb+vipdWEGpArg/oZzVgK5JmZDkd8miOlSR9X8uUciWxGMBXUBd7aVik4JUQXZ95lM4TEe+QHeyvCgVHzElfUtX5jlebKo7Wmaibqdr6CiEe4IvDmHz9tK+cS2JZdB0GP75ta/fOIYGnKCPBidMg+453RIi/FXb/OumW98Eba/eY3jDhrM/CV5KYo1Ts65RNORO+EanpixaXGuW9dnH+foKOpajnbCutN03hYLj/tvAIEqtaValVQfR5Sm0xA56jh9KJZPe5jYaBQDiIAmBdRq4qT3NRgk/Q1T7s3V6dEMvvvKJ6+uko0DqZrm4gHs/5LM+oVrSHEvXiXmQMZ5SNb8eOK0erkQlU1/nOO+4YN8pgWif3Mt+ROl5KL++jKjnKtlR6akeIu4MM461I+1DeEkNrSVe9btNWGlDh/z/NyTBdcifnevXyQkJyX6v3hgZ2tztvyFSoKdh4Jpqm5q1L9RClv7Gymd662JVEMGRqKdDI9FZx43U16IYpqqH7xKpQuXpdV4OmD99jLoTm6JivkYebUnKUWc4AMISEC65byK/qwVvadAyZvrA9itH3S41B+zdLaeygFc4v7LcPm+CQjhyLoIPK7GxJTid9exMKZfbw2/C6EZbTfxHzNiY8hG/whGYYVAJZvczzaJMbDJS6pPY1owSj87DhNeTMafsit7LYft9PrWD6YAVPkrpiyoz4j8ebgK+52OjOvABN1W6DNNLia9U+SbZsDekBvcgJQHNg6VcEGwyg2TK9yp3EoPfHqlkvTM8rrxsXNmDgftbEkQUY9r88LdnEBv7Egc6rRt9MIrnkhjpHtoFEZCfFpfxUx+NX0GKXxqlqSlLkXcjhYshN32fLWIqoLdukux0bgZnwz/AL6ah6Y58bKSNa872C6d52sNDlrW/gjPwEMqKlXNWmWx/eLpmzevPSm0FHIUg5Ye/8zLtF1BGjGiBqwIDp07tZNzGvi6eRwlyyOqmx7kV9QU2FOMxudaZ5NTJ+U3btOZv9QixcDdVcZQrAHaVKMEyEQTi0/KvVhsTEMU+GRhp7vD2sZOKucium8g6f5hi12L9+O2ZsZUmcbikyycoAsl5pDliVCbBnYZmN7dHqA2kS7Da+9KRgWwwjFCCqnSZFKprKxNl9XrZYMiohjCE2Q1ZK/4QP5fR2GvZV1Sl21KkOGOEgjHc4tSZeARIWyTD4k+Otu/2Wn/AoGYHxx2LzsNPeYjeckAc902LXzFQtHkX44t7Yexk7dcCINVPslPx4cgS/Y7tDAzl20nIpfwtg03iOYOiwhX2+xgQ71ZpoOoR+rY7WJhGO/u5xN8b5CfzqZyYVUewYlVYTojW9ue4m7X1dSGMwv7S+BkTJ9xIu5RPp5rQ87vZzzggDAHxT04EloxTdAjA3uDsnhIBpDeVoi8Rq0KdUgBmssF7NykXAGd79LYo96ATOQDjcW+NByp2mkkPNZEF7P9pY3Ute+pKCYsO8RKXcFrxd+KG0fJXEPq15/yOxShrCCz43bszElE9qZpFHQ41yygiPcXhwFCZHb/8MULrKSsMTtJ1PhP3izbnk0jrFc21kOPYRdPm2uBa9jxGzfsOxTS5UDBabG392FcHvf3XgOS9wXXYAWadTQFkRq1scno6gg96Tm4pGAV2R42je13Ox5rNEsQop/MpU3ZsifcXOXtLpOvirrEwfZ1rNl6rCVHnP/7zgbzWxN6nGub8bP+NM6GbkJ1SrkK+90MYGtvmlsKcROuqdTf1z51kou8fMjFb8pvmJsuF5N51SYUgk3lDre6tfZjwToPE+NmAtRy6nInT9tgOaYrq1EZkdbwc/Ng2eiuGjZzmAXwH8hz0lKoEgxOGo8QY4wbA6mUVBE2yePWYvdbjcEoJan3+g9aaCrM1ObqRYTuc6n1CCvQMXFIyQLBBKaEN4eMcWGSPDYPTmLfnbpwCn3fOpxx8aKE+0IDXmXDsIy6MVuMxmnHN5V2at6oCiC74K2WBX51StijKFhiy5OZWBv2rI0lGIeX8VEr69ZUez9TI6+JKxnYXUN2sT+eGP+Ldy3aXYgxMEV62OwaPcwxoxFdNkpsVIYXPw37+cte3wD3KubBpQ/3+o/tI7jbZx5a4uvmS9jXauwfQc5Q90q+xo601pI7Nv8Fwx5o3AD4AuEvRouCOwNXpQI2VIjKjnBMcBuPD2dRQupz41Mu3tRPuCx4jysx6/OOU8eHYeOKAbDiW82lSgoRwAIv19Oby/oASB4DxN+ekrXMEGREC06usfaTWBJphz9Q1Vb4XPri5+8nA945kkJgM8I1dLde2lZ94V4YAZNAb6pPQeeEeATp6A5guPJn9xGkVUWbYuK0pA4A2J+uUcm5zCLuSnmdthIEh1NoUF1lDvrXJ2LvS9FhLJQhuVgcfgARsJpEu8uT0xCgjxCW9grK2h0yVDLZV702H961eAjTvbe5AQZIvT9q7SmD9A4tIOfZaQt6TcqX4YQcVYcC4NNDwNBBezYSuML72okzBtDS84EAzY/ewtI3TMdtKX55Etb487Jetbuw2x50p5BdLw0+CVSt01rnriXMbsW5mE7NwUV+3LOx9N+FWdhRvKcJv6rOiX26mALJJTHw8eQACQ7I4XfoPxTCZh9Pm+KpkWxGmEpMd3VBlAx79f4j0Ja6mrv46qNZuWabvGOH5ZyfZaV5blMZrwcWmXsXZXOl3c/lIzZsht7iYKPKJF2RE720jKGYSCw8KCXjH5LUUu3J0pfRbPGYt8suiptM4307ZTUGfZVm5gJYXeo1lGi+8VoWcXDaygfWt6XRiSSMfODMbsBmfhGxiTf281PbjfrtJJagwFEzwSD0bll+Zq3uxvw6NvZR38BVM9p+Ag7hwm0CbnbhU8ZHhsRrlPuFVcH7J7yZZwp9rGDK2rht3qH7vyFF+gBBimChsaIiP49HDKCumPKcz4g0ArA3HyliGWOHGsatMKMiAdaw2o5ZS+iKN1H3VrB09+DLzEpU1AA842TEDYF0kiQPv+097OWetDDw2W2ecHflYds551hCACBZa+rK6Ji+nvFjnL6rjvXEm1u4QALcdkRrTocV+Lz7avhoT+yi4TSIaVi8WgzSRncfRHGebj5Mp5aiC34zuUR957rKF71IGWPSfVZLGrVTr2XVy1MFkQMUe0oFNuSSJq9eddmVcZro9M0GNg9gB7k85WwgEfM2X1X3ssqlTXGmoh9jzE0jT3DLJeL2LPQH1pSJ29uRZKNkmm+O42nCaewckQkxHMNHGqK+dYFkJfC8apNdRIAFYZt5spDZKHFSv7f8IKpz4LzJG+vjoH+rbSpt0z9iCAtHMJvpzVZSxwvyzP/Wl7LDbIZVE1sLucxJ76hZNYbCfDt0qHNR9IlyLaQE1tx1TRJSFhBdoA4lvbljov7I2rRSlBzj7f1Ww5Gl/wV5rR69baG0IjmhCe/p3uweJKbube4TCVM8+YAgqPSnX/2uevfMaWYGmXhIAQwAsjQl4q87E/pGs451LrwDYFAsS6LDc61Lv5spaUseB+yasCchpEBLo1sYVbwKuemOVjZw5CIJkk8kIUACxai1ts/1bl4kj1IDoQLgud7ral27v8myhOCvGb1t4ufzkNOuwl82nIa6r8TuFWIfSYh7rfYDDFrgc1ymHUR+927xmGPsrOWiBFMCHnu8AjOemGyTcY42D4TNfXPEPhRf9ToCPpsCRcpgipNZ9U8VH1Ekiy5jW9GmDKroEN9MIBCiOHUnJ9HHixNQbEKMCXv81uMZDVA6L0la+D5O8mELiqa2Oi/VacuUMFP5Jta5tQE9wXUo2BtHq1ccZ4w8Jw7aYLFDbj4BwEuMELq10IEGLsmTkBtyfXagaXNTcZY9qH02XCxIlfWm9fvbXWGpRePjcwC48biSoIivpWodGQxkWMZLoqs5hJqPJ2HeaQUxxDCy3ZmhMkJO5DY4d6YOfJ3FX/2aQ/7CdAHG+R7Szt6rf6AzrjEqAuotECN5sAP16ZxEiO8Um+bG1X37QuP3bm7BKwGT+phuLRU1VmF67I+CWX5hXli2vzVUjo7NM+QtRKO0FKE8n9FPRW+4uq3RDbWnHY2mxDM1ctKPfkIob3dDJcodYLuKQoI69SdzYM84oeBTX4N11+tz+63uK03L0MbkciiEtRyShQl4c1R5iGxCCQb5QoWB6GH0tw1PNs9Y9gxd7HZFG6t28wNxkJnxVkBh5ozzTQCTc8loXNmMVFsgtbdXGdOCyfTh0hg406WyOseELG5GIcAKcvZWo0evxBhohHjXlO2zadqCjBh+pAKuteKQJ6eXuXGdHml+O4dUhNFvol2IaftxT97h53tfaA/geMBBzGmSQmYTFPJJKnnb7co6OvRxidNxhQ3ov5ezTwkDue/2dM5YmFN2khrODU4YITI+/M7cN5RD6GA2sT8z2cvYwdJhBfryGDio3KTzrY6gfAzyDsCW3PCTfc4rjDwYqM9WTGFw42aURygkAsj9lCDlsroZvbfrbPxCNb1lQ6gLAsR99ZBCg/E7TV94dRI8UbPvTyST5IhYcoACEzTH+DxL0VMnGuSW1Xd/c8SahqfnGSTatKACht25kZ6Oi7g7vuS+gsxEcyEqipVvl7vNAVUvd3QH2swEne3Ko5i09TS4ITcNwCWv8WZY7svtqZORgMkcYFmp/8hq8rdVjU3eBSJQwCPtVmZ5Q0HJySJPOE0RAb2qIyQb3S0WWLkvvT1lzqsXchFUOdta5FWvrJdj8mRr/SQuQohvwQmsbYK/dTYJaE4W2KG4DILUy/qufiYx8gTWTWYXDS52MOplnciUhfT4ETJybkAXt30htlvJS6nRg0CbJKPcJaVF/9UrD1pyt0o5uz/hU+BicZLBVsapO5eUNiFK56kscGR3zBA6xhR862orFA1T2AYmfhiuuCpTktSGmqpRoVczEoR8HW48rZoDRaZLr0JYZB8ZWOlePj/ADTvlYTTJNlVmLv3tY5eKN0KRt/g1smYtL4GvQk7h7Sc+9tV1zTrU+jm+rLnBSwuzkKhLcZRD5rFOvINrruvvAuywz34YtqTqN2c0BhOMhN5XwEQBId8IpqkcvjvjqjBNnCTtYqeU+jcw0URxibIcR36RbSh7UhC93RxTDfaBZ7Reib/1TlzIeq2TuoYqq3uCLYZG97KWAdrZgJeKWmVzyrEyAAJ3PL67D5KKGpk58hCt58VXK5d6IIzcFYdFoCvi63pFCO58olURkv20uKnEh8WVRLr2wL++rRfdqmSFoPX4mgs6KAUsiPQwjhB6v/YMgD+/8zqLjN24RMtwnH0I8uZ9MW+MhH5OAeXArOd4i1QDNzBh2zA4+Ki9sQ0+ayjYXZzN4xXNhzwkWRz8ocZdYw49rpbSXdwjckKT3xFNvmOB9H2iVM8VPXlxqaxvfPGfDdtzAGYZ2dEl0tHRVHurOV11VLxnHuVuTc0mnTP3VauWpTyij5v+enLzeg2Fdo//tKhUmfWfRbAGOKfY7OsRHPo1VOODOOOOrAn/ysvrADPuCsyh6ZF0yjqn/Eo/MTz8EyIst2/tJAFOp5YunzV9yUL9ODscrQDONV9D3DIKt5PXNAbbnnO+tKi3WGpmVshuoQU3FS1XK14RpeRGUUwZhfVVIfYoLbeKCLDZZeqSNHkj+OefFP+dj1uP21hCa2hqRC53b4dUzcr6bCwt/oBYt/WuA+pMuj99QghiD/7jpjBK4OTTUfvb3fQMjNzKDLBXc8DtIk2aSs3NR/BT/uR9dnDKUw/jLQe6h4nrEccQ/1wnrLCJ7z4Yjpul465KroET16zOslvIoTYFDFyNrVHPYHUcaNS2Da+kUy/z61j91DY88uYYhFJ48L984OZxfd/BV8ohKTn82NFbCY0DuQLhpw7iFEj2gZWdwY9M6ibMDExaUUmD9U+xdOOO9t07BTrKP71kebmpk79oREsaxFspU2bmr+ztWgF0nzpWzd8+10HT67UamqfIIGlzlqLQ34JooO/4V/dLJTkLpNUG9ozj/w/qbfs4HQNxON2GloUQQ8i9Ar/OMcHRAPjSzyD1OEWD60Uz78LkQMy0z0ynP3YGQZsoyQCgUXvfvWWw7TS/Q/P1EC9RbEac1vzMB6foiCe18aCX7EV9HZPChPtcpsKYUBvhD0K4dBtpTyGFiefSkYzqal1EFS/VLeRmdXESTaA1soCkD+Efqfo/YfzfR0ehpMOJdSa+x9LPC/uqZc1QsVDrb6jRzywZj3LSdyRBdfvYHdPazIwmjL1JQiIrq0YziUwq+zGG3CuCRRCbp5AHc6lZW+fXVUDTlXRY9dluCfKJzCkMo3grxZxYmIj9NadZkFG+TNjfyMq2quNw8zdu07bWPcs2yA7jCctVMlGyEIY/2u5iPMfMNdbLm/SThz2y6mSwebl84lxpEPG2Qrv7BH3Gcs/dce4EijFkAMCpMCpKAYktJyfcOmVbCC2ejaEO8kEUnGQoxKytDFTf3tLPAnS9d5ppi70ZCWvLZbORFjdRMW1cqEttJLTMPNcrLbWcbh088mc6fVSGFvS9iNAnwVv9wNeqwkjF5oHxYxXMjagwf70wpmfCFbjJQSZwzN5yDBcgXVWvdBavu//+EFR4yzPcd2c9mniZt6wtHKdow/PhIdS7DFHwmh6A+knIGPVWHtefCmeSPFitnV1/G11ldbE89F5HC6F839idTlTWXZHl2bzfqnRTLwZ6uspGQfH95Y2c9hRcqkqhxIfiXRGbRDL22oiGduVmwEOtjdZGFd/zwfcufNidGaeErc7vRRMpf4F5+Drt2pnUGpvXjutvg8GMKrvFz33LEXNhy4ZfMCzOjM+0O5ZUKwSpmFjARlglHYoXihJ3e33XDcpW9jyXSzJAsoahXbTpUehGz9R0rA2UapfMoNaVqYaomBNfd7zCyjMabu5lWUyhkAhDshr6gn+fhyRCGzYzzJk+lmGhC2nvdX0ZfnCt6WxSUR8crkEOnS0hjJHGcQe/4SaCf8zX9ttQ/VbXLGMEAXyq86MstEwUkaqsMwlR710sMUT9tqvLRwZGqMvJlG8etcqb20Pfwwa57iGvklNjsd1HEq7iuS4+qfRt3F5py5K6kINMbezcpiBnrNxWcGyN5jwVxWNMkGdwsNqjnh6Hb7foV7hNqXkXPcVoaeSAtw2qZfuycg4yTh+69e15pY8ahMxNLcZppyN1spCsQxBcFWXTPP1MWevtTDpgh+2pawDipecuxE3fph1AzKrQIPBpmg66HTomIpNvaWoJhmdkxHO0WIOjkKXLg2wT2kKsOdC5q7TUOneQlMifokDZxsXHAqtYL7WdbjdN+JQRnb6MZpE4vV/DhiKlEfBAzciTA4MdFvoIO6U7zDEMrXyflVilBjO671LY0uuSedXZV4OxwyOCFSjuLPy/p6E0vzfPYbgSG0QErJ9Gstkzr0JTW1W5EYJypNO89AUsViqd+Dpp0tR/4k+h/MUSGolC7LyKZOKFOJKjRRkGOiFa/kalzZn0kKvEGLSyJhZJxdumxPgXN5vlDebgrTIARpFIme8aTBgdJ2+9IOsE4/bIBbk+EAClw61iLtjKVDqY8Frj0a6Z9qQ4IAyKIL1Nb6adla8JjeO1npjs9YVpPaOBlo2S9IyN2G0IHxSwJlVC0sGic0h4LTacYfJMp+7x3fDWHvUVsvLpk01GLoo7Z/9kriPNhWNeGQBbzQZWbAeGVXYwmJ3KA41Ksa3XReVvxvRZqh+wJyVoaW+mMuH6/NE3IwjLG9cqwGRphJm1d6sQXu6+RREwBJSCMqmFgKGouBUhJqCCZgrjA9trWjAiNgKpag/QHgMvSByD6+aZKITe3tMZ1Q6GUlGL4hLWcxB5ecw0PXqm4ZoMD6UiBZJ1d7nMnO4DFxRZ2/eWhu8/6n8rN+Fo/9TRgoHf0vIOdmSRWjIjyYO9KP/xn1lmKRNRE8a9iWv4ql5jNxlcYqQbHIZKcZsI0mEoegz1xamX45eocbo7jPTOAHv+KoF/YUPMODGlTap/nOr0v77HTgatu3BvLWp4vVYW/nG8dfblNf5zL5NGjofQBrAX8Jh+MuB7eODchmZlXCywdca+1Lr7+w/heez6c882tIoU0HA4VkLqYULSeKOdrah2Yl8UttfLMhpWbCMchPIXgwQdaHFro79UIRlUdH9XZBcJqu459pP7vF4fdb+zKhuK+ax4juDTav9UHuf+GXnOqExq16VoqhW/PCeuLWhcWwSTD3dFP4U9QgyFsODRskISN+eq6hFu/AUlS4nbBHyChYjapqO6LwliWOVtJkHoaGGp8b1kBVHbNCjzLJ2vlWUPlbAhdYLIU03HxGyu+9EY8DhevhRXPoub1PDKNuTPWv5zw3tV7oCWZLsyisDJIrLcoDPkK+g6g8eRvGfpu7mSskD9hk8i7PRFVt8ZIDD1rEB73V5zTF4S9bsW1/jnd8VW/KbHo5bBIGIDboyfK6HGCQY7GwiqEl3XftlfXfnn0yDjalJvjgbI6LLQFjN1Genevi7cfQLTfoR8lsaOUhIXNrFbDVfHZmpHEw5zEA5/KiwDjQtnmtqvV2O+OJYJMCmmmvatJgxEAPk9H17bmJ2Cvax2j21MNFgk9jlPKOoi3IDkYxlYlw6S6QkgiqBPqnQSMVWJaHf4tJbHBSEsw2bOwaAgsUPp63c/5ckXn2DCrPgkXYkMaAsP81Iu9jBaStFpwksBKIgZKC8FDPPRhwEZBc8eU2R56s9kVhZm3P/9bHTMCxlFor0Et0Eh4URssu9NdxSV0hcG4Gsn8b4M9GWAVnNZrXBzq5YWCBo1LZ3iQ/FsJfh58s9MIrKz+QpIl02MM0MKroDtYWDDSkZyTzOkyDQnl1v4rwxYKzqDXKSKRbg9lqwAtHdpcWKbYQgaR8x7z8nOKR2I1T0i8S4uXDRW3z53G4fUcgSChsDeX3Btu7QQqmq868KETrMvBGgCMNHXvNIq9V8FswQka3mXIRX7/VISJYMjde54fAr1Yipjs/IVZlXT2isy0hhJHGBCYJOfirOcJDCx1/pOALB0DqP1FdCXSKtgP5Qam2YGz7qLIjx43L6lqJGzSa2LZrKNP4PPsf2/uQ5p1bAKY6DpxMhcH9+XE3XeJoyU5ianbTxLGxl0dCLVhDgf/zD9Ri/rfP6DIhCcUAmVtzeB+cu/lgr9RESL399s0zQeKY/RZtDb64Ej1BN6PGwOCGUoSOwIvVlZXAPmrII3pYip06VJU3wuWa6sn5u6vc8IcONfqa95H38ab9FSZ3AHWkctZ+lfWW+eJmqX2CNeh6nwAzfODTimT6xvmHTmQTCsRXIoV3T6X68GOiRBRIdcpZe8ta9fIOH1F7pQLzPJerZXpp75b5RLEOlaCP2jze1CQYXNfxZhqS59VMDMLa09p59hbiPU3EvexkEx7hhQ4PdBTmsl5jrJuU9uit248Cx9apHS0LFAty06nP3RaXM4e4dZBGUJfe+pcWAwooB2A5yLCxXIC/AOVP/Rxzs+IiBq3JsBYVK9jV1SUi+1b0RxCPZB+D2B+nbiVx93LB9EDJu65szJy0DMPwcqsf3jGuetOzcScFvybV7/+blUUdKPt9c4BbF/Ys+NwmMYDNOBLED1fkyaeI983Ygs0t1nNCoNNmle8YPoWY+I3C8NhC9yv4waVhwj9GG+O38iRKxWpgXRexWPhi8JioH0C/Jq9dF+HmfFfia310WXdz+vVhf6im703T5Oui3IybIShrf7WIo90olqBVbOHA3eBLp84vZOWTKL307K+IdGwmFPhBApZ1wQ+smBGKrVQcDAAhtJ7wmtVfLeggf02pZmA+2mAlkVoeciIASRpk1W0UJHe6pTk3PkRqDzJV8lAxiSCNaRLO+AI0g13uJZC2lShO/Fdx59J0HaoSZxHSZeCuKCEe/qpCGh74qQma7mREE33tQ9q4TXOMHFgfRSi+TgPoEiag3xR2Idx11MZMlUX3AYeXx3yn7qFs65a+sGM82waWjIZl27+CcekAiEMa7bBLj+ruzvWp+tX6X09Qm35xiW9trQ5tqWmFvdUMMg08hOhlsEBy8tkyuL1ACRq5TRL6TqiFGLIukOxB8GOTWstXgvgyoyOIRypPCOnUhURJHvAHZXedo+nHUvpv/drLuJ3/DEGp90j+Opa2nbr20TvJXyiEj8uQxOROm1hv4XnKt1ZsHql96EwoE80OQNmewIwxk2ZS9tNlbo8ZFY7ee5bHGjvSLOp4iLNxz1e8vCR6AtuyYDJonvAkZ3D9DaKlNYhQARJgoCBuHaK+Rl9GvwMoigwZtTh+DvHScuVM3ei1bJnRXMQYpmWa8eTLz5bZpTgFTvORp+OutIUlDAqCGLWECBdept59tVWBDX9oAjv9fgeAKZ13V9KJALzRMUVhrKFcYiQH9r6oyCO5uBcgUC7nTy4pctb3aUM2vY1/xC5+rETO6OWZDlKIajBojm+6efAUawby24poXNc1y+XWtnoHthb+IXqQUROsZxj4REl19KJXSe8OZyexsTLiTktmoILlBTj5F1jtGUp91cQNxj6diWVyi1cyVIidCejH2u4NLBUVVGP2HZQmJMc3DeOx3W+pyzd1JBs/ik0XU8PSGrtjCppSCuSGQDS60eqKAsq3sQQrlv0dCggBVXvslAgXG5pa5tKOFOdkmUULb4b6SPF72r68omBioF+Rj+xyQkk2Vx986iYaC3KSyJoT4/nEFub1O9pSwJ7Ihxe0dxX23bbQVxrMBMkVWcFJRubNDVNoNK8Dai8GhJQDdkX1fbYyFSLpx4Syt93T8AdMY98lSd5OF4otWFDgofQ6dCEEv3YSDZ2SEgll/fi2WmOuDqsk462glNDzObQ/S8BBvXmMsgkPk1hZIHUyPQa6ufKP6iCUC3cORkvpECg+e+p5Of4GuhT00diLObIyNUVISOp8tdpvURnaBpK8Yjm8cZc28CZeqE4g6a7deXTx4UznzRksVpHJd6kVVGz0214GdeLhgKZxQVUkcKHhRtgqVWckUCj6MKr1bGoOxdA5Iid5UIZ+m7NiUsSrUgIB/Hx0dBGbD5rhaLlAgczLcCLncQEwwOMf2ZpWGRp9clqFlrHOJ+O0ThsTiw12FiwaWFPf2eNy5dNUgLyXEx7ojuTrFXbzc7EuTTSOY6f+aY9CachoV120Sxa4H+Wrk1SrzuUrFd9Wfqf+7kbus1M8kPliwNCbit/WDI7X1B8qClR8B4s7pSD6JmACzFC4bXVpb7ANkKEvMXB1HSZFI3szhTlbj97IYkxgwMCIOT4tp1oEFWNR4ROPfRnSlurIDQvfBmTTAgNik2uKF5dzlOYtAMew/82u6FXKDQeQusnrAOcxEET/NgGbXt6V2EY96Tp+i1Hw65qjlakxPzhzxAIrNSXPQu/EjXHPNsTsFwmezSwcm9FyomF8LpC6dCKQiifPGh7URXsrgqVzBUAvp1fNqLiNVFMzpamUHf8W8fu08t7XW+VtU1y/5mXTcUcEn/EGAzMIkAavHk94gMJI4p5AjVcORsjLAiX1T+ut26y/SSsBmxF/3y1Y04auGb0nDY/mD5wRrlvV/IE2+Iwjduihp+W5CYlSCXDOX04iwCJFavNAky8VwmYozXihOGBubA1251ylHdCuPZmWHJUyYDN9hwqPWoPMN8urlROPPhtXzsPsIzHw3444d0/+fVh9S76PVoMv2145gkKShhRPNR/FOE18y80Vbdmm/TL4ovxLDoWzu8c7eBFJxH2855Q9KXmT3opv+Hvml7Mw6S/FRgOYyBtFVuRSuDmYVW5gJyTGLWVJGjBMBDgGO1T0bzHlY6mHJTYI0At90do1+TvfBuJGP4tS3hsQ52BMNlQFvlAzzL+dsy4OQ4/5GYq+3M0rC0J/ohBViVMbbnbE70lbwCUf16P5j+MsNO+weqWppvl41Sfxs4KsQrC0tC4hwelpGbSaETQRoVNjRCryXi9s+8dIXAXehEfzDw62x/zQb4qd/6j8Df1J5XqXdGxoPy02nwF2ISjNnkI1o6thnWb9ocYUNqnyWH0vqVSMa77eaIOguPTcOgPfNDn2zuN9U+MTg0UFYruv4V2+EZs/f10Zwf7fo4Mlq/WrAw4VKLXyYwxbcAa/S1sZjmyi5Jcxz38RxfhAcfHbgPWxBiF/higQTL5FQu4sG9dml2IkPLoUVZ6s1v4oALzs3jds9SwKc8TWvZv1vdYEiIbRqDnV7e/Ls2DqWjKztNMOetHoQsTYZG8ssev6n+n9dfAKxVcshus2TewwVk1xK5L1M5W9JOmTXNI+5TIN5S6Q37Vudsmf5Ai6sFwtB7MV30+jNdSAzWEpzV2pS+1JO+SvxI7tvVSzLTl4L7uFkiUFTxKk0zDayWF3+wgLtslvMI66h8yY4W9mudAvCCKN++QaFpqY1kKxqXZgGIHbFF9SXjeXiWpTJPGV6RD7kpMI3epnZZf/WKfb8FhNeJvv7iYqKRpWCsBGGi0HskjzlE8e1dw9iLF09eK/YaGYCF2P9y8Lmv32WNTgdLYJLie/XN6U661PO9XJ28r4+fSfYR35AbbLOBQaIgWqgc985u5ibh9qz2mmSLhSqx7jfWl0U6snHRF9CZvJ3DzRgYEZmznqk8ksyEfLXQQLe3QqE9Ody6jVZiP/fyVUx+4hVTvVUc3gwPHLi/+I1PC57w/PcPNaKL7GYGck2e5UirbjRIg8/Lg3U1a9UD+Yv00xFd69ndXPUmy9DpMbOlZc5XLk2kyoy61+vghgQbu0XPKoPaTdO91t3EoZoX4iWb0DWDqiUiBLqc30sbdnYYz6ycOUZ0Y9RHz4VJhVoLtBi1RKGeYwE+rFQyS7jxCNRkZ6gakIydHP6sgrBlCprRl8FHOUw2WDUdNa3bXhXmWv2aQmoOOgd9B9IXgrEQKllPgE83RU8HefLRTuzPQ3WFa8O/BedG+BDMrPicQ6DZGxeHYEVi71OeO2mys7afza4Ftl4pPuaQKNIeTNNtJ9k+tKyD3GZxrZRPliQqmbifedDl+0LuAD9GrL8ST5vcgVEJGOD7mNdgU1jFET0BV4m24a7txN89D0rs0oGhRNBy9S8vewqh767AqKLHuLwF7BLEp8jiBD1tVTp8+2BLjZBLOLXTPLEcA6KXZCvph3Gjp9wh945EAf9qYdP4B97Fqrjn4ENXA31VROPSFeZ7unwQ3CsRTElPBNUzRWn1hJVE43rhJmYa7Oq9pidCx1EolNjPWPKWyfZFpiETw4+O8gJ7U8bZ7kTk6XiksfnPLT/qhA/xbkdWtyKNTsL55xMUABVHMxaJYxwLwmm9naFR85+5gKOX1lYKumcTY9MostIxOzxwKx6fgPIkRdonxHxyflQ7cgJVI5LvrkeR3s6ytXpNaC6sx3FO5kkxpyza5Q/1zKv8W+tODgunziZtm0MEWRqJS+hYy6KTw59KT6TykjTziiu0ZKx5zn9tlft0v8/ygPWl1ODquuif2oecOQUSxt07o60V7LN0Pb7RjycKGnQDVGBhOe2d2NC+bFuvbjKz9dGliJ2DDNBJ0r6nBvaJ4ab1ciFgRg/1+ZhCD5xIjzmd7+/HOgml9ZjTGImEy/dJv5Ou8OJd1R8NbxH0OqEBKmtjhLGlj+mxFAHhVqUPOjmOipsV5CBPjswaGlGPS56G7YftVivF0rEU1ciRNY4S3UAJUidaRsHAwtzD9vE1ugnCnBXcwZ7plJ/YzbBufiVGQPD2JEaf0rjmbYZbPP1HJrgNWfBd7HkRBI0owb1nSbxzOlxk8n0wYxidKv0PWvPDeq2VjyJ392ECYqvutvu5z08jekSfzZaIe1GKl27KSKB27lkhAs61hBwnIAjKbilmytu8b0ubonnX/z4vZmfMeB1jZAFLYaTwahNe+tMLIpOWSo2yCqk1izz70XFSnLECbRHM3B9SviUnlUsxiQAesekvU63R0BsMKnbrWVDpPOrYjQGpLKInyGDuzWm46jIayFGBjRvfqzQi0BYejhd2p3fC88OXSd6qeuwPx6Mc7t2yAccuAF354TbzxsnLNnGxEppnuafqhuhIEkKI1cBxWf5XeWsXMFda+HQ2Q61UIh6i2chbEK6tsK759vi0s7CXEtL2KyUNiFNspw22cPu+BlI8nS8nBCWSIM4tZIs4AeFM+KDz3Vxy2Vy9m5RjWHHzwIrf+cwtnuqii1bKuTNGEfLONN4FVeq6Io4g5I6elpg5Xd0daXze1iVXIG1PAFk4jSAT29Mh7Dk4fl2a6xX7PCShIkgVKYQGK9hdn7qn7LwsPEjHIoCeMXlHvZRERmUaYGzysxKthQvf45nE+64dceXw=</kycRes></Resp>";
		String responseXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Resp status=\"0\" ko=\"KUA\" ret=\"Y\" code=\"99e2d9ce6470473da8baf887f81a2b69\" txn=\"UKC:STGMLI0001:20151029064602333\" ts=\"2015-10-29T18:46:04.449+05:30\"><kycRes>VkVSU0lPTl8xLjAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCi0jxTW5+YhRGkiFuAfGEGRf933mK9RPzsStdE0RxHgacjBhqnwitZvQOKCCIwiFrb2mqkfNs2RiSgv/C4y16eCEI/JKwbpkjAODUPvKS4bNItqFWFtSt3eWZbPta8I57bDfdmelQBC1EXXIseeXEMkJyTvlR2Y9EM8d9ZThYpDR3My9FEL/ct+Ug5nje9+L2e+QwgbMuRnWFynuqYWDVIO0OUEi7j3ONAS3FqJpVD+kDcAidRHKzRAtpzOX2I9zTR74d6+il9ugq7pHqlvx3evT/cTCFlmvoHAeUCAaxU4QKcBlmQ9mNHnDJcXq0HCiI95cPqEgu5X49ryYfpenZ1AgMBAAGCmqtzIRYY2VSScMV+mGPzNejFVaAl/zGDfGY8F0aAzSAvgEMLGNXtNaidIYfKUcSwYjlupumCWsJq4Nm2D2wO/JG7lQbM7O/T6jCLJOaWjEZhocknuvKWLhOEzbvbE3CwBFzap5NYROZFPXSzdnAbPm17Qudie5KGIdKYN2i6CSYe4HrzAaKxvi6XPH/ZoNrLgpZkAEnondrqAsRHMykMK0/D2eAtgFEu4C5yn6nXuFu9Y6TY+RTTWtHwsq5SRpwEGmRXGiLCUba9X9tjUpbHSzq+ocYC0CJ6tmrlBmeKu+EAe91VF6xO4LXEs0x10eRN1rsNmpPM3HpzaggvdmTx/4+d3/WmJ0Vo9Ah8a5cq/LvubRrYwsWqjq2pUOguv9Lb0KlGeR7cuT9X9IVFHgsIt4bmo4MpzeidKRiIVGnd+6sb3XY7iC2Ig24di16mYhGM/+b48iFqmp15ZV1c8hS8FllKUxdYFbwjwVwJoy9W69xH/dAMdj0A1uGSLWMoYXdEKeQG7sN6wZHHnhNG7NiOMjs2ROf3nbkf8GVKC1Q9uGoB35Eg43yi3d39uHGkZUKR0S60dCW6FO891O8NIYGF+hyvZqgHtZ0EcPjnxC7QQgixpHgLgXqBOAq/5sG302BQKDYYoY2eQZ6we2Ws4CVr8mEFLX4u171lREzL/ua/BJL6soyK/RlNy/pZZHEBcOl4MPrMAZybVsS63hZO7GTPoJwPVlZoqagHa5zwy5L94DZLaNZ8DOhZVuIh1H7MS4a2m/K5CItIJXZhojjTK1ZyykWkwQ9Z5prMWCha9Dg3eEKh0oKrtIxkY4zzr66ikfGQt/t+seBP5YiHaxxJLKiOphneCcRY2wCxLbDWo811EkK53WrEAYYV8RcfFO0DsWH1wAIw5r60WsvDvFmeN6bLMTXgXpaydjexDw1O8SK7SHyPAWPX3c52KWsbbg7Pwu71mEyUYhW5uH0HvTmzSsTLfEY2eQWPlq6mckKdLgnXdIxt0W0gAHwlmR2GOE8IuMW/a5nK5hrxtVMlhhxxnueEY0Roh1zlM7Krxqnuza1fskgD7tmBmPdTioQFxHXUGvPZBBVCOwKSjRGQd+boo1GHcLOu/4ray6L/EXaFCmY9wxHkXcyZuUhIl2bu93/kYgvZKXARL5F1PyfwPva390G9qMVypSyzaf4+iMRKt3lF8ZcYUYguURebfDWGU/VKMSmeQdW/119KvJ1cBNhn/zeKSeem09PPmCeNdheBgl2n08TqHPOyqZNi9B3KpXnCXRWpiLE8OH1/jPMg/T+rxuZd3qHtKFoKNcXvCAXr2CLh7fkEd5YuAWSbnlfRR8NKuiXVNkO4kUYd2MwdE4/m7eAiPHoaxsBas3bOYcDBPPxn+IYau75QZgX31z66fPPzB0pDvtT5XfOmsoutdTu3r6nUHgf0fb5lsa4AxcyTXyN37vfHdgSGOiFY7KCMFrU4XmDkCd45KgQLADnuInP0diRA2++7sc3DBfZzdOK6PK+c5GaxcAwgdRGk7mPDee7Pj+8dXSVZADdM4OtKgERE1nfR3cdM6okrb3toHPCusCVbJXzNmdTMeOtBSupaU0H6BRuFBIZJLLY9M9YyhPZZVj0jkQJ2aiYNa6fm68c5PfO299u3J5Kqt0kyEf+Q5jlS+yo9eKwdfERKmB6ceL/vNMIQEmK7BwQMLQc7c79qU6YSnU3j2PmwAa381UIhfaBZq9/Z78OY5iqPqj1Hpq6iIdSmQb92hneepWkpX9oQS7XhfsJrvqA6v1csq0FJ0VpU886nlFE3BuflcLkJqjI8sCa0ZYl/+9wB92I5wr2wYjLvcLsObzcD/ANaW5jd/rjnT0AamO7pUTxFi0/R7xtyT4cPU22PyduQZEXRcfp3w32P8R6ENQu/AziRKLRv0V5CIoM3eKQYiMJ2RM3qi0LkegpqU0bfHVNEcd8TU9lfK1qBncXqtEPsKhm5+m6pKzAogzODrLP6PV4M2Uyzj49na0ZiIYWPhvmfFOPhCFNl+nz2Q7Wjfzf6A7LMi6Hf0cmaXJgDyTux2sePph1PNXByQGTpt5pENsY0UNS1NkpMqdjyhdcDdXINS4Zks0cwIznTiOTzeG+nQFCYfYQP1HFaU2M1Q/Nrw3cKtkFsKzz3Jf3jhZoYHr7VyfGgx7EfwO5wIvzijuXToVpb7mrrQvZ2krqUDYF688DLjnyUiyGV3ew6gKbngQOpwnVK4O27NsXmPMAOY1YjAhkloot64kuTcw8qrF0RBOe+DwvqUYAXBroLmCDGyd/7JX2cP2RUonyETuPop1XVq1R8J6IsSSQJMhOeO2ZgxusFMLaC4RGiegpve9eTr5j4gw1ZPRNWEl+UgVZt2CmSy9Vf84sc/HSKhSiUMHWtFzBtV00v0P0VjHhvFGwdth7n0tpDysqyKNAw8Z1htQv6w7dNWoPJHc7Vxx9csJkrfhtxs9h3Nw3bXCd9D4AKDlmr0uqcuNErF/0/Y0WWj3FsPIvxl93Dj80ltjXY78lF6Y65WeDZKdTaA7tPJq8wHb66Vvp/L/xZ6F3Rhj5qEVT/TnyGs7LPwY616vNmJhPAOg6RBrzVRUxHchILB4cOE1lSyoicns+tF4uLKFBUzSUf9Pp85wpCc/4q9wDXaRwJh8MO+Gr9BKOUSiixByyfAj+MqJBMUadlJiKEZP6tWV4jzDiu9PkkgR+kJQh0ko+NiDykEU7Am5ikVtqc7f29d4o6AiPWvgTKq6L75f571Gf+XQgAWziqyOut8a2a6ECZt7TpxtklBtzi8Rgyus2DtgRR0+T/Qhf4Af80hUIybeWBkX85ciP2Zg916bk6DhHWdTlfH4T0zDVparsAzvSMaSorwoCHIu7+ZlT84m2AchkEJU+fChEPo5ZvfT5RCtbNUm5KeNp8ea2bDgC/cQibkXKVsa/EsPMQ19/UvE9BY8RVhTFHuoUcucPsrFsp+zWD9QeImHsH3tzXMnYEpwey/xg2/pXu2E5jSmDQWAQ95DfgJ1ya6fxkA+PJGyqQPYE7eX+GZpZVyoxUMSFOjgIXXM5rRJqAx8CJHi5kHpm86DrDmf0uk7mQu3v74mdmhpOIcELfJAkmYjHs3fvZuOeNYvjAVGMtEZb1bahoDYTLOT5JO95zgcOSB/1oQCGJoUtC6vaH4N9JidvFT4FXZhd8M2xeELIHNyTXIR3Wp0+cDNOuE2xjV/eWrzh4tCLrAl0Ep30D8rO/Fd72jpKMHsO8Aogk1vuahJVjwgmWFuvhoW9B0Q8GkLCECD15tjFvmSdNvI+bk+NuY2vJ1pEAA7/52eBqcZZisLio4Gvrn785daRw4UwNENFSbYwHZpBamd8ZxkmUqqw+HEPQjhqNUq7swkOa5srxByZu6Lg8pbWdw8xeU6BKukfALfrwFfQoYg614haqYNuYCZf7LS2Xla/UjL8bal0+FtRi94fidgCb4Tc+Mn7v1U2Tlc2WBcYTsUC0O4zstdogwzd1vq7ySam96Zxg3XTWxGiccqL15/VlXfeup5x79aforaedXB+VWmz/58ODw57htGgQvzLEhe++B0piZcCPIxlenYh2XOYrxQMDeGu4A3gVmTmppsq0d/Nv1daAYaRUqI5qqsbyRwFs2c/J7HHud/YsOBWN1mMDF0cvzXqCBWqvf/+DIuNl1Pnv8C0/Bmhs1f7si/TiZ+F0/IGsoa3IcEhRwYPe12ieXeAV8ksXFPh67MiHx8EqDAavUP3s3jkthj0gUB0UGRDG5d3pf/1+cszGdi3QWndyjFabVA1SbveMuRacZxhKRHR69Nn1gOvRuIMbOGSUoZJKMj55FG5RhqaNYpPpStx7rG+M4c0ARimNftWROs4HKOkB1JxsGtASMrN16NulAl8+lgqsYbHjQcWQbKbgEfjebXM0RDnlgUdgplDqTlNZkVwlqI0+qgK8z+KyVNeYKigwIDXpW9Z4xMEGjhF0iBRNOsz98NC/LR1vA+ppi/e+7+fRY55IEyrNvpsi0dV9e3RoAL8d6tz+eUkjuXOIUgrnD0JQTx9byeB31KOxRfWUZLA9SJ7TsWHT30pin6o2/vHRDbwP3EHEP8eFZlObN1SSjcq2h45nFsqut1qzw1qEhOMH3ZnYlbrURAYb72moqF2vUGmtlnJrYIJViw/skaY2Seq0jTAMlhkxVYwtXAOdY4++XQtB8QGwiqdEsShlIkrg/JHuDdeNagaiBs/JhI+M+2GudS7t3LQNAecoi1j7gymmJ1jThjvJjwpH8ehzUm7pN2hA3YIsQtYwlfYSq9vWGmUFPfjCCqh5IgTKLwNIPxraGdZYPNPskWZo56fVeFvCLtSEg/JTSFF03kJFa9vIkZ3O1gUweeRktfWfMY84pO7KhXTdF/53uRzX/Qcv2zgIqwtNVFsbu5A8Do1dJdhKP6WpqnamhWwa94OGAswusr/xfunsaY/Iktyi6qK1g8xjZ6lWVEiTKDGo1IanSTo+MOgs8E+w4Cco6Ox/xvWhz1m3xVzXbNbDcVYD0Hj/1DGLWJn9f6bkAS8r/1PSFPm21VyvUQJGARP3h9Y5ebyEA7Y7PH2xOlS48itrGhsDWLcHW2fGfVj8AQqXzxaab324DWcLVmICW1/OU+RiuO4bHX2SebKh32p36rDNQu5hw+HDHfZ4iN7h7cnoF0qEwaFyJZ5w0HfdYWvjs2a05qVZJyF7k55co6jXh7sgX411Wt0jptohprrMkOF3x9963RcBvqC22z8tyaUovYjKx9g3V2k+qmUGMvxUELzhNVAfLgh7sD8CyymVy8QMHF6Knr6QNxZ6naIfFWViOlpQds977NXEZ2j+z97N4yPpfvN7j4w3Yw30FewdhRWSJwk3VUl6PcLl2UwICm36Uv4i26VY1y3G7NrjcSUXn9MX1+nUk4hwzKXCf+STeSZXip4VI6yQRaHcYLZky9lL/sfpZyHGgfSolpjAuobrA5yckepfh0LPLSdquz2P/HBuKtd15LezuP3zzdcW6pXSbCm3rXprWHxsFP2O9gtrPOtEclzFx+BERBL/H9eRGUh/AgzCOerkFLf3Op4pqpPuQdxYWpKsSDuQrZku+4V+Fd8+KG+e6shBfbouahTYM4ZJ+E8FaqTuRqQ38bfMgwEUozPS/6UDVmDh/92ugV19mNkDbLZA36tpAzdOIhaJjQSFlxFMkUs3bT5E5HGyyadtF2Dv+jtO5yGJWgQddnohNDl3UlENN6g4hxqsgmOL3cRbVH5tEIVL3/8SHATptH4k8UGsLEtnn2+ePWCl5AKaTyOlYDjoZjcaNJY/VfCp75gZaBthtkgWA79S44yc+uoD1P4vy6fFrj/qcEEy/M7w5+ibKvkrCuV0IlAXWQ3nCn2dGKr7KKrFNNavNFiBXO53QbgI8guVtzrK+abMMT2yR9i3311pr3rBmCorMSQip2pY3SX6cAzW604b5hfRCj3W422G83qnbKOm+sc3XhrRW/J5OLAzi95k+uzZkhHXlKaIBghDQoRDtNP60IHuA7Zuihqar4FqrLtcpDCVds1Cz8chd7t3YPA4UUwFVJCbjwU30cKUMInX1WV5bVu/6Xn0/7wXBzPR549j2AQWavixEeCZehwt64IJtCf5zd9D1S0Ntp/SUJyPw1y2tFqiLNjRXJrt8qBRNtR36t7u9LK39TlXP/9V/WX0jV+nO4C+wD6J8SO8cw7hmRE9O+k9t40+CakJx2qN36XJoIXJzisjAT5CrKEEUC/OudN85nVCVTi3bX5lLQKO0dmkOpaF3TKDlGGlOgohRh6sLqiCLdoVE5o11p+w0qLVLta4Umqksu0sfOiQY+J92raSrPHeVYI4UKBMyuQ8SgyVaJgYVmgKD6EuRSQE27A5RVXtXnWeWb5gc6bppVW9ybceuB+bCYjBFS0xPGgHFl7/IX6kzXfbQS6pwormxa/oS/GroDwFligpLLsEvgDpckFznALhASOz0MvqPlC67vLo2knLjqaJQKanNcnzzZeUknte5vD0LLkJx/KHKEPIjsPsrd8y7SmMFbtPhoA9+vo5ozrw0z3KhndXwsvpHmlWFLgBuPm5Pr0E6OuGMbQMLCrTCygXKulLl8Qs5+gNkO4W053ft+j1IZGZ96U3Zn7QhqA6ntv48MnnFMIwLwasuINri0Neja8CUz6Hv+d1nc1L9LOlwsWwhV6Vkzp7aQxWRl00z9AIH/NglRofJCum657sKh7Vvmxd924qk4/OdODHwdaE6YjX8uQkff4PqiohFXpN5jgmjDnJKfwM/je2V4igENURViOmvMfdSIKrqN+uA0aAxlSHcWNwjdgjtZDtQPtP6QEKoy5PfEEq90QP52NaImcCYQ317QfjIwutqJqrlhjthNmei0SIr9TK2yHCzFTI2Y7yRvGULKeb/tJCcaCPMa2dxhFU2YBAX8HYZuQlXH09AXOkLXq1F3JRoHL38hqv/REGxfiwxZ0s8sqN7fAtEaPYLZrrX/HpJmtpx7l9RUeXyGy1p52EYZUtj4yTfYA2EieXAHor8XlWYBGHUMxO9rlysDbXFWwdct4TCK/rptWseiGezCIsOeRzPcuai+D/1mmPfOkBBHPe9oxdp95vMDQkhnrz9utcXOL/07Wv6DS6yCQG6ARcs7siQQZtDA12Uff7JFJjP0kQaI8ahHo+PdrOueaFGc9nz4gaTJOAGpJq6/SRJ6bNcMYDOKypCvzL12GF3YFAg3JhOxUSxaEUpzLRQitGxf/OPJy++LBAbVXm9IeO+RcBTseG/Hy0EQkmhZZOXy6uDuYO/jo9/jfjx+KtW0pg3i2zu+RVLebWv2TROjUdIcBtIRVgaDxK4XNa/GqGaoRBojPa7Q7538gCaD3olkHRLwia4cV9gtHlz/dxtyMaPSnSv7As1/XCorPD3QeBKODFqCEL23m4l+TqCfzlaaTVxivB/43ctiWtuFhIHcsD49gJw+3LGXrnawID+dMetnD4cbkkSXDekBSwOJ2y81z4Td9Ern6eZa1jwhX1f0mVRLxHMV7jss+ktLFuABcVJdoe83Y2OPFT4ihhryCNde64OmSsfmiVQxe+w+YhcXrSj1mvC/kZkdG0HKHSht9Gdv7dGYxD6SICj2Qoe62DGfaDGbPDZ3CTC6R2OfyYjqhRVeJTx98fTeEaLDo+0gNBYVR1q3CQVI9gGGptYXPd0Qr7Z7mCHFOIn/Ao9vCPE6fbPL/fIEgSraUxuSwS915EbkbpNH1woiMxVhSsvTfzO7UpthHr/4KGoquSTh3thty/x9OQNjqupAlffCCuE4mctapkq0BgxfWgyfeHJtSXQMqx/Qsbqoj0FXgOS/apXi79+PqAxrGjwxooCpVPB8+o2cbyTPgPg/3/ZYE++EwZCcIVaJ30LW1+brRzr/+GQqGGD7nN81Y/ZpQE3ES8yv5yHOR7Gsk2q/eDqrvrqeFml7eib/f6PpY3hE4zEbEnBdXZ9mhyW4ANY1HWTttGKgPYINgDvNg2TVFgxXY/4Lm2t6RwePBkZSGxaQ1IUCV4CfpGMkTjL7mE+D+SEh/6Ya803ZPj2LzCdq/5bK4kqL5aXwS3PGA7RM+kYfHfYPe0fvsOhyTd7uCgEexh9wUPyPG5krQrxb3sDCEEVPJ3D4TQhfmyJTlHVdrg7oHpZS9QTYW2ZxeakaZNtRn/UblEzZY5pkhVbKpGelXRdaZYaenPaCPq+t7tVFRzuQsPxCFBivRsSsL29RYhZA0CfbZMeUVR1P9M5zGUBZmjTDHFezI5f0017/YP8Xn+z3x8mohoE2LaC1M1PJkzy8rG1wuXX9E5I04MAXfmJ7TFPX3SQSkj5vnhPpFtcQlW9GPL7eU7lfAyXnRT+Nw1YcALsnIb2kBdf/XRF+jZx38bFgv+kyk4j6lD1VT7Y6waHxVAT3aYu3fohskqHVOOEi9o2KkSuhyC9XhDqeKkjfoC8fGhwcDkDWyGHPNSa57MDYNYZYYRixrKnlRG4Lhoi0evEZrq0dNeRYx56d03TlVZE7+Or8j0zBqd6HD2RwaM2ScFlBe1BhWq0/W+E55FkJCvAbFwwrOXdvFZIZeHS32U6gpm0oQcxuKsRy7osDI245sx3TQyF35NC5TjGV5IdJ+PHl3lpPxAZwiXezcW5kbM0lP1NsAVw1304FZood455kDv7yQQTNzCXMF+/j/CbQfLhmk3PGtkL5idqJ/pEP7Ge3Vgmp9BgwwHoe83zZGLVT0Ykzutim7XXi06yjWu3aSvsZt4EpUyGwXjRw9GvWmBe96iLw5C+Y9OCsqZUZw09Hg4jyL71IqRjF0wWcAXsUH3K3WSmWZSIWzYC+m6FWw5w7xrVc8A2vZ+qwaCilNliHh2mvLcIdK0iBPH5cdB7GunlK1ar2/s7mPY8hnbEmr8ganFrd27oI2hU7a50yL5+wL6QZYuq5OU2BmYzd85FolySikVdElwH1UkyKzj+1PWzHMOMhnlELsjTkdCv57nymqMPoAPC5llJMQaWAZT/0hV0i3KYStN6ilvJSP0/p1A/1/eNg0pDFixjSdsKkR6qXPl99XYCzGfqHf5idkHkMiSStFiCFuZ8KydqLoJLOajhQUS5XmQZ4oLbPEfSxziQHr/a4dI+fJ5FafhH3UCF7R1vz7ML+8AP3ijoq1nwiAjn+XB7acfYfsIIzxcwq9SlIUs+bL5T39rjlEFxX2wQO81YROX50ZxoPyHVvDToA0s6wOrBrflUOuJ4VZaLV54T6Xky2BraUqXNA7+mZnW40EUGXizDwkmPLY4+j/tSnjK7Utx7bCQY0WOa6ryJg15WPoli1UKUbdoJO70LXUVAbJvQQXlbIFDLLkwcTsnGAtbUAD7v69Pxynyq7aVcjwojzjLHK5s1GL5jxeKAWa525NM7tiIWlEm5n0f+Km6ZSPcPE4NTO/mGpITQiRas+4F57Xv4sDTvGpe7oj3l9qWEsvQXhw04482l4T8KeaJ4VbeMfKwSoU/vZ+272xNIZQoL866DrQZAjzWYQcJAvfoMswoJaD4L732EN1LWHftKDNW28+W1ALngyJzxXDr8Pw0Q+fstUg4I4bBKr87I8F8JIdjQRt9kIdb8B6ADkBIXwk8KTGJ5Ga72l6FtiyhLZjczYATVjW8D1WThA0vtdbm9f2fL2UeB6PP+jhBJ6qiQDJyO5Rf/X+UjUKCPWxZhxnkUPezUc8tzaO81IlpA5JzsmPnUWY6NPXW9gKbPdhPiAGmILaWk10XXcEIUSfWnZibiU1fiymhLy8Q4/8W0yUHFPgzsVP4qp07F0UhfVErwzURy22HjmDpVwgyDrmLh+5MzhjOpEEX8JuXe8fsjm28JaYrsknQaE4GhzPQa+ikC+OXZMEOyyz/Vxfh5ydsZTR7rk/LdQLlO03pC1IhOMGURwaj+52D0uaY5Sx9AwrDwb2zjY07yQAJO9sBgrXmSmYa/UWhQKlF8MkjtdX8xAgYWFf3f9pFFZ74/skzCa/KWKHOKG7rYFWlbXE7qI/jr/FtKml8ZskV8WvOuuXLkGyTyC7Pf5KREmKQse5BfmmrqMd2sPRyXor+2OrMRQstEF//viYPQnBdd0cgK8V2LpG5hwjsOnNwJWN5RhreAj6eNFP2F0yTyYau/qzJ6q7cQbI54uu888E4r4fjtUIXCmBI5xtYkB0uTBGaN8lTbuaf2a4+f+nImqPIX/hlGs3Z3VpepW02gBrZqywPWlC2B1Ox2xsK7UiWoRDMA+2/dojpo8ZHVDttbpDOzTIVQOD+qMgdrUM2SWxO7aUxb4G5lsTqSS3WPsED1IFPzNxl/1tBrqoBzHYrbXbJk5OF7WW1db2xrVOtZ8S7KTMpLhvLKfRvLRbZPzL3ukPYCdv7HSCOWTP/GuovkKe9Ol9BzIuiK/WSqMnW33Jld/wUsSgvO4/TJSxPiDzxJd/jmCkku2ly/PRKKRDED+LC9Gzz0y7IfxLz0jFMVWsoDYlEbhpC4QzK96ZKkEPE90aZjpxsca7LAjphbRRhdTmrvTuNWYR3fZirW0Q9oXLkySaNJRbRN8u8mquaWfOMgcq6d2uF+nC6L+jen9UM5zrNfZQRA1CjRQJGAHcGODEP65hnToKN4MwrzYPQ6AoAmLneOKSsm11Xbhx5QfnoRx0gVUHtZ1OYfImXeAZzxTKJirzSV4kLOqDRQWRDW/7Xg3ruRn48LZw/ymdYyYZpVN5sauqGa7mlzLDL+Fy2dv0T0W6zWv/YppPEZMO97LX7Onwu4EYxrMyjjuHNbCEqsgfeG6EBIMvSAohh3dMnGWyziOgwc8FqGBlklQwYNbNMzuR3q6HBWb2B9YrzNF4+A6qFGU3LVpJc041/apx1yyvJpUt4E15QrzSnr5KDB/QnRfNOnbUeBS4+W9pIQfFPy300kYq3h55LqDNsZ8kYGoXZ8l63Nm3J62RvMScsQ1C446FUXkBm//Ffi0FcUh0r3amOgjgL4JJJfqpwpn3bKjY3xFTMI/jAhs4DaB6mr01eEGcrM7CYSH8R8tOvsF/+4rebIL6xsL3UVa9MKsIDiz1EewMKOJt566JFQD3kWKXZ3jgQsjn3heWn86RqSms2fUiMAFY190PEAIcg0BaN1uDs5zeg0WwiF8HsVWSbDJ75L9CHXaOWF9MBm51Der9VWFKnKbIGhi0TyAQOYvMTRfZgbhLlCe3Pi5O4xQSgNSVF8WnilqR7DCP2QdB9uwp7p2l8ZlqRcmjjJEzPnZO66C5p7BZptLCWKbmjuE00WKbjD9ScgHLf++EciVBGJ6Y7qM9VWm+j7dAcbQdHy+4cful4js6WqunUUBlrMb3WKhUi8OqMFf5mQh6kuni5Zcb+FcZ1ykqyi0mx/1jeMWHDOkDzi7S9/SGeMa46xy6x/vAtkUYfwID0u93bdcXNznaNUodNhHPYiazRIwLjQDE9C/fa4uxi2j9oeAhk2Q2YH2XRoCUevviYzOg1WSwMSkTrQ/lLE4bmxLqxGQKFHPc+HWf6nBu/lyiWJ7iKVrmR1E90oDYwOlhMcHOU9omXwItOadmcbDwpjSoZvdbMp6onFyjY+tvFzs/4foIDA5Ij0lfjYV7gtsL+0fab+l7bGnhW0gdiSCwrqPq1YOhdmIqdJWr38jl1MVImD8rfKhOTG299axnfp8/oF5e5V7TI+HdUch0+tXFkyAcpOFhSSpBB3wLGlJ7MuTK4egPGNtld5pgsJZo8ZtPKMmKblKJzVR6i7cqjzcWYrcr7fz5CoFM/trgxve5hX4GMu8tGwSlRdYnNRhhByAo7tG25jPgKOJeWOtf8srr/nCfyVevDaXYAToM3rYjYVsCTTL/GcEhIApXV4B4BpTO92vOZyptxu12If+47HFs+pklyCSoNqT3wm/qXHpkQbN72RnkYPiivtI/igZGRhT9rrvZKGgT7yHrL2uml8i6t/rIygx0lo7uFwEd5TGpV/Hne8CbxB/3n7TN5JoOljjo8nKBIYLDyXoOKochpv6rsjkGYmUdf+G7NohcvDxmlDtPLCZrKwkIwDDIH3vSPYgkJArw/jPalaLC3E3HoKuTYX8cAFCSzQpa2YbM1D4Ph2tuSu2n0ReyDwaqWpi1lJq2oDC2UUPhqfTX4tMHXW1gyLj6+kBbUJtlnlvyq/MfaSQpabtM1bmmUj+0ZyGin+9U6nONSjPvxHkvI2RYAlG9p/hnCr5EEokMiyLWKu7VQSCdfsRwJUeBU5bn+GTPO++ru/naBfGgp+/dfVYdUffh/xmOBqjmuTofdDqDyi+NhpAjGolJZCAtrlgsNw2kwZHU1FgyIOjwf90tEoRFBAJVv9JaU/8z0JNIQoeR0dYxqKcmNsE+SzihFk+P1E/p9M5ksx4R6/F3ZwqkVoCzeEAuGJ8rONhGpI4TNnE6+18Q8ktmd8kydeTtgWfo5i6JmqdQxq/l241BPlegQdJLo3IZYhO/fSWgpW8eMEc/O5xakd8OJWkUQnFT3LtwGfYKyOM4O8m4uRO0RO6hyUjh9btriqdZIYhOauMm8Vj9YbrQy7I9IhkEKareVZfPJ1UggOFjYcLONwUX8XYt+k3KHqWf8yiTQXq977u5loM2wti14Y9iw4zh13w8O64etR++NAaVmboLtbfVjnTBdzGi3uWXsGMwBhfNbDsKAXoHSd3CMyYgA2C6FhV4GH4gbZMUpqgIvamT1ngvfOVR6u92pZqmb4miqvOzSWK6puCbBEfFEftpnsFqxAWfdv0qtsLMDy+KBAud0bBr3X28SoJbyw/AYpeuL6XODL6nH2lcYImsnuqt7LlASQEiykH/CnS3t+WG8L7nIVVk6WBzRZc5/p6iScqTmYAr6omq4BX/N0Tcux9xC6QWsUpJBZQWzat6yWdDGT/ZzIJpLqHwX1SLNiEgM9EOXg/84uqtRXIRV28weegQSbm4NdAB6izGYMkGUsSSyyQtr3JhWcxV1oj5f69lVdjsIwEW4MqCuexPg4f7FC5yRpb6yxoic2rqAidXlcS1bwAuaFnFj81G/iBgrjNRGAZvRdaUaRuFYhDK/eYmCso/CZNgKpERK2i/av+WH6ln9JDdsXD2bquwKxHlftITjvCf6skCfBqz3SlX9GDk7J7EPtI1HHYbeZUtwr0OrEuZtsm1TK+dhAJs0QYQvU42EXujx2yPebNvXmhkiCcv1koT6aCbJNYr3ooQ4qtr4njENfMjQZ01Mli8xtp54siAsz2SvReJLXa1QXCAaj6x22h9Nz8fPhuYRwu1DS/96xV7qvuG+wmunO9QIzCk40DCTwuUNi12kOVJ7USAoAZLrr/7+w2gLivJwmCynKwsGVP1nAxdUuYGNhZh9DMJcYAIr3s3U4BvqCnJ1ghUEZjDZf2U2LCI7GDPd2u3Rn85Um0cYZxXcYZuw018iojNZRhCSggscEmSifGwFL9Bur/WE9RjsrD20MM4BJSQJLs1JwvJ77I0uHQjC3A0yuM2Gk3RZDeU+6/UF9CL5tYgp+j7DPShbQxeAcGEW2F0g7a4A+6AC6r6h6/GJYYD8lmNiOrA1DR7xz+2jIWZBe3oThxMayoKXQV+2/SFTeqsUQ5OHB2UfMwt6sokouYbg2MhksdbvaPS6oLaWxkoU7zZCbjzq3BDNAdOySAHS0pE6jIICu9PKC7kwaQZLDDMyro/q23hsmAJuEjMpNQVUEM53EYQ3+6SGMO40CTa3H6Jk47l3ND8YJfi0QGgqYOINO8Uo1JYhrYGIDayJEYZCGvpEGP/r8L2UxTWrQbTRpTag4aLSZk7/aIGuVWlx+6EKqSACbqIsFzmWt6/pTEDnfL06Kdr+mZNvgmJyc8eQacURQHaFUllAM/M8rotzE3/a0EYHMBXpRPghLziu1qejxjz2EpiaoSF8XHPf1vOppyNwiKhS/h5aTS2cpQ/5eNSSqi0d71yyslc5PZAEdleIDUO78VHPrsM4sHjmBHtwDsvQuZxBcd8ErNLrI+lHwP4mUCWD58FTjnjppE1iTVQcVak5l1mRpS/Q48JU90C2pMBVhSXc+BqMJk+Tag+35AeyMoU3qop8Gvl3RFip5LGn3g8IxPZbAuMM4BRZSsDZLUtPaYzdFQkAFWDaYDbRvymdk8CyhaKcG2S9ZT6tK+5D6+SXhfVcl5FHoX3u4VEvl8vwhMKbnU0azndDepK6FxNswFhaGUvHNY54APeaae5/2T5lfdIKXcjGyZ+Kteisccx+FPlc8f8ObNtG+ky48Ko/EqYBfeO3ZA7LL4sabclcjjIfcoKlYsY6N0HaS8oc9QzGoLhvh4lBf0cokQdiFMpI/voL6FQxumlgpHBW0NNHxYlLRCdyARHB6B29blf/FgvuhhoSz3NmN7+vdifWtyRNosQkf6Yc86VzSlXnFxAugq5KVPpuiNyJIUt+VYNerju9wgGEFFlUO2AazgmajfLrnEGxtDWkh6jJ4LRGOdR17fIeMxVIbF9K03vzH6sNL5d2juO+JEcrSGIUunr02DyRwCjZfQDdVuvcQo/eGupHzr24nszRT9dV07MDxSrakvhRr5t6GP+Ixsmfljpuvy0ickmiopM+ylWTA5+ybEY+P4qurE2MnThGtUUsrT4OZ2PAcwDrkNPTXib4O+Lu2gBTaclGOYPGunq6HLnOkmzSr/i+qrM6raJLUxQd8AHxcrKzb8+suirGhtcPnp/5qm1FUreTWTcMOkwWbh/YttlTsS3SPsplPLHz1yx8q8dQm1SeEUou6GtcpVXB9Phb+sH7p2Pm/4p6b39QdG3u7mZy9FGD6SHEyno3/+wJZV+emweWMJDkb0Sdm7Nzm9gpHhP5ppA+7tF3IiatCkyBZA9xLYIeLltGCl/Qtysq9rYBCMUJqdkM6p+BPRfmkz87eXXG84J6kRHZf+hkpuIW+HA+IRXgnZRjsOIucjlZedY6KBzYaeCWmY+sSd/jcXCbxVPmPDUUUyR251u/3WGezNc7ScUOhd1apOpKMKgaoVYwU0+p5DkyX6RrqU29y6QXH1BVrJePQLTP2h71W4Gq0PVOLeqhqLBxohc8XM0eWHxkALaDapadS6txhNfueBH/Wd7jBBml70JGIusofe8UGJBtFLUg1uYu/+ZXTMsgCViPWduow+b4d177PBb4LA6LcahPpIbQIrr+sQtiOUurtSHiuJmA6AYqutGU3ihsq56CDpoZN/uXEBiKWz+m9sFg4abqqocZbFlv3JlLo85hb7tAOSIG4KlkslfyeGuDIJ+A80EBHxTn9AmMjzaI5B/PJUV5IIRKyYQZkifpnmbaJwCP2POu27lj1bxLhEY7KJl68sXMI0WNE0E3SnotOyogQkX0zFb6BzSZ9dTUT3Vi3QIj+vS92NOc+1JBOvpN5Yk3zT/kOE7DnJswjfPY0zq96OHposTkL/2vepucso31/WNwqCgdYyREoDhJ6NdT6uSny0Zv04pYZavaK5iNKE5hGpIVJHOCN0NFMhzSbRmsEreNP4W5Gsk4Ucuot56B9y4qU0r4saQW/X1nvESn4u8iZTj4pozPBDoK6+C4J5f3xcGGFwPOxNn8xFeVpp1tGSkG0357DzIesE+X+VTJNzgx3WWp1pkbbz4Y92mw/hPm1Fn5pcHTBnpEm4ZoTpaLuz5e8l8IW1Vv0j53bkwafJp9Z6sL29QQdlBglUwqv6VfGGXERnS1q/nSSlmqMFb57gSxiBxFMAqI8tEsF0ytauJ0Jzkw+GIJDrkt6ZosAaJJj8k7CiOTaNQ2G9XyB5pol3U+68SF0ZwHoZM3DF5bib2W/SeskMEhuZf0wMIxfhPIVbN6KoKnSZef0Kw622Ta29Uy5se02L1mbMRolVUEnNQzunaKWlx0L+Nf3AY4zluPMR0lFKNfnNFQx4530oxepWM8+kr3AjyyTO6P9zphRDVpEcWpisw/3NpDEXfDC7D+8FgEZWkPM58jwFu3jSyunZfqXeTe2dxuRf4FrxrNzUn55VlLt5bJcECa0EAULS6MOkBAvw83DprPtx9hFdlwgkoLElAnJzqYQAoyXo8G5Kdl9Bx4GgwrxN7KXEY/a8NABGg5plrxX28WKLUCd+R3guLEzSNMNtMg0p45UUXvLpkwP7988TcuhES9N+sReWNKIREHfb/EwssCTlqS6Dw6oR6v8ngsp8pcXnSPMa8RuanSl5ryTpjk7carQn6mRQy0jCMTBbHbgmJdbmrAw0SV93k1Qf7L+6cRD/PVCzRHsvwzo0Teo7x00qVSCp5vj8gOCcxGk2IcSuIUQZfi5MTY76oELwLFIAZD5KE1oIXX7afi3jJRAZuSMTOeaEbmwX03bsTPpf5+KdDIUaxFqAi+1vc0BMy3RnS5SwR4AexzeB39NOzKOXHE+UOwiyBGFzRPtv4sbuMHYLHaDzYhPEIhRc1jKJhNsUiKEjAL4286kdt6ad0DlTOfxxn4z2oEYDkJRs+z4dfkP2czqMNOsM/QWGecaalJrFpBUh4Wajy0gwU4GRIyKuzGo7+yHJu/AWHFRT2lYM9P7G93Xr0PT/qud8hs0Khqt7MDfBYte/tExO2tlQ2e+Ox5quwTTUMM3CTeX0QBtr6wtRfqzhGF38ofFAo11Ty2xffVe9hqUo+AkWRj1DORfSJlQFOXz2CeW/R3C/q0zcl1EW2zp45Xs+q78ugUbEdw0huiohdnevpNCuwB5eQK5JkGYJeFs5okWadd0NrIlYGqHKQGLflXndcRPFKiLIUA/2bZihwTcIW03fw/E+Hfhw/V2l9plAEKS1mQb8IXIcmTiOWpRHA0cIe/GiD1SXz8knuFHAK4knqJaaLNMdmDj8pWkd1Aa++EqLTM3rdg4uItnfmcVv7qFPsBICADyASX49pFXBUHdc3nHq13+uJYlw7i8s3vwW+aZ9uOEjkTQJKyF4eGxDR2jgwurrO6+ej/lvB06gs3HDeoD+np22XIL2xW/fubHIeNf1O707wgldniP90Ka61jKg3oFR88oNsydqGRb5mwsblILdP0X8KxtOLXCpWBURATm78C004r4IbjU3MT9zqwksxx2T2XgXiZrWHmtVdFTH7fRNp5fEKOP1gGBvYnEtZfcEzVBKWLIxv90XucGFNPhZcK46vExGhEuCZEKGW7z++Ram7ExjjdXeGWPdxcXZxGOcuUpk+C3dp+jyu6A1FdpTpMFUfme87O1B6Tcm1F48Xmd/1ZIHtDL/c6tTMMLk28d9vk7NTT1on0kW9Fz/cNhH5I1UnLhTRv/LYb6q8HfcxzvXtdfDIjIXYaalFmRLCyos27JtXgsOKg60tumrqOgs+I0DU+nEnJqILPSSfsUTQ4eE1LJmL/i1YXdcGXAP6PaI3/dQGfYFd/MW20qQhWrnUCaLCh/QijdaFOgN4/7pxndmWUlZMc7Sg4nI137b0V812rrFtX5muoU90evJph0dJxC69eAQOMHftWUYoZDiMg7vqUSZpDDM1SxXsMo7Exu7fA8V9lTukwX9tqtZDxHj9/gMUyQmdYC0ID4r6VJg40LCbgBHbiul5s+pXOS96eopnSHrahOinleNtMjlaOjxmoMiO03AhPI/T9y+UbSik++xdZk+7OUkTDrAfYNVVdsPRVTisw65MoX+wwg0XLg/QV89+EJ9Q4+FJWiQ9j0fHIOb8M7w3z5FfqobRhcoIn0nvN16LnjIyg20ed35olw2vEEqxPsIO1eh3hWVf0BdYKwYHXdijY5shY/l46plFVOGxmHehip/VyPCunHr3HN3Zo2NS/bG/0RKnuU4ry8YtOEFAZi888oIFduLHv33Uxh2xQCgJkPdCi3cCFLkMTbnu1KB1hhMuOZlIE5Ryj71TSkBiAzp9f+DKPG61NK1VaAhbu2OJ1mZpzk7r6LEkkGC1R3V9YYjKPJ5XMdW8pD9K3HOZnAnjeCKkNe7dDiXnt399ZTq88hdV9XsKzvoWtsXwIL3YLtUeN2nLpOCDS0HmFf65bLEXsYyELqRNWx9fOjkCN730EjG4XCM+A+a6dkEmDlq3JUIY5NleUkjhkw8FZI7MXoUbN4xTb3aBg03vlXjIxeVHJHQ4Ln2QelkNsW0a8SvkHvK/yhW9pXgxpC8REyOIv845PaTzfUZzffZPbdf2nfXzC4iy6p0dQw4mZz8UXyRw5z87MU+5OhFJGbWUleFjgGUaaueeSYxZumEb58vWQnKEHBgn/e/KrAiNApb0f9cXiJdFXgQFuGN7F9YOABF0YoJRMaYmI3Gof6eUj5fgJZaRkhjUVpt7Y1x7FG8z1rH3CgLofcLHO2slFPtUsaB7qTeI9NyElLJr0vwtLsyTAIOaEVyZfYEZpAgNRU/3EAUrDzhROj/13PcxDM6XKamrummGidYOmvFsyZZiEBbQrdxNpW6p2PFu4RJ/grtZWEz/9KKyknWeH1Yg2xuNA4cIPCYGJ+NmNca1oAIje/E39NAV8zf+rllFiu8LPVVT2TCQfCJ79Zfjb+sUAGt+LzvqI3Ej+NR8+l7Hs3FaCtKm6dkGpIMrAnvezbUfh8azbzkTNMW5I3Gv/cMU9h2v5WuohxBhdGfrMN1XQCSqid0P09yvEyxcUXO93YgPbEuNKTWHwBoejrb+ngqYYJeQHjkhaQdQZQflJQb+ATIF0g+W1c1VFzYEtZm7IRlkacZ4FdCNPfC85X44kCCKoWPhq4Xb8ujXjkYtEh2nmbh8rVgI5ZxhivOJGfUpIGAgMbWWGCeszyHT394eBBeaw4+5t9xPGsIKpZCpqxC3ilKyftNH4rjmX8Ui1aTH036ZmZJPzelNCbVASPWkVGvrn5IiHtEKnCropGvtHgftvBXMx50UZs98tsdlhFCbeEf1pI6u43vl/rOqLoh0BJGZ/7kd1Eqzz/waRPyViqSYt16ELQqauJunWcQprFiXUSnmHYe4LoCBeDYa9Z04+xdVP3gw9u9izOEghBJjEIWDJZDTe+gTTsOYCIHcQNS/z0XImAmBN6obUDsYxpZTAXOSZs8yTYCEQODQ2u3njbdxvZ5lIIsz3T44FsV6morqhwgc8AEBkQqVAgc0TJAawh4YwMrkVVSG9DCfmkaCx0oFKeFF89tSw94krXOlTWAnoXuLxN7Fnlz34xXqqzObLs0+olr3PJBB4RPfutFZ0t57fYfp3JuT8u/j1a1j7hLyjwHwEQLh973mX9c6eWV94t8GWz/Y9JyHckcEHhCc/eDw8y5YoeIC0rvZKa46CpgkdDrnB1j46vMnlAuktUMcxnhcRVaIB/XV/o4xO/8EQ5/Sas2kTieYTlY50aSWPXhl7FEFPipYSjqGeS2W5/CHF4B6F3noTkTXgWLtwpTJTuzQxPoqbfZVHqwAvHWULcnTOgrboBuXW7r74G4GnaA3JVXRlNCOU+8b/yAYRjIyJrMgwUzuxOgNI5NTwoRCwoytLjlrmF4WLIYgXLDwy4VFvy6F9bOPDsTHKqKlzZ06i8Cm7h4utgrL5CgIdJiJ754KOrgpLps0RC8sjuLC1H6nDeWff3gEDwNIdRaU+fpikWrpao6h8Dl00FcOvMLznIeKhFO4mH07GZbDfimoeKJu2smh9FFbuA1jXf1pzQ1PqvwunD8jPBBZL0Idu6NVrrR1eSkVoHGv67TOicMLr7NI4PhAgi7+fydr6jYyM+duCSqxqEjs083wX5YGFSHjUJMjj9UZZytJ0FiYiRzs3aODnrm9WTuGOXnPXaC2ixBCL1ViHF3MrJejQBw0xbzaADdHgy/bbj48rxmzdMqp3NOOJwv3aYn5/Hx62uZ8TpwaH2ZDklIlsbUGoPckB7TUCy5Z/NPF9+lKQUs0kUeCCLmce0Dc2Kvv4Ty8+j7Igo1+PddZLQfKS0jgI3Cjk0ic2a0Rd7nWhoTis3iFxveUXdg3NRntEQdqj5dMsDkcUGLemdnNUsFUHO5KMtKoYJTc+CwGpz6Ab97uJbjl37dzdhrBANpmVKM6sEYS/1MNqHnbdwSiotNuaUvr7C69MOjAMRmKGwOjPSMQYExoS19ZpZhPUJk33qTFSks/mwwFU8tToyPV5h/ICrZ4TKyi8N4nLedrA7/aycjFzcMKOqrwaLCZNHQpXbgqEIzPgFiqrXvzMwjNe+N9/qcTxAu2i5fmkl4tN5W1NnWrH7d2jCB4o5BTHd3f63CslqBsdkXxn7FyuPEizaVygM8cesfX9ct7v38Xg2SwClHGRjL5yX3fwEL46+7c/HMeUHZI3JIyIY8nXYINtHYnZDqGHWbUarS3k6bc8tJPxmqoDGt7xwWojb0+52pxX3XbrAkBpqFYlPRGV4oqgcHWQHzoKQKP6rkQK1Zr/vnxvpLIB78VDbx9JtpoIgltGzMO5Bx7Tzty43n/yAWsCDCiDMcAmkFg9Os+EvB67UkZJTecXXn/RcpbDTxKXhGN1u32ely2jVHYGQTbmK/xlvLfhFpbBTZ/vwzteIiaFgUDkFspI1X4r1NgChqmupo6yDUKErDxPlSLUeIPEhuFq6D5lBtDu3y+5fUzlzK34LKY8b3IykxcOuMcEoFgeka7upDBLRtwyZZs3VUZ19Iqunbpzq7IQISHEifFaJ5fwRBf2MWkI1Q6f/P9jKLoKCqlL9QT1KDni5xvTnW18xi26r4oB8wLWWbDy9qBCLoQYTKa7po4wnKpNWeipYn9cHTDW1x6TrVOvfcnUbEOXjUSJNoV5euGkAI2eKg35QDjy0nE0nymP7bwzhLdCfZYfEqtgaDedflnJDJF5OykmNd+ofkNBDNvXgiHW7oz2m/QcKajNHBO53KIqef1fZB7GL04UhufKZeUhJsiHsEWVtkVWibr211ZZFaJ10BRIKP76MAm/4L4DQqdOyflmUrq5j/Uoa5oVw2eKMp3wsNWj51Am/t978seLn6aP16oseXCtZuH3QbQ65m/dou9JOagj18/3VMrrNy2NfY8FX/MYdXvHN8k=</kycRes></Resp>";
		Resp resp1 = (Resp) XMLUtilities.parseXML(Resp.class, responseXML);
		System.out.println("Encrypted response XML :\n"+resp1.getStatus());
		
		if (resp1.getStatus().equalsIgnoreCase("-1"))
		{
			if (resp1.getKycRes().length == 0) {
				throw new Exception(
						"KYC response xml retured a status of -1, no content found.");
			}
		}
		
		
		byte[] kycRes = resp1.getKycRes();
		
		 //START BECAUSE OF CHANGE IN resp.JAVA........ DATED 26mar2014
		int x1=responseXML.indexOf("<kycRes>");	
        x1+=8;
        int y1=responseXML.indexOf("</kycRes>");
        String  kycResStr =    responseXML.substring(x1, y1);
        //Log.ksa.info("kycResStr :"+kycResStr);
        
        //end BECAUSE OF CHANGE IN resp.JAVA........ DATED 26mar2014
        
        kycRes = com.qualtech.in.gov.uidai.base64.CustomBase64.decodeBase64(kycResStr);
    //    System.out.println("Starting decryption");
        DataDecryptor dd= new DataDecryptor("D:\\Docs\\Finger Print Scanner SDK\\SupportFiles\\pkcs11.cfg",
        		"password".toCharArray(),"D:\\Docs\\Finger Print Scanner SDK\\SupportFiles\\oldCer\\uidai_auth_stage_pre-prod.cer");
        
	//	System.out.println(new String(dd.decrypt(kycRes)));
		String xml = new String(dd.decrypt(kycRes));
	//	System.out.println(dd.verify(xml));
	//	System.out.println("response >>> "+xml);
		
	}
}
