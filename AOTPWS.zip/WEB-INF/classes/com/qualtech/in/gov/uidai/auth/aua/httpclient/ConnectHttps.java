/*
 * Created on Nov 1, 2013
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.qualtech.in.gov.uidai.auth.aua.httpclient;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ConnectException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.log4j.Logger;

import com.qualtech.in.gov.uidai.auth.aua.qc.KYCRequestCaller;



public class ConnectHttps {
	private static Logger _ologger = Logger.getLogger(KYCRequestCaller.class.getName());
	public static class DummyTrustManager implements X509TrustManager {
		
		public DummyTrustManager() {
		}

		public boolean isClientTrusted(X509Certificate cert[]) {
			return true;
		}

		public boolean isServerTrusted(X509Certificate cert[]) {
			return true;
		}

		public X509Certificate[] getAcceptedIssuers() {
			return new X509Certificate[0];
		}

		public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}

		public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {

		}
	}
	public static class DummyHostnameVerifier implements HostnameVerifier {

		public boolean verify( String urlHostname, String certHostname ) {
			return true;
		}

		public boolean verify(String arg0, SSLSession arg1) {
			return true;
		}
	}
	
	public static String getResponseFromHttps(String asaUrl,String xml)
	{
		_ologger.debug("In getResponseFromHttps method of ConnectHttps");
		SSLContext sslcontext = null;
		String  responseXML ="";
		try {
			
			sslcontext = SSLContext.getInstance("SSL");
			
			//Added for  Testing for Security Notification for SSLv3
			//sslcontext = SSLContext.getInstance("");
			_ologger.info("protocol "+"");

			sslcontext.init(new KeyManager[0],
					new TrustManager[] { new DummyTrustManager() },
					new SecureRandom());
		} catch (NoSuchAlgorithmException e) {
		
			_ologger.error("Exception in ConnectHttps :"+e,e);
			
		} catch (KeyManagementException e) {
			_ologger.error("Exception in ConnectHttps :"+e,e);	
		}
		
		String urlParameters="eXml=";
		try{
			urlParameters =urlParameters + URLEncoder.encode(xml, "UTF-8");
		}catch(Exception e){
			
			_ologger.error("Exception in ConnectHttps :"+e,e);
			
		}
		try{
			SSLSocketFactory factory = sslcontext.getSocketFactory();
			URL url;
			HttpsURLConnection connection;
			InputStream is = null;


			String ip=asaUrl;
			url = new URL(ip);
			System.out.println("URL "+ip);
			
			Proxy proxy1 = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
			
			
			
			connection = (HttpsURLConnection) url.openConnection(proxy1);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");
			connection.setUseCaches (false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setSSLSocketFactory(factory);
			connection.setHostnameVerifier(new DummyHostnameVerifier());
			OutputStream os = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			osw.write(urlParameters);
			osw.flush();
			osw.close();
			is =connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			
			String strTemp;
		    while ((strTemp = in.readLine()) != null) 
		    {
		    	responseXML = responseXML + strTemp;
		    	 //System.out.println(responseXML);
		    }
		    

			//System.out.println("Output: "+line);
			is.close();
			in.close();
		}
		catch(ConnectException e){
			_ologger.error("Exception in ConnectHttps :"+e,e);
		}
		catch(Exception e){
			
			_ologger.error("Exception in ConnectHttps :"+e,e);
		}
		_ologger.debug("In getResponseFromHttps method of ConnectHttps");
		return responseXML;
	}
	public static String getResponseFromHttps(String httpsUrl,String postParName, String postParValue)
	{
	
		_ologger.debug("In getResponseFromHttps method of ConnectHttps");
		SSLContext sslcontext = null;
		String  responseXML ="";
		try {
			sslcontext = SSLContext.getInstance("SSL");
			//Added for  Testing for Security Notification for SSLv3
			//sslcontext = SSLContext.getInstance("");
			_ologger.error("UIDProperties.getProtocol() :"+"");

			sslcontext.init(new KeyManager[0],
					new TrustManager[] { new DummyTrustManager() },
					new SecureRandom());
		} catch (NoSuchAlgorithmException e) {
		
			_ologger.error("Exception in ConnectHttps :"+e,e);
			
		} catch (KeyManagementException e) {
			_ologger.error("Exception in ConnectHttps :"+e,e);	
		}
		
		String urlParameters=postParName+"=";
		try{
			urlParameters =urlParameters + URLEncoder.encode(postParValue, "UTF-8");
		}catch(Exception e){
			
			_ologger.error("Exception in ConnectHttps :"+e,e);
			
		}
		try{
			SSLSocketFactory factory = sslcontext.getSocketFactory();
			URL url;
			HttpsURLConnection connection;
			InputStream is = null;


			String ip=httpsUrl;
			url = new URL(ip);
			System.out.println("URL "+ip);
			connection = (HttpsURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
			connection.setRequestProperty("Content-Language", "en-US");
			connection.setUseCaches (false);
			connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setSSLSocketFactory(factory);
			connection.setHostnameVerifier(new DummyHostnameVerifier());
			OutputStream os = connection.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			osw.write(urlParameters);
			osw.flush();
			osw.close();
			is =connection.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(is));
			
			String strTemp;
		    while ((strTemp = in.readLine()) != null) 
		    {
		    	responseXML =  strTemp;
		    }
			is.close();
			in.close();
		}
		catch(ConnectException e){
			_ologger.error("Exception in ConnectHttps for license key check :"+e,e);
			responseXML =   "Unable to connect to server" ;
			e.printStackTrace();
		}
		catch(Exception e){
			responseXML =  "Exception Occured" ;
			_ologger.error("Exception in ConnectHttps for  license key check  :"+e,e);
			e.printStackTrace();
		}
		_ologger.debug("In getResponseFromHttps method of ConnectHttps for license key check  ");
		return responseXML;
	}
}
