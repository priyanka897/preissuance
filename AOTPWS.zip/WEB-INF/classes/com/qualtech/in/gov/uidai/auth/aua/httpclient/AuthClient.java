/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.aua.httpclient;

import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.device.model.AuthResponseDetails;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_response._1.AuthRes;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ResourceBundle;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.nsdl.*;

import com.qualtech.webservice.nsdl.NSDLCaller;
//import com.sun.jersey.api.client.Client;
//import com.sun.jersey.api.client.WebResource;
import com.qualtech.webservice.service.RequestTypeValidator;


/**
 * <code>AuthClient</code> class can be used for submitting an Authentication
 * request to UIDAI Auth Server, and to get the response back. Given an
 * <code>Auth</code> object, this class (@see {@link AuthClient#authenticate})
 * will convert it to XML string, then, digitally sign it, and submit it to
 * UIDAI Auth Server using HTTP POST message. After, receiving the resonse, this
 * class converts the response XML into authentication response
 * 
 * @see AuthRes object
 * 
 * 
 * @author UIDAI
 * 
 */
public class AuthClient {
	private static Logger _ologger = Logger.getLogger(RequestTypeValidator.class.getName());
	ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
	private URI authServerURI = null;

	private String asaLicenseKey;
	private DigitalSigner digitalSignator;

	/**
	 * Constructor
	 * 
	 * @param authServerUri
	 *            - URI of the authentication server
	 */
	public AuthClient(URI authServerUri) {
		this.authServerURI = authServerUri;
	}

	public AuthClient() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Method to perform authentication
	 * 
	 * @param auth
	 *            Authentication request
	 * @return Authentication response
	 */
	public String authenticate(Auth auth) 
	{
		try {
			String authSignedXML ="";
			
			authSignedXML = generateSignedAuthXML(auth);
			
			authSignedXML = IApplicationConstants.AUTH_REQUEST+auth.getUid().charAt(0)+auth.getUid().charAt(1)+authSignedXML;
			
			authSignedXML = authSignedXML.replaceAll("[\n\r]", "").trim();
			
			// System.out.println("auth xml ... "+authSignedXML);

			 return authSignedXML;
			 
			 	//NSDLCaller nsdlrev = new NSDLCaller();
				//responseXML = nsdlrev.getResponseFromHttps(signedXML);  // for auth
			
			 
			/*
			String uriString = authServerURI.toString()
					+ (authServerURI.toString().endsWith("/") ? "" : "/")
					+ auth.getAc() + "/" + auth.getUid().charAt(0) + "/"
					+ auth.getUid().charAt(1);

			if (StringUtils.isNotBlank(asaLicenseKey)) {
				uriString = uriString + "/" + asaLicenseKey;
			}

			URI authServiceURI = new URI(uriString);

			WebResource webResource = Client
					.create(
							HttpClientHelper.getClientConfig(authServerURI
									.getScheme())).resource(authServiceURI);

			responseXML = webResource.header("REMOTE_ADDR",
					InetAddress.getLocalHost().getHostAddress()).post(
					String.class, signedXML);

			System.out.println(responseXML);

			*/
			
			//return new AuthResponseDetails(responseXML,parseAuthResponseXML(responseXML));

		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("Exception during authentication "
					+ e.getMessage(), e);
		}
	}

	private String generateSignedAuthXML(Auth auth) throws JAXBException,
			Exception {
		StringWriter authXML = new StringWriter();
		_ologger.info("Enters in AuthClient method where 1.0 --saurav>>>>>>>>>>> :");
		//System.out.println("Enter into generateSignedAuthXML");
		JAXBElement authElement = new JAXBElement(new QName("http://www.uidai.gov.in/authentication/uid-auth-request/2.0",
				"Auth"), Auth.class, auth);

		JAXBContext.newInstance(Auth.class).createMarshaller().marshal(authElement, authXML);
		boolean includeKeyInfo = true;

		if (System.getenv().get("SKIP_DIGITAL_SIGNATURE") != null) 
		{
			return authXML.toString();
		} else {
			String str = this.digitalSignator.signXML(authXML.toString(),includeKeyInfo);
			
			//System.out.println("Exit from generateSignedAuthXML");
			return str;
		}
	}

	private AuthRes parseAuthResponseXML(String xmlToParse)
			throws JAXBException {

		// Create an XMLReader to use with our filter
		try {
			// Prepare JAXB objects
			JAXBContext jc = JAXBContext.newInstance(AuthRes.class);
			Unmarshaller u = jc.createUnmarshaller();

			XMLReader reader;
			reader = XMLReaderFactory.createXMLReader();

			// Create the filter (to add namespace) and set the xmlReader as its
			// parent.
			NamespaceFilter inFilter = new NamespaceFilter(
					"http://www.uidai.gov.in/authentication/uid-auth-response/1.0",
					true);
			inFilter.setParent(reader);

			// Prepare the input, in this case a java.io.File (output)
			InputSource is = new InputSource(new StringReader(xmlToParse));

			// Create a SAXSource specifying the filter
			SAXSource source = new SAXSource(inFilter, is);

			// Do unmarshalling
			AuthRes res = u.unmarshal(source, AuthRes.class).getValue();
			return res;
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * Method to inject an instance of <code>DigitalSigner</code> class.
	 * 
	 * @param digitalSignator
	 */
	public void setDigitalSignator(DigitalSigner digitalSignator) {
		this.digitalSignator = digitalSignator;
	}

	public void setAsaLicenseKey(String asaLicenseKey) {
		this.asaLicenseKey = asaLicenseKey;
	}

	
	public AuthResponseDetails authenticate(Auth auth,String uid) {
		try {
			String signedXML = generateSignedAuthXML(auth);
			String pre = "A" + uid.charAt(0)+ uid.charAt(1);
			signedXML  = pre + signedXML;
			//Log.biom_Log.info("Auth Request Xml :\n"+signedXML);
		    signedXML = signedXML.replace("+", "%2B");
			//Log.biom_Log.info("UID :"+uid);
			//Log.biom_Log.info("XML :\n"+signedXML);

			/*
			String uriString = authServerURI.toString() + (authServerURI.toString().endsWith("/") ? "" : "/")
			+ auth.getAc() + "/" + auth.getUid().charAt(0) + "/" + auth.getUid().charAt(1);
			
			if (StringUtils.isNotBlank(asaLicenseKey)) {
				uriString  = uriString + "/" + asaLicenseKey;
			}

			URI authServiceURI = new URI(uriString);
			Log.biom_Log.info("in authenticate method");
			WebResource webResource = Client.create(HttpClientHelper.getClientConfig(authServerURI.getScheme())).resource(authServiceURI);
			Log.biom_Log.info("getting response");
			String responseXML = webResource.header("REMOTE_ADDR", InetAddress.getLocalHost().getHostAddress()).post(String.class,
					signedXML);
			*/
			String responseXML="";
			
			try
		      {
				/*
				Log.biom_Log.info("Connecting to " + ASA_IP
		                             + " on ASA_PORT " + ASA_PORT);
		         Socket client = new Socket(ASA_IP, ASA_PORT);
		         Log.biom_Log.info("Just connected to "
		                      + client.getRemoteSocketAddress());
		         OutputStream outToServer = client.getOutputStream();
		         DataOutputStream out =
		                       new DataOutputStream(outToServer);
		         //String signedXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Auth xmlns=\"http://www.uidai.gov.in/authentication/uid-auth-request/1.0\" ac=\"public\" lk=\"ME1u5JbX3fTNYqTFSFwxuTSOQFLkm_dp3x9qAVt2ybevmmBk93zckpc\" sa=\"public\" tid=\"public\" txn=\"AuthDemoClient:public:20130704045729300\" uid=\"999999990042\" ver=\"1.6\"><Uses bio=\"n\" otp=\"n\" pa=\"n\" pfa=\"n\" pi=\"n\" pin=\"n\"/><Meta fdc=\"NC\" idc=\"NA\" lot=\"P\" lov=\"400079\" pip=\"127.0.0.1\" udc=\"UIDAI:UAT\"/><Skey ci=\"20150922\" ki=\"877354ba-2fc0-44c1-89ab-72e104759461\">Z4EtP38WPFtzZd5hZeLwOn/+2dB0gPicIRwTO15KbZsYv9wxMoEMzaUhHoRnVopX2o3kU8O212xbUMYKmCpq5R+nluxQDBQ8yV5M6o15IYApJtDhvJKYycpCm6nvdLlEHfs01AYbNbI5J8Ggwfuv2DPuQOGd67bHGwhD/fnIgBsmgdE8uqFxZrW7YN/vwGg0gX5H/+X2FmE3S5MGvE4djKM/bJaIP4+IUg4z1/lxZyG3cpFVYQ0GqGE5vmDtMeO/yuKvpcUsu+yA0GSgxNZ9mltzIjNhnNlBIR7e/CnaVYqJxjnad2s5vyfUnRVmRhyXI4TUVqHpUS3366EP6PoKaw==</Skey><Data type=\"X\">WGRnBD4Db5pKFJRi3++N25AJR2paTQbmt+oDrPbuQJhifneHebM4MbxRUne15XsLLrleLPnZUSjOWU1350464nfB0glhg1dpm+A51O3DkXdPDqdNqkuRcNDxvxznZpFFDdwV3PHBD2vuNoVrndg32iPZZyIZdrlwI+ygPsOD8g1tbIdpQWKwvrNii76JHMhE6eVjVmakbIYvDOVNz6kXt5qMZgkIfSjzXZb/fiQIK6d5+SEtIDwTOuabDehuCERVbX2mruYgnt5PFkLT8qE6VP6QrojtvHkR1kFgouZoHJbTawlM59t/+ik40s4vXwJwHyvBzyIzJY8wup2eRTo26Q==</Data><Hmac>4rFshJcL+7hfEyuClijo599l9yy9+4ulxXpV+v2W26xBPWci7yskl6fT+T7NaPN6</Hmac><Signature xmlns=\"http://www.w3.org/2000/09/xmldsig#\"><SignedInfo><CanonicalizationMethod Algorithm=\"http://www.w3.org/TR/2001/REC-xml-c14n-20010315\"/><SignatureMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#rsa-sha1\"/><Reference URI=\"\"><Transforms><Transform Algorithm=\"http://www.w3.org/2000/09/xmldsig#enveloped-signature\"/></Transforms><DigestMethod Algorithm=\"http://www.w3.org/2000/09/xmldsig#sha1\"/><DigestValue>c9HuTyAQ0kdoFoGKyGYGlxgo8RA=</DigestValue></Reference></SignedInfo><SignatureValue>Wu24IT/mCWQYzzycIN38TpvnsVpH/jlwv1IhaV1j4mZN6EqCIiaOGKdxRA/6uz7xh1NIYVlwVqtK2y3+pGW3pucMXLVe3nH+R6r2G8r/kRuAP5peQ4Q1m5Kosa7SSFdxZ3U9FKiw+DZgIcFpgVrq3ZiZrPzNMe1CXwXb3h8zvj0gal3qF5bY/D/XzDGmXDamcHmoObw2B6lpf68UAzZgEtiFjktC9gVnvUyhOKGRPmLEpMtbYJ5ZlmY3CwSb4JnusMAL7ZYvHm7LojuvWHqiueoRTjaBfTYItRoHfzH/VfU9Y/k3WhEjcWOb+QQi7UvUKXmPrY4I/Y86jsTIDuZ4MQ==</SignatureValue><KeyInfo><X509Data><X509SubjectName>CN=Public AUA for Staging Services,OU=Staging Services,O=Public AUA,L=Bangalore,ST=KA,C=IN</X509SubjectName><X509Certificate>MIIDvTCCAqWgAwIBAgIGWXyspv4MMA0GCSqGSIb3DQEBBQUAMIGSMQswCQYDVQQGEwJJTjELMAkGA1UECBMCS0ExEjAQBgNVBAcTCUJhbmdhbG9yZTEOMAwGA1UEChMFVUlEQUkxGTAXBgNVBAsTEFN0YWdpbmcgU2VydmljZXMxNzA1BgNVBAMTLlNlbGYgU2lnbmVkIFJvb3QgQ0EgZm9yIFVJREFJIFN0YWdpbmcgU2VydmljZXMwHhcNMTIwNTI0MTEwMjM0WhcNMTYwNTI0MTEwMjM0WjCBiDELMAkGA1UEBhMCSU4xCzAJBgNVBAgTAktBMRIwEAYDVQQHEwlCYW5nYWxvcmUxEzARBgNVBAoTClB1YmxpYyBBVUExGTAXBgNVBAsTEFN0YWdpbmcgU2VydmljZXMxKDAmBgNVBAMTH1B1YmxpYyBBVUEgZm9yIFN0YWdpbmcgU2VydmljZXMwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCRStGvcMgKjv+s8QWdHTYuIq0w30QW1LQ/ElIN/JGlcg2vmyfD6dnyNl2Knn8uDXeSL4ueTIdijv+u6gFnY7inoiXa5Un+E6yMtrhJhIZL5Fy54oJ+YTjqu8x23Nva7dlHL+b/rWlJHKksy7ZhFTw+RdYqJHRlH6vJp6R+6yRGdHGiJQw6NF4SR1Cpa9GmTKhyaF+01RC6UQ4OaD4p7HECmPkCVtcyQVLKjgDJHDCXCmh7BpUq0c1EM7iBOSznr1R0FOFR/mA4RFA8nCMbCtscbTG471KzPD0yJLKV0ybahI0vtfcR4JGMjJFfZzmSBh4MDNluQmCmSvAlQcW9zRSzAgMBAAGjITAfMB0GA1UdDgQWBBTqyNrEemYkwM6F9ytRIleyFvDedzANBgkqhkiG9w0BAQUFAAOCAQEAHaLyjaQZKbzVkOpOibK/oarvh3nX+mgZeVskku+Y7BWxbHYHKTt0Sj93Vbg+62pBZoa5kgx+c7CZuzwv+Z7k+0M5bQh73jA4UAXYHjNet+2XMZ+19/3tUQI6cI3vQKZXEvqAZNBhOwC5xcKI073RItEdheWHo/uv/ppwaZ+KsfbqLWh9uR+Xl/ES9hIGRW4+1s5DAhgmQlJFcVnzZXTPOqgofWVEsZn1JQLzS6WmmslUkaHWdeqHsOsB6gW8UBnSpSDA/migz1WdWAScwk+9Z8umd6HKhKttHX3ESSBez/4EFbAWRxB+xdf91MTsBHKM2htPI9rrz64kU/Fr/M709w==</X509Certificate></X509Data></KeyInfo></Signature></Auth>";
		         out.writeUTF(signedXML);
		         InputStream inFromServer = client.getInputStream();
		         DataInputStream in =
		                        new DataInputStream(inFromServer);
		         responseXML=in.readUTF();
		         Log.biom_Log.info("Reponse XML :\n"+responseXML);
		         //System.out.println("Server says " + responseXML);
		         client.close();
		         */
				String asaUrl =bundle.getString("URL"); 
				_ologger.info("ASA URL :"+asaUrl);
				
				boolean isHttp = false;
				String subStr = asaUrl.substring(0, asaUrl.indexOf(":"));
				if(subStr.equalsIgnoreCase("http"))
				{
					isHttp=true;
				}
				
				if(isHttp)
				{
					URL url = new URL(asaUrl);
				    URLConnection con = url.openConnection();
				    con.setDoInput(true);
				    con.setDoOutput(true);
			
				  
				    con.setUseCaches (false);
				    con.setDefaultUseCaches (false);
				    con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
				  
				    PrintWriter outWriter = new PrintWriter(con.getOutputStream());
				    
				    
				     // send data to the servlet
				  
				    //// Log.kua.info(" Request Xml :\n"+kycSignedXML);
				    //System.out.println("Kyc Xml = \n"+kycSignedXML);
				    _ologger.info("Before sending Request Xml ");
				    signedXML= URLEncoder.encode(signedXML, "UTF-8");
				     outWriter.print("eXml="+signedXML);
				     _ologger.info("After sending Request Xml ");
				     outWriter.close();
				     _ologger.info("Signed Auth XML sent to ASA");
				     _ologger.info("Getting Stream from ASA for response");
				     InputStream input = con.getInputStream();
				     BufferedReader br = new BufferedReader(new InputStreamReader(input));
				     String strTemp;
				     while ((strTemp = br.readLine()) != null) 
				     {
				    	 responseXML = responseXML + strTemp;
				    	 //System.out.println(responseXML);
				     }
				}
				else
				{
					responseXML = ConnectHttps.getResponseFromHttps(asaUrl, signedXML);					
				}
				_ologger.info("Response XML from ASA :\n"+responseXML);
		      }
		       
		      catch(Exception e)
		      {
		    	  _ologger.error("Exception in AuthClient :"+e,e);
		      }
			
			//System.out.println(responseXML);
		      if(responseXML.equalsIgnoreCase("E"))
				{
		    	  _ologger.info("Error received from ASA");
					
				}
				else
				{	
					return new AuthResponseDetails(responseXML, parseAuthResponseXML(responseXML));
				}
			
			
		} catch (Exception e) {
			_ologger.info("exception in authclient",e);
			
		}
		return null;
	}

	
}
