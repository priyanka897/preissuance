/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.aua.httpclient;

import com.itextpdf.text.log.SysoLogger;
import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.aua.qc.KYCRequestCaller;
import com.qualtech.in.gov.uidai.auth.device.helper.PidCreator;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Uses;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;
import com.qualtech.in.gov.uidai.base64.CustomBase64;
import com.qualtech.in.gov.uidai.kyc.client.DataDecryptor;
import com.qualtech.in.gov.uidai.kyc.client.utils.XMLUtilities;
import com.qualtech.in.gov.uidai.kyc.common.types._1.YesNoType;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_request._1.Kyc;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_request._1.RaType;
import com.qualtech.in.gov.uidai.kyc.uid_kyc_response._1.Resp;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.exception.AppBaseException;
import com.qualtech.webservice.nsdl.*;

import com.qualtech.webservice.nsdl.NSDLCaller;
//import com.sun.jersey.api.client.Client;
//import com.sun.jersey.api.client.WebResource;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;




/**
 * <code>OtpClient</code> class can be used for submitting an OTP Generation
 * request to UIDAI OTP Server, and to get the response back
 * 
 * @author UIDAI
 * 
 */
public class KYCClient {
	
	private URI kycServerURI = null;
	private static Logger _ologger = Logger.getLogger(KYCRequestCaller.class.getName());
	public static final String SLASH = "/";

	private String asaLicenseKey;
	private DigitalSigner digitalSignator;
	private DataDecryptor dataDecryptor;
	private String encrpytXml;

	public String getEncrpytXml() {
		return encrpytXml;
	}


	public void setEncrpytXml(String encrpytXml) {
		this.encrpytXml = encrpytXml;
	}


	public KYCClient(URI kycServerURI) {
		this.kycServerURI = kycServerURI;
	}
	public KYCClient() {
		
	}
	
	/**
	 *  added by mohit for getting KYC details....
	 * @throws AppBaseException 
	 *  
	 */
	
	public String getKycDetails(Auth auth,boolean isRcReceived,Pid pid,Uses usesElement , String kycVer) throws AppBaseException
	{
		String kycSignedXML="";
		String raType = "";
		
		//System.out.println("usesElement "+usesElement);
		//System.out.println("usesElement.getBt() "+usesElement.getBt());
		
		if (usesElement.getBt().contains("FIR")
				|| usesElement.getBt().contains("FMR")) {
			raType += "F";
		}
		if (usesElement.getBt().contains("IIR")) {
			raType += "I";
		}
		if (usesElement.getOtp().toString().contains("Y")) {
			raType += "O";
		}
		if (raType.isEmpty())
			raType = "F";

		String rcType = "N";
		String mecType="N";
		String lrType="N";
		if (isRcReceived) {
			rcType = "Y";
			mecType="Y";
			lrType="Y";
		}
		
		try
		{
			String authSignedXML = generateSignedAuthXML(auth);
			_ologger.debug("signed auth xml-->"+authSignedXML);
			byte[] codedAuthXML =authSignedXML.getBytes();
			
			Kyc kyc = new Kyc();
			kyc.setRa(RaType.valueOf(raType));
			kyc.setRc(YesNoType.valueOf(rcType));
			kyc.setVer(kycVer);
			kyc.setDe(YesNoType.N);
		  //	kyc.setTs(pid.getTs());
			kyc.setLr(YesNoType.valueOf(lrType));
			//kyc.setMec(YesNoType.valueOf(mecType));
			kyc.setPfr("N");
			/*Calendar calendar = GregorianCalendar.getInstance();
			kyc.setTs(XMLGregorianCalendarImpl.createDateTime(
					calendar.get(Calendar.YEAR),
					calendar.get(Calendar.MONTH) + 1,
					calendar.get(Calendar.DAY_OF_MONTH),
					calendar.get(Calendar.HOUR_OF_DAY),
					calendar.get(Calendar.MINUTE),
					calendar.get(Calendar.SECOND)));*/
			
			//XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
			//kyc.setTs(calendar);  
		//	_ologger.info("KYC timestamp::->>>> "+kyc.getTs());
			kyc.setRad(codedAuthXML);
			
			
		
			if (StringUtils.isBlank(System.getenv("USE_CUSTOM_KYC_XML"))) {
				_ologger.info("USE_CUSTOM_KYC_XML>>>>>>>>>>>>--------if executed");
				kycSignedXML = generateSignedKycXML(kyc);
			
			} else {
				_ologger.info("USE_CUSTOM_KYC_XML>>>>>>>>>>>>--------else executed");
				String customKYCXML = "";
				Document kycDOM = XMLUtilities.getDomObject(customKYCXML);
				XMLUtilities.addRarNode(kycDOM, codedAuthXML);
				String updatedCustomKYCXML = XMLUtilities.getString(kycDOM);
		//		System.out.println(updatedCustomKYCXML);
				kycSignedXML = generateSignedKycXML(updatedCustomKYCXML);
			}
			
				kycSignedXML = IApplicationConstants.AUTH_REQUEST+auth.getUid().charAt(0)+auth.getUid().charAt(1)+kycSignedXML;
			
				kycSignedXML = kycSignedXML.replaceAll("[\n\r]", "").trim();
							
				_ologger.debug("kycSignedXML-->"+kycSignedXML);
			
		}
		catch(Exception ee)
		{
			//ee.printStackTrace();
			_ologger.info("Exception in kycSignedXML-->"+ee.getMessage());
			//throw new AppBaseException("Exception during KYC transaction "+ ee.getMessage(),ee);
		}
		
		return kycSignedXML;
	}
	
	
	// Changed for Mobile/Email ID consent and Local  Language required Consent
	String mecType;
	String lrType;
	String deType;
//	public String kycTrans(Auth auth, String kua, boolean isRcReceived,
//			String ksaLicense, Uses usesElement, String customXML
//	) {
//		setAsaLicenseKey(ksaLicense);
//
//		String raType = "";
//		if (usesElement.getBt().contains("FIR")
//				|| usesElement.getBt().contains("FMR")) {
//			raType += "F";
//		}
//		if (usesElement.getBt().contains("IIR")) {
//			raType += "I";
//		}
//		if (usesElement.getOtp().toString().contains("Y")) {
//			raType += "O";
//		}
//		if (raType.isEmpty())
//			raType = "F";
//
//		String rcType = "N";
//		if (isRcReceived) {
//			rcType = "Y";
//		}
//
//
//		try {
//			String signedXML = generateSignedAuthXML(auth);
//			byte[] codedAuthXML =signedXML
//			.getBytes();
//			Kyc kyc = new Kyc();
//			kyc.setRa(RaType.valueOf(raType));
//			kyc.setRc(YesNoType.valueOf(rcType));
//			kyc.setMec(YesNoType.valueOf(mecType));
//			kyc.setLr(YesNoType.valueOf(lrType));
//			kyc.setDe(YesNoType.valueOf(deType));
//			kyc.setVer("1.0");
//			XMLGregorianCalendar calendar = DatatypeFactory
//			.newInstance()
//			.newXMLGregorianCalendar(
//					(GregorianCalendar) GregorianCalendar.getInstance());
//			kyc.setTs(PidCreator.pidTs.getTs());
//			System.out.println("KYC"+PidCreator.pidTs.getTs());
//			kyc.setRad(codedAuthXML);
//
//			String kycSignedXML;
//			if (StringUtils.isBlank(System.getenv("USE_CUSTOM_KYC_XML"))) {
//				kycSignedXML = generateSignedKycXML(kyc);
//				System.out.println(kycSignedXML);
//			} else {
//				String customKYCXML = customXML;
//				Document kycDOM = XMLUtilities.getDomObject(customKYCXML);
//				XMLUtilities.addRarNode(kycDOM, codedAuthXML);
//				String updatedCustomKYCXML = XMLUtilities.getString(kycDOM);
//				System.out.println(updatedCustomKYCXML);
//				kycSignedXML = generateSignedKycXML(updatedCustomKYCXML);
//			}
//
//			String uriString = kycServerURI + SLASH + kua + SLASH + "1" + SLASH + "0" + SLASH
//			+ ksaLicense;
//			URI authServiceURI = new URI(uriString);
//
//			WebResource webResource = null;//Client.create(HttpClientHelper.getClientConfig(kycServerURI.getScheme())).resource(authServiceURI);
//			
//			System.out.println(kycSignedXML);
//			String responseXML = webResource.header("REMOTE_ADDR",
//					InetAddress.getLocalHost().getHostAddress()).post(String.class, kycSignedXML);
//			System.out.println("resp\n\n" + responseXML);
//
//			Resp resp1 = (Resp) XMLUtilities.parseXML(Resp.class, responseXML);
//			if (resp1.getStatus().equalsIgnoreCase("-1")) {
//				if (resp1.getKycRes().length == 0) {
//					throw new Exception(
//					"KYC response xml retured a status of -1, no content found.");
//				}
//			}
//			byte[] kycRes = resp1.getKycRes();
//			String xml = "";
//			if (resp1.getStatus().equalsIgnoreCase("0")) {
//				xml = new String(dataDecryptor.decrypt(kycRes));
//			} else {
//				xml = new String(kycRes);
//			}
//			System.out.println(xml);
//			if(StringUtils.isBlank(System.getenv("SKIP_RESP_SIG_VERIFY")))
//			{
//				if (dataDecryptor.verify(xml)) {
//					return xml;
//				} else {
//					throw new Exception(
//					"KYC response xml signature verification failed.");
//				}
//			}
//			else{
//				return xml;	
//			}
//
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new RuntimeException("Exception during KYC transaction "
//					+ e.getMessage(), e);
//		}
//	}


	private String generateSignedKycXML(Kyc kyc) throws JAXBException,
	Exception {
		StringWriter kycXML = new StringWriter();
		_ologger.info("Enters in  generateSignedKycXML--saurav18>>>>>>>>>>> :");	

		JAXBElement kycElement = new JAXBElement(new QName(	"http://www.uidai.gov.in/kyc/uid-kyc-request/1.0", "Kyc"),
				Kyc.class, kyc);

		JAXBContext.newInstance(Kyc.class).createMarshaller().marshal(
				kycElement, kycXML);
		boolean includeKeyInfo = true;
		_ologger.info("value of kycXML in  generateSignedKycXML--saurav18>>>>>>>>>>> :"+kycXML);	
		//String namespaceremove=kycXML.toString().replaceFirst("xmlns=\"http://www.uidai.gov.in/kyc/uid-kyc-request/1.0", "");
	//	System.out.println(">>>>>>>>>>>>>>>>>>>>>>> "+kycXML.toString());
		return this.digitalSignator.signXML(kycXML.toString(), includeKeyInfo);

	}

	private String generateSignedKycXML(String kycXML) throws JAXBException,
	Exception {
		boolean includeKeyInfo = true;
		return this.digitalSignator.signXML(kycXML.toString(), includeKeyInfo);

	}

	private String generateSignedAuthXML(Auth auth) throws JAXBException,
	Exception {
		StringWriter authXML = new StringWriter();
		_ologger.info("Enters in KYCClient method where 2.0 --saurav>>>>>>>>>>> :");
		JAXBElement authElement = new JAXBElement(new QName(
				"http://www.uidai.gov.in/authentication/uid-auth-request/2.0",
		"Auth"), Auth.class, auth);

		JAXBContext.newInstance(Auth.class).createMarshaller().marshal(
				authElement, authXML);
		boolean includeKeyInfo = true;

		if (System.getenv().get("SKIP_DIGITAL_SIGNATURE_AUTH_ONLY") != null) 
		{
			_ologger.debug("auth-xml-in-jaxbmethod-saurav2-->"+authXML.toString());
			return authXML.toString();
		} else {
			_ologger.debug("auth-xml-in-jaxbmethod-saurav2-->"+authXML.toString());
			return this.digitalSignator.signXML(authXML.toString(),
					includeKeyInfo);
		}
	}

	/**
	 * Method to inject an instance of <code>DigitalSigner</code> class.
	 * 
	 * @param digitalSignator
	 */
	public void setDigitalSignator(DigitalSigner digitalSignator) {
		this.digitalSignator = digitalSignator;
	}

	public void setAsaLicenseKey(String asaLicenseKey) {
		this.asaLicenseKey = asaLicenseKey;
	}

	/**
	 * @param dataDecryptor
	 *            the dataDecryptor to set
	 */
	public void setDataDecryptor(DataDecryptor dataDecryptor) {
		this.dataDecryptor = dataDecryptor;
	}
	//ADDED for mec and lr requirement
	public void setMecLr(boolean isMecRecieved,boolean isLrRecieved){
		mecType="N";
		lrType="N";
		if (isMecRecieved) {
			mecType = "Y";
		}
		if (isLrRecieved) {
			lrType = "Y";
		}

	}
	public void setDe(boolean isDeRecieved){
		deType="N";
		if (isDeRecieved) {
			deType = "Y";
		}
	}

	 public String kycTrans(Auth auth, String kua, boolean isRcReceived, String ksaLicense, Uses usesElement,
			  String customXML, boolean isMec, boolean isLr, boolean isDe,String fingerPrint,String serviceUrl,Pid pid)
	  {
	    setAsaLicenseKey(ksaLicense);
	    String xml = "";
	    String raType = "";
	    if ((usesElement.getBt().contains("FIR")) ||(usesElement.getBt().contains("FMR"))) 
	    {
	      raType = raType + "F";
	    }
	    if (usesElement.getBt().contains("IIR")) 
	    {
	      raType = raType + "I";
	    }
	    if (usesElement.getOtp().toString().contains("Y")) 
	    {
	      raType = raType + "O";
	    }
	    if (raType.length() == 0) 
	    {
	      raType = "F";
	    }
	    String rcType = "Y";
	    if (isRcReceived) 
	    {
	      rcType = "Y";
	    }
	    String mecType = "N";
	    if (isMec) 
	    {
	      mecType = "Y";
	    }
	    String lrType = "N";
	    if (isLr) 
	    {
	      lrType = "Y";
	    }
	    String deType = "N";
	    if (isDe) 
	    {
	      deType = "Y";
	    }
	    try
	    {
	      String signedXML = generateSignedAuthXML(auth);

	    //  _ologger.info("Request Xml :\n" + signedXML);
	      byte[] codedAuthXML = signedXML.getBytes();
	      Kyc kyc = new Kyc();
	      kyc.setRa(RaType.valueOf(raType));
	      kyc.setRc(YesNoType.valueOf(rcType));
	      kyc.setMec(YesNoType.valueOf(mecType));
	      kyc.setLr(YesNoType.valueOf(lrType));
	      kyc.setDe(YesNoType.valueOf(deType));
          kyc.setPfr("N");
	      kyc.setVer("2.0");

	      
	     // _ologger.info( fingerPrint.length());
	      
	           
	      
	     /* if(fingerPrint.length()==0)
	      {
	     	  java.util.Date date= new java.util.Date();
	      	  String a=new Timestamp(date.getTime()).toString();
	          XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(a);
	          kyc.setTs(date2);
	      }
	      else
	      {
	     	   //kyc.setTs(PidCreator.getPidTsXML());
	    	  kyc.setTs(pid.getTs());
	      }*/
	     // java.util.Date date= new java.util.Date();
      	  //String a=new Timestamp(date.getTime()).toString();
          // XMLGregorianCalendar date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(a);
           
	     //  XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
           
           
           
           
	      
	      
	      _ologger.info("KYC ts :" + kyc.getTs());
	      kyc.setRad(codedAuthXML);

	      String kycSignedXML = generateSignedKycXML(kyc);
	      kycSignedXML = "A" + auth.getUid().charAt(0) + auth.getUid().charAt(1) + kycSignedXML;
	      _ologger.info("Signed KYC XML generated");

	      String responseXML = "";

	      String ksaUrl = serviceUrl;
	      _ologger.info("KSA URL :" + ksaUrl);
	      boolean isHttp = false;
	      String subStr = ksaUrl.substring(0, ksaUrl.indexOf(":"));
	      if (subStr.equalsIgnoreCase("http"))
	      {
	        isHttp = true;
	      }

	  	/*if(isHttp)
		{
			URL url = new URL(ksaUrl);		
		    URLConnection con = url.openConnection();
		    con.setDoInput(true);
		    con.setDoOutput(true);

		  
		    con.setUseCaches (false);
		    con.setDefaultUseCaches (false);
		    con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		  
		    PrintWriter outWriter = new PrintWriter(con.getOutputStream());
		    
		    
		     // send data to the servlet
		    _ologger.info("Kyc Request Xml :\n"+kycSignedXML);
		    //kycSignedXML = kycSignedXML.replace("+", "%2B");
		    //// Log.kua.info(" Request Xml :\n"+kycSignedXML);
		    //System.out.println("Kyc Xml = \n"+kycSignedXML);
		    _ologger.info("Before sending Request Xml ");
		   //  outWriter.print("eXml="+kycSignedXML);
		     _ologger.info("After sending Request Xml ");
		     outWriter.close();
		     _ologger.info("Signed KYC XML sent to KSA");
		     _ologger.info("Getting Stream from KSA for response");
		     InputStream input = con.getInputStream();
		     BufferedReader br = new BufferedReader(new InputStreamReader(input));
		     String strTemp;
		     while ((strTemp = br.readLine()) != null) 
		     {
		    	 responseXML = responseXML + strTemp;
		    	 //System.out.println(responseXML);
		     }
		     br.close();
		}
		else
		{				
				//responseXML = ConnectHttps.getResponseFromHttps(ksaUrl, kycSignedXML);	
			//NSDLCaller nsdlrev = new NSDLCaller();		   
		   // kycSignedXML = kycSignedXML.replace("+", "%2B");
		  //  _ologger.info("eXml=  "+kycSignedXML);
		    System.out.println("eXml=  "+kycSignedXML);
			//responseXML = nsdlrev.getResponseFromHttps(kycSignedXML);  // for auth
		}*/
		//responseXML ="<?xml version=\"1.0\" encoding=\"UTF-8\"?><Resp status=\"0\"><kycRes>VkVSU0lPTl8xLjAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCRStGvcMgKjv+s8QWdHTYuIq0w30QW1LQ/ElIN/JGlcg2vmyfD6dnyNl2Knn8uDXeSL4ueTIdijv+u6gFnY7inoiXa5Un+E6yMtrhJhIZL5Fy54oJ+YTjqu8x23Nva7dlHL+b/rWlJHKksy7ZhFTw+RdYqJHRlH6vJp6R+6yRGdHGiJQw6NF4SR1Cpa9GmTKhyaF+01RC6UQ4OaD4p7HECmPkCVtcyQVLKjgDJHDCXCmh7BpUq0c1EM7iBOSznr1R0FOFR/mA4RFA8nCMbCtscbTG471KzPD0yJLKV0ybahI0vtfcR4JGMjJFfZzmSBh4MDNluQmCmSvAlQcW9zRSzAgMBAAHrDcW1QORPfci1PSinddFzGe6P0tNxyZhanCZP3E4V2yPklZFdg0fN3Lm77+5LUIjvcMgDn4jG3VTOzbO69OBBhoRd9Nmoe5FCUuIQFZoCWCyx59GbwMBcl2x8ZYWwM1wN9N1WEUVpnxYF2QrcRvO3YZ2JG5unMInCIIbMvJ+VzQ8Oo5uUKCc8LIlGIjpyIW1Uk8q+N9mKDdXCncFiJ+mNvXn9mOUj6PzJtqcwzCdw93suGbOeiqhACDybIHgkbzx06kT974BkGdaO+AMg6SRApH/zaZzXwB+enUnDeQ4K9amcSfS3ap/Mybj1S8LH2gPJNt34HrXnxcIztXI7fiQQuFDBSH3dNe3wazkNXAMbKjE2Y3J9jjagwx4whPzSwAZEm1xdEJRsE1tOpqvzsggEqT5G2gtuhW3i/a6b/Ng33GwMDbmlTIoaVXgo6z3/yb1RZCr250FbYPLFqcakEXx72EqlTnF19Li+ZhKbyatzOaj2DxlhbGqJ38EWoweogAOZfNCkix+pUoxN0U9zBxOInaFR5umorRZx3iXYcWPMwVf/ZlJGJSb694mj7AvIPmz+bYfFnDFuzo6455yu7WKa7eJUtXd44szjJBTUpUFzHF8f5hvNaoHZ4iJA2PVY2YzHf1tGGM+oQ1alFTGbbewJLD5F3wIvnrDOsyPca9d1gBk6tgZ1kvFqUQRrFPoeqax5z/TSAYudSw7/AIDlzaKV5q1L/jotJvfTCkeue6U5391TiGTEzOjITwIyMMQrCk3D9pQI2fDhk1Rnw69WmC0buT/FhjTHCWYop+ZMa3ISdz7xyS74A6pwU+Vwk/hY/92oDWupmg0uBePq83u/Na8kf7WXzRxOkeDeZTWUwGrbFYngr1zp4WeXTOVRTZvDnagBJ+7Zb9xXOT/GfFiFnJa5X78QQvqX+iTaNIAttRF2oHrgO1QTNdwV9sZrfurDmK+GoPn94D1c2tguptgOo8z5SVwc4KrzHUrdS/mjzDNY3pjOTsnIc5h6YNU2E1CxVFD8M+ruWFtn259Z3I2dHfpcq/fp/Ho1Gm4CernZBa65GrfsiNValjk3dauwf1C9gHE2lk3KDgqZHdjzLNNFGHsFLWvKdMzuMzr4b6S2hYMRgYOBRcfoBTfRQtnMMOsxo1fvQ2rZc4an8iH1ZSqCt/0Spwy/d01qP2JXbya1FMokxpgwRdxalDXfMJJB5h3jdX5tKvhEQWO7/rhxFlus6otAUyyT9EWswchCcif95eKbD3AMtlzFnWNalayo62JgQuburTvuzKakXk+8+iVOdAnqxy7yUGGMxOfuJMUgABypRJtgEjEjr1jjt4d83D2AlmedouIu6RKmU78mgmFpsC9xFJhswN9z09cQ4owtZa8u83DCoX6q+2H15nk7gvP3Tnu1xh922k06WpzsJtthK4wdxpCjYb9wet0DPV//cRCuHKimlw4h6g6zOKdoeVtQJOUpfyjp8AJpsd73syUA5H+uj7Y9Bl7O7u1w3YJkogGzPWpcdAFxo82dyRADVan0uL3J/+IHK4UBmITo0d7GCkBlnANRyRbDypQsXwIvqwC7CY43j8K27JEJxQoohXM4vgThBPsGQii6ibty/kXryn7ygeEA91B5WhlpY6ZedM4aPFGdL9b8n3JDt4Wq3A5clchOmUlEP+itA/k7O8EtzEkoYNfyuzN/3K66hahDwuW+NGNkvL+AXq/VVhhoQy+JefHlp252LD+E4iWHDItsjZIBbFipp61DZyALolfVg7uOEsPb5HtF8bXo/ohJB2YvSyxqb0v1WCBiCuFutM5v//IqOU6WMFD6H+B4j4zBjMwd251niOd7HPJVtvXylLAUxTt+LnIUx8zG4UXr+ghM3l+9gF8IOOSuc+5pVYC04nBQYAzfvEYR912d5lgB4mwS45TLuiwgezjtRC2N9lLTGxNV9suYVm4Mguy9b/LVVLpeWwn+c2iDv7bQK5pyrILUF99n7VS1KeElMLaAia8lNQCdnQzHRys+hGWa3tV0PJel6q/EeoA1R+3F7pkDF8RTEzHFS4AY1f3d8ZvYUGxhESyk2OeQL9VG3EFe9jwHBbfyGbgIx3//APGR93kIHdE/mMCso9nSonABqaeNSbtW5nQdV6FGbXhFSGLLguzNLIC7/kVHrTQVNFF8tZhjLuPYwBukLIQamiN0/h3LFdIVRUz0WiwS5lbXN/ZyGOqfUno0Vwo3AzixaWDzUb7RcKI0NA6suvC18TQuCY8gK4pXEWW+hzjCCj0GNzWVF7bzEiIIkGzQ77L3+gAEj6QDNOLQBscMaxMuOqNnzXX23UeE79yH9CimmhV/pyQBJQ8D6uvUa/4w8BkXhnP2iYUhzxGoHc92Al2XqS6ivsE3D+9Irg6Qwk7VDy/KZbHwksPGEN5CjaGlfM2JFoAtllbdvVd9qWyfglWpUAdD0ViPYG26qJLEmubP9hDS6QhEgDl6+XByyB2y14RyKJUSYEWcDoAlNfJC2c1pEzm8pRuphUiKWKY51W5GPP7XHoea2S0QAzx+eOika7MRh3Hj5KDRunoj2H62BOT2n4s8xpXvMo1mW2w+kBSkpRmtfuAPg2P9hANgLTBpXDH+Vvkgn3MuezAyoPp17tQl9QW2bpHeAGMuLgNTzvUyed5WRdSOJM1t/WT71V2lWMmR6E6BatgKMyGLL3Vk9xtRuaQUbmF1baeK8hvYaXmjYwTEoUu+bUhVriURSvwtA+DvCbHxXx4gdRgXTOff5/PdecGRNK4jN86shVy0JmV+w6VYq8Lp9DUqsE9LZOJZhEt1xOIRpQNGYhJHTbP20NgKmCciQ0PE7R44Bk6Qy1suBIgVu9Og5fncWEi7wJtQwh9kV6xWgvEm8hosBWf0VrRCEazbQ8nCSVewsYgxz3eOnBGrGlpRclMa8mOS7+8rLg3Cqsy1QcIt1q9htG3eN/LaauUibIHiQCnebiLLvpqIV9GeIM+sC8obW/532gVvdBgjg6FjF5Gs54wH1q57fyt+Cn5OfMCBs7Aavbf1PGesgcKxcFP5jpU9hn41BLSarOIq1ddOXybivSiWh/mgH4DEODY3D1+J1zxXO17VwUYXbwuudwiC0LFMpE3/+opEuHT/dvnsNv8qW99BW6UX6aOruwiSDEUIL07sGj4WU8my4Xbi1n4TAubXR3Cgoe7x9VMF/YOHJXTTMaCMutNbuY+ppY0ml8N6sTYiu1yaqSQ6yK09IQ5itNk3U1bFQCor2keKxcCgd6ymtY4tKFTiICfk8NMz8oxN+9evCOgwXnSdo9ATkOkRioWXASN9cQBk21iv2y4VPBko8darIvP9X30D09Xwu1Xb88oz9yeuSP1JRU7Cee/hGBXs/QxSOIkaNBOrGp5t0hO4mIjW3Drwdi0LH049Eso0CIokR/1o9lsVNXePNiRluOVvRMeQaoXoMdnqJeUFMdl3T7q9zhN7LKDCXlVF6ujIHZE7zAEuGvZu1Xrq2nkqmuiryCG0kI1hoZ2N6kyqg+DONN5sUsHnbeRATUWBF3tH/ybt3F9n/zDDLRJAdCOELo1oXOUVFBsFBD70+ibc60dlueLpYVAKG7BG5nxOPKafyMWQgUO+dj17LBVrPPfYfIILLq6UZnf4RhqR8s/wlNUFVhxsWLPDwzKrseTULXu2j/VTbRmc0Kv7l12qhIYtYje2TmeNktz+jU2JOA6agxGMuuS/m0N8Nrjqii9OiP5g9/9YC6NZgOaWjCDlkdXjxkm3TaftB0vcbvbWBS6xuJfI5P88xpyd471z5UxYGUl1xpevrdrazmjISBnTLRW4tSExPIfvssgepwcSRdBOU0eiy1/nPbupzLkqxDK7jGykNbL4IjvzYWflVrcRxL1WmMZ2GSnmycNbdGgf2ZT3wAsnE8jJaZ0gkTgv4x7T+4ZhZ2pxwGhgTSyorII0KZT4rejf+3fSdfhkU04kAYclT5QfSZ950nvN/zD+dIHjDPD2qDGqpvBghW9HBvD1qYPPoYY7s0K5T58jDH9iMsvFzFFZnUiu2U/uHTGkawu2WNemeQXHGsHrUsVd/HtioYmr19CT/swQQYS46pvPh2+qUB9l68VsOHNvulmK07E6dfmSoKCj1WIxmK3dMq5CIU9KF4h09RRr38ZgkiHIhCqADaYYMi/b9sTKND5hkUd/deXHXMl+7BChuD+aRyJQcBwBwl9V/AoY1JxzhSH09rwXTZU5O/uDCZbldyETYTFk06FtG8lWXD9QiSsm/KHVC6jKL4JQdY/jwuUnkfLHZiqIMtNXog+qNfvloV2Ivq40UBmI9m1FdkQP+fEyGEH4NjNjt74Qfox4GfNk+O5YEOg0wfvmINHUhZkY6YXuuGfEQYTgpFAmtlBnyt93YJJivL3+M4+dbbP1REHG6npAo/4g+PmfdZyhf+/E4ZAWKPL1A/VjkaNb796ubQYVDV1LYPScTv7sUYQ77DrWIQOvi8GRD+uph1MT8OGLFd2b9pVmZ/M3EBacVWFFlOr6wntG9ZcadT84U9Fokmj8ohZRGuZvVpDpow/usBFSfVjgdYOpvAhRmQV7vCdKNDPH5jMDrL41fcR3CD1jDrqZVsXIbWU3d2MRjms0wFmJp/fdvs4q+8X+rk1vPkb0vWo7p1TKVJetGj3p93bfpyMVD8uZA00yG5erIj79/Q+mCP3KfqUhjDqfhLioY4SjRI4VBj+IhfhIdV16OUyv8QOaSxwiD4CkfJ1fgmgvnQ0/Oaw+K61DICUogFPCQVNHsbGhDrPCncnysiewpHnRhqn48U2UHCuNIM7zZpuP5WKX0L4vyqfz00UzhAxdq/KMLW6psW9gdbU56D/Gr1l22T0f2vbTlSYRunLEtsXNX/D+l0dwcWdwBCxetQYcvziK3iZN3L9e5aUwvqTybZWiLTZAjS8zgjWOSKvCvw6YlHsJgDD8blCN9PBKAq/G4RtOU/Q/MA681FxMoGrj0WN0C+OnonUTkEEELlrYD3naciV3OIRO4CzVTvbPpF0uG4+yNYqxjQA9qH3Yt8a92x1upuJSvx/AwgwWpFy6XucHdG/nIXAFdr+6voLOSGyAP3IqYBX0tkk8rg3hs33KbSt+P1Kp4d3Y5eedsTZtLFGAO4YxLBU1EcSxZ2P71jCpVhO5IO80kW3lAcDGdWiI42eKLmwLqCuclYKE5mfomdzEAFx6KSS+C7lV6MuqmMSHbzLx1l66b9bZmuMoaxktxSyRioY3MDOELCS6lFcXiRlbVCdmlEEKVoU4REah+4YCrj63EriQsil20wY3MIPiW+1NoC+M7E+Ej8nX6ZU7d6CDgLLGbNy9q5Em10FzDbOc8ETWT+UWEcDO86ryrWkyB3d2OnPEBPQFNLpLRbH4PkBAoilpnAECQtvB46aVO7WIPxf+Vy7Idb6rMZEaDCTUXahiVfgtjQROXjNo55yY6mtNDSy5YlEBwdHnpFQfcS1YO06KTPx/NfzFcLeR+hFFElgCspNqoQSt/0+0N4uXrsZ6Bjl1cQn6KqxYFxMMzEESxDffRIJnQmCds8hYim2IwRXBeb7afW5XJ2Q7PORaRacWEJiHQt01BwNSQSeF8X1WyONUtUwmSpom87tD+5lr7u+DB0H0KIHBFpp8bwFhz2r0FsrajUMQF7bRetLyIC3JBm+5b/cn9kw6SVPr361mAq0V8Y092de+RCkr+usEfTjZltaxS6EulqI1g8UdSEuuLat16jiPFpIdDM2YSzWEMtZORQfXbnQJLElL0Y+biPHEDRbZdmiZe0K5JLcJ7wvatGKqO10DEJsdGThZXKJaVRDOE0vSr5WRiRT2BftOrPf0WYNSgJgKt8iSsUmKrF15scWWOjUMwi04Xzs/GDBaMPU7S3XvFWXHLslBXEjAx+NGI49Ev9gnHTTQ1GLA2fRrWW3NLGyDuN8sKsDJsznpkTpOFxchFOQ64q8nmrQWxEcAgjtbOlVLmgKtyayrOnkZyQ82AyQUgPX8ZJG72lS8Y/FLZ5qv1p60JB85HK4PDN7RPju3n0GyCtFvMxB7MD0Q8KAxUTJWyJY0HvL6AdbxYhH009xHA4gub8KcdkBvFyz+Y19Utsr6NvQhy36rxW+LyWSq+osFiel0Vr0jXrfmfn5iLYezcTdED59CeYfzyQ65AG9NzQZoGXFlT6epeugD0jLsku14Ch2VA1Qu13iVAnAGBg2Jfcq4gEqppiDgxYNa578SdOtGBDC/R4qhPa/RAV8QALhSXu311ER/9t/XpXXBfHG86l3dvllHC+nCxmT/AsB3Sf+bAn86PAw/OMaKdFchwS2u/608MzlOT2h13DxeKnQZm4i+ffDSNxnTTwH67gsOpaKkCEnrJ+XOojPjQtiwMK/iA2u9VGlpxFgfARhlh8/N40hmedKLHVQR0/aZUcNG4nQxF4djN/DNyxygndAN0PI1DPNUeF5758Dx9EaJaAcJAyYpAXaaQswl1T0IjkrqDXmvrPB/TpCBDY59CsqjHPx+A7QhF9+3WHfXg0UuH3TW/MVMPs9AHTXPmhI57S2+ut0zqm5Oh/JciUA/nf4z3rU4RLBoZVepK43RTPORttBPEuDTgM01fEnxEsV0HEIvXR/h8Xrp2tPX9PGJac0ZOVJyf3lEgkb26joJfzJEYQvBq599Iju7v1JWTJu2cBYeP/mgvstqCDXIiknP+To0FhB4VMMLbPY89Hz5EcVNtxr7/c7AcssyDIXdefAJJvyVNYIS+YhzZuRXUtsqAvmCGnLbFSAHUaRV1MnVoxctAJRSqXks92EPZRppkHIeKLAvPET9jOTcuAfadh+Y/j9FKMD2GS8+cazMlBpfeA1Bs0RiVn3I1O6A2rftqbilWmmDSu9zWdG3dC5wxPiA+bBkcvFJy253Nb3QcqV+ETD1T+RearTFuexPKaehgpbbyKwODQ2HuGuXL93lzmD7OHiuW5cHbk2Lpyi5lq3NRhgom/oCbitlFV3eQoDg6P15BMYkQ0VkxHGkNGg0ny93IIluXv/N8Zy3F8hV+fU6fKko3VjZXmuujRyN1TVXDattxhamAsPU93COXVdipMejG3qxC9Sakj5uwCKo7uiB2EJEP2GrVXGkAmeyB7Xjz8TP5QVcIEwWBQIVWTNAa9n3f7MSKjI3udf5V8qiVucd++51tXHsdt5cTKFRKmJDPZo19KmFDberYibunkzs3R1GnQxB16XaRRR3rsURUlxx1mdQL/Jlt+S3KEzZtLMcdWcyL2N0DR9br/QkarqT7Kdf0xb8yPWPC65+VxcF4OX/dbo2m/HmPp9mITaFf/Ns8cYvuvo+IJa4J1VF/M7WaaKGp7wIdpNOQYmerIzkS3bUnKYeW23jMOVvtaKn1YKwlZYnT69JpdB4Zr006/nx3b1bXobR+76MTKQOLQ12yiIuEfiywh2t8RmHfK4MK24Rs2irz7RN28mgVUO2LI1eE6X7ANvaRI38arL/6reA6lKTXBEICJXB3A/sXA4tbqP+s7RrUhEog93D1LTEvlHNksD1f7iq8Sd6XLOckJSHJLt/18XnB94yf7FMzQ8qi9d1yhmt6QS0qUKLDCEXPhvA4FfAl/8x6aKyMf4T+flXQs9hW+IPl9Wm7vlCkla+6QJ8NoYI+okPv2wEVv+GFLx3IYX6scFnczMSPAVTitqxDQUR4J6qfI0dNyz+J7uW6KZ6YbI9WJmMStID0QB9iTpA2kskvpDZjH3TwOmI2mR4RG6dRcyP7BO2Kd0sgoO0OHW8q5eI53s+0X+Cwqh5qTolMb+Y1iZixXPajMgxGlnW0XraWljLVvSyqkdSoKtlOZUhv52wFywWMR9Gl/kPCVtJJuskDo7hwAtrMKzpGLHUYRvUh5OGK48RxeM1WRJpF8p0KGTGx5vKa/3c6i9Aer3mxcGS1xfF1XLASz7LXX00yj76CkaBqVKx4LAcwCtSYf3/GuKeHQ0CYibKeve9hUTkYNKnsjqunk4apwS7y6rlhJ9D3tWmy/HjTUMSr7HWUt9DNYnkDJWMDU/GomCi/iUvyDRDuJ3HYDM5/Wgm5LxPZa0kh+uqr1B9WJr8LPCeyznN/8u9QPt5wT63Jc8DtVK4B/tXwO+8ScmnRceWpdPcjQD28pgmlJZ6H5Xrg3ljfbQSGlded5HLu4f6W113qS6iLoadcttlDwZ7k9xzwlaNZ+d77bKOWEchxy2abZFQ8CXy6vFF9dWLRaoy067J9QGZO6t43nPDvCXYXxSWQ13gct/18UU8i3xVz9MFGkFws7+ByDAeZn2wwATrNqN4KfONnG8GgcXRH2Akl53Cjut//lSxpe84qNOHOoSv7/v6GUzBeOZRTFFJxWTMJ/zBgFHoenQlXML4KSWc0M+AJYZlsgCvOVt3OttHbffsp2g7Qg+SanzFHJrXofLTvmdA5iWm/CPvWcYtbhzdJoL1AmNviJHjyGUJGEOxFEXcyeRn5vMK/Fe6imrujiLNPjBMDamUm1Mea/7S8N3+uBKzGW8rHRFUAf4cqfFF6tGeXDzb7Xe22fZRlnRmv2JZMBPeFeLL4Y7c7FoNRcxVlMdeH/5AHNIs/XvJyw/OZ+h0KJFNfQMaxCb1iu4LFVaTPRJY59pca4P1L3khH2Jrwa+rKQn37M33EqJXXMTEmbsya7XZstqdzzx05blwyDuC7lczy3jRBCG4TwDam6uomy6fCjPg0zI7uqgTvgHeWecfT6V+10waxHLKZCqMmrp59+TDTuQE0E8rqucxrAdYC/ErGU5qGcwbVyNmgwCCB5xEMTIfR35tF6Wd0cBwXyv3CtKUZiJyQO6VHaVumq/G1d2YhzZgdMVscQisvjWkJzDeNThk562GtS/ZwfcaIpGCaj3xp69KBXBXKefQBDXfo7w3bBxdUOth/HxIegs6MsPwkE9avXbiWeP172i1qjxLDEPrGPzr96mvnmXCuIGPrntLRs8CJKXwSfboOEuCDFwnR8Wl+YwKBEMydF5KaoIEtoC2mgRT6A1fY9ApEJaYjOftpOZvFxBDWm5AiIqEPsJE5LlWIJzRz+mqUWCFdprtDUEE8GLGasWg4irXFFZQ+XwC3WmNggQgryG+/fgmVpGQ8QzWTOFuiFSVkoTW/raZMdp7VHTnTmIx9cJXQsow84rrvxsWkdN+ykd1Pc9zCSljcUaFyI7YQG+DCiXPXilIOhPao+/1PpX6r6m20yxvsha7OjOWccepdh2/uoTnyAIUiHqrka/EdP9Km75k4BC2sxuter6bZZxKm53s63Dw225N1vyure1zukJgcLTZ76B6iDl8GU2t3nhu7r8eEj++s1c7HetyFAh3ydOCkh7lGFNRNUF3UGsSKRD7cZIwCB1q4481zogikcWeP2sglHMZHMS3RspzYgkFiICEOILLf/zhk3cZDCY6Ua/F9Io6/907oXpvR0z+HXnuuznr9VdyFvToyNcVEdZ91q+mVHcGbXeOmdppFM7IddeVviCtSMhEL/YZwnVfcL0xjB5K1/priE3JLduMpUqBeqxvfY40kvfGB4oPjtnDUmUMbZSnRhTZvbHhQWmb4BhwRvfvqi1T61ZK/dBDXxxG6GIjhqlbqDCVqBSJ7vj9DGkXOgaNM16vtvS8lOzq//eq7oan1zNm/3p3DseC2x5MVhrDXL9p64YAehDZdZ/MQgMc741tOQk/xlOnwea8yoLBPua16uJlQbpa9F/1WoWKs8XFcY/oYmxHpy3jIHyQsAsQqjl534TNB2outOayR6TQ98jjVsky6rul6Wx4Yslt5PEsICUswM8evwL8UwGNYzP1KEzG7eoEa10RtbvGFJRUF2HveWRewNPkDcPnIOOIWVwPPFst4iIF8b8krv3/pyry2+86Pi/43xi6avIgeAzmkf8pkNeXtdKkUm2twKaa3Spx/mFOMh2FP8x7SCgqAagXlHmMkZQklEQGWkO6JB4yPgmvsSQ02fFWb9EB1d302W/sNi2eoOYv0l+lhdVG++ROO3tv5lhth+FAm0smMhz2IOqokvXdiB8emZRrSxKfi7YI+j69TjCRt3qKh/fakmaeRq97cKHvyEFAW9LVkP5iUhsanhFJVTTqnic3969ira2FdWrtX9S3OQn0vYZuATwtAbdPBSzQZJCML1DigW1YGnnOQoESEogwG6/yuEqolCI7MpEe/qNzgTmHN0DTR3vjpjPDhnUjno2MZAVp/h880iJv1sgw52hJ3XsSBEkFwAheC111xmACkf8bwIzfl6Tl7yIcoQM4eBIy2wlGly46MqQ1SSPi791cBHwzKyBiV39Dj1u0uvnSuOfegNIwScN8spP1acKeHnbXEP5ENf2u5SjB2C4c8NksM7RyWWN5bTWyVyPnJ8f4BmshpfgSDD01Nu4UpAoe4sKV9OG+j/89xh/gKzCAFNfZy5t2kbBUgGJRaCGla9XeOgAlreD1qVUNRd/lweELKMtCl7G+Zux1HrlN/k7JwfjhrMEMmbL2Z6pgrBHA6ssV3ELdhTjLjJBI71MdprC4C1RkMN+dBJHx4jVc51PAxN0M18GdasH2XrvTWqQOGBaS87gevz6EAtobIAEqbRONF+8lZY2NIRTB/7I2zFt6+Xd73DjclWNo0sMz++EVQqHPDBUBgwo9YBB8Ke+hGP9AGVW9wbnpIp1VaNF55mNqVWXGHheLyGE2UF2N8JZWW00djioGJR1C7YuVYKnlrDrjne2YFLHGhJH62IK9zUoTbAKOsousb8MzMGWOUWNNQTz6U1DsA6z89xluUUmNO1pm8mQubwSQzIBKg5UIXjQ/wekiKgj9lUXn23bzvtIkvoQ7rna4jL04ru9SbAzn/LQgk5UbnowC/lZxLF2XrcUGqWZRyVpmUOrBxdXdto1JHqAyuuAb0wKuasUYhDsbC8ZmL2ZTPRWiuovXyk+0YC1TnyJlrCBuYUDbyJNJVd9BCCxE3sQChEtaJY1ww/l3OMqhXzBFiCfqVXBOHTWpbcdj1Oda5qz38Nm0RX+kqyzKbB3c14Bi6qnx5KY5cOofZirrRCdhKd7bXRNucZMs5vX6HzNRZyjDu5N1PN4swRqCBQCC5MBAegLT1d4QdP3UEUATrG0/jQRANPHUZA0fFez9cb0P3Dhb4UmDz7TVeA/jnuXY0+0qYRN2fk3eaFVDMaUg0BcWfJB0m/YGn6uxqTUiEmMZWLjJ7dH40uNhqyakbd98GEQb5SXW5xR5UMI5lNBbSnmoa7a/n1G2y4kN2bXKOL4TNg6ZZK/rhmS/1Gx19Kkecv/NRVb1/UuUNx8dBoQGhDKza5/pWE/B+wZ5XB3lX2yIHNbndNCRK0N7WE5x88PYDWERWCZV9zV91J6C6uKux4bQOWFc5kwMlETnIYJyRFwAwu5y/ijSdRBEakPxEvUTe7hSF2sfVAjJAFUxT7iX4WPB+8mJ6qVqusxCqrGm/B1/fu4yjfiVJ9XQK3miSkF588ozy2lPuWmcloeXCXAvGSIE2N9sYFmYSN7ZXPdxwKSGFI78X5PZXhXdFZeUjXHVM3KZGtFmeXffF/NfRw5aWt+C+7nSDqlzA3GygyWgta42ls4xK2DVUxv/Sn46NhzanxBcZhsTuBwBW82u54xvD7X+DYbzEP2XJFeDF1dPLO35iZgN42LvcErCop5Zf1rNvw2T2zLJg56abeK0kNW0EVw1hLQC204UJmdDixxESlF4YbwNLnFtHJTnmUFuX6aWa+67bhMPGIB4LBFEZnrvCQLram8iByzWQHgIiMW9VqlCRO496jr8YQvlsT1A5RHhvtpWTkiYprDlV/UHJmriHooklZe4Xs+Nv+9+Y511uhYcELswwdOETMW/3fKa6NEaezaZK9J886vq6Uqq4WXpQozabKNvVp6CMRTRsq/1Fjj/ZayXK1UIG4kupJGzigbIkOQGhIM7RN+8rnnlaaJGo79LhTRx97GNgPAtZf2gI4KR9puBnYiBUdbM2Z7mq4sQDxhIVKtR8qQgTH9PxHXO9cHrrMRJ8CfbnoBn/rrTEBhWVnxhAOHS4z1BD/loOvYPrtbTkZDpFAbd3Vd4zouKoFrwN8pRjGb4i9QCF2I50jh4SlAMTwjCZ//O+YHS7BtlSj60FJ0z5J03iIOmCYIGW6Gmdtxz2X+RfTHxbQhPlMZ/21/as2MvZpFDGz9Frz53a6MiV1VAOjAaeelekn96xKKKZ5C59t5q4GctFblYznjOa4OAd4IJzLRgGwG9rNY1CxKagaVQJVwYdf6L04cWyVpIl5Fz648YLf59zq/KTG2NFxcnx3x57kzsgPq+967qBkdoXZBybL9k6JHoC5xKmOqpLiEx+VYxFeBQ5dymrLjmyjgYlpdK4sRoSjmIdnctPvw3rjbnf/3XjCQnGEsiDGHAr6QRWNcB21XBgISDqlIemuKdEqgZ0AujtcMyy7d138e029oC0oFaV16o9MclCkjxRA/RekCxbCYjU2xc7AFssig9rFInuB2wBIXObigrTZoOv1Gi1gZUZsctY+sZdGwM2AeHAW+JkKVYoO0S1f3muihcUWE2xrWO2B/K5KV8kbK2evBepeOghqvZahJ+sUnM0tBrgO37KM8buMiUgf1cDE9P1qQ0g1uu7B1W+9DCTXmxSvH4of4+h3GPAxL5MWew1r5p9Ps8Tn9kMzRK0E+YhR7WTPzeIiyOqTb7yJcIvyA/ATqKAu5ePIqUaPEth8Pnw01nyuEpgdlDdo+kWlGjwJ85+Oka/DZ1BiK/FTJfRU7Nj2j/uTDK9+7TpF3v/3saBKKLbRVTsyKug/d2iDE8XR+1vH1CAzUAuD3OphBFHOpZBo9AvS4hNBac6brGWLDd7ZfoIN2ksc7etsYGPPOyaK4PAJUUPiGGJsrz7c9AE86zPmOSsu00Kfu/qSPWfAygai0YxJTw9ig8bddbTWajQsXPzSmoQSOs/XfrHAiAtKTil4jHm43z2WQnh8Mn/H92je4N8nqHT1q20TjObbFFIiznP5PioAf+X3wx65zkJ6H5iPmYlkRh9cMJlX6pN2JIayrDhmKAv4l2daXZYNGSlP/NZXY75yCvhw3YTMnRe+3ZDmMmS1bZ+ds0EHCt/AOX/HQ/CKmlv4tMIe5xH4BsH0omdTsEhKamYNbDcmYMApCvHeT/SrI4950CSAjAmhOpOKaI0aezXquDjTXKBmY9StpoA6naCWerT0BOfIqjnv9vi/FraozCOmz0pGpM2IwuU/9cv1MOLE2EU6SrJEn9oc0x4vStfX7qT6WmCv4q0jFKtXZjs60aWoDwhXhDs5q4EVAW+MTWOOTMuQt+fJi8SxQsMFDZRqf0GwVUyMh3k+FsahHpEesBq0mXX/7Ezh3eXFJFEWzrJDmXBspjZ1H77VyUpyboC0xcTXA/JecFgcy7C3nEyyZHRh7lMbPm+Eojr+xJjsU7miwZu7Knb9tJNVuGcLMhSvt+HxZTDl6kpa1VY1iGtUta8q9pzhldADlRAKtvVtz2MtlQX9fEMrub8xvnWOW8yDRX4ToEdJh8kScgyD+nx6KJsJ85sd+Pu3b/Ox2WBNYBFjLS1fauC9D6BWeHSoBETPzUPP1chMp7rRVuKUtnysQp+bDjN61Dh32eGNFzniJNWwFbJWQ4H2RYHRcPsB6PfEHkjSe347cZoB4SHzyXw4sG5ISt5J3xmqjRXZdBJiSFnHOdS3Up3gKOfuDTxTamxYTX6sa+0Ld7/CF1DCIVsZmyVovZO0kK1fkMZRn5NWUY7MTZCuoyMHQVfR8lRc2mBqq9OwEJBhOOOxxTlTn5ilwAsHmU1hOwD69gO4DLs/Sh0H2mAtlgaio/7KeLt7MPgiAlMsy8hyq7qeXEwntlBTqJVqP8YPQUBoC2qLTWYKGTCc6xqO0s+YEaJR3gin3V6mRp07L+9fiD/CBDbxn+Javp/3M/GBl9H6zgAZPGof8ehg79Z8ZGbeul9YUcZU6dg35N8eQ2t4H4E3CAcoQ/oxBVU+TG9NsutqMV28r9UZ+mJEXx3s/XeZoS6xqGZy5Ep3VWhWyOGe9KEZ+/9nd7KapJocN04Ro1DhcJe+hpLjhwPgKMDs60cxrRe9sldzXVryor93HlueKr6rd/jSKgKVswc+Wxo+xlB2XOVptQ9IZxPkgd/i7XJXv2h8PjBedkunbifb2di0Ml9Ma6JnjV2eOcjdIaAXDdOZAjQzvKT5TkFZpfFzTIUi2qfFBD/ky/Y3MESb9fbmSnmriZLkjFjCl2wTd599b1vEfur8/3H0nQTk51PetmNRB1BYG5G+Hp+ZrhcNu/GcziyYYKQbSzHbZuq+93tsqJPxSRZ8nNsymEwiLWltFbyNJY8b0RAVtPMXKIutH6jr34XHeS8WhL4ruiYjg6TG4fPBiNI1/+EXrtqFeWIhlufd7w9VCeXdnTmvhLmCl2sTCyBnCLQzLaqDLAqeIdk2K6yqk1rFj0KmQcCjrrhBhPqF9vg3Rr/RoaCCZ2Nw/zYgZmnV+xoKdWvJahmqNqiIoDFYx1kWE+8nNU7FcMgPujr7jEaJNWakabrBBQ9/TL56E/v5wkmHZtDCLfT7k/eMrka2W7KHwoG0S7bc2cqKnu2/3QB3pBj2K61m6x3pYgofOs1J5XA7cDVA9aUNiMp0CNXzfz5YGVBCx9S6Ck5wWGrTbiMyRyw5qT5Hgje/9ez4WiE6y9Kzwj913Nc1QRhPG5piqxVFZ0P8c/5ePKr/v86BmhrsahbYVCwEBNr1mGP74glMpdXZL6lMod1vNlH60tHPls75fet+kQVTcrjAiTNPjYw//yJt+ljW/hhTio0/ymIYKomxGWDGW1xQCvmWAyiGNzsXiTlauct9ctUpPShZGhnrUfX9T/v+4Isk0gNAJSzXU5+oTcmgG8yD2SVtQ50tbzTzP8qNPdYVGEWB61eZ6icbkD0pJz8BAEgiJXB2Rt/nJ4e+ZXq4pZWc2LW81WbvkpB7VYE/ih33FcKq4OEjiXMvx3qmn2jWTuNyNQovOdpYBxP+JvHT/Mi1kgHUixPhN7V0/1MGaW1OQkh2B95eE0+8M0ohvbTUM2/YYl6UVZYUlLu9F1inSWzMpXd5o/7QbukCJ3drMebY1p1zQ9trh+sIfT4mO19ARl5gn+Py7zWNjZTIp5yOUtcN82CmsNlcBVP/CNUb5DhYEv/6zwa5gACBOZOVV71QNx/Bgt0L3n8OjFU/JmKUKKjg8b6+c8MtJsrHUXLzCy1XPnSFp6nr8UB8nRs1Ym+gkDRosSVhA/ZpjlO8vAQhNTbu8rQc5PfCsq5PgUbJi9VeV9+R5z59XHZCZIVJdwUh2Kbkss/56uS5z7bXWvcuSpOktQdB3JtmHuQmkRxA9NUmT1ixleszUvPrgx1zEx6q9EvR6C2DdLuc5WXuUHfz1mid0ODb/U5KEQV84zpcOjV3H1224g0ARYQbiwj8tcAIZIq9FAL/bGvGFQLQhe/u8BNaR2MKg8+MJHeKWe09K/7Oc9VeqwYg+19a+/4gZOyjAIyB98B/pCIqvoXsYrNaS2HsLnd2uypvW7QWvXCJw0rlHcu2eNe6pThGGIf0hE4nVUPGESZdGbjebLiaH+N1OtqwhohcI/07P5LiNvToAvxdoCmfVYehAosHS8t9thiFbtZ87lqojGSksCv8EyNluS0wbXhbtelybXGTCYL1JAazFDH8eKf1MHQ8xGAADukbdTBR4Dl/PJThrG88BUEbEIJo5F8NqZplpp0ae9rbVKn0M5G+20IUFeA9buQud+Ez5V+qVirLqr69LYwc6zFW2qsW9ay06sA2Z4pSuOapZyUMBXCMOXjqkImvaV9NeuOZ3jYSgDglVbchCA2hTvRU+FBoCDxriHHdoNa8q9UccW5u+rG6L3X9JAgqp09FGOsUsijXsv4ABIDDaZTPb6+mZbg0F7oSqQcqCeh7PJE4X2Otw7fUfgPmpVw2RoMa7YBhKFU1guGrnfpwfNqp8EHNzf5rwDYmJMG4SM5jzyAlyU8XXwgCiulgsVa5zyGuKzUIL2IUPQ7fDz/o+oh+XJqOrJXuSTxDbs7N+aK1+dj97Jco5hC7jF32f6iv+K5G8mA16gJEPeY13y8eL8/dfUE4bfZ8TK6s9V7dK0NvYGvrz7L8UxGGQ9NHxWdAfOnlEV+8m6eQR7wepmeot4On0bFkmYsQrl9WSzwkO1MwjBGn8NwoEUb/+VeRIHvWuE20QVyRc35W8iGrJvNPfzktB7nxMGzzOYSDyFSTUDZturPrd/wlLgXOO3pC/CKbEjHEylu9F4iGirw2VmQIwhABD0mWWdCwRaK8V028jGtHm58Q09GmUPUxmMczSdgWVYG/sAn1Ghqypjg/y0m2Vob7BSvqEsIhmfPb5BKJT3JKJ/7WyQE2vxWp/Fl45sIJ16gl3iduUF+hrvZbVkb+NP4daKGH5QQUPhoFHIqJ162Cxc2TskLbIrsk3V0WO/HCcoqKIMXhhM0fiVZIMlfyoF4zvC5H2kRuVOMRqsoMzAs+bIqfwfTs0fI4VLNj3xl11sdHhJFqXS9e23slPKJ1UDktpsTGE3zynheaLi1rHOSDvHht2N9CaSkP6DVyu4lCXtS7W8oT29/QCYyfTMtsORs7SWdxHFo74dv1l6jUGsqxZT4mffJwLsy/UuKcl8fTmUJIIBMvpXqv7YGUFZ7Ca5VMutuC3EjxpZqdmjrr021RBt0/j0JR6pYLh9CvCgS+QbJrx0pST3LSMIQxPVvnhZobmostKxW9QsTDpaA/hpLiAWO+AEndUmGEsfvMa8YMwQS1NGklrpMFf7kJ9LEPLzyag7g+dNxg1TEabaH8X/1rw3iWss3WHgSwyr3mlNdFZ/Tnzzn+meQ4u1UlzSOf4xiokwGQagQpblX1AwLTPTFkQ264V+lx2ZpFIOvsU2mwfAenrBSgDhGD3dOYYNMRMUsAfPGoVut0bR9aeTq7Y2m2k3YB6pENk94Gzx8WGtFcVfg3U6Y2HpbtpEP1BfT8aANJdDa6l17Wz12JPmfvY2P+sOhtJ2cBkuI7e8PF2ZIn34e5I2bkJ/ur0wBJ9i3HzWStL8yxgk6qlFGB/3/+cU2xwKvmFM7C819tlEMmejOZu4ms2NLbdDLxNeX8qFR/dpMEn6TT+npP5KYbbmfVVKWnIjE1ktiXqL4PkvxyUZVI9Ujg0i2cCP/AKB9OaVyV7owrYKMO4L0fVYgfP1fQCOL0PElpgFUaBhOf/t96SDOI70aI4zT2mud3MoHnxMn96mQiBeMVoRvZLWQspJHVc96mTqYloLMwoTec6k2OLz4divT1gqImHQ+oGhbsA7JV8LmnWtzIBlBnIZEmm7tihxIsNCyZICSnzZ6wz9Bmp0NfYIBJpUqDxSc7EuEgK/w5ZXsQJD/Ec8cIf5W3YCtGuJq+lAruKxsPYCaAR2k7MEGUdfb51opKgoM+lmDTODSn8x/rdFXfoG3TKdXffwc6nmEVj+cUAKvvR6iY+XR3wYIvQRxPbnllb061OLE2zDxtcg/74nTJtl2sfruACclGQsaRxfFFds06fAUs/Nq3NZmfx2IrWD5CV8I1wJpde3/MneOx+iiTR8m1MmhGcOoUKX4WvJXJSDoiJECYXo2wSWSKyJl8h8BlSaAT7X/4v9sZtoPLXEqQ4PfzwjKUQbR5FRBxUirUIx+/xJvKHtVGBdLZZ9E+S3fKo7MXN9XlAfEeCMlgX8CsrOmvnCMPGqtwqSvL6UGoRHg+7tu/rkh5Xse5OWiT9yeAv7aL5exLarLAiPC1Nk2UWht60a3+Yu2qEnJWsMiBSGxV+bRx7f8JTITvjC+sHlWUSuRpjjCNbGgrZZsBIP7cc/miICFaE3smSAjGj6sxD6rWjtJ2k9IJUdQm8HAbSklvAFNQ95TUmUB9h50KzkI3p0uYXbh9jGKvW+tRZ47/zPpsmaY2nMJO56ae3p1cpW2u9lQ7G8nefOFqgnKzsAKvUrt8qe93ITv+cXKeAxaL4X3aYtUWB7MSD7LwqwiaoyvbkYxoa09jpt8Ol22mHTJf4HZjCgSMfJySwPypH8Db0zKJPI8mgwNNPC9cGCF14r6tSRd69NaLmTTkN/GObPi5gSsZdJpxyWi1O5zibaKOSQ4p53TBkt0rcKyJX1K2Gl3fRwGbK2NQ9ERW1A78iEF1wnWJb7K55wnpxWVCtkih+frJUT5aGi5TpqACeFM0WoBGV4vd0PDV/GCE2Os8AE0YRxTRNXTSe2akjazSV2EV4QzpFQfBV9FCooII/BLSqHMxQ6Y107BnThlUMQD5lt9YnEJbSHxk1M1/mOt9igl3N6figmJxY+CzLcYjrQMHBOA9Eokd1ARrgtDGYhjTe6rx4scCHGh8w+UDDnNu2McCI19goISiHaZD2dSly4TM6CA6fTmGhZvJsKB43a4Y/gTr2aOo7Ru57iMSxKyzt8nCzPYpM7/dvXsZMEEEib+KilEnvL71aC6Kdb9eN3MKou+1gvz9+zsJF7FGDxgCBP5LtBWNhws+R/xwfuLkeUgZRxGbJvIX/oZ+Cog6Cx/vWUgwgXo+IZbPiNZCJKmmIUjeWXOzfnonlFgy1tmoHhijJAvaKdvTHb/eUiLc3wKJqVT/oEJL0H6DhWyj0YlOnEtS7gAlNGSpCxf/4qBE6qE/9msncCD6mnC1d6yaSaUr1WkvRiVoKEls/jkqgPQqW1z3QiGzBqCtnikB66MfIwhw1KldEIHj8qtQaX9JaKC27ZoYjPU8Zr17PBEmJ5nyXj1Gtcxc52Fo2w5OwIkWgmoQpMfHkhHVmr6mhKT7wAbzXF7Zvqk7QcoXuuNGQfLY9keDuyb0k0p6q4Fv4Y934u/G83j5zhLe7REG/8hiTZTZ9oYe3KZK8F89+TOvRuop0UAdkkxWvMNk41NyNqnJnovoJBqX06Ht1wc26WRq+IK0fd9CxxjaPbUeiOaoS3QISIb3SC47HLQqZHBDJ03mf9tnKIcuNMkkGWlgCDi0v2VlMaCr3puOKO9Ym+JvAIu2Ye/VXVPsQ1SOz7qBiJs3cy0uQuDPUixeyjRy94FGjYUdZJKLF3Rq1VFfoZXwzMF0P+DxDDLCua7P4q9ZDH3aaFaJj4MEecQir+a385tVsnsOdFS7wP/Kg3dK0OPHFFuJaOy63EkteQXLRtF8JiZeU4QuekXCt4FPbfe/70WS3tIPypUuT+BfnAYRJSYruILCfQbCI6tg2O9plH7tjF/5mp9s8X1KmcXvDcfQBWb22tjt9EZtfa4K5f1i9HC8tDdQN4HpGjk+UpIPg=</kycRes></Resp>";
	    // // Log.kua.info("Encrypted XML received from KSA");			
	  	
	  	
	  	
	  	
	  	/*_ologger.info("Response XML from KSA :\n"+responseXML);
	    setEncrpytXml(responseXML);   
	    if(responseXML.length()>1)//added to handle E response from ksa
		    {   
	    	
		    	if(!responseXML.contains("KycRes"))
		    	{	
					Resp resp1 = (Resp) XMLUtilities.parseXML(Resp.class, responseXML);
					_ologger.info("Encrypted response XML :\n"+resp1.getStatus());
					
					if (resp1.getStatus().equalsIgnoreCase("-1")) 
					{
						if (resp1.getKycRes().length == 0) 
						{
							throw new Exception("KYC response xml retured a status of -1, no content found.");
						}
					}
					
					
					byte[] kycRes = resp1.getKycRes();
					
					 //START BECAUSE OF CHANGE IN resp.JAVA........ DATED 26mar2014
					int x1=responseXML.indexOf("<kycRes>");	
		            x1+=8;
			        int y1=responseXML.indexOf("</kycRes>");
			        String  kycResStr =    responseXML.substring(x1, y1);
			        _ologger.info("kycResStr :"+kycResStr);
			        
			        //end BECAUSE OF CHANGE IN resp.JAVA........ DATED 26mar2014
			        _ologger.info("Decoding response in base 64 ");
			        kycRes = CustomBase64.decodeBase64(kycResStr);
			        
					if (resp1.getStatus().equalsIgnoreCase("0")) 
					{
						xml = new String(dataDecryptor.decrypt(kycRes));
						if(xml.length()!=0)
						{
							_ologger.info("Decrypted XML Generated successfully.");
							_ologger.info("Decrypted Kyc Response Xml :\n"+xml);
						}
					} 
					else 
					{
						xml = new String(kycRes);				
					}
				
		    	}
		    	else
		    	{
		    		
		    		// For handling the RESP element present int response
		    		
		    		int startindex=responseXML.indexOf("><Resp");
		    		int middleindex=responseXML.indexOf("<KycRes");
		    		int endindex=responseXML.indexOf("</Resp>");
		    		String tempResp=responseXML.substring(0,startindex+1)+responseXML.substring(middleindex,endindex);
		    		
		    		//String tempResp=responseXML.substring(startindex+1,endindex);
		    		
		    		//xml  = responseXML;
		    		
		    		xml=tempResp;
		    	}
				//// Log.kua.info("Response XML :\n"+xml);
				if(StringUtils.isBlank(System.getenv("SKIP_RESP_SIG_VERIFY")))
				{
					if (dataDecryptor.verify(xml))
					{
						return xml;
					} 
					else 
					{
						throw new Exception(
								"KYC response xml signature verification failed.");
					}
				}
				else
				{
					return xml;	
				}
		    }		   
		    else
		    {
		    	return responseXML;//added to handle E response from ksa
		    }*/
	  	xml=kycSignedXML;
		} catch (Exception e) 
		{
			//e.printStackTrace();
		
			_ologger.error("Exception during KYC transaction "+ e.getMessage(), e);
		}
		
		return xml;	
		}


}
