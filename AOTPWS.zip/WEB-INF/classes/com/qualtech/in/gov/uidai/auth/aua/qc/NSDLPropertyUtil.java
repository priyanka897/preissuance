package com.qualtech.in.gov.uidai.auth.aua.qc;

import java.io.IOException;
import java.io.InputStream;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.qualtech.webservice.db.DBHelper;
import com.qualtech.webservice.exception.AppBaseException;

public class NSDLPropertyUtil {
	
	static Logger logger = Logger.getLogger(NSDLPropertyUtil.class.getName());
	
	private static NSDLPropertyUtil instance=null;
	
	
	public static void main(String[] args) {
		
		try {
			//new NSDLPropertyUtil().getNDSLProp();
			getInstance().getNDSLProp();
		} catch (AppBaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static synchronized NSDLPropertyUtil getInstance()
	{
		if(instance == null)
		{
			try
			{
				logger.info("Creating NSDLPropertyUtil Instance.");
				instance = new NSDLPropertyUtil();
				logger.info("Initializing NSDLPropertyUtil Instance.");
			}
			catch(Exception e)
			{
				logger.error("Error in database Instance Initialization:-"+e,new Throwable());
				e.printStackTrace();
			}
		}
		return instance;
	}
	
	
	public PropertyResourceBundle getNDSLProp() throws AppBaseException
	{
		
		InputStream oInputStream = null;
        Class objClass = null;
        PropertyResourceBundle resBund=null;
        try {
            objClass = Class.forName(
                    "com.qualtech.in.gov.uidai.auth.aua.qc.NSDLPropertyUtil");
           
        oInputStream = objClass.getResourceAsStream(
                "/com/qualtech/in/gov/uidai/auth/aua/qc/nsdlConfig.properties");
        logger.debug("Got property file /com/qualtech/in/gov/uidai/auth/aua/qc/nsdlConfig.properties");        
      
        resBund = new PropertyResourceBundle(oInputStream);
        
            logger.debug("rbbbb "+resBund);
           // System.out.println(resBund);
        } 
         
        catch (ClassNotFoundException e) {
            throw new AppBaseException("AppBaseException in getting nsdl resource bundle",e);
        } 
        catch (IOException e) {
        	 logger.error("IOException in getting error desc -->"+e);     
        	 throw new AppBaseException("IOException in getting nsdl resource bundle",e);
        }
        catch (MissingResourceException e) {
        	 throw new AppBaseException("MissingResourceException in getting nsdl resource bundle",e);
        	
        	
        }
        catch (Exception e) {
        	 logger.error("Exception in getting error desc -->"+e);     
            throw new AppBaseException(e);
        }
        
		return resBund;
	}
	

}
