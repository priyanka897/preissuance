package com.qualtech.in.gov.uidai.auth.aua.qc;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;

import com.qualtech.in.gov.uidai.auth.aua.helper.AuthRequestCreator;
import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.AuthClient;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.KYCClient;
import com.qualtech.in.gov.uidai.auth.device.helper.AuthAUADataCreator;
import com.qualtech.in.gov.uidai.auth.device.helper.Encrypter;
import com.qualtech.in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.auth.device.model.AuthResponseDetails;
import com.qualtech.in.gov.uidai.auth.device.model.SessionKeyDetails;
import com.qualtech.in.gov.uidai.authentication.common.types._1.LocationType;
import com.qualtech.in.gov.uidai.authentication.common.types._1.Meta;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.DataType;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Tkn;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Uses;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.UsesFlag;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Bios;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Demo;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pv;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.dvo.InputRequestDVO;

public class AuthRequestCaller {

	private static Logger _ologger = Logger.getLogger(AuthRequestCaller.class.getName());
	
	public static void main(String[] args) {

		try {
			new AuthRequestCaller().generateAuth(null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public String generateAuth(InputRequestDVO reqDVO) throws Exception
	{
		String authReqXML="";
		URI otpServerURI = null;
	
		ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
		_ologger.debug("bundle "+bundle);
		
		String strUrl=bundle.getString(IApplicationConstants.URL);
		String strKeyStorePwd =bundle.getString(IApplicationConstants.KEYSTOREPASSWORD);
		String strKeyStoreAlias =bundle.getString(IApplicationConstants.KEYSTOREALIAS);
		String strTermID =bundle.getString(IApplicationConstants.TERMINALID);
		String strAua =bundle.getString(IApplicationConstants.AUA);
		String strSa =bundle.getString(IApplicationConstants.SA);
		String strLickey =bundle.getString(IApplicationConstants.LICENSEKEY);
		String strAsaLickey =bundle.getString(IApplicationConstants.ASALICENSEKEY);
		String strkeyStoreFile =bundle.getString(IApplicationConstants.KEYSTOREFILEPATH);
		String strPublicKeyFile =bundle.getString(IApplicationConstants.PUBLICKEYFILENAME);
		String strAuthVersion = bundle.getString(IApplicationConstants.AUTHVERSION);
		String strPidVersion = bundle.getString(IApplicationConstants.PIDVERSION);
		
		String strUdc = bundle.getString(IApplicationConstants.UDC);
	//	String strFdc = bundle.getString(IApplicationConstants.FDC);
	//	String strIdc = bundle.getString(IApplicationConstants.IDC);
	//	String strPip = bundle.getString(IApplicationConstants.PIP);
	//	String strLov = bundle.getString(IApplicationConstants.LOV);
		
		
		try {
		
			otpServerURI = new URI(strUrl);
		
		char[] 	keyStorePassword = strKeyStorePwd.toCharArray();
		String keyStorealias=strKeyStoreAlias;
		
		//String uid="423995958384";    // ravi sir's uid
		//String uid="638808139048";
		
		String uid = reqDVO.getAadharNo();
		String otp = reqDVO.getOtp();
		//String otp="109093";
		
		String terminalId=strTermID;
		
		String aua=strAua;
		String sa=strSa;
		String licenseKey=strLickey;
		String asaLicenseKey=strAsaLickey;
		String udc=strUdc;
	/*	String fdc=strFdc;
		String idc=strIdc;
		String pip=strPip;
		String lov=strLov;
		*/
		
		Uses uses = new Uses();
		uses.setBio(UsesFlag.N);
		uses.setOtp(UsesFlag.Y);
		uses.setPa(UsesFlag.N);
		uses.setPfa(UsesFlag.N);
		uses.setPi(UsesFlag.N);
		uses.setPin(UsesFlag.N);
		
		Tkn tkn= null;
		/*
		Tkn tkn=new Tkn();
		tkn.setType("");
		tkn.setValue("");
		*/
		
		Meta meta = new Meta();
		/*meta.setUdc(udc);
		meta.setFdc(fdc);
		meta.setIdc(idc);
		meta.setPip(pip);
		//meta.setLot(LocationType.P);
		meta.setLov(lov);*/
		
		
		DataType dataType = DataType.X;
		
		//***************PID START *******************

		Pv _oPv = new Pv();
		_oPv.setOtp(otp);
		
		Pid _oPid=new Pid();
		_oPid.setVer(strPidVersion);
		_oPid.setPv(_oPv);
		/*Calendar calendar = GregorianCalendar.getInstance();
		_oPid.setTs(XMLGregorianCalendarImpl.createDateTime(
				calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND)));*/
		
		XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
		_oPid.setTs(calendar);
        
		//_oPid.setDemo(demo);        optional....
		//_oPid.setBios(new Bios());  optional....
		
		 //*************** END *******************
		
		
		
		Object pid=_oPid;
		//String publicKeyFileName = "E:\\Software\\eclipse\\workspace_10mar14\\AadhaarVerficationWebService\\src\\components\\uidai_auth_stage__preprod.cer";
		
		String publicKeyFileName = strPublicKeyFile;
		
		AuthAUADataCreator aadc = new AuthAUADataCreator(new Encrypter(publicKeyFileName),false);
		//AuthDataFromDeviceToAUA authData = aadc.prepareAUAData(uid, terminalId, meta, pid, dataType);
		
		AuthRequestCreator reqCreator = new AuthRequestCreator();
	//	Auth auth = reqCreator.createAuthRequest(aua, sa, licenseKey, uses, tkn, authData, meta  , strAuthVersion);	
		AuthClient authclient = new AuthClient(otpServerURI);
		authclient.setDigitalSignator(new DigitalSigner(strkeyStoreFile,keyStorePassword,keyStorealias));
		
		authclient.setAsaLicenseKey(asaLicenseKey);
		
		//authReqXML = authclient.authenticate(auth);
		
		
		} catch (URISyntaxException e)
		{
			e.printStackTrace();
		}
		
		catch (Exception e) 
		{
			_ologger.error("Exception in Auth request xml "+e,new Throwable());
			//throw new AppBaseException("Exception in KYC request xml "+e);
			e.printStackTrace();
		}
		
		return authReqXML;
	}
	
	
	
	
	

}
