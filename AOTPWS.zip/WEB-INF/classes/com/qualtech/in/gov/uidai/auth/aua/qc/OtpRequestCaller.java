package com.qualtech.in.gov.uidai.auth.aua.qc;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.PropertyResourceBundle;

import org.apache.log4j.Logger;

import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.exception.AppBaseException;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.aua.helper.OtpRequestCreator;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.OtpClient;
import com.qualtech.in.gov.uidai.auth.device.model.OtpDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.authentication.otp._1.Otp;

public class OtpRequestCaller {

	static Logger logger = Logger.getLogger(OtpRequestCaller.class.getName());
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		
	}
	
	/**
	 *  method to fetch OTP request XML
	 * @param reqDVO
	 * @return
	 * @throws AppBaseException
	 */
	
	public String getOTPReqXML(InputRequestDVO reqDVO) throws Exception 
	{
		logger.debug("fetching otp request xml ");
		String reqXML="";
		URI otpServerURI=null;
		PropertyResourceBundle bundle= NSDLPropertyUtil.getInstance().getNDSLProp();
		
		String strUrl=bundle.getString(IApplicationConstants.URL);
		String strKeyStorePwd =bundle.getString(IApplicationConstants.KEYSTOREPASSWORD);
		String strKeyStoreAlias =bundle.getString(IApplicationConstants.KEYSTOREALIAS);
		String strTermID =bundle.getString(IApplicationConstants.TERMINALID);
		String strAua =bundle.getString(IApplicationConstants.AUA);
		String strSa =bundle.getString(IApplicationConstants.SA);
		String strLickey =bundle.getString(IApplicationConstants.LICENSEKEY);
		String strAsaLickey =bundle.getString(IApplicationConstants.ASALICENSEKEY);
		String strkeyStoreFile =bundle.getString(IApplicationConstants.KEYSTOREFILEPATH);
		String strOtpVersion = bundle.getString(IApplicationConstants.OTPVERSION);
		
	try 
	{
		otpServerURI = new URI(strUrl);
	
		String uid  =  reqDVO.getAadharNo();
		String strOtpRecType = reqDVO.getOtpRecieveType();
		
		
		
		logger.debug("input uid for OTP XML"+uid);
		
		//char[] 	keyStorePassword = {'p','u','b','l','i','c'};
		
		char[] keyStorePassword = strKeyStorePwd.toCharArray();
		String keyStorealias=strKeyStoreAlias;
		//String uid="489312726072";
		//String uid="423995958384";   // ravi sir's uid
		String terminalId=strTermID;
		
		String aua=strAua;
		String sa=strSa;
		String licenseKey=strLickey;
		String asaLicenseKey=strAsaLickey;
	
		logger.debug("input uid for OTP XML 1"+uid);
		
	OtpDataFromDeviceToAUA auaData=new OtpDataFromDeviceToAUA(uid,terminalId,strOtpRecType);
	
	OtpRequestCreator reqCreator=new OtpRequestCreator();
	
	logger.debug("input uid for OTP XML 2"+uid);
	
	Otp otpobj = reqCreator.createOtpRequest(aua, sa, licenseKey, auaData,strOtpVersion);
	logger.debug("otp obj:::"+otpobj);
	
	OtpClient _otpClient =new OtpClient(otpServerURI);
	logger.debug("_otpClient::"+_otpClient);
	
	_otpClient.setDigitalSignator(new DigitalSigner(strkeyStoreFile,keyStorePassword,keyStorealias));
	
	logger.debug("input uid for OTP XML 3"+uid);
	
		_otpClient.setAsaLicenseKey(asaLicenseKey);
	
		reqXML = _otpClient.generateOtp(otpobj);
		logger.debug("input uid for OTP XML 4"+reqXML);
		logger.debug("input uid for OTP XML 5"+uid);
	
	}
	
	catch (URISyntaxException e) 
	{
		e.printStackTrace();
		logger.error("URISyntaxException in getting otp request xml"+e,new Throwable());
		//throw new AppBaseException("URISyntaxException in OTP request xml "+e);
		
	}	
	catch (Exception e) 
	{
		e.printStackTrace();
	logger.error("Exception in getting otp request xml"+e,new Throwable());
		
	}
	
	return reqXML;
	
}
	
	

}
