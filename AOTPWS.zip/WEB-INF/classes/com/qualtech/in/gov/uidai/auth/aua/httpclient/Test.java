package com.qualtech.in.gov.uidai.auth.aua.httpclient;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.itextpdf.text.log.SysoLogger;

public class Test {

	public static XMLGregorianCalendar getXMLGregorianCalendar(Timestamp timestamp)
     {
		GregorianCalendar gc =null;
		XMLGregorianCalendar xc=null;
try {
     gc = new GregorianCalendar();
    gc.setTimeZone(TimeZone.getTimeZone("GMT+02:00"));
    gc.setTimeInMillis(timestamp.getTime());
    
} catch (Exception ex) {
    System.out.println(ex);
}
try {
	xc= DatatypeFactory.newInstance().newXMLGregorianCalendar(gc);
} catch (DatatypeConfigurationException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
return xc;
}
	public static void main(String[] args) 
	{
		XMLGregorianCalendar calendar=null;;
		try {
			calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
     System.out.println (calendar);
	}

}
