package com.qualtech.in.gov.uidai.auth.aua.qc;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.qualtech.in.gov.uidai.auth.aua.helper.AuthRequestCreator;
import com.qualtech.in.gov.uidai.auth.aua.helper.DigitalSigner;
import com.qualtech.in.gov.uidai.auth.aua.httpclient.KYCClient;
import com.qualtech.in.gov.uidai.auth.device.helper.AuthAUADataCreator;
import com.qualtech.in.gov.uidai.auth.device.helper.Encrypter;
import com.qualtech.in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.authentication.common.types._1.LocationType;
import com.qualtech.in.gov.uidai.authentication.common.types._1.Meta;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.DataType;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Tkn;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Uses;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.UsesFlag;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Demo;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pv;
import com.qualtech.util.IApplicationConstants;
import com.qualtech.webservice.dvo.InputRequestDVO;
import com.qualtech.webservice.exception.AppBaseException;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;


public class KYCRequestCaller {
	
	private static Logger _ologger = Logger.getLogger(KYCRequestCaller.class.getName());
	boolean residentConsent =false;
	public static void main(String[] args) throws Exception {
		InputRequestDVO reqDVO = new InputRequestDVO();
		
		try {
			new KYCRequestCaller().generateKyc(reqDVO);
		} catch (AppBaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	/**
	 * 
	 * @param reqDVO
	 * @return
	 * @throws AppBaseException 
	 */
	public String generateKyc(InputRequestDVO reqDVO) throws Exception
	{
		String kycReqXML="";
		String customKYCXML="";
		URI otpServerURI=null;
		//PropertyResourceBundle bundle= NSDLPropertyUtil.getInstance().getNDSLProp();
		
		ResourceBundle bundle = ResourceBundle.getBundle("com.qualtech.in.gov.uidai.auth.aua.qc.nsdlConfig");
		
		_ologger.debug("bundle "+bundle);
		
		
		/*System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.URL));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.KEYSTOREPASSWORD));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.KEYSTOREALIAS));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.TERMINALID));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.TERMINALID));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.AUA));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.SA));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.LICENSEKEY));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.ASALICENSEKEY));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.KEYSTOREFILEPATH));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.PUBLICKEYFILENAME));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.AUTHVERSION));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.KYCVERSION));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.PIDVERSION));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.UDC));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.FDC));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.IDC));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.PIP));
		System.out.println("PID timestamp::->"+bundle.getString(IApplicationConstants.LOV));
*/		
		
		String strUrl=bundle.getString(IApplicationConstants.URL);
		String strKeyStorePwd =bundle.getString(IApplicationConstants.KEYSTOREPASSWORD);
		String strKeyStoreAlias =bundle.getString(IApplicationConstants.KEYSTOREALIAS);
		String strTermID =bundle.getString(IApplicationConstants.TERMINALID);
		String strAua =bundle.getString(IApplicationConstants.AUA);
		String strSa =bundle.getString(IApplicationConstants.SA);
		String strLickey =bundle.getString(IApplicationConstants.LICENSEKEY);
		String strAsaLickey =bundle.getString(IApplicationConstants.ASALICENSEKEY);
		String strkeyStoreFile =bundle.getString(IApplicationConstants.KEYSTOREFILEPATH);
		String strPublicKeyFile =bundle.getString(IApplicationConstants.PUBLICKEYFILENAME);
		String strAuthVersion = bundle.getString(IApplicationConstants.AUTHVERSION);
		String strKycVersion = bundle.getString(IApplicationConstants.KYCVERSION);
		String strPidVersion = bundle.getString(IApplicationConstants.PIDVERSION);
		
		String strUdc = bundle.getString(IApplicationConstants.UDC);
		String strdc = bundle.getString(IApplicationConstants.DC);
		String strDpid = bundle.getString(IApplicationConstants.DPID);
		String strRdver = bundle.getString(IApplicationConstants.RDSVER);
		String strRdsid = bundle.getString(IApplicationConstants.RDSID);
		
		
		try {
			otpServerURI = new URI(strUrl);

		char[] 	keyStorePassword = strKeyStorePwd.toCharArray();
		String keyStorealias=strKeyStoreAlias;
		
		String uid=reqDVO.getAadharNo();
		_ologger.debug("uid ::->"+uid);
		//String uid="423995958384";    // ravi sir's uid
		
		String otp=reqDVO.getOtp();
		_ologger.debug("otp ::->"+otp);
		String terminalId=strTermID;
		_ologger.debug("terminalId ::->"+terminalId);
		String aua=strAua;
		String sa=strSa;
		String licenseKey=strLickey;
		String asaLicenseKey=strAsaLickey;
		String udc=strUdc;
		String dc=strdc;
		String dpid=strDpid;
		String rdver=strRdver;
		String rdsid=strRdsid;
		
		
		boolean isRcReceived = true;
		
		Uses uses = new Uses();
		uses.setBio(UsesFlag.N);
		uses.setOtp(UsesFlag.Y);
		uses.setPa(UsesFlag.N);
		uses.setPfa(UsesFlag.N);
		uses.setPi(UsesFlag.N);
		uses.setPin(UsesFlag.N);
		uses.setBt("");
		_ologger.debug("uses ::->"+uses);
		Tkn tkn= null;
		/*
		Tkn tkn=new Tkn();
		tkn.setType("");
		tkn.setValue("");
		*/
		
		Meta meta = new Meta();
		meta.setUdc(udc);
		meta.setDc(dc);
		meta.setDpId(dpid);
		meta.setRdsId(rdsid);
		meta.setRdsVer(rdver);
		meta.setMc("");
		meta.setMi("");
	//	meta.setLot(LocationType.P);
		
		
		_ologger.debug("meta ::->"+meta);
		
		DataType dataType = DataType.X;
		
		
		//***************PID START *******************
		
		/*  can be added later based on the requirement....
		Pi pi= new Pi();
		pi.setMs(MatchingStrategy.P);
		pi.setMv(50);
		pi.setName(reqDVO.getCustomerName());
		pi.setGender(Gender.M);
		
		Pfa pfa = new Pfa();
		pfa.setMs(MatchingStrategy.P);
		pfa.setMv(50);
		pfa.setAv("S/O Ramesh Babu Sharma,431/2 ghitorni,Mehrauli,South Delhi Delhi,110030");
		*/
		
		Demo d = new Demo();
		//d.setPi(pi);
		//d.setPfa(pfa);
		
		
		Pv _oPv = new Pv();
		_oPv.setOtp(otp);
		
		_ologger.debug("_oPv ::->"+_oPv);
		
		Pid _oPid=new Pid();
		_oPid.setVer(strPidVersion);
		_oPid.setPv(_oPv);
		_oPid.setWadh("".getBytes());
		
		_ologger.debug("_oPid ::->"+_oPid);
		
		Calendar calendar = GregorianCalendar.getInstance();
		
		
		_ologger.debug("calendar timestamp::->"+calendar);
		
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.YEAR));
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.MONTH));
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.DAY_OF_MONTH));
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.HOUR_OF_DAY));
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.MINUTE));
		_ologger.debug("calendar.get(Calendar.YEAR) timestamp::->"+calendar.get(Calendar.SECOND));
		
		//_oPid.setTs("2014-02-25T20:29:55");
		
		_oPid.setTs(XMLGregorianCalendarImpl.createDateTime(
				calendar.get(Calendar.YEAR),
				calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DAY_OF_MONTH),
				calendar.get(Calendar.HOUR_OF_DAY),
				calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND)));
		
		/*XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
		_oPid.setTs(calendar);*/
		
		_ologger.debug("calendar.get(Calendar.YEAR) getTs::->"+_oPid.getTs());
		
		//_oPid.setDemo(d);       // optional....

		_ologger.debug("PID timestamp::->"+_oPid.getTs());
		
		 //*************** END *******************
		
		
		
		Object pid=_oPid;
		String publicKeyFileName = strPublicKeyFile;
		_ologger.debug("publicKeyFileName  1::->"+publicKeyFileName);
		AuthAUADataCreator aadc = new AuthAUADataCreator(new Encrypter(publicKeyFileName),false);
		_ologger.debug("aadc timestamp 1::->"+aadc);
		_ologger.debug("aadc timestamp 2::->"+aadc);
		AuthDataFromDeviceToAUA authData = aadc.prepareAUAData(uid, terminalId, meta, pid, dataType);
		_ologger.debug("authData timestamp::->"+authData);
		AuthRequestCreator reqCreator = new AuthRequestCreator();
		_ologger.debug("AuthRequestCreator reqCreator::->"+reqCreator);
		Auth auth = reqCreator.createAuthRequest(aua, sa, licenseKey, uses, tkn, authData, meta , strAuthVersion);
		
		_ologger.debug("_oPid timestamp::->"+_oPid.getTs());
		KYCClient kycclient = new KYCClient(otpServerURI);
		kycclient.setDigitalSignator(new DigitalSigner(strkeyStoreFile,keyStorePassword,keyStorealias));
		
		kycclient.setAsaLicenseKey(asaLicenseKey);
		
		kycReqXML = kycclient.getKycDetails(auth, isRcReceived, _oPid, uses ,strKycVersion );
		
		
		/*boolean mec = false;
		boolean lr = false;
		boolean de = false;
		if(reqDVO.getRc()!=null && reqDVO.getRc().equalsIgnoreCase("Y"))
		{
			residentConsent = true;
		}
		if(reqDVO.getMec()!=null && reqDVO.getMec().equalsIgnoreCase("Y"))
		{
			mec = true;
		}
		if(reqDVO.getLr()!=null && reqDVO.getLr().equalsIgnoreCase("Y"))
		{
			lr = true;
		}
		
		
		Uses usesElement = createUsesElement();*/
		//kycReqXML =kycclient.kycTrans(auth,aua,true,"",usesElement,customKYCXML,mec,lr,de,reqDVO.getFingerPrint(),strUrl,_oPid);
		
		}
		catch (URISyntaxException e) 
		{
			_ologger.error("URISyntaxException in KYC request xml "+e,new Throwable());
			//throw new AppBaseException("URISyntaxException in KYC request xml "+e);
			e.printStackTrace();
		}	
		catch (Exception e) 
		{
			_ologger.error("Exception in KYC request xml "+e,new Throwable());
			//throw new AppBaseException("Exception in KYC request xml "+e);
			e.printStackTrace();
		}
		 
		 return kycReqXML;
	}
	private Uses createUsesElement() 
	{
		_ologger.debug("in  createUsesElement"); 
		Uses uses = new Uses();
		uses.setPi(UsesFlag.Y);
		uses.setPa(UsesFlag.Y);
		uses.setPin(UsesFlag.Y);
		uses.setOtp(UsesFlag.Y);
		uses.setBio(UsesFlag.Y);
		uses.setPfa(UsesFlag.Y);
		
		String biometricTypes = "FMR";
		if(biometricTypes.length()!=0)
			biometricTypes +=  ",FIR" ;
		else
			biometricTypes +=  "FIR";
		
		if(biometricTypes.length()!=0)
			biometricTypes +=  ",IIR";
		else
			biometricTypes += "IIR";
		/*
	 	if (jCheckBoxFMR.isSelected()) {
		
			biometricTypes += "FMR";
		}
		
		if (jCheckBoxFIR.isSelected()) {
			if (StringUtils.isNotBlank(biometricTypes)) {
				biometricTypes += ",";
			}
			biometricTypes += "FIR";
		}
		
		if (jCheckBoxIIR.isSelected()) {
			if (StringUtils.isNotBlank(biometricTypes)) {
				biometricTypes += ",";
			}
			biometricTypes += "IIR";
		}
		*/
		uses.setBt(biometricTypes);
		_ologger.debug("end  createUsesElement"); 
		return uses;
	}
	

}
