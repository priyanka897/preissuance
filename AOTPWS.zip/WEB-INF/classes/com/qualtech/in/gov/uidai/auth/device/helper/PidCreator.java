/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.device.helper;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.qualtech.in.gov.uidai.auth.device.model.DeviceCollectedAuthData;
import com.qualtech.in.gov.uidai.auth.device.model.DeviceCollectedAuthData.BiometricData;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Bio;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Bios;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Demo;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Gender;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pa;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pi;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pid;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request_data._1.Pv;
import com.qualtech.webservice.service.RequestTypeValidator;


/**
 * This class provides utility method to create Pid object using data that was collected by the Auth Device
 * in the Auth Client GUI.
 * 
 * @author UIDAI
 * 
 */
public class PidCreator 
{
	private static Logger _ologger = Logger.getLogger(RequestTypeValidator.class.getName());

	public static XMLGregorianCalendar getPidTsXML() {
		return pidTsXML;
	}


	public static void setPidTsXML(XMLGregorianCalendar pidTsXML) {
		PidCreator.pidTsXML = pidTsXML;
	}


	public static Pid pidTs=null;
	private static XMLGregorianCalendar pidTsXML;
	
	public static Pid createXmlPid(DeviceCollectedAuthData data) throws DatatypeConfigurationException 
	{

		Pid pid = new Pid();
		
		if (data != null) {

			boolean isPiPresent = false, isPaPresent = false, isPfaPresent = false;

			Demo demo = new Demo();

			demo.setLang(data.getLanguage());

			if (data.getName() != null && data.getName().length()!=0
					|| data.getLname() != null && data.getLname().length()!=0
					|| data.getDob() != null && data.getDob().length()!=0
					|| data.getDobType() != null && data.getDobType().length()!=0 
					|| data.getEmail() != null && data.getEmail().length()!=0 
					|| data.getGender() != null && !data.getGender().equalsIgnoreCase("Select gender")
					|| data.getAge() != null && data.getAge().length()!=0
					|| data.getPhoneNo() != null && data.getPhoneNo().length()!=0) {
				_ologger.info("inside set pi :"+data.getName() +"|" + data.getLname() +"|" + data.getDob() +"|" + data.getDobType() +"|" + data.getEmail()+"|" + data.getGender()+"|" + data.getAge()+"|" + data.getPhoneNo());
				
				Pi pi = new Pi();
				pi.setMs(data.getNameMatchStrategy());
				pi.setMv(data.getNameMatchValue());
				pi.setName(data.getName());

				if (data.getLname() != null && data.getLname().length()!=0) {
					pi.setLmv(data.getLocalNameMatchValue());
					pi.setLname(data.getLname());
				}

				pi.setDob(data.getDob());
				pi.setDobt(data.getDobType());

				if (StringUtils.isNumeric(data.getAge())) {
					pi.setAge(new Integer(data.getAge()));
				} else {
					if (StringUtils.isNotBlank(data.getAge())) {
						throw new RuntimeException("Age should be numeric");
					}
				}

				pi.setEmail(data.getEmail());
				if (data.getGender().equalsIgnoreCase("Male")) {
					pi.setGender(Gender.M);
				} else if (data.getGender().equalsIgnoreCase("Female")) {
					pi.setGender(Gender.F);
				} else if (data.getGender().equalsIgnoreCase("Transgender")) {
					pi.setGender(Gender.T);
				} else {
					pi.setGender(null);
				}
				pi.setPhone(data.getPhoneNo());
				demo.setPi(pi);

				isPiPresent = true;
				_ologger.info("Is Pi Present :"+isPiPresent);
			}

			/*if (data.getFullAddress().length()!=0 || (data.getLocalFullAddress() != null && data.getLocalFullAddress().length()!=0)) 
			{
				Pfa pfa = new Pfa();
				_ologger.info("inside set pfa :"+data.getFullAddress()+"|"+data.getLocalFullAddress()+"|"+data.getFullAddressMatchStrategy()+"|"+data.getFullAddressMatchValue());
				pfa.setMs(data.getFullAddressMatchStrategy());
				pfa.setMv(data.getFullAddressMatchValue());
				pfa.setAv(data.getFullAddress());

				if (data.getLocalFullAddress().length()!=0) {
					pfa.setLav(data.getLocalFullAddress());
					pfa.setLmv(data.getLocalFullAddressMatchValue());
				}

				demo.setPfa(pfa);

				isPfaPresent = true;
				_ologger.info("Is Pfa Present :"+isPfaPresent);
			}*/
			// Add Pa only if one of the constituent attributes have a value
			// specified
			if (data.getCareOf() != null && data.getCareOf().length()!=0
					|| data.getDistrict() != null && data.getDistrict().length()!=0
					|| data.getBuilding() != null && data.getBuilding().length()!=0
					|| data.getLandmark() != null && data.getLandmark().length()!=0
					|| data.getLocality() != null && data.getLocality().length()!=0
					|| data.getPinCode() != null && data.getPinCode().length()!=0 
					|| data.getPoName() != null && data.getPoName().length()!=0
					|| data.getSubdistrict() != null && data.getSubdistrict().length()!=0
					|| data.getState() != null && data.getState().length()!=0
					|| data.getStreet() != null && data.getStreet().length()!=0
					|| data.getVillage() != null
					&& data.getVillage().length()!=0) {
				
				Pa pa = new Pa();
				_ologger.info("inside set pa :"+data.getCareOf()+"|" + data.getDistrict() +"|" + data.getBuilding() +"|" + data.getLandmark()+"|" + data.getLocality()+"|" + data.getPinCode()+"|" + data.getPoName()+"|" + data.getSubdistrict()+"|" + data.getState()+"|" + data.getStreet()+"|" + data.getVillage()+"|" + data.getVillage());
				pa.setMs(data.getAddressMatchStrategy());
				pa.setCo(data.getCareOf());
				pa.setDist(data.getDistrict());
				pa.setHouse(data.getBuilding());
				pa.setLm(data.getLandmark());
				pa.setLoc(data.getLocality());
				pa.setPc(data.getPinCode());
				pa.setPo(data.getPoName());
				pa.setSubdist(data.getSubdistrict());
				pa.setState(data.getState());
				pa.setStreet(data.getStreet());
				pa.setVtc(data.getVillage());
				demo.setPa(pa);

				isPaPresent = true;
				_ologger.info("Is Pa Present :"+isPaPresent);
			}

			if (isPiPresent || isPaPresent || isPfaPresent) {
				pid.setDemo(demo);
			}

			if (StringUtils.isNotBlank(data.getStaticPin()) || StringUtils.isNotBlank(data.getDynamicPin())) {
				pid.setPv(new Pv());
				pid.getPv().setPin(data.getStaticPin());
				pid.getPv().setOtp(data.getDynamicPin());
			}

			/*Calendar calendar = GregorianCalendar.getInstance();
			pid.setTs(XMLGregorianCalendarImpl.createDateTime(
					calendar.get(Calendar.YEAR),
					calendar.get(Calendar.MONTH) + 1,
					calendar.get(Calendar.DAY_OF_MONTH),
					calendar.get(Calendar.HOUR_OF_DAY),
					calendar.get(Calendar.MINUTE),
					calendar.get(Calendar.SECOND)));*/
			
			XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar((GregorianCalendar) GregorianCalendar.getInstance());
			pid.setTs(calendar);  
			_ologger.info("PID TS  timestamp::->>>> "+pid.getTs());
			

			if (data.getBiometrics() != null
					&& data.getBiometrics().size() > 0) {
				
				Bios bios = new Bios();
				pid.setBios(bios);

				for (BiometricData p : data.getBiometrics()) {
					Bio bio = new Bio();
					bio.setType(p.getType());
					bio.setValue(p.getBiometricContent());
					bio.setPosh(p.getPosition());

					pid.getBios().getBio().add(bio);
				}
			}
		}

		return pid;
	}}