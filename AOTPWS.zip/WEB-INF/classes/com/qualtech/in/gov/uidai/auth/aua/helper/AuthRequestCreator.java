/*******************************************************************************
 * DISCLAIMER: The sample code or utility or tool described herein
 *    is provided on an "as is" basis, without warranty of any kind.
 *    UIDAI does not warrant or guarantee the individual success
 *    developers may have in implementing the sample code on their
 *    environment. 
 *    
 *    UIDAI does not warrant, guarantee or make any representations
 *    of any kind with respect to the sample code and does not make
 *    any representations or warranties regarding the use, results
 *    of use, accuracy, timeliness or completeness of any data or
 *    information relating to the sample code. UIDAI disclaims all
 *    warranties, express or implied, and in particular, disclaims
 *    all warranties of merchantability, fitness for a particular
 *    purpose, and warranties related to the code, or any service
 *    or software related thereto. 
 *    
 *    UIDAI is not responsible for and shall not be liable directly
 *    or indirectly for any direct, indirect damages or costs of any
 *    type arising out of use or any action taken by you or others
 *    related to the sample code.
 *    
 *    THIS IS NOT A SUPPORTED SOFTWARE.
 ******************************************************************************/
package com.qualtech.in.gov.uidai.auth.aua.helper;

import com.qualtech.in.gov.uidai.auth.device.helper.Encrypter;
import com.qualtech.in.gov.uidai.auth.device.model.AuthDataFromDeviceToAUA;
import com.qualtech.in.gov.uidai.authentication.common.types._1.Meta;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Skey;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Tkn;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Uses;
import com.qualtech.webservice.service.RequestTypeValidator;
import com.qualtech.in.gov.uidai.authentication.uid_auth_request._1.Auth.Data;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * <code>AuthRequestCreator</code> class provides a method to generate the <code>Auth</code> object
 * using information that has been received from authentication device and from the information that
 * is available with AUA.
 *  
 * @author UIDAI
 *
 */
public class AuthRequestCreator {

	private static Logger _ologger = Logger.getLogger(AuthRequestCreator.class.getName());
	static String ekycNo="";
	/**
	 * Constructor
	 * @param aua AUA code
	 * @param saSub AUA code
	 * @param licenseKey License key
	 * @param usesElement Uses element
	 * @param token Token element, typically used for authentication requests received over mobile networks.
	 * @param auaData Data received from authentication device.
	 * @param metaData 
	 * @return Instance of {@link Auth}
	 */
	public Auth createAuthRequest(String aua, String sa, String licenseKey, Uses usesElement,
			Tkn token, AuthDataFromDeviceToAUA auaData, Meta metaData , String authVer) {
		Auth auth = new Auth();
		try {
			_ologger.info("auth"+ auth);
			_ologger.info("aua"+ aua);
			_ologger.info("auaData"+ auaData);
			_ologger.info("metaData"+ metaData);
			_ologger.info("authVer"+ authVer);
			_ologger.info("token"+ token);
			_ologger.info("sa"+ sa);
			_ologger.info("licenseKey"+ licenseKey);
			_ologger.info("uses"+ usesElement);
			
			auth.setUid(auaData.getUid());
			ekycNo=auaData.getUid();
			auth.setVer(authVer);
			auth.setAc(aua);
			auth.setSa(sa);
			auth.setRc("Y");
			_ologger.info("auth"+ auth);
			String txn = createTxn(aua);
			auth.setTxn(txn);
			_ologger.info("auth"+ auth);
			auth.setLk(licenseKey);
			auth.setTid(""); 
//			auth.setTid(auaData.getTerminalId());       comment for Auth2.0 as it need to be blank for OTP --saurabh Aug-2017
			_ologger.info("auth token"+ token);
			if (token != null) {
				auth.setTkn(token);
			}
			auth.setMeta(metaData);
			_ologger.info("auth metaData"+ metaData);
			
			Skey skey = new Skey();
			skey.setCi(auaData.getCertificateIdentifier());
			
			skey.setValue(auaData.getSessionKeyDetails().getSkeyValue());
			skey.setKi(auaData.getSessionKeyDetails().getKeyIdentifier());
			
			auth.setSkey(skey);
			_ologger.info("auth skey"+ skey);
			Data data = new Data();
			data.setType(auaData.getDataType());
			data.setValue(auaData.getEncryptedPid());
			auth.setData(data);
			_ologger.info("auth data"+ data);
			auth.setHmac(auaData.getEncrytpedHmac());
			auth.setUses(usesElement);
			_ologger.info("auth uses"+ usesElement);
			_ologger.info("auth auth"+ auth);
			
			return auth;
		} catch (Exception e) {
			e.printStackTrace();
			//throw new RuntimeException(e);
		}finally{
			try{
				return auth;
			}
			catch(Exception ex)
			{
				
				ex.printStackTrace();
				return auth;
			}
			
		}
	}

	/**
	 * Method to construct transaction code based on AUA code and current time.
	 * @param aua AUA code
	 * @return String representing transaction code.
	 */
	private static String createTxn(String aua) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddhhmmssSSS");
		String txn = "UKC" + ":";
		String otptxn=((RequestTypeValidator.Authtxno.containsKey(ekycNo))?(RequestTypeValidator.Authtxno.get(ekycNo)):txn);
		_ologger.info("OTP Fetched txnno============================================= " +otptxn );
		return (txn+otptxn);
	}

	

	

}
