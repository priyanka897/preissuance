package com.qualtech.in.gov.uidai.auth.aua.helper;
/** Description :  Standalone Program for Generating PKCS7 signature from e-Token (PKCS11 KyeStore Type)
 *  Created By  :  Masters Team
 *  Date 	    :  February 2014
 *  Team	    :  Masters Team
 *  Project     :  NSDL TIN
 *   
 */

//Import bouncy castle and java Security related Packages

import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.util.encoders.Base64;

import java.security.PrivateKey;
import java.security.Provider;
import java.security.PublicKey;
import java.security.Security;
import java.security.KeyStore;
import java.security.cert.CertStore;
import java.security.cert.CollectionCertStoreParameters;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;


//Begining the Class
public class Etoken_Sig {
	
	private static final Provider UserProvider = new sun.security.pkcs11.SunPKCS11("D:\\DevCodes\\Aadhaar Web Services\\AadhaarVerficationWebService\\src\\components\\pkcs11.cfg");
	private static final X509Certificate myPubCert = null;
	private static  KeyStore ks = null;
	private static  X509Certificate UserCert = null; 
	private static  PrivateKey UserCertPrivKey = null; 
	private static  PublicKey UserCertPubKey = null;
	private static  String alias = null;
	private static final char Password[] = "password123".toCharArray();
	//private static final char Password[] = "Div123".toCharArray();
	private static byte[] dataToSign=null;
	
	public static void main(String[] args) 
	{
		dataToSign = "Data to be Signed".getBytes();//args[0].getBytes();
		//dataToSign=args[0].getBytes();
		//loginToken();
		
		new Etoken_Sig().getPrivateKeySignature();

	}
	
	
	
	
	
	public Etoken_Sig()
	{
		
		//Adding Security Provider for PKCS 11
		Security.addProvider(UserProvider);
	
		try 
		{
			
		//Setting password for the e-Token
		

		//logging into token
		ks = KeyStore.getInstance("PKCS11", UserProvider);

		//Loading Keystore
		ks.load(null, Password);	
	
		//enumeration alias
		
		Enumeration e = ks.aliases();
		//System.out.println("11111");
		while (e.hasMoreElements()) 
		{

				alias = (String) e.nextElement();//"9f28cf52-e4ef-493d-8000-0e4279ff793e";
				//alias = "le-fc0dc2fa-5bfa-40b7-a5fd-f6192031ab99";
		
				

				//Populating UserCert
				UserCert = (X509Certificate) ks.getCertificate(alias);
			
				//Populating PublicKey
				UserCertPubKey = (PublicKey) ks.getCertificate(alias).getPublicKey();

				
					//Populating PrivateKey reference
					UserCertPrivKey = (PrivateKey) ks.getKey(alias, Password);
			
					//System.out.println("ALIAS UNKNOWN");
					//System.exit(1);
				
		
		}

		//Method Call to generate Signature
		
//		if (MakeSignature())
//		{
//			System.out.println(" *** SIGNATURE OK *** ");
//			}
//	else
//		{
//			System.out.println(" *** SIGNATURE KO *** ");
//		}
//		
		}
		
		catch (Throwable e) 
		{
			e.printStackTrace();
			System.out.println("ERROR: " + e);
		}
		

		}


		public static boolean MakeSignature() 
		{
		try {
		
		
		
		
		// PKCS7 Signature generation Starts
		ArrayList certList = new ArrayList();
			
		CertStore certs = null;

		//FileOutputStream sigfos = new FileOutputStream("E:\\Ravikant\\Test_Signature.txt");
		
		//PrivateKey privateKey=(PrivateKey) ks.getKey(alias,Password.toString().toCharArray());
		
		
		
		X509Certificate myPubCert=(X509Certificate) ks.getCertificate(alias);
		
		CMSSignedDataGenerator sgen = new CMSSignedDataGenerator();
		
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider ());
		
		sgen.addSigner(new Etoken_Sig().getPrivateKeySignature() , myPubCert,CMSSignedDataGenerator.DIGEST_SHA1);
		
		certList.add(myPubCert);
		
		certs = (CertStore.getInstance("Collection", new CollectionCertStoreParameters(certList), "BC"));
		
		sgen.addCertificatesAndCRLs(certs);
		
		CMSSignedData csd = sgen.generate(new CMSProcessableByteArray(dataToSign),true, "SunPKCS11-Aladdin_eToken");
	
		byte[] signedData = csd.getEncoded();
		
		byte[] signedData64 = Base64.encode(signedData); 
		
		//System.out.println("Signed Data : "+signedData64);
			
		/* PKCS7 Signature generation Ends */
	
		//save signature on file
//		sigfos.write(signedData64);
//		sigfos.close();

		return true;
		}
		catch (Throwable e) 
			{
			e.printStackTrace();
			System.out.println("ERROR: " + e);
			return false;
			}
		
		}
		
		
		
		public  PrivateKey getPrivateKeySignature() 
		{
			
			PrivateKey privateKey= null;
			try {
					privateKey=(PrivateKey) ks.getKey(alias,Password.toString().toCharArray());
					
					//System.out.println(privateKey);
					
					return privateKey;
			
			}
			catch (Throwable e) 
			{
				e.printStackTrace();
				System.out.println("ERROR: " + e);
				return null;
			}
		
		}
		

}
