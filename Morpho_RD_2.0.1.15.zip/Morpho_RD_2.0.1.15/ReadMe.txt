========================================================================
    RD Service Solution for Windows : 2.0.1.15
========================================================================


Pre-Requisites for Https Communication from Web Browser after Installation:

1) Set value 'CommunicationMode:0' in 'C:\MorphoRdServiceL0Soft\ConfigSettings.ini'
   file to enable Https communication in Morpho RD Service.

2) Keep the Bank/Merchant's server certificate file at 'C:\MorphoRdServiceL0Soft\' named
   as 'server.crt'. Certificate must be in pem format.

3) Keep the Bank/Merchant's server private key file at 'C:\MorphoRdServiceL0Soft\' named
   as 'server.key'. Private key must be in pem format.

4) Rename '127.0.0.1' as Bank/Merchant's URL to which certificate is issued, in the host file 
   of the windows present at 'C:\Windows\System32\drivers\etc'. Update this URL in the calling Javascript functions given in the
   MorphoRDServiceTestPage.html.

5) Restart the Morpho RD Service.

========================================================================

Installation Steps:

1) Run 'MorphoRdServiceL0SoftSetup.exe' as administrator to install the
   RD Service

2) Follow the instruction in setup wizard to complete the installation.

3) Then plug-in the Morpho Biometric Device.

4) Prompt to enter One-time-token will appear. Enter the provided token
   for RD Service to launch successfully.
   
5) In case of Device is already Whitelisted then in case of first time registration, otp window will not come instead registration should be done successfully without OTP.

========================================================================

Un-Installation Steps:

1) Run 'C:\MorphoRdServiceL0SoftSetup\unins000.exe' to uninstall the
   RD Service

2) Follow the instruction in setup wizard to complete the installation.


=======================================================================

Configuration settings according to environment :

#Staging :

 1. Change the RDEnviroment variable in ConfigSetting.ini file (PATH : C:\MorphoRdServiceL0Soft\).
    RDEnviroment:0
                
 2. Change the URLs:
    Registration       : https://Stage-rdm.smartbioplus.com/rdm-device-app/registration
    Keyrotation        : https://Stage-rdm.smartbioplus.com/rdm-key-management-app/keyRotation
    Telemetry          : https://Stage-rdm.smartbioplus.com/rdm-telemetry-app/telemetry
                
 3. Change URL_IP : Stage-rdm.smartbioplus.com

 4. Change URL_Port: 443
  
 5. Restart the service

---------------------------------------------------------------------

#Preproduction :

 1. Change the RDEnviroment variable ConfigSetting.ini file (PATH : C:\MorphoRdServiceL0Soft\).
    RDEnviroment:1
                
 2. Change the URLs:
    Registration       : https://pre-rdm.smartbioplus.com/rdm-device-app/registration
    Keyrotation        : https://pre-rdm.smartbioplus.com/rdm-key-management-app/keyRotation
    Telemetry          : https://pre-rdm.smartbioplus.com/rdm-telemetry-app/telemetry
                
 3. Change URL_IP : pre-rdm.smartbioplus.com

 4. Change URL_Port: 443

 5. Restart the service

=======================================================================